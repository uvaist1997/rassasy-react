import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import AssignedWorkForm from "../forms/AssignedWorkForm";
import CustomizedMenus from "../summary/components/CustomizedMenus";
import AssignedItem from "./components/AssignedItem";
import OverallContainer from "./components/OverallContainer";

const AssignedWorks = () => {
  const [state, setState] = useState({ data: { note: "" } });

  const [showModal, setModal] = useState(false);
  // note menu
  const [anchorEl, setAnchorEl] = useState(null);
  const [NoteEl, setNoteEl] = useState(null);
  const open = Boolean(anchorEl);
  const openNote = Boolean(NoteEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleNotePreview = (event, date, note) => {
    setNoteEl(event.currentTarget);
    setState({ ...state, note: state.data.note });
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handlePreviewClose = () => {
    setNoteEl(null);
  };
  // note menu ends
  return (
    <Container>
      <Header>
        <Heading>Assigned Works</Heading>
        <ActionContainer>
          <Division className="dropdown">
            <CustomizedMenus />
          </Division>

          <Division className="button">
            <StyledButton variant="contained" onClick={() => setModal(true)}>
              Assign Work
            </StyledButton>
          </Division>
        </ActionContainer>
      </Header>
      <AssignedItem
        type="debit"
        data={state.data}
        state={state}
        setState={setState}
      />
      <AssignedItem
        type="credit"
        data={state.data}
        state={state}
        setState={setState}
      />
      <AssignedItem
        type="credit"
        data={state.data}
        state={state}
        setState={setState}
      />
      <AssignedWorkForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

export default AssignedWorks;
const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: 0;
  }
`;
const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.dropdown {
    width: 25%;
    align-items: flex-end;
  }
  &.name {
    width: 18%;
  }
  &.select {
    width: 16%;
  }
  &.button {
    width: 70%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-end;
    width: 17%;
  }
`;
const StyledButton = styled(Button)`
  &&.pay {
    background: #fff !important;
    color: #185a6d;
    border: 1px solid;
  }
  && {
    background: #185a6d !important;
    color: #fff;
  }
`;
const ActionContainer = styled.div`
  display: flex;
  justify-content: space-between;
  width: 17%;
`;
