import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import CreateLoanForm from "../../forms/CreateLoanForm";
import PayToLoanForm from "../../forms/PayToLoanForm";
import CustomizedMenus from "../../summary/components/CustomizedMenus";

const OverallContainer = () => {
  const [showModal, setModal] = useState("");
  return (
    <Container>
      <Division className="name">
        <OverallText>Total Loan</OverallText>
        <AmountText>INR 20,700.00</AmountText>
      </Division>
      <Division className="amount">
        <DetailText className="paid">Total Paid</DetailText>
        <DetailText>INR 50000.00</DetailText>
      </Division>
      <Division className="amount">
        <DetailText className="pending">Balance</DetailText>
        <DetailText>INR 50000.00</DetailText>
      </Division>
      <Division className="dropdown">
        <CustomizedMenus />
      </Division>
      <Division className="button">
        <StyledButton
          className="pay"
          variant="contained"
          onClick={() => setModal("pay_to_loan")}
        >
          Pay To Loan
        </StyledButton>
      </Division>
      <Division className="button">
        <StyledButton
          variant="contained"
          onClick={() => setModal("add_to_loan")}
        >
          Add To Loan
        </StyledButton>
      </Division>
      <CreateLoanForm showModal={showModal} setModal={setModal} />
      <PayToLoanForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

export default OverallContainer;

const StyledButton = styled(Button)`
  &&.pay {
    background: #fff !important;
    color: #000;
    border: 1px solid;
  }
  && {
    background: #000 !important;
    color: #fff;
  }
`;
const Container = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;

const AmountText = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 0;
  margin-bottom: 4px;
`;
const PendingText = styled.span`
  font-size: 12px;
  color: #969696;
  margin-left: 10px;
`;
const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.dropdown {
    width: 20%;
    align-items: flex-end;
  }
  &.name {
    width: 18%;
  }
  &.select {
    width: 16%;
  }
  &.button {
    width: 12%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-end;
    width: 17%;
  }
`;
const DetailText = styled.div`
  text-align: right;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  &.paid {
    color: green;
    text-align: right;
  }
  &.pending {
    color: red;
    text-align: right;
  }
  span {
    font-size: 10px;
    color: #2a2a2acc;
    margin-right: 10px;
    width: 80px;
    display: inline-block;
    text-align: left;
  }
`;
const OverallText = styled.div`
  color: #2b6ec8;
`;
