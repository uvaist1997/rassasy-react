import { Button, Divider } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import CustomizedMenus from "../../summary/components/CustomizedMenus";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import Box from "@mui/material/Box";
import { FormControl, Select } from "@mui/material";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Menu from "@mui/material/Menu";

const AssignedItem = ({ type, data, state, setState, handleNotePreview }) => {
  // note menu
  const [anchorEl, setAnchorEl] = useState(null);
  const [NoteEl, setNoteEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handlePreviewClose = () => {
    setNoteEl(null);
  };
  // note menu ends
  const [attendance, setAttendance] = useState({
    note: "",
  });

  const handleSubmit = () => {
    const newData = [...state.data];
    newData[0].note = attendance.note;
    setState({
      ...state,
      data: newData,
    });
    handleClose();
    handlePreviewClose();
  };

  const handleNoteDelete = () => {
    const newData = [...state.data];
    newData[0].note = "";
    setState({
      ...state,
      data: newData,
    });
    handlePreviewClose();
  };

  const handleChange = (e) => {
    setAttendance({
      note: e.target.value,
    });
  };
  return (
    <Container>
      <DayContainer>
        <DateContainer>
          <DayText>
            28<span>September 2021, Friday</span>
          </DayText>
          {data.note ? (
            <NoteButton onClick={handleNotePreview}>{data.note}</NoteButton>
          ) : (
            <NoteButton onClick={handleClick}>
              <EditIcon fontSize="small" sx={{ color: grey[900] }} />
              Add Note
            </NoteButton>
          )}
        </DateContainer>
      </DayContainer>
      <Content>
        <ContentLabel>Title</ContentLabel>
        <ContentText>Description</ContentText>
      </Content>
      <Content>
        <ContentLabel>Amount</ContentLabel>
        <ContentText>amount</ContentText>
      </Content>
      <Content>
        <ContentLabel>Deadline</ContentLabel>
        <ContentText>30 September 2021</ContentText>
      </Content>
      <AmountContainer>
        <BasicSelect />
      </AmountContainer>
      <AmountContainer>
        <MenuList />
      </AmountContainer>
      <LongMenu
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
      />
    </Container>
  );
};

export default AssignedItem;

const Content = styled.div`
  width: 20%;
`;
const ContentLabel = styled.div``;
const ContentText = styled.div`
  color: #666666;
`;

const AmountText = styled.div`
  font-weight: bold;
  span {
    margin-right: 5px;
    color: #185a6d;
  }
`;
const Label = styled.p`
  margin: 0;
  color: #767676;
  margin-right: 5px;
`;
const DateContainer = styled.div``;

const RoundArrow = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #6fc756;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 15px;
  ${({ type }) =>
    type === "credit" &&
    `
  
  background: #e55e5e;
  `}
`;

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  transition: all 0.1s ease-in;
  margin-bottom: 10px;
  &:hover {
    background: #f8d5d5;
    transition: all 0.1s ease-in;
  }
`;
const DayText = styled.div`
  font-size: 20px;
  font-weight: bold;

  span {
    color: #767676;
    font-size: 16px;
    margin-left: 10px;
    font-weight: normal;
  }
`;
const DayContainer = styled.div`
  display: flex;
  align-items: center;
  width: 37%;
`;
const NoteButton = styled.button`
  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
`;
const AmountContainer = styled.div`
  width: 22%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
`;
const PresentType = styled(Button)`
  && {
    text-transform: capitalize;
    color: #000;
    background: #fff;
    border: 1px solid #000;
    padding: 5px 20px;
  }
  &&.present:hover {
    background: #25976a;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.half-day:hover {
    background: #f76f00;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.absent:hover {
    background: #f74344;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.late:hover {
    background: #f59300;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.overtime:hover {
    background: #3ccfc1;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.paid-leave:hover {
    background: #3389e1;
    color: #fff;
    border: 1px solid transparent;
  }
`;

function BasicSelect() {
  const [work, setWork] = React.useState("");

  const handleChange = (event) => {
    setWork(event.target.value);
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;

      ${({ work }) =>
        work === "cancelled" && `background: #f74344; color:#fff;`}
      ${({ work }) => work === "progress" && `background: #2c7ac5; color:#fff;`}
           ${({ work }) =>
        work === "done" && `background: #25976a; color:#fff;`}
      min-width: min-content;
    }
    span {
      margin: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 200 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"progress"} className="progress">
              In Progress
            </MenuItem>
            <MenuItem value={"done"} className="done">
              Done
            </MenuItem>
            <MenuItem value={"cancelled"} className="cancelled">
              Cancelled
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

// option

function MenuList() {
  const ITEM_HEIGHT = 48;
  const options = ["Edit", "Delete"];
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "9ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            selected={option === "Pyxis"}
            onClick={handleClose}
          >
            {option}
          </MenuItem>
        ))}
      </Menu>
    </div>
  );
}

// note
const options = ["Edit", "Delete"];

const ITEM_HEIGHT = 48;

function LongMenu({ anchorEl, setAnchorEl, open, handleClick, handleClose }) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: 4,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea name="name" type="textarea"></TextArea>
        <Divider />
        <NoteSubmitButton>Add Note</NoteSubmitButton>
      </StyledMenu>
    </div>
  );
}
// options ends
const TextArea = styled.textarea`
  padding: 7px;
  border-radius: 10px;
  /* border: 2px solid transparent; */
  border: 0;
  /* outline: 1px solid #ccc !important; */
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 150px;
  min-height: 100px;
  box-sizing: border-box;
  /* &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  } */
  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledMenu = styled(Menu)`
  && ul {
    display: flex;
    flex-direction: column;
    padding: 0;
  }
`;
const NoteSubmitButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
  }
`;
