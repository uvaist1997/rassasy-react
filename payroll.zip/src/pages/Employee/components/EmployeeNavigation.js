import { ButtonBase } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import BonusForm from "../forms/BonusForm";
import DeductionForm from "../forms/DeductionForm";

const EmployeeNavigation = ({ activeMenu, setMenu }) => {
  const [showModal, setModal] = useState("");
  return (
    <Container>
      <MenuContainer>
        <StyledButtonBase className={activeMenu === "summary" && "active"}>
          <Menus onClick={() => setMenu("summary")}>Summary</Menus>
        </StyledButtonBase>
        <StyledButtonBase className={activeMenu === "attendance" && "active"}>
          <Menus onClick={() => setMenu("attendance")}>Attendance</Menus>
        </StyledButtonBase>
        <StyledButtonBase
          className={activeMenu === "assigned-works" && "active"}
        >
          <Menus onClick={() => setMenu("assigned-works")}>
            Assigned Works
          </Menus>
        </StyledButtonBase>
        <StyledButtonBase className={activeMenu === "payment" && "active"}>
          <Menus onClick={() => setMenu("payment")}>Payment</Menus>
        </StyledButtonBase>
        <StyledButtonBase className={activeMenu === "bonus" && "active"}>
          <Menus onClick={() => setModal("bonus")}>Bonus</Menus>
        </StyledButtonBase>
        <StyledButtonBase className={activeMenu === "deduction" && "active"}>
          <Menus onClick={() => setModal("deduction")}>Deduction</Menus>
        </StyledButtonBase>
        <StyledButtonBase className={activeMenu === "loan" && "active"}>
          <Menus onClick={() => setMenu("loan")}>Loan</Menus>
        </StyledButtonBase>
      </MenuContainer>
      <BonusForm setModal={setModal} showModal={showModal} />
      <DeductionForm setModal={setModal} showModal={showModal} />
    </Container>
  );
};
export default EmployeeNavigation;

const Container = styled.div``;
const MenuContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 10px 0;
  border: 1px solid #f6f6f6;
  padding: 5px;
  border-radius: 5px;
`;
const StyledButtonBase = styled(ButtonBase)`
  && {
    width: 16%;
    background: #f6f6f6;
    text-align: center;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.1s ease-in;
    &&.active,
    &&:hover {
      background: #000;
      color: #fff;
      transition: all 0.1s ease-in;
    }
  }
`;
const Menus = styled.div`
  padding: 15px;
  width: 100%;
  margin: auto;
`;
