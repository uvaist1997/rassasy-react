import React from "react";
import styled from "styled-components";
import MenuItem from "@mui/material/MenuItem";
import { FormControl, Select } from "@mui/material";
import Box from "@mui/material/Box";

const BasicSelect = ({ options }) => {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const Container = styled.div`
    div[role="button"] {
      background: #fff;
    }
    span {
      margin: 0;
    }
  `;

  return (
    <Container>
      <Box sx={{ minWidth: 60, width: 200 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={age}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            {options.map((i, index) => (
              <MenuItem key={index} value={index} onClick={i.action}>
                {i.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
};

export default BasicSelect;
