import React, { useState } from "react";
import styled from "styled-components";
import Button from "@mui/material/Button";
import SelectLabels from "./SelectLabels";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Fade from "@mui/material/Fade";

const DetailsBox = () => {
  const Container = styled.div`
    background: #ddf1f5;
    padding: 10px 20px;
    border-radius: 10px;
    display: flex;
    justify-content: space-between;
  `;
  const Heading = styled.p`
    color: #5447a0;
    font-weight: bold;
    margin: 0;
    margin-bottom: 4px;
  `;
  const NameText = styled.p`
    font-size: 24px;
    font-weight: bold;
    margin: 0;
    margin-bottom: 4px;
  `;
  const PendingText = styled.span`
    font-size: 12px;
    color: #969696;
    margin-left: 10px;
  `;
  const Division = styled.div`
    width: 17%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    &.name {
      width: 18%;
    }
    &.button {
      width: 10%;
      button {
        background: #185a6d;
        font-family: "Poppins";
        text-transform: capitalize;
      }
    }
  `;
  const DetailText = styled.div`
    text-align: right;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    span {
      font-size: 12px;
      color: #2a2a2acc;
      margin-right: 10px;
      width: 100px;
      display: inline-block;
      text-align: left;
    }
  `;

  return (
    <Container>
      <Division className="name">
        <NameText>Savad farooque</NameText>
        <SelectLabels />
      </Division>
      <Division>
        <DetailText>
          <span>Phone No:</span>8838403975
        </DetailText>
        <DetailText>
          <span>From:</span>DD/MM/YYYY
        </DetailText>
      </Division>
      <Division>
        <DetailText>
          <span>Staff Type:</span>Monthly
        </DetailText>
        <DetailText>
          <span>Monthly Salary:</span>INR 50000.00
        </DetailText>
      </Division>
      <Division className="button">
        <BasicSelect />
      </Division>
      <Division className="button">
        <Button variant="contained">Edit Info</Button>
      </Division>
    </Container>
  );
};

export default DetailsBox;

function BasicSelect() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Salary Slip
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>Download PDF</MenuItem>
        <MenuItem onClick={handleClose}>Share Via Mail</MenuItem>
        <MenuItem onClick={handleClose}>Print Now</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    border: 1px solid #000;
    text-transform: capitalize;
    color: #000;
    background: #fff !important;
  }
  && svg {
    color: #000;
  }
`;
