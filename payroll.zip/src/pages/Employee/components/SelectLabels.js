import React, { useState } from "react";
import styled from "styled-components";
import MenuItem from "@mui/material/MenuItem";
import { FormControl, Select } from "@mui/material";
import ResignForm from "../forms/ResignForm";

const SelectLabels = () => {
  const [showModal, setModal] = useState(false);

  const [age, setAge] = useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const StyledSelect = styled.div`
    width: 100px;
    & .MuiFormControl-root {
      margin: 0 !important;
      border: 0;
    }
    fieldset {
      border: 0;
    }
    div[role="button"] {
      display: flex;
      align-items: center;
    }
  `;
  const ColorDot = styled.div`
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #24a605;
    margin-right: 5px;
    &.resigned {
      background: #e31c05;
    }
    &.leave {
      background: #e17407;
    }
  `;
  return (
    <StyledSelect>
      <FormControl>
        <Select
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value="">
            <ColorDot className="active"></ColorDot>
            Active
          </MenuItem>

          <MenuItem value={10}>
            <ColorDot className="leave"></ColorDot>
            Leave
          </MenuItem>

          <MenuItem value={20} onClick={() => setModal(true)}>
            <ColorDot className="resigned"></ColorDot>
            Resigned
          </MenuItem>
        </Select>
      </FormControl>
      <ResignForm showModal={showModal} setModal={setModal} />
    </StyledSelect>
  );
};

export default SelectLabels;
