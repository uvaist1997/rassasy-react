import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import CustomizedMenus from "../summary/components/CustomizedMenus";
import LoanItem from "./components/LoanItem";
import OverallContainer from "./components/OverallContainer";

const Loan = () => {
  return (
    <Container>
      <Heading>Loan</Heading>
      <OverallContainer />
      <LoanItem type="debit" />
      <LoanItem type="credit" />
      <LoanItem type="credit" />
    </Container>
  );
};

export default Loan;
const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
