import React, { useState } from "react";
import styled from "styled-components";

import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Tooltip,
  Typography,
} from "@mui/material";

import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

const SimpleAccordion = () => {
  const [expand, setExpand] = useState(0);
  const requestDate = [
    {
      id: 1,
      heading: "Net Salary",
      amount: "22800.00",
      dateRange: "1 October 2021 - 1 October 2021",
    },
    {
      id: 2,
      heading: "Advance",
      amount: "22800.00",
      dateRange: "",
    },
    {
      id: 3,
      heading: "Deduction",
      amount: "22800.00",
      dateRange: "",
    },
    {
      id: 4,
      heading: "Bonus",
      amount: "22800.00",
      dateRange: "",
    },
    {
      id: 5,
      heading: "Loan Payment",
      amount: "22800.00",
      dateRange: "",
    },
  ];
  return (
    <AccordianContainer>
      <Accordion expanded={expand === 1}>
        <AccordionSummary
          expandIcon={
            <Tooltip title={expand === 1 ? "Shrink" : "Expand"}>
              <ExpandMoreIcon onClick={() => setExpand(expand === 1 ? 0 : 1)} />
            </Tooltip>
          }
          aria-controls="panel1a-content"
        >
          <Typography width={"100%"}>
            <EntityDetailsContainer>
              <HeadingContainer>
                <Label>Net Salary</Label>
                <DateRangeText>1 October 2021 - 1 October 2021</DateRangeText>
              </HeadingContainer>
              <Label>
                <span>INR</span>
                22800.00
              </Label>
            </EntityDetailsContainer>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <EntityDetailsBottomContainer>
              <EntityDetailsContainer>
                <ReasonHeadingText>Monthly Salary</ReasonHeadingText>
                <Label>
                  <span>INR</span>
                  22800.00
                </Label>
              </EntityDetailsContainer>
              <EditButton>Edit Salary</EditButton>
            </EntityDetailsBottomContainer>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expand === 2}>
        <AccordionSummary
          expandIcon={
            <Tooltip title={expand === 2 ? "Shrink" : "Expand"}>
              <ExpandMoreIcon onClick={() => setExpand(expand === 2 ? 0 : 2)} />
            </Tooltip>
          }
          aria-controls="panel1a-content"
        >
          <Typography width={"100%"}>
            <EntityDetailsContainer>
              <HeadingContainer>
                <Label>Advance</Label>
              </HeadingContainer>
              <Label>
                <span>INR</span>
                22800.00
              </Label>
            </EntityDetailsContainer>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <ReasonHeadingText>Monthly Salary</ReasonHeadingText>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expand === 3}>
        <AccordionSummary
          expandIcon={
            <Tooltip title={expand === 3 ? "Shrink" : "Expand"}>
              <ExpandMoreIcon onClick={() => setExpand(expand === 3 ? 0 : 3)} />
            </Tooltip>
          }
          aria-controls="panel1a-content"
        >
          <Typography width={"100%"}>
            <EntityDetailsContainer>
              <HeadingContainer>
                <Label>Deduction</Label>
              </HeadingContainer>
              <Label>
                <span>INR</span>
                22800.00
              </Label>
            </EntityDetailsContainer>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <ReasonHeadingText>Monthly Salary</ReasonHeadingText>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expand === 4}>
        <AccordionSummary
          expandIcon={
            <Tooltip title={expand === 4 ? "Shrink" : "Expand"}>
              <ExpandMoreIcon onClick={() => setExpand(expand === 4 ? 0 : 4)} />
            </Tooltip>
          }
          aria-controls="panel1a-content"
        >
          <Typography width={"100%"}>
            <EntityDetailsContainer>
              <HeadingContainer>
                <Label>Bonus</Label>
              </HeadingContainer>
              <Label>
                <span>INR</span>
                22800.00
              </Label>
            </EntityDetailsContainer>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <ReasonHeadingText>Monthly Salary</ReasonHeadingText>
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion expanded={expand === 5}>
        <AccordionSummary
          expandIcon={
            <Tooltip title={expand === 5 ? "Shrink" : "Expand"}>
              <ExpandMoreIcon onClick={() => setExpand(expand === 5 ? 0 : 5)} />
            </Tooltip>
          }
          aria-controls="panel1a-content"
        >
          <Typography width={"100%"}>
            <EntityDetailsContainer>
              <HeadingContainer>
                <Label>Loan Payment</Label>
              </HeadingContainer>
              <Label>
                <span>INR</span>
                22800.00
              </Label>
            </EntityDetailsContainer>
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            <ReasonHeadingText>Monthly Salary</ReasonHeadingText>
          </Typography>
        </AccordionDetails>
      </Accordion>
    </AccordianContainer>
  );
};
const EntityDetailsBottomContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const EditButton = styled.button`
  border: 0;
  cursor: pointer;
  background: transparent;
  color: #2756c5;
  font-weight: bold;
`;
const DateRangeText = styled.p`
  margin: 0;
  color: #8b8b8b;
  font-size: 14px;
  margin-left: 15px;
`;
const HeadingContainer = styled.div`
  display: flex;
`;
const ReasonHeadingText = styled.p`
  margin: 0;
  font-size: 16px;
  font-weight: bold;
  margin-right: 15px;
`;
const ReasonText = styled.p`
  margin: 0;
  margin-bottom: 3px;
  font-size: 12px;
`;
const EntityDetailsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const EntityDetails = styled.div``;
const EntityNameText = styled.p`
  margin: 0;
  font-weight: bold;
  font-size: 12px;
`;
const EntityDateDetails = styled.div`
  display: flex;
`;
const OnText = styled.p`
  margin: 0;
  margin-right: 5px;
  font-size: 10px;
  color: #1f920a;
`;
const FullDateText = styled.p`
  margin: 0;
  font-size: 10px;
`;

const Label = styled.div`
  display: flex;
  align-items: center;
  margin-right: 10px;
  font-weight: bold;
  margin-right: 10px;
  display: block;
  span {
    margin-right: 10px;
    color: #949494;
  }
`;
const DateText = styled.p`
  margin: 0;
  margin-right: 10px;
  font-weight: bold;
  font-size: 20px;
`;
const MonthContainer = styled.div``;
const MonthText = styled.p`
  margin: 0;
  font-size: 10px;
  color: #7d7d7d;
`;
const DayText = styled.p`
  margin: 0;
  font-size: 10px;
`;

// accordian ends
const AccordianContainer = styled.div`
  margin: 10px 0;
  & .MuiButtonBase-root.MuiAccordionSummary-root {
    margin-bottom: 10px;
    border-radius: 5px;
  }
  & .MuiButtonBase-root.MuiAccordionSummary-root.Mui-expanded {
    background: #fbfbfb;
  }
  & .MuiButtonBase-root.MuiAccordionSummary-root,
  & .MuiButtonBase-root.MuiAccordionSummary-root {
    background: #fbfbfb;
    border-radius: 5px;
  }
  overflow-x: scroll;
  &::-webkit-scrollbar {
    display: none;
    scrollbar-width: none;
  }
  height: 410px;
`;

export default SimpleAccordion;
