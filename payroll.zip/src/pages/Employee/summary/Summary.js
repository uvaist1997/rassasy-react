import React, { useState } from "react";
import styled from "styled-components";
import Button from "@mui/material/Button";
import CustomizedMenus from "./components/CustomizedMenus";
import SimpleAccordion from "./components/SimpleAccordion";
import TransitionsModal from "./../forms/PayForm";
import AdvanceForm from "../forms/AdvanceForm";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Fade from "@mui/material/Fade";

const Summary = () => {
  const [showModal, setModal] = useState({ show: false, type: "" });
  return (
    <Container>
      <Heading>Salary Summary</Heading>
      <OverallContainer>
        <Division className="name">
          <OverallText>Overall Payment</OverallText>
          <AmountText>INR 20,700.00</AmountText>
        </Division>
        <Division className="amount">
          <DetailText className="paid">Paid</DetailText>
          <DetailText>INR 50000.00</DetailText>
        </Division>
        <Division className="amount">
          <DetailText className="pending">Pending</DetailText>
          <DetailText>INR 50000.00</DetailText>
        </Division>
        <Division className="button">
          <CustomizedMenus />
        </Division>
        <Division className="button">
          <Button
            variant="contained"
            onClick={() => setModal({ show: true, type: "advance" })}
          >
            Advance
          </Button>
        </Division>
        <Division className="select">
          <BasicSelect
            options={["Pay Online", "Pay By Check", "Pay In Cash"]}
            options={[
              {
                name: "Pay Online",
                action: () => setModal({ show: true, type: "payonline" }),
              },
              {
                name: "Pay By Check",
                action: () => setModal({ show: true, type: "paybycheck" }),
              },
              {
                name: "Pay In Cash",
                action: () => setModal({ show: true, type: "payincash" }),
              },
            ]}
          />
        </Division>
      </OverallContainer>
      <SimpleAccordion />
      <TransitionsModal showModal={showModal} setModal={setModal} />
      <AdvanceForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
const OverallContainer = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
`;

const AmountText = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 0;
  margin-bottom: 4px;
`;
const PendingText = styled.span`
  font-size: 12px;
  color: #969696;
  margin-left: 10px;
`;
const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.name {
    width: 18%;
  }
  &.select {
    width: 16%;
  }
  &.button {
    width: 10%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-end;
    width: 17%;
  }
`;
const DetailText = styled.div`
  text-align: right;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  &.paid {
    color: green;
    text-align: right;
  }
  &.pending {
    color: red;
    text-align: right;
  }
  span {
    font-size: 10px;
    color: #2a2a2acc;
    margin-right: 10px;
    width: 80px;
    display: inline-block;
    text-align: left;
  }
`;
const OverallText = styled.div`
  color: #6d6d6d;
`;

export default Summary;

function BasicSelect() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Payment
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
        // PaperProps={{
        //   style: {
        //     width: "10.5ch",
        //   },}}
      >
        <MenuItem onClick={handleClose}>Pay Online</MenuItem>
        <MenuItem onClick={handleClose}>Pay By Check</MenuItem>
        <MenuItem onClick={handleClose}>Pay In Cash</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    border: 1px solid #000;
    text-transform: capitalize;
    color: #000;
    background: #fff;
  }
  && svg {
    color: #000;
  }
`;
