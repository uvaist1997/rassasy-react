import React, { useEffect, useState } from "react";
import styled from "styled-components";
import { styled as styles, alpha } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import EditIcon from "@mui/icons-material/Edit";
import Divider from "@mui/material/Divider";
import ArchiveIcon from "@mui/icons-material/Archive";
import SearchIcon from "@mui/icons-material/Search";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import CircularProgress from "@mui/material/CircularProgress";
import CalandarRange from "../../components/CalandarNav/CalandarRange";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import { grey } from "@mui/material/colors";
import { FormControl, Select } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { Link, Navigate, useNavigate } from "react-router-dom";
import Fade from "@mui/material/Fade";
import DeletePrompt from "../../components/Delete/DeletePrompt";

const Employees = () => {
  const [showDelete, setDelete] = useState();
  const Container = styled.div``;
  const handleSearchChange = (e, v, n) => {
    console.log(e);
    console.log(v);
    console.log(n);
  };
  const handleSearchInputChange = (e, v, n) => {
    console.log(e);
    console.log(v);
    console.log(n);
  };
  return (
    <Container>
      <Header />
      <OverallPayment />
      <ActionGroup
        handleSearchChange={handleSearchChange}
        handleSearchInputChange={handleSearchInputChange}
      />
      <CheckBoxGroup />
      <MonthlyTable setDelete={setDelete} />
      <MonthlyTable Heading={"Hourly"} setDelete={setDelete} />
      <MonthlyTable Heading={"Work Base"} setDelete={setDelete} />
      <DeletePrompt show={showDelete} setShow={setDelete} />
    </Container>
  );
};

export default Employees;

// header
const Header = () => {
  const Container = styled.div`
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
  `;
  const Heading = styled.div`
    font-weight: bold;
    font-size: 24px;
  `;

  return (
    <Container>
      <Heading>Employee Summary</Heading>
      <CustomizedMenus />
    </Container>
  );
};
// header ends

// customized menu
const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 160,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

function CustomizedMenus() {
  const navigate = useNavigate();
  // const StyledButton = styled(Button)`
  //   & button {
  //     background: #5447a0 !important;
  //     color: #fff;
  //     border: 0;
  //     padding: 8px 10px;
  //     border-radius: 50px;
  //     cursor: pointer;
  //     transition: all 0.2s ease-in;
  //   }
  //   button:hover {
  //     opacity: 0.8;
  //     transition: all 0.2s ease-in;
  //   }
  // `;
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <ButtonContainer>
        <StyledButton
          id="demo-customized-button"
          aria-controls={open ? "demo-customized-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
          variant="contained"
          disableElevation
          onClick={() => navigate("/dashboard/add-employee")}
          // endIcon={}
        >
          + Add Employee
        </StyledButton>
        <StyledKeyboardArrowDownIcon onClick={handleClick} />
      </ButtonContainer>
      <StyledMenu
        id="demo-customized-menu"
        MenuListProps={{
          "aria-labelledby": "demo-customized-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
      >
        <MenuItem onClick={handleClose} disableRipple>
          <FileCopyIcon />
          Bul Excel Add
        </MenuItem>
      </StyledMenu>
    </div>
  );
}
const StyledKeyboardArrowDownIcon = styled(KeyboardArrowDownIcon)`
  position: absolute;
  top: 0;
  right: 5px;
  bottom: 0;
  margin: auto;
  color: #fff;
`;
const ButtonContainer = styled.div`
  position: relative;
`;

const StyledButton = styled(Button)`
  && {
    background: #5447a0 !important;
    border-radius: 50px;
    padding-right: 35px;
  }
  span {
    position: relative;
    z-index: 100;
  }
`;
// customized menu ends

// overall payments
const OverallPayment = () => {
  const Container = styled.div`
    background: #eceff9;
    padding: 10px;
    border-radius: 10px;
  `;
  const Heading = styled.p`
    color: #5447a0;
    font-weight: bold;
    margin: 0;
    margin-bottom: 4px;
  `;
  const AmountText = styled.p`
    font-size: 24px;
    font-weight: bold;
    margin: 0;
    margin-bottom: 4px;
  `;
  const PendingText = styled.span`
    font-size: 12px;
    color: #969696;
    margin-left: 10px;
  `;

  return (
    <Container>
      <Heading>Overall Payment</Heading>
      <AmountText>
        INR 112000.00<PendingText>Total Pending</PendingText>
      </AmountText>
    </Container>
  );
};
// overall payments ends
// action group

const ActionGroup = ({ handleSearchChange, handleSearchInputChange }) => {
  const Container = styled.div`
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
  `;
  const SearchContainer = styled.div`
    width: 90%;
  `;
  const CalendarContainer = styled.div`
    width: 40%;
  `;
  return (
    <Container>
      <SearchContainer>
        <SearchButton
          handleSearchChange={handleSearchChange}
          handleSearchInputChange={handleSearchInputChange}
        />
      </SearchContainer>
      <CalendarContainer>
        <CalandarRange />
      </CalendarContainer>
    </Container>
  );
};

function sleep(delay = 0) {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
}

function SearchButton({ handleSearchChange, handleSearchInputChange }) {
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const loading = open && options.length === 0;

  useEffect(() => {
    let active = true;

    if (!loading) {
      return undefined;
    }

    (async () => {
      await sleep(1e3); // For demo purposes.

      if (active) {
        setOptions([...topFilms]);
      }
    })();

    return () => {
      active = false;
    };
  }, [loading]);

  useEffect(() => {
    if (!open) {
      setOptions([]);
    }
  }, [open]);

  return (
    <SearchContainer>
      <Autocomplete
        popupIcon={""}
        size="small"
        id="asynchronous-demo"
        sx={{ width: "100%" }}
        open={open}
        onOpen={() => {
          setOpen(true);
        }}
        onClose={() => {
          setOpen(false);
        }}
        isOptionEqualToValue={(option, value) => option.title === value.title}
        getOptionLabel={(option) => option.title}
        onChange={handleSearchChange}
        onInputChange={handleSearchInputChange}
        options={options}
        loading={loading}
        renderInput={(params) => (
          <TextField
            placeholder="Search Staff"
            {...params}
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <React.Fragment>
                  {loading ? (
                    <CircularProgress color="inherit" size={20} />
                  ) : null}
                  {params.InputProps.endAdornment}
                </React.Fragment>
              ),
              startAdornment: (
                <React.Fragment>
                  <SearchIcon style={{ cursor: "pointer" }} />
                </React.Fragment>
              ),
            }}
          />
        )}
      />
    </SearchContainer>
  );
}
const SearchContainer = styled.div`
  & .MuiOutlinedInput-root.MuiInputBase-sizeSmall {
    background: #f9f9f9;
    border-radius: 10px;
  }
`;

// Top films as rated by IMDb users. http://www.imdb.com/chart/top
const topFilms = [
  { title: "The Shawshank Redemption", year: 1994 },
  { title: "The Godfather", year: 1972 },
  { title: "The Godfather: Part II", year: 1974 },
  { title: "The Dark Knight", year: 2008 },
  { title: "12 Angry Men", year: 1957 },
  { title: "Schindler's List", year: 1993 },
  { title: "Pulp Fiction", year: 1994 },
  {
    title: "The Lord of the Rings: The Return of the King",
    year: 2003,
  },
  { title: "The Good, the Bad and the Ugly", year: 1966 },
  { title: "Fight Club", year: 1999 },
  {
    title: "The Lord of the Rings: The Fellowship of the Ring",
    year: 2001,
  },
  {
    title: "Star Wars: Episode V - The Empire Strikes Back",
    year: 1980,
  },
  { title: "Forrest Gump", year: 1994 },
  { title: "Inception", year: 2010 },
  {
    title: "The Lord of the Rings: The Two Towers",
    year: 2002,
  },
  { title: "One Flew Over the Cuckoo's Nest", year: 1975 },
  { title: "Goodfellas", year: 1990 },
  { title: "The Matrix", year: 1999 },
  { title: "Seven Samurai", year: 1954 },
  {
    title: "Star Wars: Episode IV - A New Hope",
    year: 1977,
  },
  { title: "City of God", year: 2002 },
  { title: "Se7en", year: 1995 },
  { title: "The Silence of the Lambs", year: 1991 },
  { title: "It's a Wonderful Life", year: 1946 },
  { title: "Life Is Beautiful", year: 1997 },
  { title: "The Usual Suspects", year: 1995 },
  { title: "Léon: The Professional", year: 1994 },
  { title: "Spirited Away", year: 2001 },
  { title: "Saving Private Ryan", year: 1998 },
  { title: "Once Upon a Time in the West", year: 1968 },
  { title: "American History X", year: 1998 },
  { title: "Interstellar", year: 2014 },
];
// action group ends

// checkbox group
const CheckBoxGroup = () => {
  const Container = styled.div`
    display: flex;
    justify-content: space-between;
    margin: 10px 0;
  `;
  const MonthText = styled.div`
    font-weight: bold;
    display: flex;
    align-items: flex-end;
  `;
  const CheckBoxContainer = styled.div`
    display: flex;
  `;
  return (
    <Container>
      <MonthText>Monthly</MonthText>
      <CheckBoxContainer>
        <CheckboxLabels />
        <SelectLabels />
      </CheckBoxContainer>
    </Container>
  );
};

// selectbox
// menubutton
function SelectLabels() {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <StyledSelect>
      <FormControl>
        <Select
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </StyledSelect>
  );
}
const StyledSelect = styled.div`
  width: 100px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
// menubutton
// selectboxends

function CheckboxLabels() {
  return (
    <FormGroup style={{ flexDirection: "row" }}>
      <FormControlLabel
        control={
          <Checkbox
            size="small"
            sx={{
              color: grey[900],
              "&.Mui-checked": {
                color: grey[900],
              },
            }}
            defaultChecked
          />
        }
        label="Active"
      />
      <FormControlLabel
        control={
          <Checkbox
            size="small"
            sx={{
              color: grey[900],
              "&.Mui-checked": {
                color: grey[900],
              },
            }}
            defaultChecked
          />
        }
        label="In leave"
      />
      <FormControlLabel
        control={
          <Checkbox
            size="small"
            sx={{
              color: grey[900],
              "&.Mui-checked": {
                color: grey[900],
              },
            }}
            defaultChecked
          />
        }
        label="Resigned"
      />
    </FormGroup>
  );
}
// checkbox groups ends here

// monthly table
const MonthlyTable = ({ Heading, setDelete }) => {
  function BasicSelect() {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };

    return (
      <div>
        <StyledSelectButton
          id="fade-button"
          aria-controls={open ? "fade-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
          onClick={handleClick}
          endIcon={<KeyboardArrowDownIcon />}
        >
          Payment
        </StyledSelectButton>
        <Menu
          id="fade-menu"
          MenuListProps={{
            "aria-labelledby": "fade-button",
          }}
          anchorEl={anchorEl}
          open={open}
          onClose={handleClose}
          TransitionComponent={Fade}
          PaperProps={{
            style: {
              maxHeight: ITEM_HEIGHT * 4.5,
              width: "12ch",
            },
          }}
        >
          <MenuItem onClick={handleClose}>Pay Online</MenuItem>
          <MenuItem onClick={handleClose}>Pay By Check</MenuItem>
          <MenuItem onClick={handleClose}>Pay In Cash</MenuItem>
        </Menu>
      </div>
    );
  }
  const StyledSelectButton = styled(Button)`
    && {
      border: 1px solid #000;
      text-transform: capitalize;
      color: #000;
      background: #fff;
    }
    && svg {
      color: #000;
    }
  `;

  const Container = styled.div`
    table {
      width: 100%;
      border-spacing: 0 10px;
    }
    tr {
      background: #f9f9f9;
      border: 1px solid #ccc;
      border-radius: 10px;
      padding-bottom: 5px;
    }
    td {
      padding: 5px 10px;
      border-top: 1px solid #ccc;
      border-bottom: 1px solid #ccc;
    }
    span {
      font-size: 10px;
      color: #767676;
      margin-right: 10px;
    }
    table tr td:first-child {
      border-bottom-left-radius: 10px;
      border-top-left-radius: 10px;
      border-left: 1px solid #ccc;
    }

    table tr td:last-child {
      border-bottom-right-radius: 10px;
      border-top-right-radius: 10px;
      border-right: 1px solid #ccc;
    }
  `;
  const MonthText = styled.div`
    font-weight: bold;
    display: flex;
    align-items: flex-end;
  `;
  const StyledLink = styled(Link)`
    && {
      text-decoration: none;
      color: #000;
      transition: all 0.3s ease-in-out;
    }
    &&:hover {
      color: #5447a0;
      text-decoration: underline;
      font-weight: bold;
      transition: all 0.3s ease-in-out;
      transition: font-weight 0s ease-in-out;
    }
  `;
  return (
    <Container>
      {Heading && <MonthText>{Heading}</MonthText>}
      <table>
        <tbody>
          <tr>
            <td>
              <StyledLink to="/dashboard/employee">savad farooque</StyledLink>
            </td>
            <td>
              <span>Paid:</span>INR 0.00
            </td>
            <td>
              <span>Balance:</span>INR 50000.00
            </td>
            <td>
              <BasicSelect />
            </td>
            <td style={{ textAlign: "right" }}>
              <LongMenu setDelete={setDelete} />
            </td>
          </tr>
          <tr>
            <td>
              <StyledLink to="/dashboard/employee">savad farooque</StyledLink>
            </td>
            <td>
              <span>Paid:</span>INR 0.00
            </td>
            <td>
              <span>Balance:</span>INR 50000.00
            </td>
            <td>
              <BasicSelect />
            </td>
            <td style={{ textAlign: "right" }}>
              <LongMenu />
            </td>
          </tr>
        </tbody>
      </table>
    </Container>
  );
};

const ITEM_HEIGHT = 48;

function LongMenu({ setDelete }) {
  // option
  const options = [
    { name: "Edit", onClick: () => setDelete(true) },
    { name: "Delete", onClick: () => setDelete(true) },
  ];
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "8ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        {options.map((option) => (
          <MenuItem
            key={option}
            selected={option === "Pyxis"}
            onClick={option.onClick}
          >
            {option.name}
          </MenuItem>
        ))}
      </Menu>
    </div>
  );
}
// options ends
