import React, { useState } from "react";
import styled from "styled-components";
import AssignedWorks from "./assigned-works/AssignedWorks";
import Attendance from "./attendance/Attendance";
import DetailsBox from "./components/DetailsBox";
import EmployeeNavigation from "./components/EmployeeNavigation";
import Loan from "./loan/Loan";
import Payment from "./payment/Payment";
import Summary from "./summary/Summary";

const Employee = () => {
  const [activeMenu, setMenu] = useState("summary");
  return (
    <Container>
      <DetailsBox />
      <EmployeeNavigation activeMenu={activeMenu} setMenu={setMenu} />
      {activeMenu === "summary" && <Summary />}
      {activeMenu === "attendance" && <Attendance />}
      {activeMenu === "assigned-works" && <AssignedWorks />}
      {activeMenu === "loan" && <Loan />}
      {activeMenu === "payment" && <Payment />}
    </Container>
  );
};

const Container = styled.div``;

export default Employee;
