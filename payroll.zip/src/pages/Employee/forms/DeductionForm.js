import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import styled from "styled-components";
import Draggable from "react-draggable";
import { useForm } from "react-hook-form";
import InputField from "./InputField";
import TextAreaField from "./TextAreaField";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 280,
  bgcolor: "background.paper",
  border: "1px solid #c7e6ec",
  boxShadow: 24,
  p: "15px",
  borderRadius: "3px",
};

export default function DeductionForm({ showModal, setModal }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });
  const isLoading = false;

  const onSubmit = (data) => {
    const { email, password } = data;
    console.log(email);
    console.log(password);
    console.log("hello");
  };
  return (
    <Container>
      <StyledModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={showModal == "deduction"}
        onClose={() => setModal("")}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={showModal == "deduction"}>
          <Box sx={style}>
            <Heading>Add Deduction</Heading>
            <Form onSubmit={handleSubmit(onSubmit)}>
              <InputBottomContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Deduction Amount</Label>
                    <InputField
                      name="deductionAmount"
                      type="text"
                      validationMessage="This field is required."
                      validation={register("deductionAmount", {
                        required: true,
                      })}
                      errors={errors}
                      disabled={isLoading}
                    />
                  </InputGroup>
                </InputContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Reason</Label>
                    <TextArea name="name" type="textarea"></TextArea>
                  </InputGroup>
                </InputContainer>

                <StyledButton variant="contained" type="submit">
                  Save
                </StyledButton>
              </InputBottomContainer>
            </Form>
          </Box>
        </Fade>
      </StyledModal>
    </Container>
  );
}
const TextArea = styled.textarea`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 200px;
  min-height: 90px;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const StyledButton = styled(Button)`
  &&,
  &&:hover {
    width: 100%;
    background: #185a6d;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-top: 10px;
  }
  &&:hover {
    opacity: 0.9;
  }
`;
const StyledModal = styled(Modal)``;
const Container = styled.div``;
const Heading = styled.p`
  margin: 0;
  font-size: 18px;
  font-weight: bold;
  color: #185a6d;
  margin-bottom: 10px;
`;
const Form = styled.form``;
const InputGroup = styled.div`
  width: 100%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 100%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
