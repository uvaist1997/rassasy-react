import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import CustomizedMenus from "../../summary/components/CustomizedMenus";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Fade from "@mui/material/Fade";

const OverallContainer = () => {
  const [showModal, setModal] = useState({ show: false, type: "" });
  return (
    <Container>
      <Division className="amount">
        <DetailText className="paid">Total Paid</DetailText>
        <DetailText>INR 50000.00</DetailText>
      </Division>
      <Division className="amount">
        <DetailText className="pending">Total Pending</DetailText>
        <DetailText>INR 50000.00</DetailText>
      </Division>
      <Division className="button">
        <CustomizedMenus />
      </Division>

      <Division className="select">
        <BasicSelect
          options={[
            {
              name: "Payment",
              action: () => setModal({ show: true, type: "payment" }),
            },
            {
              name: "Pay By Check",
              action: () => setModal({ show: true, type: "paybycheck" }),
            },
            {
              name: "Pay In Cash",
              action: () => setModal({ show: true, type: "payincash" }),
            },
          ]}
        />
      </Division>
    </Container>
  );
};

export default OverallContainer;

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;

const AmountText = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 0;
  margin-bottom: 4px;
`;
const PendingText = styled.span`
  font-size: 12px;
  color: #969696;
  margin-left: 10px;
`;
const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.name {
    width: 18%;
  }
  &.select {
    width: 16%;
  }
  &.button {
    width: 46%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-start;
    width: 17%;
  }
`;
const DetailText = styled.div`
  text-align: right;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  &.paid {
    color: green;
    text-align: right;
  }
  &.pending {
    color: red;
    text-align: right;
  }
  span {
    font-size: 10px;
    color: #2a2a2acc;
    margin-right: 10px;
    width: 80px;
    display: inline-block;
    text-align: left;
  }
`;
const OverallText = styled.div`
  color: #2b6ec8;
`;

function BasicSelect() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Payment
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>Pay Online</MenuItem>
        <MenuItem onClick={handleClose}>Pay By Check</MenuItem>
        <MenuItem onClick={handleClose}>Pay In Cash</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    border: 1px solid #000;
    text-transform: capitalize;
    color: #000;
    background: #fff;
  }
  && svg {
    color: #000;
  }
`;
