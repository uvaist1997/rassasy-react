import { Button, Divider, Menu } from "@mui/material";
import React from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import CustomizedMenus from "../../summary/components/CustomizedMenus";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";

const PaymentItem = ({ type }) => {
  // note menu
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  // note menu ends
  return (
    <Container>
      <DayContainer>
        <RoundArrow type={type}>
          {type === "debit" ? (
            <ArrowUpwardIcon fontSize="small" sx={{ color: grey[50] }} />
          ) : (
            <ArrowDownwardIcon fontSize="small" sx={{ color: grey[50] }} />
          )}
        </RoundArrow>
        <DateContainer>
          <DayText>
            28<span>September 2021, Friday</span>
          </DayText>
          <NoteButton onClick={handleClick}>
            <EditIcon fontSize="small" sx={{ color: grey[900] }} />
            Add Note
          </NoteButton>
        </DateContainer>
      </DayContainer>
      <AmountContainer>
        {type === "debit" ? <Label>Payment</Label> : <Label>Loan</Label>}
        <AmountText>
          <span>INR</span>
          1000.00
        </AmountText>
      </AmountContainer>
      <LongMenu
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
      />
    </Container>
  );
};

export default PaymentItem;

const AmountText = styled.div`
  font-weight: bold;
  span {
    margin-right: 5px;
    color: #185a6d;
  }
`;
const Label = styled.p`
  margin: 0;
  color: #767676;
  margin-right: 5px;
`;
const DateContainer = styled.div``;

const RoundArrow = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #6fc756;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 15px;
  ${({ type }) =>
    type === "credit" &&
    `
  
  background: #e55e5e;
  `}
`;

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  transition: all 0.1s ease-in;
  margin-bottom: 10px;
  &:hover {
    background: #f8d5d5;
    transition: all 0.1s ease-in;
  }
`;
const DayText = styled.div`
  font-size: 20px;
  font-weight: bold;

  span {
    color: #767676;
    font-size: 16px;
    margin-left: 10px;
    font-weight: normal;
  }
`;
const DayContainer = styled.div`
  display: flex;
  align-items: center;
`;
const NoteButton = styled.button`
  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
`;
const AmountContainer = styled.div`
  width: 50%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
`;
const PresentType = styled(Button)`
  &&.css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    text-transform: capitalize;
    color: #000;
    background: #fff;
    border: 1px solid #000;
    padding: 5px 20px;
  }
  &&.present:hover {
    background: #25976a;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.half-day:hover {
    background: #f76f00;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.absent:hover {
    background: #f74344;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.late:hover {
    background: #f59300;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.overtime:hover {
    background: #3ccfc1;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.paid-leave:hover {
    background: #3389e1;
    color: #fff;
    border: 1px solid transparent;
  }
`;

// note
const options = ["None", "Atria", "Callisto", "Dione"];

const ITEM_HEIGHT = 48;

function LongMenu({ anchorEl, setAnchorEl, open, handleClick, handleClose }) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: 4,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea name="name" type="textarea"></TextArea>
        <Divider />
        <NoteSubmitButton>Add Note</NoteSubmitButton>
      </StyledMenu>
    </div>
  );
}
// options ends
const TextArea = styled.textarea`
  padding: 7px;
  border-radius: 10px;
  /* border: 2px solid transparent; */
  border: 0;
  /* outline: 1px solid #ccc !important; */
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 150px;
  min-height: 100px;
  box-sizing: border-box;
  /* &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  } */
  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledMenu = styled(Menu)`
  && ul {
    display: flex;
    flex-direction: column;
    padding: 0;
  }
`;
const NoteSubmitButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
  }
`;
