import React from "react";
import styled from "styled-components";
import OverallContainer from "./components/OverallContainer";
import FormControl from "@mui/material/FormControl";
import PaymentItem from "./components/PaymentItem";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";

const Payment = () => {
  const [age, setAge] = React.useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <Container>
      <Header>
        <Heading>Payment</Heading>
        <FormControl>
          <Select
            size="small"
            value={age}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value="">This Month</MenuItem>
            <MenuItem value={10}>Ten</MenuItem>
            <MenuItem value={20}>Twenty</MenuItem>
            <MenuItem value={30}>Thirty</MenuItem>
          </Select>
        </FormControl>
      </Header>
      <OverallContainer />
      <PaymentItem />
    </Container>
  );
};

export default Payment;
const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border: 0;
  }
`;
