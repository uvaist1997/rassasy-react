import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { styled as styles, alpha } from "@mui/material/styles";
import styled from "styled-components";
import AddIcon from "@mui/icons-material/Add";
import { Autocomplete, Button, Paper, TextField } from "@mui/material";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import EditIcon from "@mui/icons-material/Edit";
import Divider from "@mui/material/Divider";
import ArchiveIcon from "@mui/icons-material/Archive";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import DeductionsModal from "../../components/Deductions/DeductionsModal";
import EarningsModal from "../../components/Earnings/EarningsModal";

const top100Films = [
  { label: "The Shawshank Redemption", year: 1994 },
  { label: "The Godfather", year: 1972 },
  { label: "The Godfather: Part II", year: 1974 },
  { label: "The Dark Knight", year: 2008 },
  { label: "12 Angry Men", year: 1957 },
];

const AddEmployee = () => {
  const [next, setNext] = useState(0);
  const navigate = useNavigate();
  console.log(next);
  return (
    <Container>
      <Form>
        <Heading>Add Employee</Heading>
        <StepperContainer>
          <Stepper active={next === 0}>Basic Details</Stepper>
          <RightArrow></RightArrow>
          <Stepper active={next === 1}>Personal Details</Stepper>
          <RightArrow></RightArrow>
          <Stepper active={next === 2}>Salary Details</Stepper>
          <RightArrow></RightArrow>
          <Stepper active={next === 3}>Bank Details</Stepper>
        </StepperContainer>
        {next === 0 && <BasicDetails />}
        {next === 1 && <PersonalDetails />}
        {next === 2 && <SalaryDetails />}
        {next === 3 && <BankDetails />}
        <ButtonGroup>
          <StyledButton
            className="cancel"
            type="button"
            onClick={() => setNext(next !== 0 ? next - 1 : 0)}
          >
            {next > 0 ? "Previous" : "Cancel"}
          </StyledButton>

          <StyledButton
            className="next"
            type="button"
            onClick={() => setNext(next !== 3 ? next + 1 : 3)}
          >
            {next === 3 ? "Submit" : "Next"}
          </StyledButton>
        </ButtonGroup>
      </Form>
    </Container>
  );
};

export default AddEmployee;
const Container = styled.div`
  width: 60%;
  margin: 0 auto;
  padding-bottom: 20px;
`;
const Heading = styled.p`
  text-align: center;
  font-weight: bold;
  font-size: 32px;
  margin: 0;
  margin-bottom: 10px;
`;
const StepperContainer = styled.div`
  display: flex;
  padding: 15px;
  border-radius: 20px;
  justify-content: space-between;
  align-items: center;
`;
const Stepper = styled.div`
  transition: all 0s ease-in;
  ${({ active }) =>
    active &&
    `
  color:#52459d;
  font-weight:bold;
  transition: all 0.s ease-in;
  `}
`;
const RightArrow = styled.div`
  border-top: 2px solid #929292;
  border-right: 2px solid #929292;
  width: 10px;
  height: 10px;
  transform: rotate(45deg);
`;
const Form = styled.form`
  width: 650px;
`;
const StyledButton = styled.button`
  cursor: pointer;
  outline: none;
  width: 120px;
  padding: 10px 10px;
  border-radius: 20px;
  border: 0;

  &.cancel {
    margin-right: 10px;
    background: #1e1e1e;
    color: #fff;
  }
  &.next {
    background: #352694;
    color: #fff;
  }
`;
const ButtonGroup = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 10px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputGroup = styled.div`
  width: 100%;
  &.date {
    width: 48%;
  }
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 100%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
const SmallHeading = styled.p`
  font-weight: bold;
  margin: 0;
  margin-top: 10px;
  margin-bottom: 5px;
`;

const BasicDetails = () => {
  return (
    <>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Employee ID</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Name</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Payment Type</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Designation</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Work Location</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Department</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Email Address</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Date Of Joining</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Work Time</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
      <SmallHeading>Address</SmallHeading>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Building No/Name</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Landmark</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Country</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>City</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>State/Province</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Pincode</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
      <FormGroup>
        <FormControlLabel
          style={{ justifyContent: "center" }}
          control={<Checkbox defaultChecked style={{ fontSize: 10 }} />}
          label="Employee Portal Access"
        />
      </FormGroup>
    </>
  );
};

const PersonalDetails = () => {
  return (
    <>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>DOB</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Gender</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Father's Name</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Nationality</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>State</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Postal Code</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>PAN Card/Emirates ID</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
    </>
  );
};

const BankDetails = () => {
  return (
    <>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Bank Name</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Branch</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Account Number</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>IFSC/IBAN Code</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
    </>
  );
};

const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));
const SalaryDetails = () => {
  const [showDeduction, setDeduction] = useState(false);
  const [showEarnings, setEarnings] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const DeductionLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setDeduction(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  const EarningsLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setEarnings(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  return (
    <>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="date">
            <Label>Salary Package</Label>
            <Input name="name" type="text" />
          </InputGroup>
          <InputGroup className="date">
            <Label>Basic Salary</Label>
            <Input name="name" type="text" />
          </InputGroup>
        </InputContainer>
        <BoxContainer>
          <BoxDivision>
            <SmallHeading>Earnings</SmallHeading>
            <Box>
              <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={top100Films}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    size="small"
                    placeholder="Add Earnings"
                  />
                )}
                PaperComponent={EarningsLink}
              />
              <BoxInputGroup>
                <BoxLabel>Component</BoxLabel>
                <Input name="name" type="text" />
              </BoxInputGroup>
            </Box>
          </BoxDivision>
          <BoxDivision>
            <SmallHeading>Deductions</SmallHeading>
            <Box>
              <Autocomplete
                disablePortal
                id="combo-box-demo"
                options={top100Films}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    size="small"
                    placeholder="Add Deductions"
                  />
                )}
                PaperComponent={DeductionLink}
              />

              <BoxInputGroup>
                <BoxLabel>Component</BoxLabel>
                <Input name="name" type="text" />
              </BoxInputGroup>
            </Box>
          </BoxDivision>
        </BoxContainer>
        <DeductionsModal showModal={showDeduction} setModal={setDeduction} />
        <EarningsModal showModal={showEarnings} setModal={setEarnings} />
      </InputBottomContainer>
    </>
  );
};

const BoxContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const Box = styled.div`
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 5px;
`;
const BoxButton = styled(Button)`
  && {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    padding-right: 30px;
    margin-bottom: 30px;
  }
  &&.deductions {
    background: #5447a0;
  }
  &&:hover {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    padding-right: 30px;
    margin-bottom: 30px;
  }
`;
const BoxInputGroup = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 30px;
`;
const BoxLabel = styled.p`
  font-size: 12px;
  margin: 0;
  margin-right: 30px;
`;
const BoxDivision = styled.div`
  width: 48%;
  box-sizing: border-box;
`;
const DropDownButton = styled.button`
  border: 0;
  background: inherit;
  cursor: pointer;
  display: flex;
  outline: 0;
  box-sizing: border-box;
  align-items: center;
  padding: 0.25rem 0.5rem;
  justify-content: flex-start;
  -webkit-tap-highlight-color: transparent;
  display: block;
  width: 100%;
  text-align: left;
  color: #428bca;
  border-top: 1px solid #ccc;
  font-size: 14px;
  &:hover {
    background-color: rgba(0, 0, 0, 0.2) !important;
    color: #004d8f;
  }
`;
