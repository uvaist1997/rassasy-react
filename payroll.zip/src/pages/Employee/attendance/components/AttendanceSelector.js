import { Button, Divider, Menu } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import CustomizedMenus from "./CustomizedMenus";
import AttendanceLateForm from "../../forms/AttendanceLateForm";
import AttendanceOvertime from "../../forms/AttendanceOvertime";
import { data } from "jquery";

const AttendanceSelector = ({ data, state, index, setState }) => {
  let months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  // note menu
  const [anchorEl, setAnchorEl] = useState(null);
  const [NoteEl, setNoteEl] = useState(null);
  const open = Boolean(anchorEl);
  const openNote = Boolean(NoteEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleNotePreview = (event, date, note) => {
    setNoteEl(event.currentTarget);
    setState({ ...state, note: data.note });
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handlePreviewClose = () => {
    setNoteEl(null);
  };
  // note menu ends
  const [showModal, setModal] = useState("");

  const [attendance, setAttendance] = useState({
    note: "",
  });
  const handleSubmit = () => {
    const newData = [...state.data];
    newData[index].note = attendance.note;
    setState({
      ...state,
      data: newData,
    });
    handleClose();
    handlePreviewClose();
  };

  const handleNoteDelete = () => {
    const newData = [...state.data];
    newData[index].note = "";
    setState({
      ...state,
      data: newData,
    });
    handlePreviewClose();
  };

  const handleChange = (e) => {
    setAttendance({
      note: e.target.value,
    });
  };

  return (
    <>
      <AttendanceSelectorBox>
        <DayContainer>
          <DayText>
            {data.date.getDate()}
            <span>
              {months[data.date.getMonth()]} {data.date.getFullYear()},{" "}
              {days[data.date.getDay()]}
            </span>
          </DayText>
          {data.note ? (
            <NoteButton onClick={handleNotePreview}>{data.note}</NoteButton>
          ) : (
            <NoteButton onClick={handleClick}>
              <EditIcon fontSize="small" sx={{ color: grey[900] }} />
              Add Note
            </NoteButton>
          )}
        </DayContainer>
        <PresentTypeContainer>
          <PresentType className="present">Present</PresentType>
          <PresentType className="half-day">Half Day</PresentType>
          <PresentType className="absent">Absent</PresentType>
          <PresentType className="late" onClick={() => setModal("late")}>
            Late
          </PresentType>
          <PresentType
            className="overtime"
            onClick={() => setModal("overtime")}
          >
            Overtime
          </PresentType>
          <PresentType className="paid-leave">Paid Leave</PresentType>
          <CustomizedMenus />
        </PresentTypeContainer>
      </AttendanceSelectorBox>
      <AttendanceLateForm showModal={showModal} setModal={setModal} />
      <AttendanceOvertime showModal={showModal} setModal={setModal} />
      <LongMenu
        handleSubmit={handleSubmit}
        handleChange={handleChange}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
      />
      <NotePreview
        attendance={attendance}
        data={data}
        handleNoteSubmit={handleSubmit}
        handleNoteDelete={handleNoteDelete}
        handleChange={handleChange}
        NoteEl={NoteEl}
        setNoteEl={setNoteEl}
        openNote={openNote}
        handleNotePreview={handleNotePreview}
        handlePreviewClose={handlePreviewClose}
      />
    </>
  );
};

export default AttendanceSelector;

const AttendanceSelectorBox = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  transition: all 0.1s ease-in;
  margin-bottom: 10px;
  &:hover {
    background: #f8d5d5;
    transition: all 0.1s ease-in;
  }
`;
const DayText = styled.div`
  font-size: 20px;
  font-weight: bold;

  span {
    color: #767676;
    font-size: 16px;
    margin-left: 10px;
    font-weight: normal;
  }
`;
const DayContainer = styled.div``;
const NoteButton = styled.button`
  max-width: 300px;

  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
`;
const PresentTypeContainer = styled.div`
  width: 55%;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const PresentType = styled(Button)`
  && {
    text-transform: capitalize;
    color: #000;
    background: #fff;
    border: 1px solid #000;
    padding: 5px 20px;
  }
  &&.present:hover {
    background: #25976a;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.half-day:hover {
    background: #f76f00;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.absent:hover {
    background: #f74344;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.late:hover {
    background: #f59300;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.overtime:hover {
    background: #3ccfc1;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.paid-leave:hover {
    background: #3389e1;
    color: #fff;
    border: 1px solid transparent;
  }
`;
// note
const options = ["None", "Atria", "Callisto", "Dione"];

const ITEM_HEIGHT = 48;

function LongMenu({
  anchorEl,
  setAnchorEl,
  open,
  handleClick,
  handleClose,
  handleChange,
  handleSubmit,
}) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: 4,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="name"
          type="textarea"
          onChange={handleChange}
        ></TextArea>
        <Divider />
        <NoteSubmitButton onClick={handleSubmit}>Add Note</NoteSubmitButton>
      </StyledMenu>
    </div>
  );
}
// options ends
const TextArea = styled.textarea`
  padding: 7px;
  border-radius: 10px;
  /* border: 2px solid transparent; */
  border: 0;
  /* outline: 1px solid #ccc !important; */
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 150px;
  min-height: 100px;
  box-sizing: border-box;
  /* &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  } */
  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledMenu = styled(Menu)`
  && ul {
    display: flex;
    flex-direction: column;
    padding: 0;
  }
`;
const NoteSubmitButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
  }
  &&.delete {
    background: #ff3e3e;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
  &&.edit {
    background: #3fac93;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
`;

function NotePreview({
  NoteEl,
  setNoteEl,
  openNote,
  handleNotePreview,
  handlePreviewClose,
  state,
  setState,
  handleChange,
  date,
  handleNoteSubmit,
  handleNoteDelete,
  attendance,
  data,
}) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={NoteEl}
        open={openNote}
        onClose={handlePreviewClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: -0.9,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="note"
          type="textarea"
          value={attendance.note}
          onChange={(e) => handleChange(e)}
        ></TextArea>
        <Divider />
        <NoteButtonContainer>
          <NoteSubmitButton
            className="edit"
            onClick={(e) => handleNoteSubmit(e)}
          >
            Edit
          </NoteSubmitButton>
          <NoteSubmitButton
            className="delete"
            onClick={(e) => handleNoteDelete(e)}
          >
            Delete
          </NoteSubmitButton>
        </NoteButtonContainer>
      </StyledMenu>
    </div>
  );
}
const NoteButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
