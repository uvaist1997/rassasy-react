import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import LeaveApplicationForm from "../../forms/LeaveApplicationForm";
import CustomizedMenus from "../../summary/components/CustomizedMenus";

const AttendanceOverview = () => {
  const [showModal, setModal] = useState(false);
  return (
    <Container>
      <Division className="name">
        <OverallText>Days</OverallText>
        <AmountText>28</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Present</OverallText>
        <AmountText>28</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Absent</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Half Day</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Paid Leave</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="button dropdown">
        <CustomizedMenus />
      </Division>
      <Division className="button">
        <Button variant="contained" onClick={() => setModal(true)}>
          Leave Application
        </Button>
      </Division>
      <LeaveApplicationForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;

const AmountText = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 0;
  margin-bottom: 4px;
`;

const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.name {
    width: 10%;
  }
  &.select {
    width: 16%;
  }
  &.button.dropdown {
    width: 25%;
  }
  &.button {
    width: 15%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-end;
    width: 17%;
  }
`;

const OverallText = styled.div`
  color: #6d6d6d;
`;

export default AttendanceOverview;
