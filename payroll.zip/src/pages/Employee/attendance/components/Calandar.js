import React, { useEffect, useState } from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Button, Divider, IconButton, Menu } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import _ from "lodash";

const Calandar = () => {
  // note menu
  const employeeID = 1;
  const [anchorEl, setAnchorEl] = useState(null);
  const [NoteEl, setNoteEl] = useState(null);
  const open = Boolean(anchorEl);
  const openNote = Boolean(NoteEl);

  const handleClick = (event, date) => {
    setAnchorEl(event.currentTarget);
    setState({ ...state, dateInstance: date });
  };

  const handleNotePreview = (event, date, note) => {
    setNoteEl(event.currentTarget);
    setState({ ...state, dateInstance: date, note: note });
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handlePreviewClose = () => {
    setNoteEl(null);
  };

  const handleNoteDelete = (e, date) => {
    e.preventDefault();
    handlePreviewClose();

    const eventInstance = state.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = state.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...state.event];

    if (isDateExists) {
      eventInstances[eventInstanceIndex] = {
        ...eventInstances[eventInstanceIndex],
        note: "",
        date: date,
      };

      setState({
        ...state,
        event: eventInstances,
      });
    } else {
      setState({
        ...state,
        event: [
          ...state.event,
          {
            ...eventInstances[eventInstanceIndex],
            note: "",
            date: date,
          },
        ],
      });
    }
  };

  const handleNoteSubmit = (e, date) => {
    e.preventDefault();
    handleClose();
    handlePreviewClose();

    const eventInstance = state.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = state.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...state.event];

    if (isDateExists) {
      eventInstances[eventInstanceIndex] = {
        ...eventInstances[eventInstanceIndex],
        note: state.note,
        date: date,
      };

      setState({
        ...state,
        event: eventInstances,
      });
    } else {
      setState({
        ...state,
        event: [
          ...state.event,
          {
            ...eventInstances[eventInstanceIndex],
            note: state.note,
            date: date,
          },
        ],
      });
    }
  };
  // note menu ends

  let today = new Date();
  const [state, setState] = useState({
    monthAndYear: "",
    currentMonth: today.getMonth(),
    currentYear: today.getFullYear(),
    isToday: [{ isDay: true, date: "" }],
    tbl: [],
    event: [],
    loading: true,
  });
  const handleChange = (e, date) => {
    console.log(e.target.name);
    const eventInstance = state.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = state.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...state.event];
    if (e.target.name === "status") {
      if (isDateExists) {
        eventInstances[eventInstanceIndex] = {
          ...eventInstances[eventInstanceIndex],
          id: employeeID,
          status: e.target.value,
          date: date,
        };

        setState({
          ...state,
          event: eventInstances,
        });
      } else {
        setState({
          ...state,
          event: [
            ...state.event,
            {
              ...eventInstances[eventInstanceIndex],
              id: employeeID,
              note: "",
              status: e.target.value,
              date: date,
            },
          ],
        });
      }
    } else if (e.target.name === "note") {
      setState({
        ...state,
        note: e.target.value,
      });
    }
  };
  // calandar functions
  let months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  useEffect(() => {
    showCalendar(state.currentMonth, state.currentYear);
  }, []);

  const next = () => {
    let currentYear =
      state.currentMonth === 11 ? state.currentYear + 1 : state.currentYear;
    let currentMonth = (state.currentMonth + 1) % 12;

    setState((prev) => ({
      ...prev,
      currentYear,
      currentMonth,
    }));
    showCalendar(currentMonth, currentYear);
  };

  const previous = () => {
    let currentYear =
      state.currentMonth === 0 ? state.currentYear - 1 : state.currentYear;
    let currentMonth = state.currentMonth === 0 ? 11 : state.currentMonth - 1;
    setState((prev) => ({
      ...prev,
      currentYear,
      currentMonth,
    }));
    showCalendar(currentMonth, currentYear);
  };

  const showCalendar = (month, year) => {
    let firstDay = new Date(year, month).getDay();
    let daysInMonth = 32 - new Date(year, month, 32).getDate();
    let tbl = [];
    // filing data about month and in the page via DOM.
    setState((prev) => ({
      ...prev,
      monthAndYear: months[month] + " " + year,
    }));

    // creating all cells
    let date = 1;
    for (let i = 0; i < 6; i++) {
      // creates a table row
      let row = [];

      //creating individual cells, filing them up with data.
      for (let j = 0; j < 7; j++) {
        if (i === 0 && j < firstDay) {
          row.push("");
        } else if (date > daysInMonth) {
          break;
        } else {
          row.push(date);
          date++;
        }
      }
      tbl.push(row); // appending each row into calendar body.
    }
    if (tbl[tbl.length - 1].length === 0) {
      while (tbl[tbl.length - 2].length < 7) {
        tbl[tbl.length - 2].push("");
      }
    } else {
      while (tbl[tbl.length - 1].length < 7) {
        tbl[tbl.length - 1].push("");
      }
    }

    setState((prev) => ({ ...prev, tbl }));
  };
  // calandar functions end here
  // let eventInstance = state.event.filter(
  //   (i) => String(i.date) === String(state.dateInstance)
  // );
  // eventInstance = eventInstance.length > 0 && eventInstance[0].note;
  // let dateIndex = state.event.findIndex((i) => i.date === state.dateInstance);
  // console.log(dateIndex);
  const filterInstance = (arr, value) =>
    arr.filter((i) => String(i.date) === String(value));

  const findInstanceIndex = (arr, value) =>
    arr.findIndex((i) => String(i.date) === String(value));
  console.log(findInstanceIndex);
  return (
    <Container>
      {/* <h3 className="card-header" id="monthAndYear">
        {state.monthAndYear}
      </h3> */}
      <table className="table table-bordered table-responsive-sm" id="calendar">
        <thead>
          <tr>
            <th>Sun</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wed</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Sat</th>
          </tr>
        </thead>
        {/* TODO */}
        <tbody id="calendar-body">
          {state.tbl.map((i, indexi) => (
            <tr key={indexi}>
              {i.map((j, indexj) => (
                <TD
                  onClick={() =>
                    console.log(
                      new Date(state.currentYear, state.currentMonth, j)
                    )
                  }
                  key={indexj}
                  today={
                    j === today.getDate() &&
                    state.currentYear === today.getFullYear() &&
                    state.currentMonth === today.getMonth()
                  }
                  sunday={indexj % 7 === 0}
                >
                  <p className="date">{j}</p>
                  {j && (
                    <>
                      <p className="month-year">{state.monthAndYear}</p>

                      {filterInstance(
                        state.event,
                        new Date(state.currentYear, state.currentMonth, j)
                      ).map((k) =>
                        k.note ? (
                          <NoteButton
                            className="active"
                            onClick={(e) =>
                              handleNotePreview(
                                e,
                                new Date(
                                  state.currentYear,
                                  state.currentMonth,
                                  j
                                ),
                                k.note
                              )
                            }
                          >
                            {k.note}
                          </NoteButton>
                        ) : (
                          <NoteButton
                            onClick={(e) =>
                              handleClick(
                                e,
                                new Date(
                                  state.currentYear,
                                  state.currentMonth,
                                  j
                                )
                              )
                            }
                          >
                            <IconContainer>
                              <EditIcon
                                fontSize="small"
                                sx={{ color: grey[900] }}
                              />
                            </IconContainer>
                            Add Note
                          </NoteButton>
                        )
                      )}
                      {findInstanceIndex(
                        state.event,
                        new Date(state.currentYear, state.currentMonth, j)
                      ) === -1 && (
                        <NoteButton
                          onClick={(e) =>
                            handleClick(
                              e,
                              new Date(state.currentYear, state.currentMonth, j)
                            )
                          }
                        >
                          <IconContainer>
                            <EditIcon
                              fontSize="small"
                              sx={{ color: grey[900] }}
                            />
                          </IconContainer>
                          Add Note
                        </NoteButton>
                      )}

                      <SelectLabels
                        event={state.event}
                        handleChange={handleChange}
                        date={
                          new Date(state.currentYear, state.currentMonth, j)
                        }
                      />
                    </>
                  )}
                </TD>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      <div className="form-inline" style={{ display: "none" }}>
        <button
          className="btn btn-outline-primary col-sm-6"
          id="previous"
          onClick={previous}
        >
          Previous
        </button>

        <button
          className="btn btn-outline-primary col-sm-6"
          id="next"
          onClick={next}
        >
          Next
        </button>
      </div>
      <NoteBox
        handleNoteSubmit={handleNoteSubmit}
        state={state}
        setState={setState}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
        handleChange={handleChange}
      />
      <NotePreview
        handleNoteSubmit={handleNoteSubmit}
        handleNoteDelete={handleNoteDelete}
        state={state}
        setState={setState}
        NoteEl={NoteEl}
        setNoteEl={setNoteEl}
        openNote={openNote}
        handleNotePreview={handleNotePreview}
        handlePreviewClose={handlePreviewClose}
        handleChange={handleChange}
      />
    </Container>
  );
};

const Container = styled.div`
  table {
    width: 100%;
    border-collapse: collapse;
  }
  td,
  th {
    padding: 10px;
  }
  th {
    font-size: 25px;
    text-transform: uppercase;
    min-width: 14%;
    max-width: 14%;
    width: 14%;
    letter-spacing: 5px;
  }
  td {
    border: 2px solid #e6e6e6;
  }
  td p.date {
    font-weight: bold;
    font-size: 24px;
    margin: 0;
    margin-bottom: 2px;
  }
  td p.month-year {
    font-size: 18px;
    margin: 0;
    color: #727272;
  }
`;
const TD = styled.td`
  transition: all 0.2s ease-in;
  ${({ today }) =>
    today &&
    `
        & p.date{color:#fff;  !important}
        background:#5447a0;
         & p.month-year {
            color: #fff !important;
        }
        button{
            color:#fff !important;
        }
        svg{
            color:#fff !important;
        }
        svg[data-testid="ArrowDropDownIcon"]{
            color:#000 !important;
        }
    `}

  ${({ sunday }) =>
    sunday &&
    `
        background:#f8d5d5;
        border: 2px solid #f8d5d5 !important;
    `}
    &:hover {
    background: whitesmoke;
    transition: all 0.2s ease-in;
    & p.month-year {
      color: #000 !important;
    }
    & p.date {
      color: #000;
    }
    & button {
      color: #000 !important;
    }
    svg {
      color: #000 !important;
    }
  }
`;
const IconContainer = styled.div`
  width: 25px;
  height: 25px;
  border-radius: 3px;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: all 0.2s ease-in;
  &:hover {
    background: #f9c401;
    transition: all 0.2s ease-in;
    color: #fff !important;
    svg {
      color: #fff;
    }
  }
`;
const NoteButton = styled.button`
  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
  margin: 5px 0 15px 0;

  max-width: 100%;
  border-radius: 3px;
  padding: 4px 7px;
  width: 167px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  transition: all 0.2s ease-in;
  &.active {
    display: block;
    background: #f9c401;
    color: #4c4c4c !important;
  }
  &:hover {
    background: #f9c401;
    color: #000 !important;
    transition: all 0.2s ease-in;
    svg {
      color: #000 !important;
    }
  }
`;

export default Calandar;

function SelectLabels({ handleChange, date, event }) {
  let attendance = event.filter((i) => String(i.date) === String(date));
  attendance = attendance.length > 0 && attendance[0].status;

  const Container = styled.div`
    width: 100%;
    div[role="button"] {
      background: #eeeeee;
      ${({ attendance }) =>
        attendance === "overtime" && `background: #3ccfc1; color:#fff;`}
      ${({ attendance }) =>
        attendance === "late" && `background: #f59300; color:#fff;`}
           ${({ attendance }) =>
        attendance === "absent" && `background: #f74344; color:#fff;`}
           ${({ attendance }) =>
        attendance === "half" && `background: #f76f00; color:#fff;`}
           ${({ attendance }) =>
        attendance === "present" && `background: #25976a; color:#fff;`}
      min-width: min-content;
    }

    fieldset {
      border: 0;
    }
  `;

  return (
    <Container attendance={attendance}>
      <FormControl sx={{ width: "100%" }}>
        <Select
          name="status"
          size="small"
          value={attendance}
          onChange={(e) => handleChange(e, date)}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value={"present"}>Present</MenuItem>
          <MenuItem value={"late"}>Late</MenuItem>
          <MenuItem value={"overtime"}>Overtime</MenuItem>
          <MenuItem value={"half"}>Half Day</MenuItem>
          <MenuItem value={"attendance"}>Attendance</MenuItem>
          <MenuItem value={"absent"}>Absent</MenuItem>
        </Select>
      </FormControl>
    </Container>
  );
}

// option
const options = ["None", "Atria", "Callisto", "Dione"];

const ITEM_HEIGHT = 48;

function NoteBox({
  anchorEl,
  setAnchorEl,
  open,
  handleClick,
  handleClose,
  state,
  setState,
  handleChange,
  date,
  handleNoteSubmit,
}) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: -0.9,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="note"
          type="textarea"
          onChange={(e) => handleChange(e, state.dateInstance)}
        ></TextArea>
        <Divider />
        <NoteSubmitButton
          onClick={(e) => handleNoteSubmit(e, state.dateInstance)}
        >
          Add Note
        </NoteSubmitButton>
      </StyledMenu>
    </div>
  );
}
// options ends
const TextArea = styled.textarea`
  padding: 7px;
  border-radius: 10px;
  /* border: 2px solid transparent; */
  border: 0;
  /* outline: 1px solid #ccc !important; */
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 150px;
  min-height: 100px;
  box-sizing: border-box;
  /* &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  } */
  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledMenu = styled(Menu)`
  && ul {
    display: flex;
    flex-direction: column;
    padding: 0;
  }
`;
const NoteSubmitButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
  }
  &&.delete {
    background: #ff3e3e;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
  &&.edit {
    background: #3fac93;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
`;

function NotePreview({
  NoteEl,
  setNoteEl,
  openNote,
  handleNotePreview,
  handlePreviewClose,
  state,
  setState,
  handleChange,
  date,
  handleNoteSubmit,
  handleNoteDelete,
}) {
  return (
    <div>
      {/* <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? "long-menu" : undefined}
        aria-expanded={open ? "true" : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton> */}
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={NoteEl}
        open={openNote}
        onClose={handlePreviewClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: -0.9,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="note"
          type="textarea"
          value={state.note}
          onChange={(e) => handleChange(e, state.dateInstance)}
        ></TextArea>
        <Divider />
        <NoteButtonContainer>
          <NoteSubmitButton
            className="edit"
            onClick={(e) => handleNoteSubmit(e, state.dateInstance)}
          >
            Edit
          </NoteSubmitButton>
          <NoteSubmitButton
            className="delete"
            onClick={(e) => handleNoteDelete(e, state.dateInstance)}
          >
            Delete
          </NoteSubmitButton>
        </NoteButtonContainer>
      </StyledMenu>
    </div>
  );
}
const NoteButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
