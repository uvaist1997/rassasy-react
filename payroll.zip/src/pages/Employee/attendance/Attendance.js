import { Button, Divider, Menu } from "@mui/material";
import { ButtonBase, CircularProgress } from "@mui/material";
import React, { lazy, Suspense, useState } from "react";
import styled from "styled-components";
import CalandarRange from "../../../components/CalandarNav/CalandarRange";
import AttendanceOverview from "./components/AttendanceOverview";
import AttendanceSelector from "./components/AttendanceSelector";
import ViewListIcon from "@mui/icons-material/ViewList";
import DashboardIcon from "@mui/icons-material/Dashboard";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
const Calandar = lazy(() => import("./components/Calandar"));

const Attendance = () => {
  const [age, setAge] = useState("");
  const [showMenu, setMenu] = useState("list");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const [state, setState] = useState({
    data: [
      { date: new Date(), note: "" },
      { date: new Date(2022, 3, 6), note: "" },
      { date: new Date(2022, 3, 5), note: "" },
      { date: new Date(2022, 3, 4), note: "" },
      { date: new Date(2022, 3, 3), note: "" },
      { date: new Date(2022, 3, 2), note: "" },
      { date: new Date(2022, 3, 1), note: "" },
    ],
  });

  return (
    <Container>
      <Header>
        <Heading>Attendance</Heading>
        <CalendarContainer>
          <ActionMenu>
            <FilterContainer>
              <FilterLabel>Filter By</FilterLabel>
              <FormControl sx={{ m: 1, minWidth: 120 }}>
                <Select
                  size="small"
                  value={age}
                  onChange={handleChange}
                  displayEmpty
                  inputProps={{ "aria-label": "Without label" }}
                >
                  <MenuItem value={10}>Leaves</MenuItem>
                  <MenuItem value={20}>Twenty</MenuItem>
                  <MenuItem value={30}>Thirty</MenuItem>
                </Select>
              </FormControl>
            </FilterContainer>
            <ShowTypeContainer>
              <ButtonBase onClick={() => setMenu("list")}>
                <IconContainer showMenu={showMenu === "list"}>
                  <ViewListIcon />
                </IconContainer>
              </ButtonBase>
              <SpaceDivider></SpaceDivider>
              <ButtonBase onClick={() => setMenu("grid")}>
                <IconContainer showMenu={showMenu === "grid"}>
                  <DashboardIcon />
                </IconContainer>
              </ButtonBase>
            </ShowTypeContainer>
          </ActionMenu>
          <CalandarRange />
        </CalendarContainer>
      </Header>
      <AttendanceOverview />
      {showMenu === "list" && (
        <AttendanceSelectorContainer>
          {state.data.map((i, index) => (
            <AttendanceSelector
              index={index}
              key={index}
              data={i}
              state={state}
              setState={setState}
            />
          ))}
        </AttendanceSelectorContainer>
      )}
      <Suspense
        fallback={
          <Box>
            <CircularProgress />
          </Box>
        }
      >
        {showMenu === "grid" && <Calandar />}
      </Suspense>
      {/* {showMenu === "grid" && <FullCalendarApp />} */}
    </Container>
  );
};

export default Attendance;

const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
const CalendarContainer = styled.div`
  width: 55%;
  display: flex;
`;
const ActionMenu = styled.div`
  display: flex;
  align-items: center;
`;

const IconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: 3px;
  transition: all 0.2s ease-in;
  cursor: pointer;
  svg {
    color: #185a6d;
  }

  &:hover {
    background: #185a6d;
    svg {
      color: #fff;
    }
    transition: all 0.2s ease-in;
  }
  ${({ showMenu }) =>
    showMenu &&
    `
      background: #185a6d;
    svg {
      color: #fff;
    }
  `}
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline{
    border-radius:30px;
  }
  div[role="button"]{
    padding-top:5px;
    padding-bottom:5px;
  }
  j
`;
const FilterLabel = styled.p`
  margin: 0;
`;
const ShowTypeContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0 10px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const AttendanceSelectorContainer = styled.div`
  height: 400px;
  overflow-y: scroll;
  &::-webkit-scrollbar {
    display: none;
  }
  scrollbar-width: none;
`;
const SpaceDivider = styled.div`
  width: 1px;
  height: 30px;
  background: #ccc;
  margin: 0 5px;
`;

const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;

function FullCalendarApp() {
  const events = [
    {
      start: "2022-02-19",
      title: "test event",
      description: "This is a test description of an event",
      data: "you can add what ever random data you may want to use later",
    },
    {
      start: "2022-02-20",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-21",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-22",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-23",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-24",
      eventClasses: "optionalEvent",
      title: "test event",
    },
    {
      start: "2022-02-25",
      eventClasses: "optionalEvent",
      title: "test event",
    },
  ];
  function EventContent(eventInfo, a, e) {
    return (
      <>
        <button
          style={{
            width: "100%",
            background: "#fff",
            border: 0,
            display: "block",
            marginTop: 10,
          }}
          onClick={() => console.log(eventInfo)}
        >
          Add Note
        </button>
        <div>
          <SelectLabels />
        </div>
      </>
    );
  }

  return (
    <FullCalandarContainer>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        events={events}
        select={(eventData) => console.log(eventData)}
        selectable="true"
        // dateClick={(eventData) => window.alert(eventData.date)}
        eventContent={(e) => EventContent(e)}
      />
    </FullCalandarContainer>
  );
}

const FullCalandarContainer = styled.div`
  .fc-col-header-cell-cushion {
    font-size: 25px;
    text-transform: uppercase;
  }
  .fc-daygrid-day-top {
    flex-direction: row;
  }
  .fc-daygrid-day-top .fc-daygrid-day-number {
    font-size: 24px;
  }
  .fc-h-event {
    background: #fff;
    border: 0;
  }
`;

function SelectLabels() {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <FormControl sx={{ m: 1, minWidth: 120 }}>
      <Select
        size="small"
        value={age}
        onChange={handleChange}
        displayEmpty
        inputProps={{ "aria-label": "Without label" }}
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    </FormControl>
  );
}
