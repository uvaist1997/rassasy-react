import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components";
import InputField from "../../components/InputField/InputField";
import { motion } from "framer-motion";
import Loader from "../../components/Loader/Loader";
import { authFadeInUpVariants, staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { Navigate, useNavigate } from "react-router-dom";
import { getCookie } from "../../functions/utils";

const JoinOrganization = () => {
    const navigate = useNavigate();
    const [state, setState] = useState({
      companies: [],
    });
  const isLoading = false;
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
  });
  const onSubmit = (data) => {
    const { email, password } = data;
    console.log(email);
    console.log(password);
    console.log("hello");
  };

    // const cookies = document.cookie ? document.cookie.split("VBID=")[1] : "";
    const access = getCookie("VBID");
  const [user_id, setUserId] = useState("");
  const isAuthenticated = false;
  useEffect(async () => {
    if (access) {
      await handlePage(access);
    } else {
      window.open("http://localhost:3000/signin?service=payroll", "_self");
    }
  }, []);

  const handlePage = async (access) => {
      const companyListResponse = await fetch(
        "http://localhost:8000/api/v1/company/companies/",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            // userId: loginResponse.data.user_id,
            // BranchID: BranchID,
          }),
        }
      ).then((response) => response.json());

      if (companyListResponse.StatusCode === 6000) {
        setState((prevState) => {
          return {
            ...prevState,
            companies: companyListResponse.data,
          };
        });
      }
    
  };
    
const handleCreateOrganization = async () => {
    console.log(">>>>>>>>>>>>>>>>>||||||||||||||create");
}
    const handleJoinOrganization = async (id) => {
        navigate("/create-company", { state: { id: id } });
    };
  return (
    <Container>
      <Form
        variants={staggerOne}
        initial="initial"
        animate="animate"
        exit="exit"
        className="SignIn__form"
        // onSubmit={handleSubmit(onSubmit)}
      >
        <LogoContainer>
          {/* <Logo src="images/vikncodes.svg" /> */}
          <TopHeading>Hi Jasmal!</TopHeading>
        </LogoContainer>
        <BottomButtonContainer>
          <TopHeading>Create Your New Organization</TopHeading>
          <Button
            color="#fff"
            background="#155e4b"
            text="Create"
            type="button"
            onClick={handleCreateOrganization}
          ></Button>
        </BottomButtonContainer>

        <TopHeading>or</TopHeading>
              <TopHeading>Select an Existing Organization</TopHeading>
              {state.companies.map((i) => 
                  <BottomButtonContainerList>
                    <LogoContainerBottom>
                      <LogoBottom src="images/vikncodes-logo.svg" />
                    </LogoContainerBottom>
                    <TopHeadingList>{i.CompanyName}</TopHeadingList>
                    <JoinButton type="button" onClick={()=> handleJoinOrganization(i.id)}>
                      Join
                    </JoinButton>
                  </BottomButtonContainerList>
              )}
        
        {/* <BottomButtonContainerList>
          <LogoContainerBottom>
            <LogoBottom src="images/vikncodes-logo.svg" />
          </LogoContainerBottom>
          <TopHeadingList>Vikncodes</TopHeadingList>
          <JoinButton type="button" onClick={handleJoinOrganization}>
            Join
          </JoinButton>
        </BottomButtonContainerList>
        <BottomButtonContainerList>
          <LogoContainerBottom>
            <LogoBottom src="images/zoho-people.svg" />
          </LogoContainerBottom>
          <TopHeadingList>Zoho</TopHeadingList>
          <JoinButton type="button" onClick={handleJoinOrganization}>
            Join
          </JoinButton>
        </BottomButtonContainerList> */}
      </Form>
    </Container>
  );
};

export default JoinOrganization;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: #fff;
  overflow: hidden;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  background: #fff;
  width: 423px;
  min-height: 300px;
  height: max-content;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 2px;
`;
const InputGroup = styled.div``;
const BottomButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  align-items: center;
`;
const BottomButtonContainerList = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  align-items: center;
  border: 0;
  border-bottom: 2px solid transparent;
  transition: all 0.2s ease-out;
  border: 1px solid #ccc;
  box-sizing: border-box;
  padding: 0px 8px;
  border-radius: 3px;
  background-color: #ffffff;
  color: #141414;
`;
const ForgotPasswordContainer = styled.div`
  text-align: right;
  margin-top: 20px;
`;

const ForgotPasswordButton = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  margin-bottom: 20px;
  border-radius: 3px;
  color: ${({ color }) => color};
  background: ${({ background }) => background};
`;
const Logo = styled.img`
  width: 120px;
`;
const LogoBottom = styled.img`
  width: 100%;
`;
const LogoContainer = styled.div`
  text-align: left;
  margin: 10px 0;
`;
const LogoContainerBottom = styled.div`
  text-align: left;
  margin: 10px 0;
  width: 25px;
`;
const TopHeading = styled.p`
  text-align: left;
  opacity: 0.8;
`;
const TopHeadingList = styled.p`
  text-align: left;
  width: 230px;
`;

const JoinButton = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  padding: 10px 20px;
  border-radius: 3px;
  color: #fff;
  background: #155e4b;
  width: 130px;
  height: 40px;
`;