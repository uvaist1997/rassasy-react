import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import styled from "styled-components";
import { getCookie } from "../../functions/utils";
import AddressDetails from "./components/AddressDetails";
import OrganizationProfile from "./components/OrganizationProfile";
import TaxDetails from "./components/TaxDetails";

const CreateOrganization = () => {
  // const cookies = document.cookie ? document.cookie.split("VBID=")[1] : "";
  const access = getCookie("VBID");
  const navigate = useNavigate();
  const location = useLocation();
  const [state, setState] = useState({
    photo: [],
    CompanyName: "",
    CompanyLogo: "",
    business_types: [{ Name: "", id: "" }],
    business_type: "",
    CRNo: "",
    Email: "",
    Phone: "",
    Address1: "",
    Address2: "",
    FromDate: "",
    ToDate: "",
    countries: [],
    States: [],
    Country: "",
    State: "",
    City: "",
    Pincode: "",
    PAN: "",
    TAN: "",
    TDS: ""
  });


  useEffect(async () => {
     if (location.state.id) {
       const companyListResponse = await fetch(
         "http://localhost:8000/api/v1/company/get-company-details/",
         {
           method: "POST",
           headers: {
             "content-type": "application/json",
             Authorization: `Bearer ${access}`,
             accept: "application/json",
           },
           body: JSON.stringify({
             CompanyID: location.state.id,
           }),
         }
       ).then((response) => response.json());
       if (companyListResponse.StatusCode === 6000) {
         setState((prevState) => {
           return {
             ...prevState,
             CompanyName: companyListResponse.data.CompanyName,
             business_type: companyListResponse.data.business_type,
             CRNo: companyListResponse.data.CRNumber,
             Email: companyListResponse.data.Email,
             Phone: companyListResponse.data.Phone,
             FromDate: companyListResponse.data.FromDate,
             ToDate: companyListResponse.data.ToDate,
             Address1: companyListResponse.data.Address1,
             Address2: companyListResponse.data.Address2,
             Country: companyListResponse.data.Country,
             State: companyListResponse.data.State,
             City: companyListResponse.data.City,
             Pincode: companyListResponse.data.PostalCode,
           };
         });
       }

       const business_typeListResponse = await fetch(
         "http://localhost:8000/api/v1/company/business-types/",
         {
           method: "GET",
           headers: {
             "content-type": "application/json",
             Authorization: `Bearer ${access}`,
             accept: "application/json",
           },
         }
       ).then((response) => response.json());
         if (business_typeListResponse.StatusCode === 6000) {
           setState((prevState) => {
             return {
               ...prevState,
               business_types: business_typeListResponse.data,
             };
           });
         }
       
       const country_response = await fetch(
         "http://localhost:8000/api/v1/company/countries/",
         {
           method: "GET",
           headers: {
             "content-type": "application/json",
             Authorization: `Bearer ${access}`,
             accept: "application/json",
           },
         }
       ).then((response) => response.json());
       if (country_response.StatusCode === 6000) {
         setState((prevState) => {
           return {
             ...prevState,
             countries: country_response.data,
           };
         });
       }
      //  const country_response = await fetch(
      //    "http://localhost:8000/api/v1/company/countries",
      //    {
      //      method: "GET",
      //      headers: {
      //        "content-type": "application/json",
      //        Authorization: `Bearer ${access}`,
      //        accept: "application/json",
      //      },
      //    }
      //  ).then((response) => response.json());
      //  if (country_response.StatusCode === 6000) {
      //    setState((prevState) => {
      //      return {
      //        ...prevState,
      //        countries: country_response.data,
      //      };
      //    });
      //  }
     }
   }, []);
   
  const handleChange = (e) => {
    setState((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  }
  const fileChange = (e) => {
    // console.log(typeof e.target.files[0]);
    setState({
      ...state,
      [e.target.name]: e.target.files[0],
    });
  };
  const [next, setNext] = useState(0);
  console.log(next);

  const handleSubmit = async() => {
    console.log("handlesubmittttttttttttt")
    console.log(state)
    const companyCreateResponse = await fetch(
        "http://localhost:8000/api/v1/company/create-organization/",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            CompanyLogo: state.photo,
            Email: state.Email,
            Phone: state.Phone,
            Address1: state.Address1,
            Address2: state.Address2,
            City: state.City,
            PostalCode: state.Pincode,
            CompanyName: state.CompanyName,
            State: state.State,
            business_type: state.business_type,
            Country: state.Country,
            FromDate: state.FromDate,
            ToDate: state.ToDate,
            ToDate: state.ToDate,
          }),
        }
    ).then((response) => response.json());
    if (companyCreateResponse.StatusCode === 6000) {
      navigate("/dashboard");
    }
  }
  
  return (
    <Container>
      <Form>
        <TeamworkImage src="/images/teamwork.png" />
        <Heading>Create Organization</Heading>
        <StepperContainer>
          <Stepper active={next === 0}>Organization Profile</Stepper>
          <RightArrow></RightArrow>
          <Stepper active={next === 1}>Address Details</Stepper>
          <RightArrow></RightArrow>
          <Stepper active={next === 2}>Tax Details</Stepper>
        </StepperContainer>
        {next === 0 && (
          <OrganizationProfile
            fileChange={fileChange}
            state={state}
            next={next}
            handleChange={handleChange}
          />
        )}
        {next === 1 && (
          <AddressDetails
            fileChange={fileChange}
            state={state}
            setState={setState}
          />
        )}
        {next === 2 && (
          <TaxDetails
            fileChange={fileChange}
            state={state}
            setState={setState}
          />
        )}

        <ButtonGroup>
          <Button
            className="cancel"
            type="button"
            onClick={() => setNext(next !== 0 ? next - 1 : 0)}
          >
            {next > 0 ? "Previous" : "Cancel"}
          </Button>
          {next === 3 ? (
            <Button
              className="next"
              type="button"
              onClick={() => navigate("/dashboard/home")}
            >
              {next === 2 ? "Submit" : "Next"}
            </Button>
          ) : (
            <Button
              className="next"
              type="button"
              onClick={() => next !== 2 ? setNext(next !== 2 ? next + 1 : 2): handleSubmit()}
            >
              {next === 2 ? "Submit" : "Next"}
            </Button>
          )}
        </ButtonGroup>
      </Form>
    </Container>
  );
};

export default CreateOrganization;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  width: 650px;
  height: 650px;
  margin: 0 auto;
`;
const Heading = styled.p`
  font-weight: bold;
  font-size: 24px;
  text-align: center;
`;
const StepperContainer = styled.div`
  display: flex;
  background: whitesmoke;
  padding: 15px;
  border-radius: 20px;
  border: 1px solid #ccc;
  justify-content: space-between;
  align-items: center;
`;
const Stepper = styled.div`
  transition: all 0s ease-in;
  ${({ active }) =>
    active &&
    `
    color:#52459d;
    font-weight:bold;
    transition: all 0.s ease-in;
    `}
`;
const RightArrow = styled.div`
  border-top: 2px solid #929292;
  border-right: 2px solid #929292;
  width: 10px;
  height: 10px;
  transform: rotate(45deg);
`;
const InputGroup = styled.div`
  width: 48%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 1px solid #ccc;
  outline: none;
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
const ButtonGroup = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 10px;
`;
const Button = styled.button`
  cursor: pointer;
  outline: none;
  width: 120px;
  padding: 10px 10px;
  border-radius: 20px;
  border: 0;

  &.cancel {
    margin-right: 10px;
    background: #1e1e1e;
    color: #fff;
  }
  &.next {
    background: #352694;
    color: #fff;
  }
`;
const TeamworkImage = styled.img`
  width: 130px;
  height: 130px;
  margin: 0 auto;
  display: flex;
`;
