import React, { useEffect, useState } from "react";
import styled from "styled-components";
import ImageUploader from "../../../components/ImageUploader/ImageUploader";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";
import CircularProgress from "@mui/material/CircularProgress";
import SearchIcon from "@mui/icons-material/Search";
import { getCookie } from "../../../functions/utils";

const AddressDetails = ({ fileChange, state, setState }) => {
  const access = getCookie("VBID");
  const handleSearchChange = (e, v, n) => {
    console.log(e);
    console.log(v);
    console.log(n);
    if (v) {
      setState((prevState) => {
        return {
          ...prevState,
          [n]: v.id,
        };
      });
    }
    
  };
  const handleSearchInputChange = (e, v, n) => {
    console.log(e);
    console.log(v);
    console.log(n);
  };
  const handleChange = (e) => {
    console.log(e.target.name);
    console.log(e.target.value);
    setState((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };

  useEffect(async () => {
    if (state.Country) {
      const state_response = await fetch(
        `http://localhost:8000/api/v1/company/country-states/${state.Country}/`,
        {
          method: "GET",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
        }
      ).then((response) => response.json());
      if (state_response.StatusCode === 6000) {
        setState((prevState) => {
          return {
            ...prevState,
            States: state_response.data,
          };
        });
      }
    }
  }, [state.Country]);

  return (
    <Container>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>Building No/Name</Label>
            <Input
              name="Address1"
              type="text"
              onChange={(e) => handleChange(e)}
              value={state.Address1}
            />
          </InputGroup>
          <InputGroup className="bottom">
            <Label>Landmark</Label>
            <Input
              name="Address2"
              type="text"
              value={state.Address2}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          {/* <InputGroup className="bottom">
            <Label>Country</Label>
            <Input name="name" type="text" />
          </InputGroup> */}
          <SearchContainer>
            <SearchButton
              handleSearchChange={handleSearchChange}
              handleSearchInputChange={handleSearchInputChange}
              state={state}
            />
          </SearchContainer>
          <InputGroup className="bottom">
            <Label>City</Label>
            <Input
              name="City"
              type="text"
              value={state.City}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <SearchContainer>
            <SearchState
              handleSearchChange={handleSearchChange}
              handleSearchInputChange={handleSearchInputChange}
              state={state}
            />
          </SearchContainer>
          <InputGroup className="bottom">
            <Label>Pincode</Label>
            <Input
              name="Pincode"
              type="number"
              value={state.Pincode}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
    </Container>
  );
};
function sleep(delay = 0) {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
}
function SearchButton({ handleSearchChange, handleSearchInputChange,state }) {
  let country_index = state.countries.findIndex((i) => i.id === state.Country);
  return (
    <SearchContainer>
      <Label>Country</Label>
      <Autocomplete
        freeSolo
        id="Country"
        options={state.countries ? state.countries : []}
        getOptionLabel={(option) => option.Country_Name || ""}
        name="Country"
        onChange={(event, value) => handleSearchChange(event, value, "Country")}
        value={
          state.countries && state.Country ? state.countries[country_index] : ""
        }
        renderInput={(params) => (
          <StyledInput
            {...params}
            fullWidth
            size="small"
            variant="outlined"
            name="Country"
          />
        )}
      />
    </SearchContainer>
  );
}

function SearchState({ handleSearchChange, handleSearchInputChange, state }) {
  console.log("state.States>>>>>>>>>>>>????????????????????");
  console.log(state.States);
  let state_index = state.States.findIndex((i) => i.id === state.State);
  return (
    <SearchContainer>
      <Label>State</Label>
      <Autocomplete
        freeSolo
        id="State"
        options={state.States ? state.States : []}
        getOptionLabel={(option) => option.Name || ""}
        name="State"
        onChange={(event, value) => handleSearchChange(event, value, "State")}
        value={
          state.States && state.State && state.States[state_index]
            ? state.States[state_index]
            : ""
        }
        renderInput={(params) => (
          <StyledInput
            {...params}
            fullWidth
            size="small"
            variant="outlined"
            name="State"
          />
        )}
      />
    </SearchContainer>
  );
}

export default AddressDetails;

const Container = styled.div``;

const InputGroup = styled.div`
  width: 48%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 1px solid #ccc;
  outline: none;
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  &.bottom {
    justify-content: space-between;
    align-items: center;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
  const SearchContainer = styled.div`
    width: 286px;
    height: 54px;

  `;

const StyledInput = styled(TextField)`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 1px solid #ccc;
  outline: none`;