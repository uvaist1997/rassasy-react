import React from "react";
import styled from "styled-components";
import ImageUploader from "../../../components/ImageUploader/ImageUploader";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import { TextField } from "@material-ui/core";

const OrganizationProfile = ({ fileChange, state, next ,handleChange}) => {
  console.log(">>>>>>>>>>>>>>>>>>>>>>>>>/////")
  console.log(state)
  return (
    <Container next={next}>
      <InputTopContainer>
        <ImageContainer>
          <ImageUploader
            fileList={state.fileList}
            fileChange={fileChange}
            state={state}
          />
        </ImageContainer>
        <InputGroup>
          <InputLabelContainer>
            <Label>Organization Name</Label>
            <Input name="name" type="text" value={state.CompanyName} />
          </InputLabelContainer>
          <InputLabelContainer>
            <Label>Industry</Label>
            <Select name="business_type" onChange={(e) => handleChange(e)}>
              {state.business_types.map((i) => (
                <option
                  value={i.id}
                  selected={state.business_type === i.id ? true : false}
                >
                  {i.Name}
                </option>
              ))}
            </Select>
          </InputLabelContainer>
          {/* <InputLabelContainer>
            <Label>Industry</Label>
            <FormControl
              sx={{
                minWidth: "88%",
                "&:hover": {
                  "&& fieldset": {
                    border: "1px solid #ccc",
                  },
                },
                "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                  border: "1px solid #ccc",
                },
              }}
              size="small"
            >
              <Select
                style={{ borderRadius: 0 , width: "273px"}}
                labelId="demo-select-small"
                id="demo-select-small"
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </InputLabelContainer> */}
        </InputGroup>
      </InputTopContainer>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>Registration No</Label>
            <Input
              name="CRNo"
              type="text"
              value={state.CRNo}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
          <InputGroup className="bottom">
            <Label>{"Financial Year"}</Label>
            <FinancialYearInput>
              <DateInput
                type="date"
                id="FromDate"
                name="FromDate"
                variant="outlined"
                size="small"
                value={state.FromDate}
                onChange={(e) => handleChange(e)}
              />
              <DateInput
                type="date"
                id="ToDate"
                name="ToDate"
                variant="outlined"
                size="small"
                value={state.ToDate}
                onChange={(e) => handleChange(e)}
              />
            </FinancialYearInput>
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>Email</Label>
            <Input
              name="Email"
              type="text"
              value={state.Email}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
          <InputGroup className="bottom">
            <Label>Phone</Label>
            <Input
              name="Phone"
              type="text"
              value={state.Phone}
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
    </Container>
  );
};

export default OrganizationProfile;

const Container = styled.div``;

const InputGroup = styled.div`
  width: 48%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 1px solid #ccc;
  outline: none;
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;

const FinancialYearInput = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  border: 1px solid #bdbdbd;
  /* border-radius: 4px; */
  background: whitesmoke;
  width: 282px;
  &:hover {
    border: 1px solid #000;
  }
  &:focus {
    border: 1px solid blue;
  }
`;

const DateInput = styled(TextField)`
  input::-webkit-datetime-edit {
    max-width: fit-content;
  }
  input::-webkit-calendar-picker-indicator {
    margin: 0;
  }
  input {
    font-family: "poppinsregular";
    font-size: 14px;
  }
  & ::-webkit-datetime-edit {
    max-width: 100px;
  }
  & ::-webkit-calendar-picker-indicator {
    margin: 0;
  }
  fieldset {
    border: 0;
  }
  .MuiOutlinedInput-inputMarginDense {
    padding-top: 10px;
    padding-bottom: 10px;
  }
`;

const Select = styled.select`
  width: 88%;
  height: 40px;
  background: whitesmoke;
  padding: 7px;
  /* color: gray; */
  opacity: 0.8;
  padding-left: 5px;
  font-size: 14px;
  /* margin-left: 10px; */
  border: 1px solid #ccc;
  box-shadow: none;
  &:active {
    border: 0px;
  }
  outline: none;
`;