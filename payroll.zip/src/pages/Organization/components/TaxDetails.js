import React from "react";
import styled from "styled-components";
import ImageUploader from "../../../components/ImageUploader/ImageUploader";
import { getCookie } from "../../../functions/utils";

const TaxDetails = ({ fileChange, state, setState }) => {
  const access = getCookie("VBID");
  const handleChange = (e) => {
    console.log(e.target.name);
    console.log(e.target.value);
    setState((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };
  return (
    <Container>
      <InputBottomContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>PAN</Label>
            <Input
              name="PAN"
              type="text"
              onChange={(e) => handleChange(e)}
              value={state.PAN}
            />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>TAN</Label>
            <Input
              name="TAN"
              type="text"
              onChange={(e) => handleChange(e)}
              value={state.TAN}
            />
          </InputGroup>
        </InputContainer>
        <InputContainer className="bottom">
          <InputGroup className="bottom">
            <Label>TDS Circle/AO Code</Label>
            <Input
              name="TDS"
              type="text"
              onChange={(e) => handleChange(e)}
              value={state.TDS}
            />
          </InputGroup>
        </InputContainer>
      </InputBottomContainer>
    </Container>
  );
};

export default TaxDetails;

const Container = styled.div``;

const InputGroup = styled.div`
  width: 48%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 1px solid #ccc;
  outline: none;
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
