import React from "react";
import styled from "styled-components";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Line, Bar } from "react-chartjs-2";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import CalandarRange from "./components/CalandarRange";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const DailySummery = () => {
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: "bottom",
      },
      // title: {
      //   display: true,
      //   text: "Chart.js Line Chart",
      // },
    },
  };

  const labels = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
  ];

  const data = {
    labels,
    datasets: [
      {
        label: "You Received",
        data: [100, 200, 300, 400],
        backgroundColor: "#1d39a4",
      },
      {
        label: "You Received",
        data: [100, 200, 300, 700],
        backgroundColor: "#f76037",
      },
    ],
  };

  return (
    <Container>
      <Header>
        <SelectLabels />
        <CalandarRange />
      </Header>
      <Bar options={options} data={data} />
    </Container>
  );
};

const Container = styled.div`
  width: 48%;
  border: 1px solid #ccc;
  padding: 15px;
  border-radius: 5px;
`;
const Heading = styled.p`
  margin: 0;
  margin-bottom: 15px;
  font-weight: bold;
  font-size: 18px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;

function SelectLabels() {
  const [age, setAge] = React.useState(10);

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const Container = styled.div`
    && fieldset {
      border: 0;
    }
    && div[role="button"] {
      font-weight: bold;
    }
  `;

  return (
    <Container>
      <FormControl sx={{ minWidth: 120 }}>
        <Select
          style={{ border: 0 }}
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value={10}>Daily Summery</MenuItem>
          <MenuItem value={20}>Weekly Summery</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </Container>
  );
}
