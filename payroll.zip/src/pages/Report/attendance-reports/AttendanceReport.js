import React from "react";
import styled from "styled-components";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import CalandarRange from "./components/CalandarRange";
import ArticleIcon from "@mui/icons-material/Article";
import Menu from "@mui/material/Menu";
import Fade from "@mui/material/Fade";
import { Button } from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import SimpleAccordion from "./components/SimpleAccordion";

const AttendanceReport = () => {
  return (
    <Container>
      <Header>
        <HeaderLeft>
          <Heading>Attendance Report</Heading>
          <CalandarRange />
          <SelectLabels />
        </HeaderLeft>
        <HeaderRight>
          <SelectLabels />
          <FadeMenu />
        </HeaderRight>
      </Header>
      <SimpleAccordion />
    </Container>
  );
};

export default AttendanceReport;

const HeaderLeft = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 48%;
`;
const HeaderRight = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 22%;
`;

const Container = styled.div``;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const Heading = styled.p`
  margin: 0;
  font-weight: bold;
  font-size: 18px;
`;
function SelectLabels() {
  const [age, setAge] = React.useState(10);

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const Container = styled.div`
    /* && fieldset {
        border: 0;
      } */
    && div[role="button"] {
      font-weight: bold;
      font-size: 12px;
      min-width: 120px;
      padding: 5px 16px;
    }
  `;

  return (
    <Container>
      <FormControl sx={{ minWidth: 120 }}>
        <Select
          style={{ border: 0 }}
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value={10}>Salary</MenuItem>
          <MenuItem value={20}>Weekly Summery</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </Container>
  );
}

function FadeMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        startIcon={<ArticleIcon />}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Report
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>Download PDF</MenuItem>
        <MenuItem onClick={handleClose}>Share Via Mail</MenuItem>
        <MenuItem onClick={handleClose}>Print Now</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #fff;
    background: #1d39a4 !important;
    padding: 2px 10px;
  }
  && svg {
    color: #fff;
  }
  && span {
    font-size: 12px;
  }
`;
