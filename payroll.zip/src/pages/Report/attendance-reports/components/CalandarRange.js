import React, { useEffect, useRef, useState } from "react";
import styled from "styled-components";
import MobileDatePicker from "@mui/lab/MobileDatePicker";
import { ButtonBase, TextField, Tooltip } from "@mui/material";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import $ from "jquery";

const CalandarRange = () => {
  let dateRef = useRef(null);
  console.log(dateRef);
  const [state, setState] = useState({
    date: new Date(),
  });

  const changeDate = (dateType) => {
    if (dateType === "increment") {
      setState({
        ...state,
        date: new Date(state.date.setDate(state.date.getDate() + 1)),
      });
    } else {
      setState({
        ...state,
        date: new Date(state.date.setDate(state.date.getDate() - 1)),
      });
    }
  };

  const handleDateChange = () => {
    dateRef.current.click();
    console.log(dateRef.current);
  };

  const getFormatedDate = () => {
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    const days = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday",
    ];

    const d = new Date(state.date);

    return (
      d.getDate() +
      " " +
      monthNames[d.getMonth()] +
      " " +
      d.getFullYear() +
      " - " +
      days[d.getDay()]
    );
  };

  const handleChange = (newValue) => {
    setState({ ...state, date: newValue });
  };
  return (
    <Container>
      <CalandarSelect>
        <Tooltip title={"Previous Date"}>
          <ButtonBase style={{ borderRadius: "50%" }}>
            <NavButton onClick={() => changeDate("decrement")}></NavButton>
          </ButtonBase>
        </Tooltip>
        <DateText onClick={() => handleDateChange()}>
          {getFormatedDate()}
        </DateText>
        <DateInputContainer>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <StyledMobileDatePicker
              inputRef={dateRef}
              //   label="Date mobile"
              inputFormat="dd/MM/yyyy"
              value={state.date}
              onChange={handleChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </DateInputContainer>
        <Tooltip title={"Next Date"}>
          <ButtonBase style={{ borderRadius: "50%" }}>
            <NavButton
              className="right"
              onClick={() => changeDate("increment")}
            ></NavButton>
          </ButtonBase>
        </Tooltip>
      </CalandarSelect>
    </Container>
  );
};

export default CalandarRange;

const Container = styled.div`
  display: flex;
  justify-content: flex-end;
`;
const CalandarSelect = styled.div`
  display: flex;
  align-items: center;
  justify-content: flex-end;
`;
const NavButton = styled.div`
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: #000;

  position: relative;
  transition: all 0.2s ease-in;
  &:hover {
    cursor: pointer;
    background: #6e6e6e;
    transition: all 0.2s ease-in;
  }
  &:after {
    content: "";
    width: 5px;
    height: 5px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0px;
    margin: auto;
    border-right: 2px solid #fff;
    border-bottom: 2px solid #fff;
    transform: rotate(135deg);
    border-radius: 1px;
  }
  &.right:after {
    transform: rotate(315deg);
    right: 3px;
  }
`;
const DateText = styled.p`
  font-size: 12px;
  margin: 0 5px;
  padding: 10px 0;
  width: 190px;
  text-align: center;
  user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  -ms-user-select: none;
  &:hover {
    cursor: pointer;
  }
`;
const StyledMobileDatePicker = styled(MobileDatePicker)``;

const DateInputContainer = styled.div`
  display: none;
`;
