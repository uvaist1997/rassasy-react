import React from "react";
import styled from "styled-components";
import { Line, Bar } from "react-chartjs-2";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import CalandarRange from "./components/CalandarRange";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import ArticleIcon from "@mui/icons-material/Article";
import Menu from "@mui/material/Menu";
import Fade from "@mui/material/Fade";
import { Button } from "@mui/material";

export const PaymentReports = () => {
  return (
    <Container>
      <Header>
        <Heading>Payment Reports</Heading>
        <SelectLabels />
      </Header>
      <MiddleOptions>
        <CalandarRange />
        <FadeMenu />
      </MiddleOptions>
      <TableContainer>
        <table>
          <thead>
            <tr>
              <th></th>
              <th>Sl No</th>
              <th>Employee Name</th>
              <th>Type</th>
              <th>Paid</th>
              <th>Pending</th>
            </tr>
          </thead>
          <tbody>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(
              (i, index) => (
                <tr>
                  <td></td>
                  <td>{index + 1}</td>
                  <td>Employee Name</td>
                  <td>Type</td>
                  <td>Paid</td>
                  <td>Pending</td>
                </tr>
              )
            )}
          </tbody>
        </table>
      </TableContainer>
    </Container>
  );
};

const MiddleOptions = styled.div`
  display: flex;
  justify-content: space-between;
`;
const Container = styled.div`
  width: 46%;
  border: 1px solid #ccc;
  padding: 15px;
  border-radius: 5px;
`;
const Heading = styled.p`
  margin: 0;
  margin-bottom: 15px;
  font-weight: bold;
  font-size: 18px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const TableContainer = styled.div`
  width: 100%;
  height: 275px;
  overflow-y: scroll;
  &::-webkit-scrollbar {
    display: none;
  }
  scrollbar-width: none;
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th {
    text-align: left;
    position: sticky;
    top: 0;
    background: #fff;
    border-bottom: 1px solid #ccc;
  }
  th,
  td {
    padding: 3px;
    font-size: 14px;
  }
`;

function SelectLabels() {
  const [age, setAge] = React.useState(10);

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const Container = styled.div`
    /* && fieldset {
      border: 0;
    } */
    && div[role="button"] {
      font-weight: bold;
      font-size: 12px;
      min-width: 120px;
      padding: 5px 16px;
    }
  `;

  return (
    <Container>
      <FormControl sx={{ minWidth: 120 }}>
        <Select
          style={{ border: 0 }}
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value={10}>Salary</MenuItem>
          <MenuItem value={20}>Weekly Summery</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </Container>
  );
}

function FadeMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        startIcon={<ArticleIcon />}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Report
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>Download PDF</MenuItem>
        <MenuItem onClick={handleClose}>Share Via Mail</MenuItem>
        <MenuItem onClick={handleClose}>Print Now</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #fff;
    background: #1d39a4 !important;
    padding: 2px 10px;
  }
  && svg {
    color: #fff;
  }
  && span {
    font-size: 12px;
  }
`;
