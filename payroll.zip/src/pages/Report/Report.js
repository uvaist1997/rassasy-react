import React from "react";
import styled from "styled-components";
import AttendanceReport from "./attendance-reports/AttendanceReport";
import { DailySummery } from "./daily-summery/DailySummery";
import { PaymentReports } from "./payment-reports/PaymentReports";

const Report = () => {
  return (
    <Container>
      <TopContainer>
        <DailySummery />
        <PaymentReports />
      </TopContainer>
      <BottomContainer>
        <AttendanceReport />
      </BottomContainer>
    </Container>
  );
};

export default Report;

const Container = styled.div``;
const TopContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
`;
const BottomContainer = styled.div`
  border: 1px solid #ccc;
  width: 100%;
  height: 500px;
  border-radius: 5px;
  padding: 10px;
  box-sizing: border-box;
`;
