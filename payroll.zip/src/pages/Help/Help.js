import React, { useState } from "react";
import styled from "styled-components";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import EmailIcon from "@mui/icons-material/Email";
import ReactPlayer from "react-player";
import CloseIcon from "@mui/icons-material/Close";
import PlayCircleFilledWhiteIcon from "@mui/icons-material/PlayCircleFilledWhite";
import DoneIcon from "@mui/icons-material/Done";
import { Button } from "@mui/material";

const Help = () => {
  const [showModal, setModal] = useState("");
  return (
    <Container>
      <Header>
        <Heading>Help & Support</Heading>
        <LeftContainer>
          <TextContainer>
            <IconContainer>
              <LocalPhoneIcon />
            </IconContainer>
            <Text href="tel:+919577500400">+91 95775 00400</Text>
          </TextContainer>
          <TextContainer>
            <IconContainer className="email">
              <EmailIcon />
            </IconContainer>
            <Text href="mailto:support@vikncodes.com">
              support@vikncodes.com
            </Text>
          </TextContainer>
        </LeftContainer>
      </Header>
      <Box>
        <VideoContainer onClick={() => setModal("6qys-562kp4")}>
          <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
          <PlayerIconContainer>
            <PlayCircleFilledWhiteIcon />
          </PlayerIconContainer>
        </VideoContainer>
        <ContentContainer>
          <Heading>Grow Your Business With Vikn Payroll</Heading>
          <Points>
            <DoneIcon />
            check-iconMark Attendance and Deduct Salary for Absents
          </Points>
          <Points>
            <DoneIcon />
            check-iconRecord Salary, Advance and Pending Payments
          </Points>
          <Points>
            <DoneIcon />
            check-iconSend Payment & Attendance Reports via WhatsApp & SMS
          </Points>
        </ContentContainer>
      </Box>
      <Heading className="small">Frequently Asked Question</Heading>
      <Question>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("1L2hrG-7i2Y")}
          >
            <Image src="https://i.ytimg.com/vi/1L2hrG-7i2Y/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("hM9z2TOxdD8")}
          >
            <Image src="https://i.ytimg.com/vi/hM9z2TOxdD8/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
      </Question>
      <Heading className="small">Categories</Heading>
      <ButtonGroup>
        <StyledButton>Attendance</StyledButton>
        <StyledButton>Employee</StyledButton>
        <StyledButton>Loan</StyledButton>
      </ButtonGroup>
      <Question>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
        <VideoGrid>
          <VideoContainer
            className="grid"
            onClick={() => setModal("6qys-562kp4")}
          >
            <Image src="https://i.ytimg.com/vi/6qys-562kp4/hqdefault.jpg" />
            <PlayerIconContainer className="small">
              <PlayCircleFilledWhiteIcon />
            </PlayerIconContainer>
          </VideoContainer>
          <Caption>Lorem Ipsum?</Caption>
        </VideoGrid>
      </Question>
      <PlayerModal showModal={showModal} setModal={setModal} />
    </Container>
  );
};

export default Help;

const Container = styled.div``;
const Heading = styled.p`
  margin: 0;
  font-weight: bold;
  font-size: 24px;
  margin-bottom: 10px;
  &.small {
    font-size: 20px;
  }
`;
const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const TextContainer = styled.div`
  display: flex;
  align-items: center;
`;
const IconContainer = styled.div`
  width: 23px;
  height: 23px;
  background: #17741c;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 3px;
  margin-right: 5px;
  svg {
    color: #fff;
    font-size: 20px;
  }
  &.email {
    background: #fff;
    margin-left: 15px;
  }
  &.email svg {
    color: #1f3fac;
    font-size: 25px;
  }
`;
const Text = styled.a`
  margin: 0;
  text-decoration: none;
  color: #000;
  font-size: 14px;
`;
const LeftContainer = styled.div`
  display: flex;
`;

const Box = styled.div`
  display: flex;
  align-items: center;
  padding: 10px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 5px;
  margin-bottom: 10px;
`;
const VideoContainer = styled.div`
  width: 400px;
  height: 250px;
  position: relative;
  cursor: pointer;
  &:after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.2);
  }
  &.small {
    width: 250px;
    height: 150px;
  }
  &.grid {
    width: 100%;
    height: 170px;
  }
`;
const Image = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 5px;
  position: relative;
`;
const ContentContainer = styled.div`
  margin-left: 20px;
`;
const Points = styled.p`
  margin: 0;
  margin-bottom: 10px;
  display: flex;

  svg {
    color: #5447a0;
    font-weight: bold;
    margin-right: 10px;
  }
`;

const PlayerIconContainer = styled.div`
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  display: grid;
  place-items: center;
  z-index: 10;
  transition: all 0.3s ease-in;
  svg {
    border: 10px solid rgb(177 172 255 / 53%);
    outline: 10px solid rgb(177 172 255 / 53%);
    color: #5447a0;
    font-size: 60px;
    background: #fff;
    border-radius: 50%;
  }
  &.small {
    svg {
      border: 5px solid rgb(177 172 255 / 53%);
      outline: 5px solid rgb(177 172 255 / 53%);
      font-size: 40px;
    }
  }
  &:hover {
    svg {
      animation-name: playbutton-animation;
      animation-iteration-count: infinite;
      animation-duration: 3s;
    }
  }
  &.small:hover {
    svg {
      animation-name: playbutton-animation-small;
      animation-iteration-count: infinite;
      animation-duration: 3s;
    }
  }

  @keyframes playbutton-animation {
    0%,
    100% {
      border: 10px solid rgb(177 172 255 / 53%);
      outline: 10px solid rgb(177 172 255 / 53%);
      color: #5447a0;
      font-size: 60px;
      background: #fff;
      border-radius: 50%;
    }
    50% {
      border: 8px solid rgb(177 172 255 / 53%);
      outline: 8px solid rgb(177 172 255 / 53%);
      font-size: 40px;
    }
  }
  @keyframes playbutton-animation-small {
    0%,
    100% {
      border: 8px solid rgb(177 172 255 / 53%);
      outline: 8px solid rgb(177 172 255 / 53%);
      font-size: 40px;
    }
    50% {
      border: 10px solid rgb(177 172 255 / 53%);
      outline: 10px solid rgb(177 172 255 / 53%);
      color: #5447a0;
      font-size: 60px;
      background: #fff;
      border-radius: 50%;
    }
  }
`;
const Question = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-column-gap: 40px;
  grid-row-gap: 10px;
  margin-bottom: 20px;
`;

const Caption = styled.p`
  margin: 0;
`;

const VideoGrid = styled.div`
  color: #787878;
`;

const ButtonGroup = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 30px;
  width: 38%;
`;
const StyledButton = styled(Button)`
  && {
    width: 150px;
    text-transform: capitalize;
    background: #fff;
    border-radius: 50px;
    padding-left: 10px;
    padding-right: 10px;
    color: #000;
    border: 1px solid #000;
    &:hover {
      background: #5447a0;
      color: #fff;
      border: 1px solid transparent;
    }
  }
`;

const PlayerModal = ({ showModal, setModal }) => {
  return (
    showModal && (
      <BackContainer id="invite-video">
        <Overlay></Overlay>
        <VideoModalContainer>
          <Video className="player-wrapper">
            <ReactPlayer
              className="react-player"
              url={`https://www.youtube.com/watch?v=${showModal}`}
              playing={true}
              controls={true}
              width="100%"
              height="100%"
            />
          </Video>
          <CloseIconContainer onClick={() => setModal("")}>
            <CloseIcon />
          </CloseIconContainer>
        </VideoModalContainer>
      </BackContainer>
    )
  );
};

const BackContainer = styled.div`
  position: fixed;
  transition: 0.3s;
  width: 100%;
  height: 100vh;
  z-index: 1000;
  left: 0;
  top: 0;
  iframe {
    border-radius: 10px;
  }
`;
const Overlay = styled.div`
  background-color: rgba(0, 0, 0, 0.5);
  width: 100%;
  height: 100vh;
`;
const VideoModalContainer = styled.div`
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  border-radius: 9px;
  background-color: #fff;
  width: 70%;
`;
const Video = styled.div`
  position: relative;
  /* width: 750px; */
  height: 500px;
`;

const CloseIconContainer = styled.div`
  position: absolute;
  top: -30px;
  right: -30px;
  width: 25px;
  cursor: pointer;
  svg {
    color: #fff;
    background: #ff4545;
    border-radius: 50px;
  }
  @media (max-width: 640px) {
    right: -30px;
    width: 22px;
  }
  @media (max-width: 480px) {
    right: -22px;
    width: 16px;
  }
`;
