import React, { useState } from "react";
import styled from "styled-components";
import LogoutIcon from "@mui/icons-material/Logout";
import EditIcon from "@mui/icons-material/Edit";
import { styled as styles } from "@mui/material/styles";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import SalaryCycle from "./SalaryCycle/SalaryCycle";
import BonusSettings from "./BonusSettings/BonusSettings";

const Settings = () => {
  const [showModal, setModal] = useState("");
  const navigate = useNavigate();
  return (
    <Container>
      <Heading>Settings</Heading>
      <SmallHeader>
        <SmallHeading>Organization Profile</SmallHeading>
        <LogoutContainer>
          <LogoutIcon />
          <LogoutText>Logout</LogoutText>
        </LogoutContainer>
      </SmallHeader>
      <CompanyContainer>
        <CompanyLogo src="../images/vikncodes-logo.svg" />
        <CompanyInfoContainer>
          <CompanyNameText>Vikn Codes LLP</CompanyNameText>
          <DescriptionText>Information Technology</DescriptionText>
        </CompanyInfoContainer>
        <EditButtonContainer>
          <EditIcon />
        </EditButtonContainer>
      </CompanyContainer>
      <SmallHeading>Preferences</SmallHeading>
      <CustomizedSwitches />
      <SmallHeading>General Settings</SmallHeading>
      <GeneralSettingsOptionsContainer>
        <GeneralSettingsOptions
          onClick={() => navigate("/dashboard/salary-structure")}
        >
          <GeneralSettingsText>Default Salary Structure</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions
          onClick={() => navigate("/dashboard/salary-package-settings")}
        >
          <GeneralSettingsText>Salary Package Settings</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions onClick={() => setModal("salary-cycle")}>
          <GeneralSettingsText>Salary Cycle</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions
          onClick={() => navigate("/dashboard/holiday-settings")}
        >
          <GeneralSettingsText>Holiday Settings</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions
          onClick={() => navigate("/dashboard/admin-settings")}
        >
          <GeneralSettingsText>Admin Settings</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions
          onClick={() => navigate("/dashboard/group-settings")}
        >
          <GeneralSettingsText>Group Settings</GeneralSettingsText>
        </GeneralSettingsOptions>
        <GeneralSettingsOptions onClick={() => setModal("bonus-settings")}>
          <GeneralSettingsText>Bonus Settings</GeneralSettingsText>
        </GeneralSettingsOptions>
        {/* <GeneralSettingsOptions>
          <GeneralSettingsText>Biometric Devices</GeneralSettingsText>
        </GeneralSettingsOptions> */}
      </GeneralSettingsOptionsContainer>
      <SalaryCycle showModal={showModal} setModal={setModal} />
      <BonusSettings showModal={showModal} setModal={setModal} s />
    </Container>
  );
};

export default Settings;

const Container = styled.div``;
const Heading = styled.div`
  font-weight: bold;
  font-size: 22px;
  margin-bottom: 10px;
`;
const SmallHeading = styled.p`
  margin: 0;
  margin: 15px 0 5px;
  font-weight: bold;
  font-size: 18px;
`;
const SmallHeader = styled.div`
  display: flex;
  justify-content: space-between;
`;
const LogoutContainer = styled.div`
  cursor: pointer;
  display: flex;
  svg {
    color: #5447a0;
  }
`;
const LogoutText = styled.p`
  margin: 0;
  margin-left: 5px;
  font-weight: bold;
`;
const CompanyContainer = styled.div`
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 3px;
  display: flex;
  align-items: center;
  position: relative;
  margin-bottom: 10px;
`;
const CompanyLogo = styled.img`
  width: 60px;
  height: 60px;
  margin-right: 15px;
`;
const CompanyInfoContainer = styled.div``;
const CompanyNameText = styled.p`
  margin: 0;
  font-weight: bold;
`;
const DescriptionText = styled.p`
  margin: 0;
  font-size: 14px;
  color: #777;
`;
const EditButtonContainer = styled.div`
  position: absolute;
  right: 10px;
  top: 10px;
  svg {
    color: #5447a0;
    font-size: 22px;
    cursor: pointer;
  }
`;

const GeneralSettingsOptionsContainer = styled.div``;
const GeneralSettingsOptions = styled.div`
  border: 1px solid #ccc;
  padding: 15px;
  border-radius: 3px;
  font-weight: bold;
  font-size: 14px;
  margin-bottom: 5px;
  transition: all 0.1s ease-in;
  &:hover {
    background: #5447a0a1;
    color: #fff;
    cursor: pointer;
    transition: all 0.1s ease-in;
  }
`;
const GeneralSettingsText = styled.p`
  margin: 0;
`;

const AntSwitch = styles(Switch)(({ theme }) => ({
  width: 28,
  height: 16,
  padding: 0,
  display: "flex",
  "&:active": {
    "& .MuiSwitch-thumb": {
      width: 15,
    },
    "& .MuiSwitch-switchBase.Mui-checked": {
      transform: "translateX(9px)",
    },
  },
  "& .MuiSwitch-switchBase": {
    padding: 2,
    "&.Mui-checked": {
      transform: "translateX(12px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        opacity: 1,
        backgroundColor: theme.palette.mode === "dark" ? "#177ddc" : "#5447a0",
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
    width: 12,
    height: 12,
    borderRadius: 6,
    transition: theme.transitions.create(["width"], {
      duration: 200,
    }),
  },
  "& .MuiSwitch-track": {
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor:
      theme.palette.mode === "dark"
        ? "rgba(255,255,255,.35)"
        : "rgba(0,0,0,.25)",
    boxSizing: "border-box",
  },
}));

function CustomizedSwitches() {
  return (
    <FormGroup>
      <Stack direction="row" spacing={1} alignItems="center">
        <Typography>Notification</Typography>
        <AntSwitch defaultChecked inputProps={{ "aria-label": "ant design" }} />
      </Stack>
    </FormGroup>
  );
}
