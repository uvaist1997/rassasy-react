import { Button, FormControl, Select } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import AddIcon from "@mui/icons-material/Add";
import GroupSettingsForm from "./components/GroupSettingsForm";
import Box from "@mui/material/Box";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Fade from "@mui/material/Fade";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { styled as styles, alpha } from "@mui/material/styles";
import Check from "@mui/icons-material/Check";

const GroupSettings = () => {
  const [showModal, setModal] = useState(false);
  const [age, setAge] = useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <Container>
      <Header>
        <Heading>Group Settings</Heading>
        <ButtonContainer>
          <StyledButton startIcon={<AddIcon />} onClick={() => setModal(true)}>
            Add Group
          </StyledButton>
        </ButtonContainer>
      </Header>
      <List>
        <NameText>Group Name</NameText>
        <ContentText>Savadfarooque@gmail.com</ContentText>
        <ContentText>All Members</ContentText>
        <GroupRoles>
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <Select
              size="small"
              value={age}
              onChange={handleChange}
              displayEmpty
              inputProps={{ "aria-label": "Without label" }}
              style={{ borderRadius: "30px" }}
            >
              <MenuItem value={10}>Leaves</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </GroupRoles>

        <AccountMenu />
      </List>
      <List>
        <NameText>Group Name</NameText>
        <ContentText>Savadfarooque@gmail.com</ContentText>
        <ContentText>All Members</ContentText>
        <GroupRoles>
          <FormControl sx={{ m: 1, minWidth: 120 }}>
            <Select
              size="small"
              value={age}
              onChange={handleChange}
              displayEmpty
              inputProps={{ "aria-label": "Without label" }}
              style={{ borderRadius: "30px" }}
            >
              <MenuItem value={10}>Leaves</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </GroupRoles>
        <AccountMenu />
      </List>

      <GroupSettingsForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

export default GroupSettings;

const GroupRoles = styled.div``;
const Container = styled.div``;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
`;
const Heading = styled.p`
  margin: 0;
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const ButtonContainer = styled.div``;
const StyledButton = styled(Button)`
  && {
    text-transform: capitalize;
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    padding: 5px 25px;
    transition: all 0.2s ease-in;
  }
  &&.done {
    background: #1f911f;
    margin-left: 10px;
  }
  &&:hover {
    background: #1d39a4;
    opacity: 0.8;
    transition: all 0.2s ease-in;
  }
  &&.done:hover {
    background: #1f911f;
    opacity: 0.5;
  }
`;
const SmallHeading = styled.p`
  margin: 0;
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 5px;
  &.small {
    font-size: 14px;
  }
`;
const EarningsContainer = styled.div`
  border: 1px solid #ccc;
  border-radius: 3px;
  height: 50px;
`;

const List = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;
const NameText = styled.p`
  margin: 0;
  width: 20%;
  font-weight: bold;
  display: flex;
  align-items: center;
`;
const ContentText = styled.p`
  margin: 0;
  width: 30%;
  color: #767676;
  display: flex;
  align-items: center;
`;
const InvitationButton = styled.button`
  cursor: pointer;
  background: #fff;
  border: 0;
  color: #fe4547;
  width: 30%;
`;

function AccountMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Box sx={{ display: "flex", alignItems: "center", textAlign: "center" }}>
        <Tooltip title="Options">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? "account-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
          >
            <MoreVertIcon sx={{ width: 32, height: 32 }}>M</MoreVertIcon>
          </IconButton>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem>Edit</MenuItem>
        <MenuItem>Delete</MenuItem>
      </Menu>
    </React.Fragment>
  );
}

function FadeMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <RoleButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Group Roles
      </RoleButton>
      <StyledMenu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>
          <Check />
          Add Employee
        </MenuItem>
        <MenuItem onClick={handleClose}>
          <Check />
          Leave
        </MenuItem>
        <MenuItem onClick={handleClose}>
          <Check />
          Loan
        </MenuItem>
      </StyledMenu>
    </div>
  );
}
const RoleButton = styled(Button)`
  && {
    text-transform: capitalize;
    border: 1px solid #ccc;
    border-radius: 50px;
    color: #767676;
  }
`;
const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 100,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));
