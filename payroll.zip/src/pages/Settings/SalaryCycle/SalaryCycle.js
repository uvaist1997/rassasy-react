import React, { useState } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import styled from "styled-components";
import Draggable from "react-draggable";
import Switch from "@mui/material/Switch";
import { styled as styles } from "@mui/material/styles";
import Stack from "@mui/material/Stack";
import FormGroup from "@mui/material/FormGroup";
import DateRangeIcon from "@mui/icons-material/DateRange";
import Radio from "@mui/material/Radio";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 370,
  bgcolor: "background.paper",
  border: "1px solid #c7e6ec",
  boxShadow: 24,
  p: "15px",
  borderRadius: "3px",
};

export default function SalaryCycle({ showModal, setModal }) {
  const [state, setState] = useState({
    calandarType: "CalandarMonth",
    days: "",
    includeHolidays: false,
  });

  const handleChange = (e) => {
    setState({ ...state, days: e.target.value });
  };

  const handleRadio = (e) => {
    setState({ ...state, calandarType: e.target.value });
  };
  const handleSwitch = (e) => {
    setState({ ...state, includeHolidays: e.target.checked });
  };
  console.log(state);
  return (
    <Container>
      <StyledModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={showModal === "salary-cycle"}
        onClose={() => setModal("")}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={showModal === "salary-cycle"}>
          <Box sx={style}>
            <Header>
              <Heading>Salary Cycle</Heading>
              <CustomizedSwitches
                handleSwitch={handleSwitch}
                includeHolidays={state.includeHolidays}
              />
            </Header>
            <Form>
              <InputBottomContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <DateRangeIcon />
                    <TextGroup>
                      <Label>Calandar Month</Label>
                      <Caption>Eg: March 31 Days, April 30 Days</Caption>
                    </TextGroup>
                  </InputGroup>

                  <Radio
                    size="small"
                    checked={state.calandarType === "CalandarMonth"}
                    onChange={handleRadio}
                    value="CalandarMonth"
                    name="radio-buttons"
                    inputProps={{ "aria-label": "B" }}
                  />
                </InputContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <DateRangeIcon />
                    <TextGroup>
                      <Label>Every Month 30 Days</Label>{" "}
                      <Caption>Eg: March 30 Days, April 30 Days</Caption>
                    </TextGroup>
                  </InputGroup>
                  <Radio
                    size="small"
                    checked={state.calandarType === "EveryMonthThirtyDays"}
                    onChange={handleRadio}
                    value="EveryMonthThirtyDays"
                    name="radio-buttons"
                    inputProps={{ "aria-label": "B" }}
                  />
                </InputContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <DateRangeIcon />
                    <TextGroup>
                      <Label>Day Of Every Month</Label>{" "}
                      <Caption>Eg: March 30 Days, April 30 Days</Caption>
                    </TextGroup>
                  </InputGroup>
                  <SelectLabels handleChange={handleChange} days={state.days} />
                  <Radio
                    size="small"
                    checked={state.calandarType === "DayOfEveryMonth"}
                    onChange={handleRadio}
                    value="DayOfEveryMonth"
                    name="radio-buttons"
                    inputProps={{ "aria-label": "B" }}
                  />
                </InputContainer>

                <ButtonContainer>
                  <StyledButton
                    variant="contained"
                    onClick={() => setModal(false)}
                  >
                    Cancel
                  </StyledButton>
                  <StyledButton variant="contained" className="done">
                    Done
                  </StyledButton>
                </ButtonContainer>
              </InputBottomContainer>
            </Form>
          </Box>
        </Fade>
      </StyledModal>
    </Container>
  );
}
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const TextGroup = styled.div`
  margin-left: 5px;
`;
const Caption = styled.p`
  margin: 0;
  font-size: 12px;
  color: #767676;
`;
const TextArea = styled.textarea`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 200px;
  min-height: 90px;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;

const StyledModal = styled(Modal)``;
const Container = styled.div``;
const Heading = styled.p`
  margin: 0;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const Form = styled.form``;
const InputGroup = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 14px;
  font-weight: bold;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 100%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  border: 1px solid #cccc;
  padding: 10px;
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  box-sizing: border-box;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
const ButtonContainer = styled.div`
  display: flex;
  width: 100%;
`;
const StyledButton = styled(Button)`
  width: 50%;
  &&,
  &&:hover {
    width: 100%;
    background: #000000;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-top: 10px;
  }
  &&:hover {
    opacity: 0.9;
  }
  &&.done {
    margin-left: 10px;
    background: #185a6d;
  }
  &&.done:hover {
    background: #185a6d;
    opacity: 0.8;
  }
`;

const AntSwitch = styles(Switch)(({ theme }) => ({
  width: 28,
  height: 16,
  padding: 0,
  display: "flex",
  "&:active": {
    "& .MuiSwitch-thumb": {
      width: 15,
    },
    "& .MuiSwitch-switchBase.Mui-checked": {
      transform: "translateX(9px)",
    },
  },
  "& .MuiSwitch-switchBase": {
    padding: 2,
    "&.Mui-checked": {
      transform: "translateX(12px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        opacity: 1,
        backgroundColor: theme.palette.mode === "dark" ? "#177ddc" : "#5447a0",
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
    width: 12,
    height: 12,
    borderRadius: 6,
    transition: theme.transitions.create(["width"], {
      duration: 200,
    }),
  },
  "& .MuiSwitch-track": {
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor:
      theme.palette.mode === "dark"
        ? "rgba(255,255,255,.35)"
        : "rgba(0,0,0,.25)",
    boxSizing: "border-box",
  },
}));

function CustomizedSwitches({ handleSwitch, includeHolidays }) {
  return (
    <FormGroup>
      <Stack direction="row" spacing={1} alignItems="center">
        <Typography style={{ fontSize: "14px" }}>Include Holidays</Typography>
        <AntSwitch
          defaultChecked
          checked={includeHolidays}
          inputProps={{ "aria-label": "ant design" }}
          onChange={handleSwitch}
        />
      </Stack>
    </FormGroup>
  );
}

function SelectLabels({ handleChange, days }) {
  return (
    <div>
      <FormControl sx={{ minWidth: 60 }}>
        <Select
          size="small"
          value={days}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value={"01"}>01</MenuItem>
          <MenuItem value={"02"}>02</MenuItem>
          <MenuItem value={"03"}>03</MenuItem>
          <MenuItem value={"04"}>04</MenuItem>
        </Select>
      </FormControl>
    </div>
  );
}
