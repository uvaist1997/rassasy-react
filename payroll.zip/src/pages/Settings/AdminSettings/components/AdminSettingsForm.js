import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import styled from "styled-components";
import Draggable from "react-draggable";
import Checkbox from "@mui/material/Checkbox";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 280,
  bgcolor: "background.paper",
  border: "1px solid #c7e6ec",
  boxShadow: 24,
  p: "15px",
  borderRadius: "3px",
};

export default function AdminSettingsForm({ showModal, setModal }) {
  return (
    <Container>
      <StyledModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={showModal}
        onClose={() => setModal(false)}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={showModal}>
          <Box sx={style}>
            <Heading>Add Admin</Heading>
            <Form>
              <InputBottomContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Email Address</Label>
                    <Input name="name" type="text" />
                  </InputGroup>
                </InputContainer>

                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Staffs</Label>
                    <CheckboxesTags />
                  </InputGroup>
                </InputContainer>

                <ButtonContainer>
                  <StyledButton
                    variant="contained"
                    onClick={() => setModal(false)}
                  >
                    Cancel
                  </StyledButton>
                  <StyledButton variant="contained" className="done">
                    Done
                  </StyledButton>
                </ButtonContainer>
              </InputBottomContainer>
            </Form>
          </Box>
        </Fade>
      </StyledModal>
    </Container>
  );
}
const TextArea = styled.textarea`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 200px;
  min-height: 90px;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const StyledModal = styled(Modal)``;
const Container = styled.div`
  span {
    padding: 0 !important;
  }
  fieldset {
    border: 2px solid #000 !important;
  }
`;
const Heading = styled.p`
  margin: 0;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const Form = styled.form``;
const InputGroup = styled.div`
  width: 100%;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 100%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
const ButtonContainer = styled.div`
  display: flex;
  width: 100%;
`;
const StyledButton = styled(Button)`
  width: 50%;
  &&,
  &&:hover {
    width: 100%;
    background: #000000;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-top: 10px;
  }
  &&:hover {
    opacity: 0.9;
  }
  &&.done {
    margin-left: 10px;
    background: #185a6d;
  }
  &&.done:hover {
    background: #185a6d;
    opacity: 0.8;
  }
`;

function CheckboxesTags() {
  const Container = styled.div`
    &&
      .MuiOutlinedInput-root.MuiInputBase-root.MuiInputBase-colorPrimary.MuiInputBase-fullWidth.MuiInputBase-formControl.MuiInputBase-sizeSmall.MuiInputBase-adornedEnd.MuiAutocomplete-inputRoot {
      background: whitesmoke;
    }
    &&
      .MuiOutlinedInput-root.MuiInputBase-root.MuiInputBase-colorPrimary.MuiInputBase-fullWidth.MuiInputBase-formControl.MuiInputBase-sizeSmall.MuiInputBase-adornedEnd.MuiAutocomplete-inputRoot:hover {
      background: whitesmoke;
    }
    &&
      .MuiOutlinedInput-root.MuiInputBase-root.MuiInputBase-colorPrimary.MuiInputBase-fullWidth.MuiInputBase-formControl.MuiInputBase-sizeSmall.MuiInputBase-adornedEnd.MuiAutocomplete-inputRoot:hover {
      background: whitesmoke;
    
    && .Mui-focused:hover{
      .MuiOutlinedInput-notchedOutline {
      border: 2px solid #000 !important;
      transition: all 0.2s ease-in;

    }
    } 
  `;
  return (
    <Container>
      <Autocomplete
        size="small"
        multiple
        id="checkboxes-tags-demo"
        options={top100Films}
        disableCloseOnSelect
        getOptionLabel={(option) => option.title}
        renderOption={(props, option, { selected }) => (
          <li {...props}>
            <Checkbox
              icon={icon}
              checkedIcon={checkedIcon}
              style={{ marginRight: 8 }}
              checked={selected}
            />
            {option.title}
          </li>
        )}
        renderInput={(params) => <StyledTextField {...params} />}
      />
    </Container>
  );
}
const StyledTextField = styled(TextField)`
  && .Mui-focused .MuiOutlinedInput-notchedOutline {
    border: 2px solid #000 !important;
    transition: all 0.2s ease-in;
  }
  &&:hover {
    && .Mui-focused .MuiOutlinedInput-notchedOutline {
      border: 2px solid #000 !important;
      transition: all 0.2s ease-in;
    }
  }
`;
// Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
const top100Films = [
  { title: "The Shawshank Redemption", year: 1994 },
  { title: "The Godfather", year: 1972 },
  { title: "The Godfather: Part II", year: 1974 },
  { title: "The Dark Knight", year: 2008 },
  { title: "12 Angry Men", year: 1957 },
  { title: "Schindler's List", year: 1993 },
  { title: "Pulp Fiction", year: 1994 },
  {
    title: "The Lord of the Rings: The Return of the King",
    year: 2003,
  },
  { title: "The Good, the Bad and the Ugly", year: 1966 },
  { title: "Fight Club", year: 1999 },
  {
    title: "The Lord of the Rings: The Fellowship of the Ring",
    year: 2001,
  },
  {
    title: "Star Wars: Episode V - The Empire Strikes Back",
    year: 1980,
  },
  { title: "Forrest Gump", year: 1994 },
  { title: "Inception", year: 2010 },
  {
    title: "The Lord of the Rings: The Two Towers",
    year: 2002,
  },
  { title: "One Flew Over the Cuckoo's Nest", year: 1975 },
  { title: "Goodfellas", year: 1990 },
  { title: "The Matrix", year: 1999 },
  { title: "Seven Samurai", year: 1954 },
  {
    title: "Star Wars: Episode IV - A New Hope",
    year: 1977,
  },
  { title: "City of God", year: 2002 },
  { title: "Se7en", year: 1995 },
  { title: "The Silence of the Lambs", year: 1991 },
  { title: "It's a Wonderful Life", year: 1946 },
  { title: "Life Is Beautiful", year: 1997 },
  { title: "The Usual Suspects", year: 1995 },
  { title: "Léon: The Professional", year: 1994 },
  { title: "Spirited Away", year: 2001 },
  { title: "Saving Private Ryan", year: 1998 },
  { title: "Once Upon a Time in the West", year: 1968 },
  { title: "American History X", year: 1998 },
  { title: "Interstellar", year: 2014 },
];
