import React, { useState } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Draggable from "react-draggable";
import { useNavigate } from "react-router-dom";
import { styled as styles, alpha } from "@mui/material/styles";
import styled from "styled-components";
import AddIcon from "@mui/icons-material/Add";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@mui/material/Divider";
import ArchiveIcon from "@mui/icons-material/Archive";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import EditIcon from "@mui/icons-material/Edit";
import Menu from "@mui/material/Menu";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { Autocomplete, Paper, TextField } from "@mui/material";
import DeductionsModal from "../../../../components/Deductions/DeductionsModal";
import EarningsModal from "../../../../components/Earnings/EarningsModal";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "1px solid #c7e6ec",
  boxShadow: 24,
  p: "15px",
  borderRadius: "3px",
};

const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const top100Films = [
  { label: "The Shawshank Redemption", year: 1994 },
  { label: "The Godfather", year: 1972 },
  { label: "The Godfather: Part II", year: 1974 },
  { label: "The Dark Knight", year: 2008 },
  { label: "12 Angry Men", year: 1957 },
];

const Link = ({ children, ...other }) => {
  return (
    <Paper {...other}>
      {children}
      <DropDownButton
        onMouseDown={(event) => {
          event.preventDefault();
        }}
        onClick={() => window.open("/dashboard/create-products", "_blank")}
      >
        + {"Add"}
      </DropDownButton>
    </Paper>
  );
};

export default function SalaryPackageForm({ showModal, setModal }) {
  const [showDeduction, setDeduction] = useState(false);
  const [showEarnings, setEarnings] = useState(false);

  const DeductionLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setDeduction(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  const EarningsLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setEarnings(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <Container>
      <StyledModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={showModal}
        onClose={() => setModal(false)}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={showModal}>
          <Box sx={style}>
            <Heading>Add Salary Package</Heading>
            <Form>
              <InputBottomContainer>
                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Package</Label>
                    <Input name="name" type="text" />
                  </InputGroup>
                </InputContainer>

                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>Basic Salary</Label>
                    <Input name="name" type="text" />
                  </InputGroup>
                </InputContainer>
                <SmallHeading>Salary Components</SmallHeading>
                <CardHeading>Earnings</CardHeading>
                <Card>
                  {" "}
                  <Box>
                    <Autocomplete
                      disablePortal
                      id="combo-box-demo"
                      options={top100Films}
                      sx={{ width: 300 }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          size="small"
                          placeholder="Add Earnings"
                        />
                      )}
                      PaperComponent={EarningsLink}
                    />
                    <BoxInputGroup>
                      <BoxLabel>Component</BoxLabel>
                      <Input name="name" type="text" />
                    </BoxInputGroup>
                  </Box>
                </Card>

                <CardHeading>Deductions</CardHeading>
                <Card>
                  {" "}
                  <Box>
                    <Autocomplete
                      disablePortal
                      id="combo-box-demo"
                      options={top100Films}
                      sx={{ width: 300 }}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          size="small"
                          placeholder="Add Deductions"
                        />
                      )}
                      PaperComponent={DeductionLink}
                    />
                    <BoxInputGroup>
                      <BoxLabel>Component</BoxLabel>
                      <Input name="name" type="text" />
                    </BoxInputGroup>
                  </Box>
                </Card>
                <ButtonContainer>
                  <StyledButton
                    variant="contained"
                    onClick={() => setModal(false)}
                  >
                    Cancel
                  </StyledButton>
                  <StyledButton variant="contained" className="done">
                    Done
                  </StyledButton>
                </ButtonContainer>
              </InputBottomContainer>
            </Form>
          </Box>
        </Fade>
      </StyledModal>
      <DeductionsModal showModal={showDeduction} setModal={setDeduction} />
      <EarningsModal showModal={showEarnings} setModal={setEarnings} />
    </Container>
  );
}

const CardHeading = styled.div`
  font-size: 12px;
  font-weight: bold;
  width: 100%;
`;
const Card = styled.div`
  border: 1px solid #ccc;
  border-radius: 3px;
  width: 100%;
  margin-bottom: 10px;
  padding: 10px;
  box-sizing: border-box;
`;

const SmallHeading = styled.p`
  margin: 0;
  margin-bottom: 10px;
  width: 100%;
  font-weight: bold;
`;

const TextArea = styled.textarea`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 200px;
  min-height: 90px;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;

const StyledModal = styled(Modal)``;
const Container = styled.div``;
const Heading = styled.p`
  margin: 0;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const Form = styled.form``;
const InputGroup = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 55%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
const ButtonContainer = styled.div`
  display: flex;
  width: 100%;
`;
const StyledButton = styled(Button)`
  width: 50%;
  &&,
  &&:hover {
    width: 100%;
    background: #000000;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-top: 10px;
  }
  &&:hover {
    opacity: 0.9;
  }
  &&.done {
    margin-left: 10px;
    background: #185a6d;
  }
  &&.done:hover {
    background: #185a6d;
    opacity: 0.8;
  }
`;
const BoxButton = styled(Button)`
  && {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    padding-right: 15px;
    margin-bottom: 30px;
  }
  &&.deductions {
    background: #5447a0;
  }
  &&:hover {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-bottom: 30px;
  }
`;
const BoxLabel = styled.p`
  font-size: 12px;
  margin: 0;
  margin-right: 30px;
`;
const BoxInputGroup = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 20px;
  margin-bottom: 10px;
`;
const DropDownButton = styled.button`
  border: 0;
  background: inherit;
  cursor: pointer;
  display: flex;
  outline: 0;
  box-sizing: border-box;
  align-items: center;
  padding: 0.25rem 0.5rem;
  justify-content: flex-start;
  -webkit-tap-highlight-color: transparent;
  display: block;
  width: 100%;
  text-align: left;
  color: #428bca;
  border-top: 1px solid #ccc;
  font-size: 14px;
  &:hover {
    background-color: rgba(0, 0, 0, 0.2) !important;
    color: #004d8f;
  }
`;
