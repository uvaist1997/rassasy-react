import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import AddIcon from "@mui/icons-material/Add";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Tooltip from "@mui/material/Tooltip";
import PersonAdd from "@mui/icons-material/PersonAdd";
import Settings from "@mui/icons-material/Settings";
import Logout from "@mui/icons-material/Logout";
import AccessAlarmIcon from "@mui/icons-material/AccessAlarm";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import Fade from "@mui/material/Fade";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { styled as styles, alpha } from "@mui/material/styles";
import Check from "@mui/icons-material/Check";
import SalaryPackageForm from "./components/SalaryPackageForm";

const SalaryPackageSettings = () => {
  const [showModal, setModal] = useState(false);
  return (
    <Container>
      <Header>
        <Heading>Salary Package Settings</Heading>
        <ButtonContainer>
          <StyledButton startIcon={<AddIcon />} onClick={() => setModal(true)}>
            Add Package
          </StyledButton>
        </ButtonContainer>
      </Header>
      <List>
        <NameText>Savad Farooque</NameText>
        <AccountMenu />
      </List>
      <List>
        <NameText>Savad Farooque</NameText>
        <AccountMenu />
      </List>
      <List>
        <NameText>Savad Farooque</NameText>
        <AccountMenu />
      </List>
      <List>
        <NameText>Savad Farooque</NameText>
        <AccountMenu />
      </List>
      <SalaryPackageForm showModal={showModal} setModal={setModal} />
    </Container>
  );
};

export default SalaryPackageSettings;
const Container = styled.div``;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
`;
const Heading = styled.p`
  margin: 0;
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const ButtonContainer = styled.div``;
const StyledButton = styled(Button)`
  && {
    text-transform: capitalize;
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    padding: 5px 25px;
    transition: all 0.2s ease-in;
  }
  &&.done {
    background: #1f911f;
    margin-left: 10px;
  }
  &&:hover {
    background: #1d39a4;
    opacity: 0.8;
    transition: all 0.2s ease-in;
  }
  &&.done:hover {
    background: #1f911f;
    opacity: 0.5;
  }
`;
const SmallHeading = styled.p`
  margin: 0;
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 5px;
  &.small {
    font-size: 14px;
  }
`;
const EarningsContainer = styled.div`
  border: 1px solid #ccc;
  border-radius: 3px;
  height: 50px;
`;

const List = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;
const NameText = styled.p`
  margin: 0;
  width: 30%;
  font-weight: bold;
`;
const EmailText = styled.p`
  margin: 0;
  width: 30%;
  color: #767676;
`;
const InvitationButton = styled.button`
  cursor: pointer;
  background: #fff;
  border: 0;
  color: #fe4547;
  width: 30%;
`;

function AccountMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Box sx={{ display: "flex", alignItems: "center", textAlign: "center" }}>
        <Tooltip title="Options">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? "account-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
          >
            <MoreVertIcon sx={{ width: 32, height: 32 }}>M</MoreVertIcon>
          </IconButton>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem>Edit</MenuItem>
        <MenuItem>Delete</MenuItem>
      </Menu>
    </React.Fragment>
  );
}
