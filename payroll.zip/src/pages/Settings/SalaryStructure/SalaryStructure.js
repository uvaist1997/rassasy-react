import { Autocomplete, Button, Paper, TextField } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import { styled as styles, alpha } from "@mui/material/styles";
import AddIcon from "@mui/icons-material/Add";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@mui/material/Divider";
import ArchiveIcon from "@mui/icons-material/Archive";
import FileCopyIcon from "@mui/icons-material/FileCopy";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import EditIcon from "@mui/icons-material/Edit";
import Menu from "@mui/material/Menu";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Box from "@mui/material/Box";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Tooltip from "@mui/material/Tooltip";
import DeductionsModal from "../../../components/Deductions/DeductionsModal";
import EarningsModal from "../../../components/Earnings/EarningsModal";

const Link = ({ children, ...other }) => {
  return (
    <Paper {...other}>
      {children}
      <DropDownButton
        onMouseDown={(event) => {
          event.preventDefault();
        }}
        onClick={() => window.open("/dashboard/create-products", "_blank")}
      >
        + {"Add"}
      </DropDownButton>
    </Paper>
  );
};

const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const top100Films = [
  { label: "The Shawshank Redemption", year: 1994 },
  { label: "The Godfather", year: 1972 },
  { label: "The Godfather: Part II", year: 1974 },
  { label: "The Dark Knight", year: 2008 },
  { label: "12 Angry Men", year: 1957 },
];

const SalaryStructure = () => {
  const [showDeduction, setDeduction] = useState(false);
  const [showEarnings, setEarnings] = useState(false);

  const DeductionLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setDeduction(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  const EarningsLink = ({ children, ...other }) => {
    return (
      <Paper {...other}>
        {children}
        <DropDownButton
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          // onClick={() => console.log("hello")}
          onClick={(event) => {
            event.preventDefault();
            setEarnings(true);
          }}
        >
          + {"Add"}
        </DropDownButton>
      </Paper>
    );
  };

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <Container>
      <Header>
        <Heading>Default Salary Structure</Heading>
        <ButtonContainer>
          <StyledButton>Cancel</StyledButton>
          <StyledButton className="done">Done</StyledButton>
        </ButtonContainer>
      </Header>
      <SmallHeading>Salary Components</SmallHeading>
      <SmallHeading className="small">Earnings</SmallHeading>
      <EarningsContainer>
        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={top100Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} size="small" placeholder="Add Earnings" />
            )}
            PaperComponent={EarningsLink}
          />
          <BoxInputGroup style={{ marginTop: "10px" }}>
            <TextContainer>
              <AccountMenu />
            </TextContainer>
          </BoxInputGroup>
        </Box>
      </EarningsContainer>
      <SmallHeading className="small">Deductions</SmallHeading>
      <EarningsContainer>
        {" "}
        <Box>
          <Autocomplete
            disablePortal
            id="combo-box-demo"
            options={top100Films}
            sx={{ width: 300 }}
            renderInput={(params) => (
              <TextField {...params} size="small" placeholder="Add Earnings" />
            )}
            PaperComponent={DeductionLink}
          />
          <BoxInputGroup style={{ marginTop: "10px" }}>
            <TextContainer>
              <AccountMenu />
            </TextContainer>
          </BoxInputGroup>
        </Box>
      </EarningsContainer>
      <DeductionsModal showModal={showDeduction} setModal={setDeduction} />
      <EarningsModal showModal={showEarnings} setModal={setEarnings} />
    </Container>
  );
};

export default SalaryStructure;

const TextContainer = styled.div``;
const Container = styled.div``;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const Heading = styled.p`
  margin: 0;
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
`;
const ButtonContainer = styled.div``;
const StyledButton = styled(Button)`
  && {
    text-transform: capitalize;
    background: #000;
    color: #fff;
    border-radius: 50px;
    padding: 3px 25px;
    transition: all 0.2s ease-in;
  }
  &&.done {
    background: #1f911f;
    margin-left: 10px;
  }
  &&:hover {
    background: #000;
    opacity: 0.5;
    transition: all 0.2s ease-in;
  }
  &&.done:hover {
    background: #1f911f;
    opacity: 0.5;
  }
`;
const SmallHeading = styled.p`
  margin: 0;
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 5px;
  &.small {
    font-size: 14px;
  }
`;
const EarningsContainer = styled.div`
  border: 1px solid #ccc;
  border-radius: 3px;
  min-height: 200px;
  height: 200px;
  margin-bottom: 10px;
  padding: 10px;
  overflow: hidden;
`;
const BoxButton = styled(Button)`
  && {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    padding-right: 15px;
    margin-bottom: 30px;
  }
  &&.deductions {
    background: #5447a0;
  }
  &&:hover {
    background: #1d39a4;
    color: #fff;
    border-radius: 50px;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-bottom: 30px;
  }
`;
const BoxInputGroup = styled.div`
  width: fit-content;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  margin-bottom: 10px;
  height: 220px;
  flex-wrap: wrap;
`;
const BoxLabel = styled.p`
  font-size: 12px;
  margin: 0;
  margin-right: 30px;
  margin-bottom: 10px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 55%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;

function AccountMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    console.log("enter");
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    console.log("leave");
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Box sx={{ display: "flex", alignItems: "center", textAlign: "center" }}>
        <Tooltip title="Account settings">
          <BoxLabel onClick={handleClick}>Component</BoxLabel>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: 6.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 80,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem>Profile</MenuItem>
        <MenuItem>My account</MenuItem>
        <Divider />
        <MenuItem>Add another account</MenuItem>
        <MenuItem>Settings</MenuItem>
        <MenuItem>Logout</MenuItem>
      </Menu>
    </React.Fragment>
  );
}

const DropDownButton = styled.button`
  border: 0;
  background: inherit;
  cursor: pointer;
  display: flex;
  outline: 0;
  box-sizing: border-box;
  align-items: center;
  padding: 0.25rem 0.5rem;
  justify-content: flex-start;
  -webkit-tap-highlight-color: transparent;
  display: block;
  width: 100%;
  text-align: left;
  color: #428bca;
  border-top: 1px solid #ccc;
  font-size: 14px;
  &:hover {
    background-color: rgba(0, 0, 0, 0.2) !important;
    color: #004d8f;
  }
`;
