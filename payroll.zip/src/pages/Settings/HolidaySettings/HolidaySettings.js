import { Button, Fade, Menu } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components";
import DayOfWeek from "./components/DayOfWeek";
import Calandar from "./components/Calandar";
import DateRangeForm from "./components/DateRangeForm";
import MonthNav from "./components/MonthNav";
import YearNav from "./components/YearNav";
import DayOfWeekDialog from "./components/DayOfWeekDialog";

const HolidaySettings = () => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const [showModal, setModal] = useState(false);
  const [showWeekDialog, setWeekDialog] = useState(false);

  const [month, setMonth] = useState(new Date());
  const [year, setYear] = useState(new Date());
  const [key, setKey] = useState(0);

  useEffect(() => {
    setKey(key + 1);
  }, [month.getMonth()]);

  useEffect(() => {
    setKey(key + 1);
  }, [year.getFullYear()]);

  const [state, setState] = useState({
    event: [
      { date: new Date(2022, 2, 10), note: "dfgsdf", isHoliday: false },
      { date: new Date(2022, 2, 11), note: "hregawef", isHoliday: false },
    ],
    note: "",
    fromDate: new Date(),
    toDate: new Date(),
    // monday
    isMonday: false,
    isFirstMonday: false,
    isSecondMonday: false,
    isThirdMonday: false,
    isFourthMonday: false,
    isFifthMonday: false,
    // tuesday
    isTuesday: false,
    isFirstTuesday: false,
    isSecondTuesday: false,
    isThirdTuesday: false,
    isFourthTuesday: false,
    isFifthTuesday: false,
    // wednesday
    isWednesday: false,
    isFirstWednesday: false,
    isSecondWednesday: false,
    isThirdWednesday: false,
    isFourthWednesday: false,
    isFifthWednesday: false,
    // thursday
    isThursday: false,
    isFirstThursday: false,
    isSecondThursday: false,
    isThirdThursday: false,
    isFourthThursday: false,
    isFifthThursday: false,
    // friday
    isFriday: false,
    isFirstFriday: false,
    isSecondFriday: false,
    isThirdFriday: false,
    isFourthFriday: false,
    isFifthFriday: false,
    // saturday
    isSaturday: false,
    isFirstSaturday: false,
    isSecondSaturday: false,
    isThirdSaturday: false,
    isFourthSaturday: false,
    isFifthSaturday: false,
    // sunday
    isSunday: false,
    isFirstSunday: false,
    isSecondSunday: false,
    isThirdSunday: false,
    isFourthSunday: false,
    isFifthSunday: false,
  });

  return (
    <Container>
      <Header>
        <Heading>Holiday Settings</Heading>
        <RangeSelector>
          <MonthNav setMonth={setMonth} month={month} />
          <YearNav setYear={setYear} year={year} />
        </RangeSelector>
        <ButtonGroup>
          <StyledButton
            id="demo-customized-button"
            aria-controls={open ? "demo-customized-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            variant="contained"
            disableElevation
            onClick={handleClick}
            // endIcon={}
          >
            + Day of week
          </StyledButton>
          <Menu
            id="fade-menu"
            MenuListProps={{
              "aria-labelledby": "fade-button",
            }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            TransitionComponent={Fade}
            PaperProps={{
              elevation: 0,
              sx: {
                overflow: "visible",
                filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                mt: 1,
                ml: -2.5,
              },
            }}
          >
            <DayOfWeek
              month={month}
              year={year}
              state={state}
              setState={setState}
              setWeekDialog={setWeekDialog}
            />
          </Menu>
          <StyledButton
            className="range"
            id="demo-customized-button"
            aria-controls={open ? "demo-customized-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            variant="contained"
            disableElevation
            onClick={() => setModal(true)}
            // endIcon={}
          >
            + Date Range
          </StyledButton>
        </ButtonGroup>
      </Header>
      <Calandar
        month={month}
        year={year}
        changeKey={key}
        parentState={state}
        setParentState={setState}
      />
      <DateRangeForm
        month={month}
        year={year}
        showModal={showModal}
        setModal={setModal}
        state={state}
        setState={setState}
      />
      <DayOfWeekDialog
        showWeekDialog={showWeekDialog}
        setWeekDialog={setWeekDialog}
        state={state}
      />
    </Container>
  );
};

export default HolidaySettings;

const ButtonGroup = styled.div`
  width: 25%;
  display: flex;
  justify-content: space-between;
`;
const RangeSelector = styled.div`
  display: flex;
  justify-content: space-between;
  width: 27%;
`;
const Container = styled.div``;
const Header = styled.div`
  padding: 10px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const Heading = styled.p`
  margin: 0;
  font-size: 24px;
  font-weight: bold;
`;
const StyledButton = styled(Button)`
  &&,
  &&:hover {
    background: #5447a0;
    border-radius: 50px;
    padding-right: 35px;
    text-transform: capitalize;
  }
  &&.range {
    background: #1d39a4;
  }
  span {
    position: relative;
    z-index: 100;
  }
`;
