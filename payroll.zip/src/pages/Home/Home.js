import React, { useEffect, useState } from "react";
import styled from "styled-components";
import CalandarNav from "../../components/CalandarNav/CalandarNav";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { styled as styles, alpha } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";

import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { Box, Tooltip } from "@mui/material";
import { BASE_URL } from "../../axiosConfig";
import RequestLoader from "./components/RequestLoader";

const Home = () => {
  const access = document.cookie ? document.cookie.split("VBID=")[1] : "";
  const [state, setState] = useState({
    date: "",
    data: [],
    loading: true,
  });

  useEffect(async () => {
    await onStartChat();
  }, []);

  const onStartChat = async () => {

    await BASE_URL.get("users")
      .then((response) => {
        console.log(response);
        setState({ ...state, data: response.data, loading: false });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const DateChange = (newValue) => {
    console.log(newValue);
    setState({ ...state, date: newValue });
  };
  console.log(state);
  return (
    <Container>
      <CalandarNav handleChange={DateChange} />
      <CardItems />
      <RequestBox data={state.data} loading={state.loading} />
    </Container>
  );
};

export default Home;

const Container = styled.div``;

// accordian
function SimpleAccordion({ data, loading }) {
  const [expand, setExpand] = useState(0);
  const requestDate = [
    {
      id: 1,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "pending",
      reason: "Health Issue",
    },
    {
      id: 2,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 3,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "rejected",
      reason: "Health Issue",
    },
    {
      id: 4,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "rejected",
      reason: "Health Issue",
    },
    {
      id: 5,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 6,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 7,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 8,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 9,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
    {
      id: 10,
      date: "02",
      month: "August",
      day: "Monday",
      name: "savad farooque",
      onDate: "26 October 2021",
      status: "approved",
      reason: "Health Issue",
    },
  ];
  return loading ? (
    <AccordianContainer>
      <RequestLoader />
    </AccordianContainer>
  ) : (
    <AccordianContainer>
      {data.map((i) => (
        <Accordion expanded={expand === i.id}>
          <AccordionSummary
            expandIcon={
              <Tooltip title={expand === i.id ? "Shrink" : "Expand"}>
                <ExpandMoreIcon
                  onClick={() => setExpand(expand === i.id ? 0 : i.id)}
                />
              </Tooltip>
            }
            aria-controls="panel1a-content"
          >
            <Typography width={"100%"}>
              <EntityDetailsContainer>
                <DateContainer>
                  <DateText>02</DateText>
                  <MonthContainer>
                    <MonthText>August</MonthText>
                    <DayText>Monday</DayText>
                  </MonthContainer>
                </DateContainer>
                <EntityDetails>
                  <EntityNameText>{i.name}</EntityNameText>
                  <EntityDateDetails>
                    <OnText>On</OnText>
                    <FullDateText>26 October 2021</FullDateText>
                  </EntityDateDetails>
                </EntityDetails>
                <RequestOption status={i.status} />
              </EntityDetailsContainer>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              <ReasonHeadingText>Reason</ReasonHeadingText>
              <ReasonText>Health Issue</ReasonText>
            </Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </AccordianContainer>
  );
}
const ReasonHeadingText = styled.p`
  margin: 0;
  margin-bottom: 3px;
  font-size: 12px;
  font-weight: bold;
`;
const ReasonText = styled.p`
  margin: 0;
  margin-bottom: 3px;
  font-size: 12px;
`;
const EntityDetailsContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const EntityDetails = styled.div``;
const EntityNameText = styled.p`
  margin: 0;
  font-weight: bold;
  font-size: 12px;
`;
const EntityDateDetails = styled.div`
  display: flex;
`;
const OnText = styled.p`
  margin: 0;
  margin-right: 5px;
  font-size: 10px;
  color: #1f920a;
`;
const FullDateText = styled.p`
  margin: 0;
  font-size: 10px;
`;

const DateContainer = styled.div`
  display: flex;
  align-items: center;
  margin-right: 10px;
`;
const DateText = styled.p`
  margin: 0;
  margin-right: 10px;
  font-weight: bold;
  font-size: 20px;
`;
const MonthContainer = styled.div``;
const MonthText = styled.p`
  margin: 0;
  font-size: 10px;
  color: #7d7d7d;
`;
const DayText = styled.p`
  margin: 0;
  font-size: 10px;
`;

// accordian ends
const AccordianContainer = styled.div`
  padding: 10px;
  & .MuiButtonBase-root.MuiAccordionSummary-root {
    margin-bottom: 10px;
    border-radius: 5px;
  }
  & .css-sh22l5-MuiButtonBase-root-MuiAccordionSummary-root.Mui-expanded {
    background: #fbfbfb;
  }
  & .css-15v22id-MuiAccordionDetails-root,
  .css-sh22l5-MuiButtonBase-root-MuiAccordionSummary-root {
    background: #fbfbfb;
    border-radius: 5px;
  }
  overflow-x: scroll;
  &::-webkit-scrollbar {
    display: none;
  }
  height: 410px;
  scrollbar-width: none;
`;
// accordian

// request options
const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 100,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

function RequestOption() {
  const [work, setWork] = React.useState("pending");

  const handleChange = (event) => {
    setWork(event.target.value);
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      font-size: 13px;
      padding: 5px;

      ${({ work }) => work === "rejected" && `background: #cf0d00; color:#fff;`}
      ${({ work }) => work === "pending" && `background: #1d5194; color:#fff;`}
           ${({ work }) =>
        work === "approved" && `background: #1f920a; color:#fff;`}
      min-width: min-content;
    }
    svg {
      color: #fff;
    }
    span {
      margin: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"pending"} className="pending">
              Pending
            </MenuItem>
            <MenuItem value={"approved"} className="approved">
              Approved
            </MenuItem>
            <MenuItem value={"rejected"} className="rejected">
              Rejected
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
// function RequestOption({ status }) {
//   const [anchorEl, setAnchorEl] = React.useState(null);
//   const open = Boolean(anchorEl);
//   const handleClick = (event) => {
//     setAnchorEl(event.currentTarget);
//   };
//   const handleClose = () => {
//     setAnchorEl(null);
//   };

//   return (
//     <RequestOptionContainer>
//       <StyledButton
//         status={status}
//         id="demo-customized-button"
//         aria-controls={open ? "demo-customized-menu" : undefined}
//         aria-haspopup="true"
//         aria-expanded={open ? "true" : undefined}
//         variant="contained"
//         disableElevation
//         onClick={handleClick}
//         endIcon={<KeyboardArrowDownIcon />}
//         size="small"
//       >
//         {status}
//       </StyledButton>
//       <StyledMenu
//         id="demo-customized-menu"
//         MenuListProps={{
//           "aria-labelledby": "demo-customized-button",
//         }}
//         anchorEl={anchorEl}
//         open={open}
//         onClose={handleClose}
//       >
//         <MenuItem onClick={handleClose} disableRipple>
//           Approved
//         </MenuItem>
//         <MenuItem onClick={handleClose} disableRipple>
//           Rejected
//         </MenuItem>
//       </StyledMenu>
//     </RequestOptionContainer>
//   );
// }
const RequestOptionContainer = styled.div`
  margin-right: 10px !important;
`;
const StyledButton = styled(Button)`
  && {
    font-size: 12px !important;
    ${({ status }) =>
      status === "approved" &&
      `
  background: green !important;
  
  `}
    ${({ status }) =>
      status === "rejected" &&
      `
  background: red !important;
  
  `}

${({ status }) =>
      status === "pending" &&
      `
  background: #1d5194 !important;
  
  `}
  }
`;
// request options

// menubutton

function SelectLabels() {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <StyledSelect>
      <FormControl>
        <Select
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </StyledSelect>
  );
}
const StyledSelect = styled.div`
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
// menubutton

// request box
const RequestBox = ({ data, loading }) => {
  return (
    <RequestContainer>
      <RequestBlock>
        <RequestTopContainer>
          <RequestHeadingContainer>
            <RequestHeading>Leave Requests</RequestHeading>
            <SelectLabels />
          </RequestHeadingContainer>
        </RequestTopContainer>
        <SimpleAccordion data={data} loading={loading} />
      </RequestBlock>
      <RequestBlock>
        <RequestTopContainer>
          <RequestHeadingContainer>
            <RequestHeading>Advance Requests</RequestHeading>
            <SelectLabels />
          </RequestHeadingContainer>
        </RequestTopContainer>
        <SimpleAccordion data={data} loading={loading} />
      </RequestBlock>
      <RequestBlock>
        <RequestTopContainer>
          <RequestHeadingContainer>
            <RequestHeading>Load Requests</RequestHeading>
            <SelectLabels />
          </RequestHeadingContainer>
        </RequestTopContainer>
        <SimpleAccordion data={data} loading={loading} />
      </RequestBlock>
    </RequestContainer>
  );
};

const RequestTopContainer = styled.div`
  padding: 10px;
`;

const RequestHeadingContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;

const RequestContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
`;
const RequestBlock = styled.div`
  width: 32.8%;
  height: 500px;
  border: 1px solid #ccc;
  border-radius: 3px;
  background: #fff;
`;
const RequestHeading = styled.div`
  font-weight: bold;
  font-size: 16px;
`;
// request box

// card items
const CardItems = () => {
  const cardDate = [
    {
      heading: "Unmarked",
      count: 0,
      color: "grey",
    },
    {
      heading: "Present",
      count: 10,
      color: "#31b88c",
    },
    {
      heading: "Absent",
      count: 8,
      color: "#e54d4d",
    },
    {
      heading: "Late",
      count: 6,
      color: "#f8ba5a",
    },
    {
      heading: "Half Day",
      count: 2,
      color: "#f88229",
    },
    {
      heading: "Paid Leave",
      count: 1,
      color: "#3ea4e9",
    },
  ];
  return (
    <CardContainer>
      {cardDate.map((i) => (
        <Card color={i.color}>
          <CardHeading>{i.heading}</CardHeading>
          <CardCount color={i.color}>{i.count}</CardCount>
        </Card>
      ))}
    </CardContainer>
  );
};
const CardContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const Card = styled.div`
  width: 14%;
  border: 2px solid ${({ color }) => color};
  padding: 1%;
  border-radius: 3px;

  p {
    margin: 0;
  }
`;
const CardHeading = styled.p`
  margin-bottom: 5px;
  font-weight: bold;
`;
const CardCount = styled.p`
  font-weight: bold;
  font-size: 23px;
  color: ${({ color }) => color};
`;
// card items ends here
