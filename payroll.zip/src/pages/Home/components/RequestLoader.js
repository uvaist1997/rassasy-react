import React from "react";
import ContentLoader from "react-content-loader";
import _ from "lodash";

const RequestLoader = (props) => {
  return (
    <ContentLoader
      speed={2}
      width={410}
      height={500}
      viewBox="0 0 410 500"
      backgroundColor="#d9d9d9"
      foregroundColor="#ededed"
      {...props}
    >
      {_.range(15).map((i, index) => (
        <rect x="0" y={6 + 54 * index} rx="4" ry="4" width="410" height="45" />
      ))}
    </ContentLoader>
  );
};

RequestLoader.metadata = {
  name: "Abraham Calsin",
  github: "abrahamcalsin",
  description: "Loading a list of tasks.",
  filename: "RequestLoader",
};

export default RequestLoader;
