import React, { lazy, Suspense } from "react";
import styled from "styled-components";
import { Link, NavLink, Route, Routes as Switch } from "react-router-dom";
import { ButtonBase, CircularProgress } from "@mui/material";
import Header from "../../components/Header/Header";

const HolidaySettings = lazy(() =>
  import("../Settings/HolidaySettings/HolidaySettings")
);
const SalaryPackageSettings = lazy(() =>
  import("../Settings/SalaryPackageSettings/SalaryPackageSettings")
);
const GroupSettings = lazy(() =>
  import("../Settings/GroupSettings/GroupSettings")
);
const Help = lazy(() => import("../Help/Help"));
const Employee = lazy(() => import("../Employee/Employee"));
const AddEmployee = lazy(() => import("../Employee/AddEmployee"));
const Settings = lazy(() => import("../Settings/Settings"));
const SalaryStructure = lazy(() =>
  import("../Settings/SalaryStructure/SalaryStructure")
);
const Home = lazy(() => import("../Home/Home"));
const Employees = lazy(() => import("../Employee/Employees"));
const Attendance = lazy(() => import("../Attendance/Attendance"));
const Report = lazy(() => import("../Report/Report"));
const AdminSettings = lazy(() =>
  import("../Settings/AdminSettings/AdminSettings")
);

const Navigation = () => {
  const image_root = window.location.origin;
  const MenuList = [
    {
      label: "Home",
      image: image_root + "/images/icons/home.svg",
      link: "/dashboard/",
    },
    {
      label: "Employee",
      image: image_root + "/images/icons/employee.svg",
      link: "/dashboard/employees",
      isActive: ["/dashboard/sales", "/dashboard/create-sales"],
    },
    {
      label: "Attendance",
      image: image_root + "/images/icons/attendance.svg",
      link: "/dashboard/attendance",
    },
    {
      label: "Report",
      image: image_root + "/images/icons/report.svg",
      link: "/dashboard/report",
    },
  ];
  return (
    <Container>
      <SideNavigation>
        {MenuList.map((i, index) => (
          <Menu key={index} to={i.link}>
            <ButtonBase
              style={{
                borderRadius: "10px",
              }}
            >
              <MenuIconContainer>
                <MenuIcon src={i.image} />
              </MenuIconContainer>
            </ButtonBase>
            <MenuText>{i.label}</MenuText>
          </Menu>
        ))}
      </SideNavigation>
      <ViewPort>
        <Header />
        <Main>
          <Suspense
            fallback={
              <Box>
                <CircularProgress />
              </Box>
            }
          >
            <Switch>
              <Route path="/" element={<Home />} />
              <Route path="/employees" element={<Employees />} />
              <Route path="/attendance" element={<Attendance />} />
              <Route path="/report" element={<Report />} />
              <Route path="/employee" element={<Employee />} />
              <Route path="/add-employee" element={<AddEmployee />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/salary-structure" element={<SalaryStructure />} />
              <Route path="/admin-settings" element={<AdminSettings />} />
              <Route path="/group-settings" element={<GroupSettings />} />
              <Route
                path="/salary-package-settings"
                element={<SalaryPackageSettings />}
              />
              <Route path="/holiday-settings" element={<HolidaySettings />} />
              <Route path="/help" element={<Help />} />
            </Switch>
          </Suspense>
        </Main>
      </ViewPort>
    </Container>
  );
};

export default Navigation;

const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;

const Container = styled.div`
  display: flex;
  /* @media (max-width: 460px) {
    position: relative;
    height: 100vh;
  } */
`;
const SideNavigation = styled.div`
  min-width: 80px;
  width: 6%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  background: #f9f9f9;
  border-right: 1px solid #ccc;
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 100;
  /* @media (max-width: 460px) {
    width: 100%;
    flex-direction: row;
    top: initial;
    padding: 10px 0;
    height: 140px;
    position: absolute;
  } */
`;
const MenuIconContainer = styled.div`
  background: #eceff9;
  width: 20px;
  height: 20px;
  padding: 10px;
  margin: 0 auto;
  border-radius: 10px;
  transition: all 0.2s ease-in;
  /* @media (max-width: 460px) {
    width: 60px;
    height: 60px;
  } */
`;
const MenuIcon = styled.img`
  width: 20px;
  height: 20px;
  transition: all 0.2s ease-in;
  && path {
    fill: #fff !important;
  }

  /* @media (max-width: 460px) {
    width: 60px;
    height: 60px;
  } */
`;
const Menu = styled(NavLink)`
  && {
    margin: 0 auto;

    cursor: pointer;
    text-align: center;
    text-decoration: none;
  }
  &&.active,
  &&:hover {
    ${MenuIconContainer} {
      background: #5447a0;
      box-shadow: 0px 6px 14px 5px #0000004f;
      transition: all 0.2s ease-in;
    }
    ${MenuIcon} {
      transition: all 0.2s ease-in;
      filter: brightness(0) invert(1);
    }
  }
  /* @media (max-width: 460px) {
    display: flex;
  } */
`;

const MenuText = styled.p`
  color: #000;
  font-size: 10px;
  margin: 5px 0 10px;
  color: #5447a0;
  /* @media (max-width: 460px) {
    margin-bottom: 0;
    display: none;
  } */
`;

const ViewPort = styled.div`
  width: 94%;
  padding-left: 6%;
  /* @media (max-width: 460px) {
    width: 100%;
    overflow-x: scroll;
    padding-left: 0;
  } */
`;

const Main = styled.div`
  min-height: calc(100% - 61px);
  padding: 10px;
`;
