import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import CustomizedMenus from "../../Employee/attendance/components/CustomizedMenus";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Fade from "@mui/material/Fade";

const AttendanceOverview = () => {
  const [showModal, setModal] = useState(false);
  return (
    <Container>
      <Division className="name">
        <OverallText>Days</OverallText>
        <AmountText>28</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Present</OverallText>
        <AmountText>28</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Absent</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Half Day</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Paid Leave</OverallText>
        <AmountText>0</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Overtime</OverallText>
        <AmountText>00:00</AmountText>
      </Division>
      <Division className="name">
        <OverallText>Late Hours</OverallText>
        <AmountText>00:00</AmountText>
      </Division>
      <Division className="button">
        <FadeMenu />
      </Division>
    </Container>
  );
};

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f1f2fc;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
`;

const AmountText = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 0;
  margin-bottom: 4px;
`;

const Division = styled.div`
  width: 17%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  &.name {
    width: 10%;
  }
  &.select {
    width: 16%;
  }
  &.button.dropdown {
    width: 25%;
  }
  &.button {
    width: 15%;
    text-align: right;
    button {
      background: #185a6d;
      font-family: "Poppins";
      text-transform: capitalize;
    }
  }
  &.amount {
    align-items: flex-end;
    width: 17%;
  }
`;

const OverallText = styled.div`
  color: #6d6d6d;
`;

export default AttendanceOverview;

function FadeMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <StyledSelectButton
        id="fade-button"
        aria-controls={open ? "fade-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
      >
        Daily Report
      </StyledSelectButton>
      <Menu
        id="fade-menu"
        MenuListProps={{
          "aria-labelledby": "fade-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        TransitionComponent={Fade}
      >
        <MenuItem onClick={handleClose}>Download PDF</MenuItem>
        <MenuItem onClick={handleClose}>Share Via Mail</MenuItem>
        <MenuItem onClick={handleClose}>Print Now</MenuItem>
      </Menu>
    </div>
  );
}
const StyledSelectButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #fff;
    background: #1d39a4 !important;
  }
  && svg {
    color: #fff;
  }
`;
