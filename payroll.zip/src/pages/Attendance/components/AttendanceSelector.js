import { Button } from "@mui/material";
import React, { useState } from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import CustomizedMenus from "../../Employee/attendance/components/CustomizedMenus";

const AttendanceSelector = () => {
  const [showModal, setModal] = useState("");
  return (
    <>
      <AttendanceSelectorBox>
        <DayContainer>
          <DayText>Savad Farooque</DayText>
        </DayContainer>
        <PresentTypeContainer>
          <PresentType className="present">Present</PresentType>
          <PresentType className="half-day">Half Day</PresentType>
          <PresentType className="absent">Absent</PresentType>
          <PresentType className="late" onClick={() => setModal("late")}>
            Late
          </PresentType>
          <PresentType
            className="overtime"
            onClick={() => setModal("overtime")}
          >
            Overtime
          </PresentType>
          <PresentType className="paid-leave">Paid Leave</PresentType>
          <CustomizedMenus />
        </PresentTypeContainer>
      </AttendanceSelectorBox>
    </>
  );
};

export default AttendanceSelector;

const AttendanceSelectorBox = styled.div`
  display: flex;
  justify-content: space-between;
  background: #f8f8f8;
  padding: 10px 20px;
  border-radius: 10px;
  border: 1px solid #ccc;
  transition: all 0.1s ease-in;
  margin-bottom: 10px;
  &:hover {
    background: #f8d5d5;
    transition: all 0.1s ease-in;
  }
`;
const DayText = styled.div`
  font-size: 20px;
  font-weight: bold;

  span {
    color: #767676;
    font-size: 16px;
    margin-left: 10px;
    font-weight: normal;
  }
`;
const DayContainer = styled.div``;
const NoteButton = styled.button`
  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
`;
const PresentTypeContainer = styled.div`
  width: 55%;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const PresentType = styled(Button)`
  && {
    text-transform: capitalize;
    color: #000;
    background: #fff;
    border: 1px solid #000;
    padding: 5px 20px;
  }
  &&.present:hover {
    background: #25976a;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.half-day:hover {
    background: #f76f00;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.absent:hover {
    background: #f74344;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.late:hover {
    background: #f59300;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.overtime:hover {
    background: #3ccfc1;
    color: #fff;
    border: 1px solid transparent;
  }
  &&.paid-leave:hover {
    background: #3389e1;
    color: #fff;
    border: 1px solid transparent;
  }
`;
