import { ButtonBase, CircularProgress } from "@mui/material";
import React, { useEffect, useState } from "react";
import styled from "styled-components";
import ViewListIcon from "@mui/icons-material/ViewList";
import DashboardIcon from "@mui/icons-material/Dashboard";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import CalandarRange from "../../components/CalandarNav/CalandarRange";
import AttendanceOverview from "./components/AttendanceOverview";
import AttendanceSelector from "./components/AttendanceSelector";
import SearchIcon from "@mui/icons-material/Search";
import Autocomplete from "@mui/material/Autocomplete";
import TextField from "@mui/material/TextField";

const Attendance = () => {
  const [age, setAge] = useState("");
  const [showMenu, setMenu] = useState("list");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <Container>
      <Header>
        <Heading>Daily Attendance</Heading>
        <CalendarContainer>
          <CalandarRange />
        </CalendarContainer>
      </Header>
      <AttendanceOverview />
      <TopContainer>
        <SearchButton />
        <SelectOptions />
      </TopContainer>
      <AttendanceSelectorContainer>
        <SmallHeading>Monthly</SmallHeading>
        <AttendanceSelector />
      </AttendanceSelectorContainer>
      <AttendanceSelectorContainer>
        <SmallHeading>Hourly</SmallHeading>
        <AttendanceSelector />
      </AttendanceSelectorContainer>
    </Container>
  );
};

export default Attendance;

const TopContainer = styled.div`
  display: flex;
  width: 100%;
`;
const Container = styled.div``;
const Heading = styled.p`
  font-size: 24px;
  font-weight: bold;
  margin: 10px 0;
`;
const SmallHeading = styled.p`
  font-size: 18px;
  font-weight: bold;
  margin: 10px 0;
`;
const CalendarContainer = styled.div`
  width: 55%;
  display: flex;
  justify-content: flex-end;
`;
const ActionMenu = styled.div`
  display: flex;
  align-items: center;
`;

const IconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 30px;
  height: 30px;
  border-radius: 3px;
  transition: all 0.2s ease-in;
  cursor: pointer;
  svg {
    color: #185a6d;
  }

  &:hover {
    background: #185a6d;
    svg {
      color: #fff;
    }
    transition: all 0.2s ease-in;
  }
  ${({ showMenu }) =>
    showMenu &&
    `
      background: #185a6d;
    svg {
      color: #fff;
    }
  `}
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline{
    border-radius:30px;
  }
  div[role="button"]{
    padding-top:5px;
    padding-bottom:5px;
  }
  j
`;
const FilterLabel = styled.p`
  margin: 0;
`;
const ShowTypeContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin: 0 10px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
`;
const AttendanceSelectorContainer = styled.div`
  overflow-y: scroll;
  &::-webkit-scrollbar {
    display: none;
  }
  scrollbar-width: none;
`;
const Divider = styled.div`
  width: 1px;
  height: 30px;
  background: #ccc;
  margin: 0 5px;
`;

const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;

function FullCalendarApp() {
  const events = [
    {
      start: "2022-02-19",
      title: "test event",
      description: "This is a test description of an event",
      data: "you can add what ever random data you may want to use later",
    },
    {
      start: "2022-02-20",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-21",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-22",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-23",
      eventClasses: "optionalEvent",
      title: "test event",
      description: "This is a test description of an event",
    },
    {
      start: "2022-02-24",
      eventClasses: "optionalEvent",
      title: "test event",
    },
    {
      start: "2022-02-25",
      eventClasses: "optionalEvent",
      title: "test event",
    },
  ];
  function renderEventContent(eventInfo, a, e) {
    return (
      <>
        <button
          style={{
            width: "100%",
            background: "#fff",
            border: 0,
            display: "block",
            marginTop: 10,
          }}
          onClick={() => console.log(eventInfo)}
        >
          Add Note
        </button>
        <div>
          <SelectLabels />
        </div>
      </>
    );
  }

  return (
    <FullCalandarContainer>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        events={events}
        select={(eventData) => console.log(eventData)}
        selectable="true"
        // dateClick={(eventData) => window.alert(eventData.date)}
        eventContent={(e) => renderEventContent(e)}
      />
    </FullCalandarContainer>
  );
}

const FullCalandarContainer = styled.div`
  .fc-col-header-cell-cushion {
    font-size: 25px;
    text-transform: uppercase;
  }
  .fc-daygrid-day-top {
    flex-direction: row;
  }
  .fc-daygrid-day-top .fc-daygrid-day-number {
    font-size: 24px;
  }
  .fc-h-event {
    background: #fff;
    border: 0;
  }
`;

function SelectLabels() {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <FormControl sx={{ m: 1, minWidth: 120 }}>
      <Select
        size="small"
        value={age}
        onChange={handleChange}
        displayEmpty
        inputProps={{ "aria-label": "Without label" }}
      >
        <MenuItem value="">
          <em>None</em>
        </MenuItem>
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    </FormControl>
  );
}

function SearchButton() {
  // Top films as rated by IMDb users. http://www.imdb.com/chart/top
  const topFilms = [
    { title: "The Shawshank Redemption", year: 1994 },
    { title: "The Godfather", year: 1972 },
    { title: "The Godfather: Part II", year: 1974 },
    { title: "The Dark Knight", year: 2008 },
    { title: "12 Angry Men", year: 1957 },
    { title: "Schindler's List", year: 1993 },
    { title: "Pulp Fiction", year: 1994 },
    {
      title: "The Lord of the Rings: The Return of the King",
      year: 2003,
    },
    { title: "The Good, the Bad and the Ugly", year: 1966 },
    { title: "Fight Club", year: 1999 },
    {
      title: "The Lord of the Rings: The Fellowship of the Ring",
      year: 2001,
    },
    {
      title: "Star Wars: Episode V - The Empire Strikes Back",
      year: 1980,
    },
    { title: "Forrest Gump", year: 1994 },
    { title: "Inception", year: 2010 },
    {
      title: "The Lord of the Rings: The Two Towers",
      year: 2002,
    },
    { title: "One Flew Over the Cuckoo's Nest", year: 1975 },
    { title: "Goodfellas", year: 1990 },
    { title: "The Matrix", year: 1999 },
    { title: "Seven Samurai", year: 1954 },
    {
      title: "Star Wars: Episode IV - A New Hope",
      year: 1977,
    },
    { title: "City of God", year: 2002 },
    { title: "Se7en", year: 1995 },
    { title: "The Silence of the Lambs", year: 1991 },
    { title: "It's a Wonderful Life", year: 1946 },
    { title: "Life Is Beautiful", year: 1997 },
    { title: "The Usual Suspects", year: 1995 },
    { title: "Léon: The Professional", year: 1994 },
    { title: "Spirited Away", year: 2001 },
    { title: "Saving Private Ryan", year: 1998 },
    { title: "Once Upon a Time in the West", year: 1968 },
    { title: "American History X", year: 1998 },
    { title: "Interstellar", year: 2014 },
  ];
  // action group ends

  function sleep(delay = 0) {
    return new Promise((resolve) => {
      setTimeout(resolve, delay);
    });
  }
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState([]);
  const loading = open && options.length === 0;

  useEffect(() => {
    let active = true;

    if (!loading) {
      return undefined;
    }

    (async () => {
      await sleep(1e3); // For demo purposes.

      if (active) {
        setOptions([...topFilms]);
      }
    })();

    return () => {
      active = false;
    };
  }, [loading]);

  useEffect(() => {
    if (!open) {
      setOptions([]);
    }
  }, [open]);

  return (
    <SearchContainer>
      <Autocomplete
        popupIcon={""}
        size="small"
        id="asynchronous-demo"
        sx={{ width: "100%" }}
        open={open}
        onOpen={() => {
          setOpen(true);
        }}
        onClose={() => {
          setOpen(false);
        }}
        isOptionEqualToValue={(option, value) => option.title === value.title}
        getOptionLabel={(option) => option.title}
        options={options}
        loading={loading}
        renderInput={(params) => (
          <TextField
            placeholder="Search Staff"
            {...params}
            InputProps={{
              ...params.InputProps,
              endAdornment: (
                <React.Fragment>
                  {loading ? (
                    <CircularProgress color="inherit" size={20} />
                  ) : null}
                  {params.InputProps.endAdornment}
                </React.Fragment>
              ),
              startAdornment: (
                <React.Fragment>
                  <SearchIcon style={{ cursor: "pointer" }} />
                </React.Fragment>
              ),
            }}
          />
        )}
      />
    </SearchContainer>
  );
}
const SearchContainer = styled.div`
  && {
    background: #f9f9f9;
    border-radius: 10px;
    width: 50%;
  }
`;

// selectbox
// menubutton
function SelectOptions() {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <StyledSelect>
      <FormControl>
        <Select
          size="small"
          value={age}
          onChange={handleChange}
          displayEmpty
          inputProps={{ "aria-label": "Without label" }}
        >
          <MenuItem value="">All</MenuItem>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    </StyledSelect>
  );
}
const StyledSelect = styled.div`
  width: 100px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
// menubutton
// selectboxends
