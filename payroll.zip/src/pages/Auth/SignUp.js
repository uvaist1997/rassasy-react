import React from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components";
import InputField from "../../components/InputField/InputField";
import { motion } from "framer-motion";
import Loader from "../../components/Loader/Loader";
import { authFadeInUpVariants, staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { Navigate, useNavigate } from "react-router-dom";

const SignUp = () => {
  const navigate = useNavigate();
  const isLoading = false;
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onBlur",
  });
  const onSubmit = (data) => {
    const { email, password } = data;
  };
  return (
    <Container>
      <Form
        variants={staggerOne}
        initial="initial"
        animate="animate"
        exit="exit"
        className="SignIn__form"
        onSubmit={handleSubmit(onSubmit)}
      >
        <LogoContainer>
          <Logo src="images/vikncodes.svg" />
        </LogoContainer>
        <SmallHeading text="Create your Vikn account " align="left" />
        <InputTwinGroup>
          <InputField
            width="48%"
            type="text"
            name="firstname"
            placeholder="First Name"
            validationMessage="Please enter your first name."
            validation={register("firstname", {
              required: true,
            })}
            errors={errors}
            disabled={isLoading}
          />
          <InputField
            width="48%"
            type="text"
            name="lastname"
            placeholder="Last Name"
            validationMessage="Please enter your last name."
            validation={register("lastname", {
              required: true,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputTwinGroup>
        <InputGroup>
          <InputField
            type="email"
            name="email"
            placeholder="Your Email Address"
            validationMessage="Please enter a valid email address."
            message="This will be used for verification."
            validation={register("email", {
              required: true,
              pattern:
                /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputGroup>
        <InputTwinGroup>
          <InputField
            width="48%"
            type="text"
            name="country"
            placeholder="Country"
            validationMessage="Please select a country."
            validation={register("country", {
              required: true,
            })}
            errors={errors}
            disabled={isLoading}
          />
          <InputField
            width="48%"
            type="text"
            name="phone"
            placeholder="Phone"
            validationMessage="Please enter a valid phone number."
            validation={register("phone", {
              required: true,
              pattern:
                /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputTwinGroup>
        <InputTwinGroup>
          <InputField
            width="48%"
            type="text"
            name="password"
            placeholder="Password"
            validationMessage="The password should have a length between 6 and 30 characters."
            validation={register("password", {
              required: true,
              minLength: 6,
              maxLength: 30,
            })}
            errors={errors}
            disabled={isLoading}
          />
          <InputField
            width="48%"
            type="text"
            name="confirm_password"
            placeholder="Confirm"
            validationMessage="The password should have a length between 6 and 30 characters."
            validation={register("confirm_password", {
              required: true,
              minLength: 6,
              maxLength: 30,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputTwinGroup>
        {!errors.password && (
          <MessageText>
            Use 8 or more characters with a mix of letters, numbers & symbols
          </MessageText>
        )}

        <BottomButtonContainer>
          <Button
            background="#fff"
            color="#276eb5"
            text="Sign In Instead"
            onClick={() => navigate("/")}
            type="button"
          ></Button>
          <Button
            color="#fff"
            background="#155e4b"
            text="Sign up"
            type="submit"
          ></Button>
        </BottomButtonContainer>
      </Form>
    </Container>
  );
};

export default SignUp;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: #fff;
  overflow: hidden;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  background: #fff;
  width: 420px;
  min-height: 300px;
  height: max-content;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 2px;
  @media (max-width: 460px) {
    width: 100%;
    min-width: 200px;
  }
`;
const InputGroup = styled.div``;
const BottomButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 55px;
`;
const ForgotPasswordContainer = styled.div`
  text-align: right;
`;

const ForgotPasswordButton = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  margin-bottom: 20px;
  border-radius: 3px;
  color: ${({ color }) => color};
  background: ${({ background }) => background};
`;
const Logo = styled.img`
  width: 120px;
`;
const LogoContainer = styled.div`
  text-align: left;
  margin: 10px 0;
`;
const InputTwinGroup = styled.div`
  display: flex;
  justify-content: space-between;
  @media (max-width: 460px) {
    display: block;
  }
`;
const MessageText = styled.p`
  margin-top: 0.4em;
  font-size: 13px;
  color: #727272;
  min-height: 10px;
  margin-bottom: 0;
`;
