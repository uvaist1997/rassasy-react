import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components";
import InputField from "../../components/InputField/InputField";
import { motion } from "framer-motion";
import Loader from "../../components/Loader/Loader";
import { authFadeInUpVariants, staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { Navigate, useNavigate } from "react-router-dom";
import { getCookie } from "../../functions/utils";

const SignIn = () => {
  const navigate = useNavigate();
  const isLoading = false;
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
  });
  const onSubmit = (data) => {
    const { email, password } = data;
    console.log(email);
    console.log(password);
    console.log("hello");
  };

  const cookies = document.cookie ? document.cookie.split("VBID=")[1] : "";
  const access = getCookie("VBID");
  const [user_id, setUserId] = useState("");
  const isAuthenticated = false
  useEffect(async () => {
      if (access) {
        await handlePage(access);
      } else {
        window.open("http://localhost:3000/signin?service=payroll", "_self");
      }
    }, []);
  
  const handlePage = async (access) => {
    const companyDetailsResponse = await fetch(
      "http://localhost:8001/api/v1/organization/check-company/exist",
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${access}`,
          accept: "application/json",
        },
        body: JSON.stringify({
          // userId: loginResponse.data.user_id,
          // BranchID: BranchID,
        }),
      }
    ).then((response) => response.json());
    if (companyDetailsResponse.StatusCode === 6001) {
     navigate("/join-organization");
    } else {
      navigate("/dashboard");
    }
    
  };
  return (
    <Container>
      <Form
        variants={staggerOne}
        initial="initial"
        animate="animate"
        exit="exit"
        className="SignIn__form"
        onSubmit={handleSubmit(onSubmit)}
      >
        <LogoContainer>
          <Logo src="images/vikncodes.svg" />
        </LogoContainer>
        <SmallHeading text="Sign in with Vikn account" align="center" />
        <InputGroup>
          <InputField
            type="text"
            name="username"
            placeholder="Username"
            validationMessage="Please enter a valid username."
            validation={register("username", {
              required: true,
              pattern: /^[a-z0-9_.]+$/,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputGroup>
        <InputGroup>
          <InputField
            type="password"
            name="password"
            placeholder="Password"
            validationMessage="The password should have a length between 6 and 30 characters."
            validation={register("password", {
              required: true,
              minLength: 6,
              maxLength: 30,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputGroup>
        <ForgotPasswordContainer>
          <ForgotPasswordButton
            background="#fff"
            color="#276eb5"
            text="Forgot Password"
            type="button"
          >
            Forgot Password?
          </ForgotPasswordButton>
        </ForgotPasswordContainer>
        <BottomButtonContainer>
          <Button
            background="#fff"
            color="#276eb5"
            text="Create Account"
            type="button"
            onClick={() => navigate("/sign-up")}
          ></Button>
          <Button
            color="#fff"
            background="#155e4b"
            text="Sign In"
            type="submit"
          ></Button>
        </BottomButtonContainer>
      </Form>
    </Container>
  );
};

export default SignIn;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: #fff;
  overflow: hidden;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  background: #fff;
  width: 300px;
  min-height: 300px;
  height: max-content;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 2px;
`;
const InputGroup = styled.div``;
const BottomButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
`;
const ForgotPasswordContainer = styled.div`
  text-align: right;
  margin-top: 20px;
`;

const ForgotPasswordButton = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  margin-bottom: 20px;
  border-radius: 3px;
  color: ${({ color }) => color};
  background: ${({ background }) => background};
`;
const Logo = styled.img`
  width: 120px;
`;
const LogoContainer = styled.div`
  text-align: center;
  margin: 10px 0;
`;
