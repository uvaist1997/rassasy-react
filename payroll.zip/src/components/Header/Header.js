import React, { useEffect, useRef, useState } from "react";
import styled from "styled-components";
import LiveHelpIcon from "@mui/icons-material/LiveHelp";
import SettingsIcon from "@mui/icons-material/Settings";
import { useNavigate } from "react-router-dom";
import {
  Button,
  IconButton,
  Menu,
  MenuItem,
  Pagination,
  Tooltip,
} from "@mui/material";
import { Link, Navigate } from "react-router-dom";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { Box } from "@mui/system";
import usePagination from "../../functions/Pagination";
import { getCookie } from "../../functions/utils";

function checkWordLength(word) {
  let str = new String(word);
  let length = str.length;
  if (length > 13) {
    return true;
  }
  return false;
}

const Header = () => {
  // const cookies = document.cookie ? document.cookie.split("VBID=")[1] : "";
  const access = getCookie("VBID");
  const navigate = useNavigate();
  const [state, setState] = useState({
    companies: [],
  });
  const [showComapanyList, setComapanyList] = useState(false);
  const [showComapanyDotMenuList, setComapanyDotMenu] = useState(0);
  const PER_PAGE = 5;
  const paginated_data = usePagination(state.companies, PER_PAGE);
  let [page, setPage] = useState(1);
  // const count = Math.ceil(paginated_data.length / PER_PAGE);
    const count = state.companies
      ? Math.ceil(state.companies.length / PER_PAGE)
      : 0;
  const paginationChange = (e, p) => {
    setPage(p);
    paginated_data.jump(p);
  };

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    console.log("enter");
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    console.log("leave");
    setAnchorEl(null);
  };
    useEffect(async () => {
    await onStartChat();
    }, []);
  
  const onStartChat = async () => {
    const companyDetailsResponse = await fetch(
      "http://localhost:8000/api/v1/company/companies/",
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${access}`,
          accept: "application/json",
        },
        body: JSON.stringify({
          // userId: loginResponse.data.user_id,
          // BranchID: BranchID,
        }),
      }
    ).then((response) => response.json());
    const current_company = companyDetailsResponse.data.filter(
      (i) => i.id === companyDetailsResponse.LastLoginCompanyID
    )[0];
    let LastCompanyName = current_company.CompanyName;
    console.log(current_company);
    console.log(LastCompanyName);
    setState((prevState) => {
      return {
        ...prevState,
        companies: companyDetailsResponse.data,
        LastLoginCompanyID: companyDetailsResponse.LastLoginCompanyID,
        LastCompanyName: LastCompanyName
      };
    });
  };

  return (
    <Container>
      <LeftContainer>
        <CompanyContainer onClick={handleClick}>
          <CompanyLogo src="../images/vikncodes-logo.svg" />
          <CompanyNameText>{state.LastCompanyName? state.LastCompanyName : "Vikn"}</CompanyNameText>
        </CompanyContainer>
        <HelpButtonContainer onClick={() => navigate("/dashboard/help")}>
          <LiveHelpIcon />
          <HelpText>Help</HelpText>
        </HelpButtonContainer>
      </LeftContainer>
      <RightContainer>
        <NameText>Savad Farooque</NameText>
        <EntityImage src="../images/vikncodes-logo.svg" />
        <SettingsIcon onClick={() => navigate("/dashboard/settings")} />
      </RightContainer>
      <CompanyDropDown
        showComapanyList={true}
        showComapanyDotMenuList={showComapanyDotMenuList}
        setComapanyDotMenu={setComapanyDotMenu}
        paginated_data={paginated_data}
        paginationChange={paginationChange}
        setPage={setPage}
        count={count}
        page={page}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
        anchorEl={anchorEl}
      />
    </Container>
  );
};

export default Header;

const Container = styled.div`
  height: 60px;
  background: #fff;
  border-bottom: 1px solid #ccc;
  padding: 10px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
`;

const CompanyContainer = styled.div`
  background: #eceff9;
  max-width: 250px;
  max-height: 30px;
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  border-radius: 50px;
  display: flex;
  align-items: center;
  padding: 5px;
  padding-right: 20px;
  cursor: pointer;
`;
const CompanyLogo = styled.img`
  width: 30px;
  height: 30px;
  margin-right: 10px;
  border-radius: 50%;
  object-fit: contain;
  background: #ffffff;
  padding: 3px;
  box-sizing: border-box;
`;
const CompanyNameText = styled.div`
  font-weight: bold;
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
`;
const LeftContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  width: 50%;
  align-items: center;
`;
const RightContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  width: 50%;
  align-items: center;
  svg {
    color: #3d3d3d;
    font-size: 25px;
    cursor: pointer;
  }
`;
const HelpText = styled.p`
  margin: auto 0;
  font-size: 12px;
  font-weight: bold;
`;
const HelpButtonContainer = styled.div`
  cursor: pointer;
  display: flex;
  margin-left: 10px;
  svg {
    color: #5447a0;
  }
`;
const NameText = styled.p`
  margin: auto 0;
  font-weight: bold;
  font-size: 14px;
`;
const EntityImage = styled.img`
  width: 34px;
  height: 34px;
  object-fit: contain;
  margin: 0 15px;
  background: linear-gradient(
    0deg,
    rgba(48, 126, 217, 0.4906337535014006) 0%,
    rgba(41, 110, 190, 1) 100%
  );
  box-sizing: border-box;
  padding: 3px;
  border-radius: 3px;
`;

const CompanyDropDown = ({
  showComapanyList,
  showComapanyDotMenuList,
  setComapanyDotMenu,
  paginated_data,
  paginationChange,
  count,
  state,
  page,
  handleClose,
  handleClick,
  open,
  anchorEl,
}) => {
  const handleDotMenu = (e) => {
    if (e.currentTarget.dataset.dotMenuId === showComapanyDotMenuList) {
      setComapanyDotMenu(0);
    } else {
      setComapanyDotMenu(e.currentTarget.dataset.dotMenuId);
    }
  };
  const switch_company = (id) => {
    console.log(">>>>>>>>>>>>>>???????????????")
   console.log(id) 
  }
  return (
    <React.Fragment>
      <StyledMenu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: 3,
          },
        }}
        transformOrigin={{ horizontal: "center", vertical: "top" }}
        anchorOrigin={{ horizontal: "center", vertical: "bottom" }}
      >
        <CompanySelectMenu showComapanyList={showComapanyList}>
          <CompanyListContainer
            showComapanyDotMenuList={showComapanyDotMenuList}
          >
            {paginated_data.currentData().map((company) => (
              <CompanyList key={company.id}>
                <CompanySelectImgContainer>
                  <CompanySelectImg src="../images/teamwork.png"></CompanySelectImg>
                </CompanySelectImgContainer>
                <CompanyNameContainer
                  onClick={() => switch_company(company.id)}
                >
                  <CompanyNameLabelContainer>
                    <CompanyMarquee>
                      <CompanyNameLabel move={checkWordLength(company.Name)}>
                        {company.CompanyName}
                      </CompanyNameLabel>
                    </CompanyMarquee>
                  </CompanyNameLabelContainer>
                </CompanyNameContainer>
                <CompanySelectSubMenu>
                  <AccountMenu />
                </CompanySelectSubMenu>
              </CompanyList>
            ))}
          </CompanyListContainer>
          <PaginationContainer>
            <StyledPagination
              count={count}
              page={page}
              size="small"
              onChange={paginationChange}
            />
          </PaginationContainer>
          <CompanyCreateButton>Add Organization</CompanyCreateButton>
        </CompanySelectMenu>
      </StyledMenu>
    </React.Fragment>
  );
};
const CompanyMarquee = styled.div`
  overflow: hidden;
  position: relative;
  background: #fefefe;
  color: #333;
  width: 100%;
  transition: all ease-in-out 0.3s;
`;
// link
const CompanyList = styled.div`
  padding: 0 7px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 40px;
  min-width: 200px;

  margin: 10px 0;
  border-radius: 20px;
  transition: all ease-in-out 0.3s;
  &:hover {
    ${CompanyMarquee} {
      background: #e0e0e0;
      transition: all ease-in-out 0.3s;
    }
    color: #000;
    background: #e0e0e0;
    border-radius: 20px;
    transition: all ease-in-out 0.3s;
  }
`;
const CompanySelectMenu = styled.div``;
const CompanySelectImgContainer = styled.div`
  width: 30px;
  height: 30px;
`;
const CompanySelectImg = styled.img`
  border: 2px solid green;
  width: 100%;
  height: 100%;
  border-radius: 30px;
  display: block;
  object-fit: cover;
  box-sizing: border-box;
`;
const CompanyNameLabelContainer = styled.div`
  width: 135px;
  display: flex;
  justify-content: space-between;
`;
const CompanyNameContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 10px;
`;
const ProfitAndLossText = styled.p`
  font-weight: bold;
  margin-left: 5px;
`;
const ProftAndLossBarContainer = styled.div``;
const ProftAndLossBarFull = styled.div`
  position: relative;
  width: 100%;
  background: #ccc;
  height: 2px;
`;
const ProftAndLossBarValue = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: ${({ percentage }) => (percentage ? percentage + "%" : "100%")};
  max-width: 100%;
  background: ${({ percentage }) => (percentage < 50 ? "red" : "green")};
`;
const CompanySelectSubMenu = styled.div``;
const CompanyDotMenuSelect = styled.div`
  box-shadow: 0px 0px 5px 0px #dcd9d9;
  background: #fff;
  padding: 7px;
  border-radius: 10px;
  width: 100px;
  position: absolute;
  top: 0px;
  left: 25px;
  right: 0;
  bottom: 0;
  height: max-content;
  z-index: 2;
  &:hover {
    z-index: 10000;
  }
`;
const CompanyDotMenu = styled.div`
  display: block;
  padding: 6px;
  transition: all ease-in-out 0.3s;
  border-radius: 10px;
  &:hover {
    border-radius: 5px;
    transition: all ease-in-out 0.3s;
    background: #ccc;
    z-index: 10000;
  }
`;
const CompanySelectSubMenuContainer = styled.div`
  position: relative;
  border: 1px solid #ccc;
  border-radius: 19px;
  padding: 5px;
  width: 15px;
  height: 15px;
  margin-right: 5px;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  & svg {
    font-size: 18px;
  }
  &:hover {
    background: #bbbbbb;
  }
`;
const CompanySelectSubMenuImg = styled.img`
  width: 100%;
  height: 100%;
`;
const PlusIconContainer = styled.div`
  width: 30px;
  height: 30px;
  margin-right: 25px;
  border-radius: 30px;
  padding: 7px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
`;
const PlusIconPositionContainer = styled.div`
  width: 30px;
  height: 30px;
  margin-right: 25px;
  background: #33d917;
  border-radius: 30px;
  padding: 5px;
  position: absolute;
  transition: width ease-in-out 0.3s;
`;
const CreateCompanyLabel = styled.div`
  color: #fff;
  margin-left: 50px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 2;
  display: flex;
  align-items: center;
`;
const CompanyCreateButton = styled(Button)`
  &&,
  &&:hover {
    cursor: pointer;
    background: #212121;
    border-radius: 50px;
    padding: 8px 5px;
    display: flex;
    align-items: center;
    position: relative;
    text-transform: capitalize;
    color: #fff;
    width: 100%;
    margin-top: 10px;
  }
`;
const PlusIconImg = styled.img`
  filter: invert(1);
  width: 100%;
  height: 100%;
`;
const QuickMenuDrawer = styled.div`
  cursor: initial;
  box-shadow: 0px 0px 5px 0px #dcd9d9;
  position: absolute;
  top: 50px;
  left: 30px;
  right: 0;
  background: #ccdbe5;
  opacity: ${({ showQuickMenu }) => (showQuickMenu ? "1" : "0.5")};
  transform: ${({ showQuickMenu }) =>
    showQuickMenu ? "translateY(0)" : "translateY(-200%)"};
  transition: transform ease-in-out 0.5s;

  display: grid;
  grid-template-columns: 14% 14% 14% 14% 14% 14%;
  -webkit-column-gap: 2%;
  column-gap: 3%;
  row-gap: 0%;
  width: max-content;
  background: #ccdbe5;
  padding: 25px;
  border-radius: 25px;
`;
// const QucikMenuSelect = styled(Link)`
//   cursor: pointer;
//   display: flex;
//   flex-direction: column;
//   justify-content: center;
//   align-items: center;
//   width: 70px;
//   height: 70px;
//   border-radius: 15px;
//   transition: all ease-in-out 0.3s;
//   color: #000;
//   &:hover {
//     color: #000;
//     background: #fff;
//     transition: background ease-in-out 0.3s;
//     border-radius: 15px;
//   }
// `;
const QuickMenuIconContainer = styled.div`
  width: 35px;
  height: 35px;
  margin-bottom: 5px;
`;
const QuickMenuIconImg = styled.img`
  width: 100%;
  height: 100%;
`;
const QuickMenuLabel = styled.div``;
const PaginationContainer = styled.div`
  width: 100%;
`;
const StyledPagination = styled(Pagination)`
  width: 100%;
  .MuiPagination-ul {
    justify-content: center;
  }
  .MuiPaginationItem-sizeSmall {
    font-size: 12px;
    font-weight: bold;
  }
`;
const CompanyListContainer = styled.div`
  max-height: 255px;

  &::-webkit-scrollbar {
    display: none;
  }
`;

const CompanyNameLabel = styled.p`
  font-weight: bold;
  overflow: hidden;
  width: 100%;
  font-size: 12px;
  margin: 0;

  ${({ move }) =>
    move &&
    `
    width: 230%;
     -moz-transform: translateX(50%);
  -webkit-transform: translateX(50%);
  transform: translateX(50%);
  -moz-animation: bouncing-text 5s linear infinite alternate;
  -webkit-animation: bouncing-text 5s linear infinite alternate;
  animation: bouncing-text 10s linear infinite alternate; 
  `}

  @-moz-keyframes bouncing-text {
    0% {
      -moz-transform: translateX(10%);
    }
    100% {
      -moz-transform: translateX(-50%);
    }
  }

  @-webkit-keyframes bouncing-text {
    0% {
      -webkit-transform: translateX(10%);
    }
    100% {
      -webkit-transform: translateX(-50%);
    }
  }

  @keyframes bouncing-text {
    0% {
      -moz-transform: translateX(10%);
      -webkit-transform: translateX(10%);
      transform: translateX(10%);
    }
    100% {
      -moz-transform: translateX(-50%);
      -webkit-transform: translateX(-50%);
      transform: translateX(-50%);
    }
  }
`;
const BoxLabel = styled.p`
  font-size: 12px;
  margin: 0;
  margin-right: 30px;
  margin-bottom: 10px;
`;
const StyledMenu = styled(Menu)`
  && .MuiPaper-root.MuiPaper-elevation {
    box-sizing: border-box;

    box-shadow: 0px 0px 5px 0px #dcd9d9;
    background: #fff;
    border-radius: 25px;
    padding: 8px;
    z-index: 100;
    ul {
      padding: 0;
    }
    transition: transform ease-in-out 0.5s;
    ${CompanyList}:first-child {
      margin-top: 0;
    }
    ${CompanyList}:last-child {
      margin-bottom: 0;
    }
  }
`;

function AccountMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Box sx={{ display: "flex", alignItems: "center", textAlign: "center" }}>
        <Tooltip title="Options">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? "account-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
          >
            <MoreVertIcon sx={{ width: 20, height: 20 }}>M</MoreVertIcon>
          </IconButton>
        </Tooltip>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: -4.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 20,
              right: 65,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem>Edit</MenuItem>
        <MenuItem>Delete</MenuItem>
      </Menu>
    </React.Fragment>
  );
}
