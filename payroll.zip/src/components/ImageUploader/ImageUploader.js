import React, { useEffect, useState } from "react";
import $ from "jquery";
import "./ImageUploader.scss";
import { getAvatar } from "../../functions/utils";
import styled from "styled-components";
import AddIcon from "@mui/icons-material/Add";

const ImageUploader = (props) => {
  const [state, setState] = useState({});

  useEffect(() => {
    var readURL = function (input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
          $("#imagePreview").attr("src", e.target.result);
        };

        reader.readAsDataURL(input.files[0]);
      }
    };

    $("#imageUpload").on("change", function () {
      readURL(this);
    });
  }, []);

  console.log(props.state.photo);
  return (
    <div className="container">
      <div className="avatar-upload">
        <div className="avatar-edit">
          <input
            type="file"
            id="imageUpload"
            name="photo"
            onChange={props.fileChange}
            accept="image/*"
          />
          <label htmlFor="imageUpload">
            <CameraIcon />
          </label>
        </div>
        <div className="avatar-preview">
          {
            props.state.photo ? (
              <img src={props.state.photo} id="imagePreview" />
            ) : null
            // <img
            //   src={getAvatar(String(4), "robohash", 115)}
            //   id="imagePreview"
            // />
          }
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;

const CameraIcon = styled(AddIcon)`
  && {
    position: absolute;
    top: 8px;
    left: 7px;
    width: 20px !important;
    height: 20px !important;
    color: #fff;
  }
`;
