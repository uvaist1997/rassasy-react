import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import styled from "styled-components";

export default function DeletePrompt({ show, setShow }) {
  return (
    <Container>
      <Dialog
        open={show}
        onClose={() => setShow(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {"Do you want to delete ?"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            If you delete data. The data will be permanently removed.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <StyledButton onClick={() => setShow(false)}>Disagree</StyledButton>
          <StyledButton
            className="agree"
            onClick={() => setShow(false)}
            autoFocus
          >
            Agree
          </StyledButton>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
const Container = styled.div`
  &&button {
    text-transform: capitalize;
  }
`;
const StyledButton = styled(Button)`
  && {
    text-transform: capitalize;
  }
  &&.agree {
    background: red;
    color: #fff;
  }
`;
