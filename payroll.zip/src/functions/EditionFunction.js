export const get_EditionPermission = (Edition, Value) => {
  let result = true;
  if (Value === "DashboardChart") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "AccountGroup") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "LoyaltyCustomer") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "Bank") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "PriceCategory") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "Route") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "MultiUnit") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "LedgerReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "OutstandingReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "Expense" || Value === "ExpenseReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BankReconciliation") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "PurchaseTaxReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "SalesTaxReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "PaymentReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "ReceiptReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "TrialBalance") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "TradingProfitAndLossAccount") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BalanceSheet") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "DayReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "CashBook") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BankBook") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BankReconciliationReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "GSTR1") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "GSTR2") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "GSTR3B") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "VATReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "SalesOrder") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "SalesEstimate") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "LoyalityProgram") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "SalesSummary") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "SalesOrderReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "SalesRegisterReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "SalesIntegratedReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "BillwiseProfit") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "PurchaseOrder") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "PurchaseOrderReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "PurchaseRegisterReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "Warehouse") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "Shelf") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "OpeningStock") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "StockTransfer") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "WorkOrder") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "StockManagement") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "StockOrder") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "StockValueReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "StockReport") {
    if (Edition === "Lite") {
      result = false;
    }
  } else if (Value === "OpeningStockReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "StockTransferRegister") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "StockLedgerReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "SupplierVsProductReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "ProductAnalysisReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "InventoryFlowReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BatchWiseReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "BatchReport") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "ProductReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "StockAdjustment") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "ShortageStockReport" || Value === "ShortageStock") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "ExcessStockReport" || Value === "ExcessStock") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "VanReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "VanStockReport") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "PriceChecker") {
    if (Edition === "Lite" || Edition === "Essential") {
      result = false;
    }
  } else if (Value === "ActivityLog") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  } else if (Value === "VanSalesSettings") {
    if (
      Edition === "Lite" ||
      Edition === "Essential" ||
      Edition === "Standard"
    ) {
      result = false;
    }
  }
  return result;
};
