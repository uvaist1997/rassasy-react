import {
  salesVoucherURL,
  mainVoucherURL,
  formsetTableSettingURL,
} from "../api/VoucherNoAPIs";

export const get_VoucherNo = (
  CompanyID,
  user_id,
  BranchID,
  VoucherType,
  access,
  EnableVoucherNoUserWise
) => {
  let voucher_datas = [];
  voucher_datas = fetch(mainVoucherURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      UserID: user_id,
      BranchID: BranchID,
      VoucherType: VoucherType,
    }),
  }).then((response) => response.json());
  // if (EnableVoucherNoUserWise == true) {
  //   voucher_datas = fetch(mainVoucherURL, {
  //     method: "POST",
  //     headers: {
  //       "content-type": "application/json",
  //       Authorization: `Bearer ${access}`,
  //       // "accept": "application/json"
  //     },
  //     body: JSON.stringify({
  //       CompanyID: CompanyID,
  //       UserID: user_id,
  //       BranchID: BranchID,
  //       VoucherType: VoucherType,
  //     }),
  //   }).then((response) => response.json());
  // } else {
  //   voucher_datas = fetch(salesVoucherURL, {
  //     method: "POST",
  //     headers: {
  //       "content-type": "application/json",
  //       Authorization: `Bearer ${access}`,
  //       // "accept": "application/json"
  //     },
  //     body: JSON.stringify({
  //       CompanyID: CompanyID,
  //       CreatedUserID: user_id,
  //       BranchID: BranchID,
  //       VoucherType: VoucherType,
  //     }),
  //   }).then((response) => response.json());
  // }
  return voucher_datas;
};

export const get_formsetSettings = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  VoucherType,
  SettingsName,
  SettingsValue,
  Type
) => {
  let formset_datas = await fetch(formsetTableSettingURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      UserID: user_id,
      BranchID: BranchID,
      VoucherType: VoucherType,
      SettingsName: SettingsName,
      SettingsValue: SettingsValue,
      Type: Type,
    }),
  }).then((response) => response.json());
  let is_product_code = false;
  let is_barcode = false;
  let is_name = true;
  let is_description = false;
  let is_unit = true;
  let is_qty = true;
  let is_free_qty = false;
  let is_rate = true;
  let is_stock = false;
  let is_inclusive_tax = false;
  let is_gross_amount = true;
  let is_discount_percentage = false;
  let is_discount_amount = false;
  let is_tax = false;
  let is_amount = true;
  let is_tax_type = true;
  let is_tax_perc = true;
  let is_tax_amount = true;
  let is_tax_inclusive = true;
  let is_batchcode = false;
  let is_mfg_date = false;
  let is_exp_date = false;
  let is_cost = true;
  let is_salesP = false;
  let is_cost_total = true;
  let is_sales_total = false;
  if (formset_datas.datas) {
    console.log("formset_datas.datas");
    console.log(formset_datas.datas);
    let product_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_product_code"
    );

    let bar_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_barcode"
    );

    let name_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_name"
    );
    console.log(name_code_val);
    let description_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_description"
    );

    let unit_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_unit"
    );

    let qty_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_qty"
    );

    let free_qty_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_free_qty"
    );

    let rate_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_rate"
    );

    let stock_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_stock"
    );

    let inclusive_tax_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_inclusive_tax"
    );

    let gross_amount_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_gross_amount"
    );

    let discount_percentage_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_discount_percentage"
    );

    let discount_amount_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_discount_amount"
    );

    let tax_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_tax"
    );

    let amount_code_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_amount"
    );

    let is_tax_type_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_tax_type"
    );

    let is_tax_perc_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_tax_perc"
    );

    let is_tax_amount_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_tax_amount"
    );

    let is_tax_inclusive_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_tax_inclusive"
    );

    let is_batchcode_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_batchcode"
    );

    let is_mfg_date_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_mfg_date"
    );

    let is_exp_date_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_exp_date"
    );

    let is_cost_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_cost"
    );

    let is_salesP_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_sales_price"
    );

    let is_cost_total_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_cost_total"
    );
    let is_sales_total_val = formset_datas.datas.filter(
      (i) => i.SettingsName == "is_sales_total"
    );

    is_product_code = product_code_val.length
      ? product_code_val[0].SettingsValue
      : false;
    is_barcode = bar_code_val.length ? bar_code_val[0].SettingsValue : false;
    is_name = name_code_val.length ? name_code_val[0].SettingsValue : true;
    is_description = description_code_val.length
      ? description_code_val[0].SettingsValue
      : false;
    is_unit = unit_code_val.length ? unit_code_val[0].SettingsValue : true;
    is_qty = qty_code_val.length ? qty_code_val[0].SettingsValue : true;
    is_free_qty = free_qty_code_val.length
      ? free_qty_code_val[0].SettingsValue
      : false;
    is_rate = rate_code_val.length ? rate_code_val[0].SettingsValue : true;
    is_stock = stock_code_val.length ? stock_code_val[0].SettingsValue : false;
    is_inclusive_tax = inclusive_tax_code_val.length
      ? inclusive_tax_code_val[0].SettingsValue
      : false;
    is_gross_amount = gross_amount_code_val.length
      ? gross_amount_code_val[0].SettingsValue
      : true;
    is_discount_percentage = discount_percentage_code_val.length
      ? discount_percentage_code_val[0].SettingsValue
      : false;
    is_discount_amount = discount_amount_code_val.length
      ? discount_amount_code_val[0].SettingsValue
      : false;
    is_tax = tax_code_val.length ? tax_code_val[0].SettingsValue : true;
    is_amount = amount_code_val.length
      ? amount_code_val[0].SettingsValue
      : true;
    is_tax_type = is_tax_type_val.length
      ? is_tax_type_val[0].SettingsValue
      : true;
    is_tax_perc = is_tax_perc_val.length
      ? is_tax_perc_val[0].SettingsValue
      : true;
    is_tax_amount = is_tax_amount_val.length
      ? is_tax_amount_val[0].SettingsValue
      : true;
    is_tax_inclusive = is_tax_inclusive_val.length
      ? is_tax_inclusive_val[0].SettingsValue
      : true;
    is_batchcode = is_batchcode_val.length
      ? is_batchcode_val[0].SettingsValue
      : false;
    is_mfg_date = is_mfg_date_val.length
      ? is_mfg_date_val[0].SettingsValue
      : false;
    is_exp_date = is_exp_date_val.length
      ? is_exp_date_val[0].SettingsValue
      : false;
    is_cost = is_cost_val.length ? is_cost_val[0].SettingsValue : true;

    is_salesP = is_salesP_val.length ? is_salesP_val[0].SettingsValue : false;
    is_cost_total = is_cost_total_val.length
      ? is_cost_total_val[0].SettingsValue
      : true;

    is_sales_total = is_sales_total_val.length
      ? is_sales_total_val[0].SettingsValue
      : false;
  }
  console.log(is_sales_total);
  return [
    is_product_code,
    is_barcode,
    is_name,
    is_description,
    is_unit,
    is_qty,
    is_free_qty,
    is_rate,
    is_inclusive_tax,
    is_gross_amount,
    is_discount_percentage,
    is_discount_amount,
    is_tax,
    is_amount,
    is_tax_type,
    is_tax_perc,
    is_tax_amount,
    is_tax_inclusive,
    is_batchcode,
    is_mfg_date,
    is_exp_date,
    is_cost,
    is_salesP,
    is_cost_total,
    is_sales_total,
    is_stock,
  ];
};

export const validate_GSTNO = (gstn, state_code) => {
  var reggst =
    /^([0-9]{2}[a-zA-Z]{4}([a-zA-Z]{1}|[0-9]{1})[0-9]{4}[a-zA-Z]{1}([a-zA-Z]|[0-9]){3}){0,15}$/;
  let gstn_arr = gstn.split("");
  let state_code_arr = state_code.split("");
  let error_message = "";
  if (
    String(state_code_arr[0]) + String(state_code_arr[1]) ==
    String(gstn_arr[0]) + String(gstn_arr[1])
  ) {
    if (gstn_arr[13]) {
      if (gstn_arr[13] == "Z") {
        if (gstn_arr.length == 15) {
          if (gstn.match(reggst)) {
            error_message = "";
          } else {
            error_message = "Invalid GSTNumber";
          }
        } else if (gstn_arr.length > 14) {
          error_message = "GSTNumber Should have 15 number";
        }
      } else {
        error_message = "GSTNumber 14th Letter Should Have 'Z'";
      }
    }
  } else {
    error_message = "Invalid GSTNumber";
  }
  return error_message;
};
