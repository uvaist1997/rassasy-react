import { searchAccountLedgerUrl } from "../api/AccountLedgerAPI";
import { journalViewURL } from "../api/JournalAPI";
import { ledgerListforPaymentsUrl, ledgerListforPayments_ReceieptUrl, PaymentGatewayListUrl, PaymentTransactionsListUrl, paymentViewURL } from "../api/PaymentAPI";
import { receiptViewURL } from "../api/ReceiptAPI";

export const get_journalSingle = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    unq_id
) => {
    let single_datas_journal = await fetch(journalViewURL + unq_id + "/", {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            BranchID: BranchID,
            PriceRounding: PriceRounding,
        }),
    }).then((response) => response.json());
    return single_datas_journal;
};
export const get_paymentSingle = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    unq_id
) => {
    let single_datas_payments = await fetch(paymentViewURL + unq_id + "/", {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            BranchID: BranchID,
            PriceRounding: PriceRounding,
        }),
    }).then((response) => response.json());
    return single_datas_payments;
};
export const get_receiptSingle = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    unq_id
) => {
    let single_datas_receipts = await fetch(receiptViewURL + unq_id + "/", {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            BranchID: BranchID,
            PriceRounding: PriceRounding,
        }),
    }).then((response) => response.json());
    return single_datas_receipts;
};
export const get_ledgerListforPayments = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
) => {
    let ledger_list_for_payments = await fetch(ledgerListforPaymentsUrl, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            BranchID: BranchID,
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            PriceRounding: PriceRounding,
        }),
    }).then((response) => response.json());
    return ledger_list_for_payments;
};

export const get_ledgerListforPayments_Receiept = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    load_data,
    ledger_name,
    length,
) => {
    let ledger_list_for_payments_reciept = await fetch(ledgerListforPayments_ReceieptUrl, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            BranchID: BranchID,
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            PriceRounding: PriceRounding,
            load_data,
            ledger_name,
            length,

        }),
    }).then((response) => response.json());
    return ledger_list_for_payments_reciept;
};

export const get_paymentTransactionsList = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    MasterName,
) => {
    let payment_Transactions_list = await fetch(PaymentTransactionsListUrl, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            CreatedUserID: user_id,
            BranchID: BranchID,
            CompanyID: CompanyID,
            MasterName: MasterName,
        }),
    }).then((response) => response.json());
    return payment_Transactions_list;
};


export const get_ledgerSearchList = async (
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    load_data,
    EnableVoucherNoUserWise,
    ledger_name,
    length,
) => {
    let ledger_seach_list = await fetch(searchAccountLedgerUrl, {
        method: "POST",
        headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
        },
        body: JSON.stringify({
            BranchID: BranchID,
            CompanyID: CompanyID,
            CreatedUserID: user_id,
            PriceRounding: PriceRounding,
            load_data: load_data,
            EnableVoucherNoUserWise: EnableVoucherNoUserWise,
            ledger_name,
            length

        }),
    }).then((response) => response.json());
    return ledger_seach_list;
};
