import { countryListURL, stateListURL } from "../api/StateCountryAPI";
import { warehousesUrl, listWarehouseUrl } from "../api/WarehouseAPI";
import { branchListUrl } from "../api/BranchAPI";
import { employeesUrl, priceCategoriesUrl } from "../api/EmployeeAPI";
import { inventoryLedgerURL } from "../api/InventoryLedgerList";
import { taxListByTypeUrl, getTaxDetailsUrl } from "../api/TaxCategoryAPI";
import {
  getProductBarcodeURL,
  productSearchURL,
  singleUnitURL,
  unitDetailsURL,
  getProductBatchcodeURL,
  singleUnitbyBatchURL,
  getsearchBatchcodeURL,
  productCodeSearchURL,
} from "../api/ProductAPIs";
import { openingStockFilterURL } from "../api/OpeningStockApis";
import { expnseViewUrl } from "../api/ExpenseAPIs";
import {
  salesViewURL,
  salesReturnViewURL,
  salesOrderViewURL,
  getSalesOrderURL,
  getfilterdSalesOrderURL,
  getSalesByCustomerOrderURL,
  getfilterdSalesEstimateURL,
  getSalesEstimateURL,
  getSalesByCustomerEstimateURL,
  getproductHistoryURL,
} from "../api/SalesInvoiceAPIs";
import { workOrderViewURL } from "../api/WorkOrderAPI";
import { salesEstimateViewURL } from "../api/SalesEstimateApis";
import { purchaseViewURL, purchaseReturnViewURL } from "../api/PurchaseAPIs";
import { purchaseOrderViewURL } from "../api/PurchaseOrderAPI";
import { usersUrl } from "../api/UserAPI";
import { useSelector } from "react-redux";
import { openingStockViewURL } from "../api/OpeningStockApis";
import { viewStockTransferURL } from "../api/StockTransferAPIs";
import { StockManagementViewURL } from "../api/StockManagementApis";
import {
  reconciliationDatasURL,
  reconciliationViewURL,
} from "../api/BankReconciliationAPIs";

export const get_InventoryLedgers = (
  CompanyID,
  user_id,
  BranchID,
  type_invoice,
  access,
  PriceRounding,
  load_data,
  val,
  length
) => {
  let ledgers = fetch(inventoryLedgerURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      type_invoice: type_invoice,
      PriceRounding: PriceRounding,
      load_data: load_data,
      ledger_name: val,
      length: length,
    }),
  }).then((response) => response.json());
  return ledgers;
};

export const get_Warehouse = (CompanyID, user_id, BranchID, access) => {
  let warehouses = fetch(warehousesUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
    }),
  }).then((response) => response.json());
  return warehouses;
};

export const get_Warehouse_list = (CompanyID, user_id, BranchID, access) => {
  let warehouses = fetch(listWarehouseUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
    }),
  }).then((response) => response.json());
  return warehouses;
};

export const get_BranchList = (CompanyID, user_id, access) => {
  let branches = fetch(branchListUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
    }),
  }).then((response) => response.json());
  return branches;
};

export const get_TaxList = (
  CompanyID,
  user_id,
  BranchID,
  access,
  tax_type_param
) => {
  let taxList = fetch(taxListByTypeUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      TaxType: tax_type_param,
    }),
  }).then((response) => response.json());
  return taxList;
};

export const get_salesManList = (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  list_type
) => {
  let salesmans = fetch(employeesUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      list_type: list_type,
    }),
  }).then((response) => response.json());
  return salesmans;
};

export const get_priceCategoriesList = (
  CompanyID,
  user_id,
  BranchID,
  access
) => {
  let priceCategories = fetch(priceCategoriesUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
    }),
  }).then((response) => response.json());
  return priceCategories;
};

export const get_countriesList = (access) => {
  let countries = fetch(countryListURL, {
    method: "GET",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
  }).then((response) => response.json());
  return countries;
};

export const get_coutryStateAPI = (country, access) => {
  let states = [];
  if (country) {
    states = fetch(stateListURL + country, {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
    }).then((response) => response.json());
  }

  return states;
};

export const get_productSearchList = (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  product_name,
  WarehouseID,
  length,
  type
) => {
  let ProductList = fetch(productSearchURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: Number(PriceRounding),
      product_name: product_name,
      WarehouseID: WarehouseID,
      length: length,
      type: type,
    }),
  }).then((response) => response.json());
  return ProductList;
};

export const get_productCodeSearchList = (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  product_name,
  length
) => {
  let ProductCodeList = fetch(productCodeSearchURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: Number(PriceRounding),
      product_name: product_name,
      length: length,
    }),
  }).then((response) => response.json());
  return ProductCodeList;
};

export const set_productSelected = (event, value, index, name, Details) => {
  let ProductID = value.ProductID;
  let Stock = value.Stock;
  let ProductName = event.target.innerHTML;
  Details[index]["PriceListID"] = "";
  Details[index]["ProductCode"] = value.ProductCode;
  Details[index]["Stock"] = Stock;
  Details[index]["ProductID"] = ProductID;
  Details[index]["ProductName"] = ProductName;
  Details[index]["HSNCode"] = value.HSNCode;
  Details[index]["Qty"] = 1;
  let is_inclusive = value.is_inclusive;
  Details[index]["is_inclusive"] = is_inclusive;
  Details[index]["BatchCode"] = value.BatchCode;
  Details[index]["product_id"] = value.product_id;
  //   setState({ ...state, saleDetails });
  return Details;
};

export const ProductCommonFunction = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  ProductID,
  type,
  Details,
  index,
  ProductName,
  state,
  GST,
  VAT
) => {
  Details = await get_UnitDetails(
    CompanyID,
    user_id,
    BranchID,
    access,
    PriceRounding,
    ProductID,
    type,
    Details,
    index,
    ProductName
  );
  let PriceListID = Details[index]["PriceListID"];
  Details = await get_SingleUnitDetails(
    CompanyID,
    index,
    user_id,
    BranchID,
    PriceListID,
    PriceRounding,
    access,
    Details
  );

  let SalesPrice = Details[index]["SalesPrice"];
  let SalesPrice1 = Details[index]["SalesPrice1"];
  let SalesPrice2 = Details[index]["SalesPrice2"];
  let SalesPrice3 = Details[index]["SalesPrice3"];
  if (state.PriceCategoryID == 2) {
    SalesPrice = SalesPrice1;
  } else if (state.PriceCategoryID == 3) {
    SalesPrice = SalesPrice2;
  } else if (state.PriceCategoryID == 4) {
    SalesPrice = SalesPrice3;
  }
  Details[index]["ActualSalesPrice"] = SalesPrice;
  let PurchasePrice = Details[index]["PurchasePrice"];
  if (type == "OpeningStock") {
    Details[index]["Rate"] = PurchasePrice;
  } else if (type == "StockTransfer") {
    Details[index]["Rate"] = PurchasePrice;
  } else {
    Details = await setCalculatedPrice(
      CompanyID,
      index,
      PriceListID,
      state,
      Number(SalesPrice),
      PurchasePrice,
      Details,
      GST,
      VAT,
      type,
      "None"
    );
  }
  return Details;
};

export const get_UnitDetails = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  ProductID,
  type,
  Details,
  index,
  ProductName
) => {
  let unit_details = await fetch(unitDetailsURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      ProductID: ProductID,
      PriceRounding: PriceRounding,
      type: type,
    }),
  }).then((response) => response.json());
  if (unit_details.StatusCode == 6000) {
    let UnitList = unit_details.data;
    Details[index]["UnitList"] = UnitList;
    // Details[index]["BatchList"] = unit_details.BatchCode_list;
    // Details[index]["BatchCode"] = unit_details.BatchCode_list[0].BatchCode;

    let Tax1_PurchaseTax = 0;
    let Tax2_PurchaseTax = 0;
    let Tax3_PurchaseTax = 0;
    let GST_PurchaseTax = 0;
    let Vat_PurchaseTax = 0;
    let MinimumSalesPrice = 0;
    let is_kfc = 0;
    if (type == "sales") {
      Tax1_PurchaseTax = unit_details.Tax1_SalesTax;
      Tax2_PurchaseTax = unit_details.Tax2_SalesTax;
      Tax3_PurchaseTax = unit_details.Tax3_SalesTax;
      GST_PurchaseTax = unit_details.GST_SalesTax;
      Vat_PurchaseTax = unit_details.Vat_SalesTax;
      MinimumSalesPrice = unit_details.MinimumSalesPrice;
      is_kfc = unit_details.is_kfc;
    } else if (type == "purchase") {
      Tax1_PurchaseTax = unit_details.Tax1_PurchaseTax;
      Tax2_PurchaseTax = unit_details.Tax2_PurchaseTax;
      Tax3_PurchaseTax = unit_details.Tax3_PurchaseTax;
      GST_PurchaseTax = unit_details.GST_PurchaseTax;
      Vat_PurchaseTax = unit_details.Vat_PurchaseTax;
    }
    let ProductTaxID = unit_details.ProductTaxID;
    let HSNCode = unit_details.HSNCode;

    let Vat_Inclusive = unit_details.Vat_Inclusive;
    let GST_Inclusive = unit_details.GST_Inclusive;
    let Tax1_Inclusive = unit_details.Tax1_Inclusive;
    let Tax2_Inclusive = unit_details.Tax2_Inclusive;
    let Tax3_Inclusive = unit_details.Tax3_Inclusive;

    let is_inclusive = unit_details.is_inclusive;
    Details[index]["is_inclusive"] = is_inclusive;

    Details[index]["Vat_Inclusive"] = Vat_Inclusive;
    Details[index]["GST_Inclusive"] = GST_Inclusive;
    Details[index]["Tax1_Inclusive"] = Tax1_Inclusive;
    Details[index]["Tax2_Inclusive"] = Tax2_Inclusive;
    Details[index]["Tax3_Inclusive"] = Tax3_Inclusive;

    let half_gst = Number(GST_PurchaseTax / 2);
    Details[index]["ProductTaxID"] = ProductTaxID;
    Details[index]["VATPerc"] = Vat_PurchaseTax;
    Details[index]["SGSTPerc"] = half_gst;
    Details[index]["CGSTPerc"] = half_gst;
    Details[index]["IGSTPerc"] = GST_PurchaseTax;
    Details[index]["TAX1Perc"] = Tax1_PurchaseTax;
    Details[index]["TAX2Perc"] = Tax2_PurchaseTax;
    Details[index]["TAX3Perc"] = Tax3_PurchaseTax;
    Details[index]["ProductID"] = ProductID;
    Details[index]["ProductName"] = ProductName;

    Details[index]["MinimumSalesPrice"] = MinimumSalesPrice;
    Details[index]["is_kfc"] = is_kfc;
    Details[index]["HSNCode"] = HSNCode;
    Details[index]["PriceListID"] = UnitList[0].PriceListID;
    Details[index]["MultiFactor"] = Number(UnitList[0].MultiFactor);
  }

  return Details;
};

export const get_SingleUnitDetails = async (
  CompanyID,
  index,
  user_id,
  BranchID,
  PriceListID,
  PriceRounding,
  access,
  Details
) => {
  let unit_detail = await fetch(singleUnitURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceListID: PriceListID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());

  let SalesPrice1 = unit_detail.data.SalesPrice1;
  let SalesPrice2 = unit_detail.data.SalesPrice2;
  let SalesPrice3 = unit_detail.data.SalesPrice3;
  let SalesPrice = unit_detail.data.SalesPrice;
  let MRP = unit_detail.data.MRP;
  let PurchasePrice = unit_detail.data.PurchasePrice;
  let Barcode = unit_detail.data.Barcode;
  let MultiFactor = unit_detail.data.MultiFactor;
  Details[index]["SalesPrice"] = SalesPrice;
  Details[index]["StandardSalesPrice"] = SalesPrice;
  Details[index]["SalesPrice1"] = SalesPrice1;
  Details[index]["SalesPrice2"] = SalesPrice2;
  Details[index]["SalesPrice3"] = SalesPrice3;
  Details[index]["MRP"] = MRP;
  Details[index]["PurchasePrice"] = PurchasePrice;
  Details[index]["CostPerPrice"] = PurchasePrice;
  Details[index]["Barcode"] = Barcode;
  Details[index]["MultiFactor"] = Number(MultiFactor);
  return Details;
};

export const check_hsn_code = (HSNCode) => {
  let is_HSNCode_ok = false;
  if (HSNCode.length < 16 && isNaN(HSNCode) == false) {
    is_HSNCode_ok = true;
  }
  return is_HSNCode_ok;
};

export const setCalculatedPrice = (
  CompanyID,
  index,
  PriceListID,
  state,
  SalesPrice,
  PurchasePrice,
  Details,
  is_Gst,
  is_Vat,
  type,
  mode
) => {
  // let Details = [...state.saleDetails];
  let is_inclusive = Details[index]["is_inclusive"];
  let is_Tax1 = state.is_Tax1;
  let is_Tax2 = state.is_Tax2;
  let is_Tax3 = state.is_Tax3;

  let total_inclusive = 0;
  let total_tax = 0;
  let treatment_ok = true;
  if (
    is_Gst &&
    state.type == "sales" &&
    (state.GST_Treatment == "4" || state.GST_Treatment == "6")
  ) {
    treatment_ok = false;
  } else if (
    is_Gst &&
    state.type == "purchase" &&
    (state.GST_Treatment == "2" ||
      state.GST_Treatment == "4" ||
      state.GST_Treatment == "6")
  ) {
    treatment_ok = false;
  }

  if (is_Vat && state.type == "purchase" && state.VAT_Treatment == "1") {
    treatment_ok = false;
  }

  if (
    (is_Vat == true && state.is_nontaxable == false && treatment_ok == true) ||
    (is_Gst == true && state.is_nontaxable == false && treatment_ok == true)
  ) {
    let is_B2C = false;
    if (state.TaxType == "GST Intra-state B2C") {
      is_B2C = true;
    }
    // let SGSTPerc = Details[index]["SGSTPerc"];
    // let CGSTPerc = Details[index]["CGSTPerc"];
    // let IGSTPerc = Details[index]["IGSTPerc"];
    // let Vat_tax = Details[index]["VATPerc"];
    // let TotalGstPerc = Number(SGSTPerc) + Number(CGSTPerc) + Number(IGSTPerc);
    // let is_kfc = Details[index]["is_kfc"];
    // let HSNCode = Details[index]["HSNCode"];
    // let is_HSNCode_ok = check_hsn_code(HSNCode);
    // if (TotalGstPerc == 3) {
    //   if (
    //     is_B2C == true &&
    //     is_kfc == true &&
    //     is_HSNCode_ok == true &&
    //     state.kfc_in_sttings == true
    //   ) {
    //     total_tax += 0.25;
    //     if (is_inclusive == true || is_inclusive == "true") {
    //       total_inclusive += 0.25;
    //     }
    //   }
    // } else if (TotalGstPerc > 5) {
    //   if (is_B2C == true && is_kfc == true && state.kfc_in_sttings == true) {
    //     total_tax += 1;
    //     if (is_inclusive == true || is_inclusive == "true") {
    //       total_inclusive += 1;
    //     }
    //   }
    // }
    if (is_Vat == true || is_Vat == "true") {
      let Vat_tax = Details[index]["VATPerc"];
      if (is_inclusive == true || is_inclusive == "true") {
        total_inclusive += Vat_tax;
      }
      total_tax += Vat_tax;
    }
    if (is_Gst == true || is_Gst == "true") {
      let Gst_tax = Details[index]["IGSTPerc"];
      if (is_inclusive == true || is_inclusive == "true") {
        total_inclusive += Gst_tax;
      }
      total_tax += Gst_tax;
    }
    if (is_Tax1 == true || is_Tax1 == "true") {
      let Tax1_tax = Details[index]["TAX1Perc"];
      if (is_inclusive == true || is_inclusive == "true") {
        total_inclusive += Tax1_tax;
      }
      total_tax += Tax1_tax;
    }
    if (is_Tax2 == true || is_Tax2 == "true") {
      let Tax2_tax = Details[index]["TAX2Perc"];
      if (is_inclusive == true || is_inclusive == "true") {
        total_inclusive += Tax2_tax;
      }
      total_tax += Tax2_tax;
    }
    if (is_Tax3 == true || is_Tax3 == "true") {
      let Tax3_tax = Details[index]["TAX3Perc"];
      if (is_inclusive == true || is_inclusive == "true") {
        total_inclusive += Tax3_tax;
      }
      total_tax += Tax3_tax;
    }
    let UnitPrice = 0;
    let InclusivePrice = Details[index]["InclusivePrice"];
    if (type == "sales") {
      UnitPrice = Number(SalesPrice);
    } else if (type == "purchase") {
      UnitPrice = Number(PurchasePrice);
    }
    // let total_tax = (Vat_tax+Gst_tax+Tax1_tax+Tax2_tax+Tax3_tax)
    if (total_inclusive == 0) {
      if (mode == "UnitPrice") {
        let TaxAmt = (Number(UnitPrice) * Number(total_tax)) / 100;
        let InclusivePrice = Number(UnitPrice) + Number(TaxAmt);
        Details[index]["InclusivePrice"] = Number(InclusivePrice);
      } else if (mode == "InclusivePrice") {
        UnitPrice = UnitPrice;
        let InclusivePrice = Number(UnitPrice);
        Details[index]["InclusivePrice"] = Number(InclusivePrice);
        var TaxAmt = (UnitPrice * total_tax) / (100 + total_tax);
        let ActualUnitPrice = Number(UnitPrice) - Number(TaxAmt);
        Details[index]["UnitPrice"] = Number(ActualUnitPrice);

        if (type == "sales") {
          Details[index]["ActualUnitPrice"] = Number(ActualUnitPrice);
        } else if (type == "purchase") {
          Details[index]["ActualUnitPrice"] = Number(ActualUnitPrice);
        }
      } else {
        UnitPrice = UnitPrice;
        Details[index]["UnitPrice"] = Number(UnitPrice);
        let TaxAmt = (Number(UnitPrice) * Number(total_tax)) / 100;
        let InclusivePrice = Number(UnitPrice) + Number(TaxAmt);
        Details[index]["InclusivePrice"] = Number(InclusivePrice);

        if (type == "sales") {
          Details[index]["ActualUnitPrice"] = Number(SalesPrice);
        } else if (type == "purchase") {
          Details[index]["ActualUnitPrice"] = Number(PurchasePrice);
        }
      }
    } else {
      if (mode == "UnitPrice") {
        let taxAmt = (UnitPrice * total_inclusive) / 100;
        let InclusivePrice = UnitPrice + taxAmt;
        Details[index]["InclusivePrice"] = Number(InclusivePrice);
      } else {
        UnitPrice = Number(UnitPrice);
        total_inclusive = Number(total_inclusive);
        let taxAmt = Number(
          (UnitPrice * total_inclusive) / (100 + total_inclusive)
        );
        UnitPrice = Number(UnitPrice - taxAmt);
        if (type == "sales") {
          Details[index]["InclusivePrice"] = Number(SalesPrice);
        } else if (type == "purchase") {
          Details[index]["InclusivePrice"] = Number(PurchasePrice);
        }

        Details[index]["ActualUnitPrice"] = Number(UnitPrice);
        Details[index]["UnitPrice"] = Number(UnitPrice);
      }
    }
  } else {
    let Price = 0;
    if (type == "sales") {
      Price = SalesPrice;
    } else if (type == "purchase") {
      Price = PurchasePrice;
    }
    Details[index]["InclusivePrice"] = Number(Price);
    Details[index]["ActualUnitPrice"] = Number(Price);
    Details[index]["UnitPrice"] = Number(Price);
  }
  if (type == "sales") {
    Details[index]["CostPerPrice"] = PurchasePrice;
  }
  Details[index]["ActualSalesPrice"] = SalesPrice;
  Details[index]["Units"] = PriceListID;
  Details[index]["PriceListID"] = PriceListID;
  Details[index]["is_BatchSalesPrice"] = false;

  return Details;
};

export const Calculations = (index, Details, state) => {
  if (index != null) {
    // GrossAmount
    let FreeQty = Details[index]["FreeQty"];
    let Qty = Details[index]["Qty"];
    let UnitPrice = Details[index]["ActualUnitPrice"];
    if (!FreeQty) {
      FreeQty = 0;
    }
    if (!Qty) {
      Qty = 0;
    }
    let qty = Qty;
    if (!UnitPrice) {
      UnitPrice = 0;
    }
    if (!qty) {
      qty = 0;
    }

    let GrossAmount = Number(UnitPrice * qty);
    let DiscountPerc = Details[index]["DiscountPerc"];
    let DiscountAmount = Number((GrossAmount * DiscountPerc) / 100);
    Details[index]["GrossAmount"] = GrossAmount;
    Details[index]["DiscountAmount"] = DiscountAmount;

    // AddlDiscAmtItem

    let AddlDiscPerc = Details[index]["AddlDiscPerc"];
    let AddlDiscAmt = Details[index]["AddlDiscAmt"];

    if (!GrossAmount) {
      GrossAmount = 0;
    }

    if (!AddlDiscPerc) {
      AddlDiscPerc = 0;
    }
    if (!AddlDiscAmt) {
      AddlDiscAmt = 0;
    }

    if (!DiscountAmount) {
      DiscountAmount = 0;
    }
    DiscountAmount = parseFloat(DiscountAmount);
    let total_Discount = "0";
    let TaxableAmount = "0";
    total_Discount = DiscountAmount + AddlDiscAmt;
    TaxableAmount = Number(GrossAmount - total_Discount);
    Details[index]["TaxableAmount"] = TaxableAmount;

    // CostPerItem
    FreeQty = Number(FreeQty);
    let total_Qty = Qty + FreeQty;
    total_Qty = Number(total_Qty);
    if (!Qty) {
      Qty = 0;
    }
    if (state.type == "purchase") {
      let CostPerItem = Number(TaxableAmount / Qty);
      if (!CostPerItem) {
        CostPerItem = 0;
      }
      Details[index]["CostPerItem"] = CostPerItem;
    }

    // TaxAmount
    let SGSTPerc = Details[index]["SGSTPerc"];
    let CGSTPerc = Details[index]["CGSTPerc"];
    let IGSTPerc = Details[index]["IGSTPerc"];
    let TAX1Perc = Details[index]["TAX1Perc"];
    let TAX2Perc = Details[index]["TAX2Perc"];
    let TAX3Perc = Details[index]["TAX3Perc"];
    let VATPerc = Details[index]["VATPerc"];
    if (state.TaxType == "Export" || state.TaxType == "Import") {
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
      SGSTPerc = 0;
      IGSTPerc = 0;
      CGSTPerc = 0;
      VATPerc = 0;
    }
    if (state.TaxType == "GST Inter-state B2B") {
      VATPerc = 0;
      SGSTPerc = 0;
      CGSTPerc = 0;
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
    }
    if (state.TaxType == "GST Intra-state B2B Unregistered") {
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
      SGSTPerc = 0;
      IGSTPerc = 0;
      CGSTPerc = 0;
      VATPerc = 0;
    }
    if (state.TaxType == "GST Intra-state B2B") {
      VATPerc = 0;
      IGSTPerc = 0;
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
    }
    if (state.TaxType == "GST Inter-state B2B") {
      VATPerc = 0;
      SGSTPerc = 0;
      CGSTPerc = 0;
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
    }
    if (state.TaxType == "GST Inter-state B2C") {
      VATPerc = 0;
      SGSTPerc = 0;
      CGSTPerc = 0;
      if (state.is_Tax1 == "false" || state.is_Tax1 == false) {
        TAX1Perc = 0;
      }
      if (state.is_Tax2 == "false" || state.is_Tax2 == false) {
        TAX2Perc = 0;
      }
      if (state.is_Tax3 == "false" || state.is_Tax3 == false) {
        TAX3Perc = 0;
      }
    }
    let is_B2C = false;
    if (state.TaxType == "GST Intra-state B2C") {
      is_B2C = true;
      VATPerc = 0;
      IGSTPerc = 0;
      if (state.is_Tax1 == "false" || state.is_Tax1 == false) {
        TAX1Perc = 0;
      }
      if (state.is_Tax2 == "false" || state.is_Tax2 == false) {
        TAX2Perc = 0;
      }
      if (state.is_Tax3 == "false" || state.is_Tax3 == false) {
        TAX3Perc = 0;
      }
    }
    if (state.TaxType == "None") {
      SGSTPerc = 0;
      IGSTPerc = 0;
      CGSTPerc = 0;
      VATPerc = 0;
      TAX1Perc = 0;
      TAX2Perc = 0;
      TAX3Perc = 0;
    }
    if (state.TaxType == "VAT") {
      SGSTPerc = 0;
      IGSTPerc = 0;
      CGSTPerc = 0;
      if (state.is_Tax1 == "false" || state.is_Tax1 == false) {
        TAX1Perc = 0;
      }
      if (state.is_Tax2 == "false" || state.is_Tax2 == false) {
        TAX2Perc = 0;
      }
      if (state.is_Tax3 == "false" || state.is_Tax3 == false) {
        TAX3Perc = 0;
      }
    }

    if (!SGSTPerc) {
      SGSTPerc = 0;
    }
    if (!CGSTPerc) {
      CGSTPerc = 0;
    }
    if (!IGSTPerc) {
      IGSTPerc = 0;
    }
    if (!TAX1Perc) {
      TAX1Perc = 0;
    }
    if (!TAX2Perc) {
      TAX2Perc = 0;
    }
    if (!TAX3Perc) {
      TAX3Perc = 0;
    }
    if (!VATPerc) {
      VATPerc = 0;
    }
    let SGSTAmount = Number((TaxableAmount * SGSTPerc) / 100);
    let CGSTAmount = Number((TaxableAmount * CGSTPerc) / 100);
    let IGSTAmount = Number((TaxableAmount * IGSTPerc) / 100);
    let TAX1Amount = Number((TaxableAmount * TAX1Perc) / 100);
    let TAX2Amount = Number((TaxableAmount * TAX2Perc) / 100);
    let TAX3Amount = Number((TaxableAmount * TAX3Perc) / 100);
    let VATAmount = Number((TaxableAmount * VATPerc) / 100);

    // let TotalGstPerc = Number(SGSTPerc) + Number(CGSTPerc) + Number(IGSTPerc);

    // let is_kfc = Details[index]["is_kfc"];
    // let HSNCode = Details[index]["HSNCode"];
    // let is_HSNCode_ok = check_hsn_code(HSNCode);
    let KFCAmount = 0;
    let KFCPerc = 0;
    // if (TotalGstPerc == 3) {
    //   if (
    //     is_B2C == true &&
    //     is_kfc == true &&
    //     is_HSNCode_ok == true &&
    //     this.state.kfc_in_sttings == true
    //   ) {
    //     KFCPerc = 0.25;
    //     KFCAmount = (Number(TaxableAmount) * KFCPerc) / 100;
    //   }
    // } else if (TotalGstPerc > 5) {
    //   if (
    //     is_B2C == true &&
    //     is_kfc == true &&
    //     this.state.kfc_in_sttings == true
    //   ) {
    //     KFCAmount = Number(TaxableAmount) / 100;
    //     KFCPerc = 1;
    //   }
    // } else {
    //   KFCAmount = 0;
    //   KFCPerc = 0;
    // }

    Details[index]["SGSTAmount"] = SGSTAmount;
    Details[index]["CGSTAmount"] = CGSTAmount;
    Details[index]["IGSTAmount"] = IGSTAmount;
    Details[index]["TAX1Amount"] = TAX1Amount;
    Details[index]["TAX2Amount"] = TAX2Amount;
    Details[index]["TAX3Amount"] = TAX3Amount;
    Details[index]["VATAmount"] = VATAmount;
    Details[index]["KFCAmount"] = KFCAmount;
    Details[index]["KFCPerc"] = KFCPerc;

    // TotalTax
    let TotalTax = Number(
      TAX1Amount +
        TAX2Amount +
        TAX3Amount +
        VATAmount +
        SGSTAmount +
        CGSTAmount +
        IGSTAmount +
        KFCAmount
    );
    Details[index]["TotalTax"] = TotalTax;

    // RateWithTax
    if (!Qty) {
      Qty = 0;
    }
    if (!FreeQty) {
      FreeQty = 0;
    }
    if (!TotalTax) {
      TotalTax = 0;
    }

    let R_Qty = Qty;

    let singleTax = Number(TotalTax / R_Qty);

    UnitPrice = Details[index]["UnitPrice"];

    if (!UnitPrice) {
      UnitPrice = 0;
    }
    UnitPrice = Number(UnitPrice);
    let RateWithTax = Number(UnitPrice + singleTax);
    if (!RateWithTax) {
      RateWithTax = 0;
    }
    Details[index]["RateWithTax"] = RateWithTax;

    // NetAmount
    if (!TaxableAmount) {
      TaxableAmount = 0;
    }
    let NetAmount = Number(TaxableAmount + TotalTax);
    Details[index]["NetAmount"] = NetAmount;
  }
  return Details;
};

export const MasterCalculations = async (
  Details,
  state,
  PriceRounding,
  RoundOffFigure
) => {
  let TotalNetAmount = 0;
  let TotalGrossAmt = 0;
  let TotalTaxableAmount = 0;
  let GrandTotalTax = 0;
  let TotalDiscountAmount = 0;
  let TotalAddlDiscAmt = 0;
  let TotalVATAmount = 0;
  let TotalSGSTAmount = 0;
  let TotalCGSTAmount = 0;
  let TotalIGSTAmount = 0;
  let TotalTAX1Amount = 0;
  let TotalTAX2Amount = 0;
  let TotalTAX3Amount = 0;
  let TotalKFCAmount = 0;
  let TotalQty = 0;
  let TotalFreeQty = 0;

  let IGST_perc_list = [];
  let IGST_final_list = [];
  let SGST_perc_list = [];
  let SGST_final_list = [];

  let shipping_tax_amount = state.shipping_tax_amount;
  let half_shipping_tax_amt = Number(shipping_tax_amount) / 2;
  let ShippingCharge = state.ShippingCharge;
  let SalesTax = state.SalesTax;

  if (!shipping_tax_amount) {
    shipping_tax_amount = 0;
  }
  if (!half_shipping_tax_amt) {
    half_shipping_tax_amt = 0;
  }
  if (!ShippingCharge) {
    ShippingCharge = 0;
  }
  if (!SalesTax) {
    SalesTax = 0;
  }

  let TaxTaxableAmount = 0;
  let NonTaxTaxableAmount = 0;

  Details.map((i) => {
    TotalNetAmount += i.NetAmount ? Number(i.NetAmount) : 0;
    TotalGrossAmt += i.GrossAmount ? Number(i.GrossAmount) : 0;
    TotalTaxableAmount += i.TaxableAmount ? Number(i.TaxableAmount) : 0;
    GrandTotalTax += i.TotalTax ? Number(i.TotalTax) : 0;
    TotalDiscountAmount += i.DiscountAmount ? Number(i.DiscountAmount) : 0;
    TotalAddlDiscAmt += i.AddlDiscAmt ? Number(i.AddlDiscAmt) : 0;
    TotalVATAmount += i.VATAmount ? Number(i.VATAmount) : 0;
    TotalSGSTAmount += i.SGSTAmount ? Number(i.SGSTAmount) : 0;
    TotalCGSTAmount += i.CGSTAmount ? Number(i.CGSTAmount) : 0;
    TotalIGSTAmount += i.IGSTAmount ? Number(i.IGSTAmount) : 0;
    TotalTAX1Amount += i.TAX1Amount ? Number(i.TAX1Amount) : 0;
    TotalTAX2Amount += i.TAX2Amount ? Number(i.TAX2Amount) : 0;
    TotalTAX3Amount += i.TAX3Amount ? Number(i.TAX3Amount) : 0;
    TotalKFCAmount += i.KFCAmount ? Number(i.KFCAmount) : 0;

    let qty = i.Qty ? Number(i.Qty) : 0;
    let free_qty = i.FreeQty ? Number(i.FreeQty) : 0;
    let MultiFactor = i.MultiFactor ? Number(i.MultiFactor) : 1;
    let BaseQty = Number(qty) * Number(MultiFactor);
    let BaseFreeQty = Number(free_qty) * Number(MultiFactor);

    TotalQty += Number(BaseQty);
    TotalFreeQty += Number(BaseFreeQty);

    if (i.VATPerc > 0 || i.IGSTPerc > 0) {
      TaxTaxableAmount += Number(i.TaxableAmount);
    } else {
      NonTaxTaxableAmount += Number(i.TaxableAmount);
    }

    let is_exist_IGST = IGST_perc_list.includes(i.IGSTPerc);
    if (is_exist_IGST == false && i.IGSTPerc > 0) {
      IGST_perc_list.push(i.IGSTPerc);
      let IGSTAmount = Number(i.IGSTAmount) + Number(shipping_tax_amount);
      IGST_final_list.push({
        key: Number(i.IGSTPerc).toFixed(PriceRounding),
        val: Number(IGSTAmount),
      });
    } else {
      IGST_final_list.map((b) => {
        if (Number(b.key).toFixed(2) == Number(i.IGSTPerc).toFixed(2)) {
          let val_amt = b.val;
          b.val = Number(val_amt) + Number(i.IGSTAmount);
        }
      });
    }

    let is_exist_SGST = SGST_perc_list.includes(i.SGSTPerc);
    if (is_exist_SGST == false && Number(i.SGSTPerc) > 0) {
      SGST_perc_list.push(i.SGSTPerc);
      let SGSTAmount = Number(i.SGSTAmount) + Number(half_shipping_tax_amt);
      SGST_final_list.push({
        key: Number(i.SGSTPerc).toFixed(PriceRounding),
        val: Number(SGSTAmount),
      });
    } else {
      SGST_final_list.map((b) => {
        if (Number(b.key).toFixed(2) == Number(i.SGSTPerc).toFixed(2)) {
          let val_amt = b.val;
          b.val = Number(val_amt) + Number(i.SGSTAmount);
        }
      });
    }
  });

  if (Number(TotalVATAmount) > 0) {
    TotalVATAmount = Number(TotalVATAmount) + Number(shipping_tax_amount);
  }
  if (Number(TotalSGSTAmount) > 0) {
    TotalSGSTAmount = Number(TotalSGSTAmount) + Number(half_shipping_tax_amt);
  }
  if (Number(TotalCGSTAmount) > 0) {
    TotalCGSTAmount = Number(TotalCGSTAmount) + Number(half_shipping_tax_amt);
  }
  if (Number(TotalIGSTAmount) > 0) {
    TotalIGSTAmount = Number(TotalIGSTAmount) + Number(shipping_tax_amount);
  }
  if (Number(SalesTax) > 5) {
    TotalKFCAmount = Number(TotalKFCAmount) + Number(shipping_tax_amount);
  }

  TotalTaxableAmount =
    Number(TotalTaxableAmount) +
    Number(shipping_tax_amount) +
    Number(ShippingCharge);

  let BillDiscPercent = state.BillDiscPercent;
  let BillDiscAmt = Number(
    (TotalTaxableAmount * Number(BillDiscPercent)) / 100
  );
  let TotalDiscount =
    Number(TotalDiscountAmount) +
    Number(TotalAddlDiscAmt) +
    Number(BillDiscAmt);
  let GrandTotal = 0;

  TotalNetAmount =
    Number(TotalNetAmount) +
    Number(shipping_tax_amount) +
    Number(ShippingCharge);

  // if saudi vat then Calculation will change if bill discount  start function
  if (state.CountryCode == "SAR" && state.VAT && BillDiscAmt > 0) {
    GrandTotalTax = await get_vat_changed_details(
      TotalGrossAmt,
      Details,
      BillDiscAmt,
      TaxTaxableAmount,
      NonTaxTaxableAmount
    );
    TotalVATAmount = Number(GrandTotalTax) + Number(shipping_tax_amount);
  }
  // end function
  GrandTotal = Number(
    TotalGrossAmt +
      GrandTotalTax -
      TotalDiscount +
      Number(shipping_tax_amount) +
      Number(ShippingCharge)
  );

  let roundoff = state.RoundOff;
  if (state.edit_did_mount == false) {
    if (state.is_manual_roundoff == false) {
      let grand_int = Math.floor(GrandTotal);
      let grand_dec = Number(GrandTotal % 1);
      let round = 0;
      if (RoundOffFigure > 0) {
        round = Number(RoundOffFigure) / 10;
      }
      if (round > 0) {
        if (grand_dec <= round) {
          GrandTotal = grand_int;
          roundoff = Number(grand_dec) * -1;
        } else {
          GrandTotal = Number(grand_int + 1);
          roundoff = 1 - Number(grand_dec);
        }
      }
    } else {
      GrandTotal = Number(GrandTotal) + Number(state.RoundOff);
    }
  } else {
    GrandTotal = Number(GrandTotal) + Number(state.RoundOff);
  }

  if (!roundoff) {
    roundoff = 0;
  }

  let LoyaltyValue = state.LoyaltyValue;
  if (!LoyaltyValue) {
    LoyaltyValue = 0;
  }
  if (GrandTotal > LoyaltyValue) {
    GrandTotal = Number(GrandTotal) - Number(LoyaltyValue);
  }

  let CashReceived = Number(state.CashReceived);
  let BankAmount = state.BankAmount;
  let cash = Number(CashReceived) + Number(BankAmount);
  let Balance = Number(GrandTotal) - Number(cash);
  TotalQty = Number(TotalQty) + Number(TotalFreeQty);
  let master_values = {
    TotalNetTotal: Number(TotalNetAmount),
    TotalGrossAmt: Number(TotalGrossAmt),
    TotalTaxableAmount: Number(TotalTaxableAmount),
    GrandTotalTax: Number(GrandTotalTax),
    TotalDiscount: Number(TotalDiscount),
    GrandTotal: Number(GrandTotal),
    TotalVATAmount: Number(TotalVATAmount),
    TotalSGSTAmount: Number(TotalSGSTAmount),
    TotalCGSTAmount: Number(TotalCGSTAmount),
    TotalIGSTAmount: Number(TotalIGSTAmount),
    TotalTAX1Amount: Number(TotalTAX1Amount),
    TotalTAX2Amount: Number(TotalTAX2Amount),
    TotalTAX3Amount: Number(TotalTAX3Amount),
    TotalKFCAmount: Number(TotalKFCAmount),
    BillDiscPercent: Number(BillDiscPercent),
    BillDiscAmount: Number(BillDiscAmt),
    Balance: Number(Balance),
    Balance_print: Number(Balance).toFixed(PriceRounding),
    RoundOff: Number(roundoff).toFixed(PriceRounding),
    RoundOffSaveVal: Number(roundoff),
    IGST_final_list: IGST_final_list,
    SGST_final_list: SGST_final_list,
    TaxTaxableAmount: TaxTaxableAmount,
    NonTaxTaxableAmount: NonTaxTaxableAmount,
    TotalQty: Number(TotalQty),
  };
  return master_values;
};

const get_vat_changed_details = async (
  TotalGrossAmt,
  Details,
  BillDiscAmt,
  TaxTaxableAmount,
  NonTaxTaxableAmount
) => {
  let tax_sum = 0;
  if (Number(TaxTaxableAmount) >= Number(BillDiscAmt)) {
    let vat_tax = (Number(BillDiscAmt) / Number(TaxTaxableAmount)) * 100;
    Details.map((i, index) => {
      if (i.VATPerc > 0) {
        let tx_amt = (Number(i.TaxableAmount) * Number(vat_tax)) / 100;
        let new_taxble = Number(i.TaxableAmount) - Number(tx_amt);
        tax_sum += (Number(new_taxble) * Number(i.VATPerc)) / 100;
      }
    });
  }
  return tax_sum;
};

export const get_DiscountPerc = (DiscAmt, GrossAmt) => {
  if (isNaN(DiscAmt)) {
    DiscAmt = 0;
  }
  DiscAmt = Number(DiscAmt);

  let DiscountPerc = Number((DiscAmt * 100) / GrossAmt);
  if (isNaN(DiscountPerc)) {
    DiscountPerc = 0;
  }
  return DiscountPerc;
};

export const get_DiscountAmt = (DiscPerc, GrossAmt) => {
  if (isNaN(DiscPerc)) {
    DiscPerc = 0;
  }
  DiscPerc = Number(DiscPerc);

  let DiscountAmount = Number((GrossAmt * DiscPerc) / 100);
  if (isNaN(DiscountAmount)) {
    DiscountAmount = 0;
  }
  return DiscountAmount;
};

export const AddItemsByBarcode = async (
  event,
  access,
  CompanyID,
  user_id,
  BranchID,
  PriceRounding,
  Details,
  index,
  AllowNegativeStock,
  ProductList,
  type
) => {
  let is_product = false;
  let message = "";
  let is_enter = false;
  let values = [];
  if (event.key === "Enter") {
    is_enter = true;
    let item_detail = await fetch(getProductBarcodeURL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        BarCode: event.target.value,
        PriceRounding: Number(PriceRounding),
      }),
    }).then((response) => response.json());

    if (item_detail.StatusCode == 6000) {
      let itemData = item_detail.data;
      let ProductID = itemData.ProductID;
      let PriceListID = itemData.PriceListID;
      let ProductName = itemData.ProductName;
      let Stock = itemData.Stock;
      let is_inclusive = itemData.is_inclusive;
      let ProductCode = itemData.ProductCode;
      let product_id = itemData.id;
      let BatchList = itemData.BatchList;
      let BatchCode = 0;
      if (BatchList.length) {
        BatchCode = BatchList[0].BatchCode;
      }
      values = [
        {
          ProductID: ProductID,
          PriceListID: PriceListID,
          ProductName: ProductName,
          Stock: Stock,
          is_inclusive: is_inclusive,
          ProductCode: ProductCode,
          product_id: product_id,
          BatchCode: BatchCode,
        },
      ];
      if (
        type == "Purchase" ||
        (type == "Sales" && AllowNegativeStock == true) ||
        Stock > 1
      ) {
        Details[index]["PriceListID"] = PriceListID;
        Details[index]["ProductID"] = ProductID;
        Details[index]["ProductName"] = ProductName;
        Details[index]["Stock"] = Stock;
        Details[index]["is_inclusive"] = is_inclusive;
        Details[index]["Qty"] = 1;
        Details[index]["ProductCode"] = ProductCode;
        Details[index]["BatchList"] = BatchList;
        Details[index]["BatchCode"] = BatchCode;
        let pros = [];
        ProductList.map((i) => {
          pros.push(i.ProductID);
        });
        let is_exist = pros.includes(ProductID);
        if (!is_exist) {
          let ProductItem = {
            ProductID: ProductID,
            ProductName: ProductName,
            BatchCode: BatchCode,
            product_id: product_id,
            ProductCode: ProductCode,
            Stock: Stock,
            is_inclusive: is_inclusive,
            PriceListID: PriceListID,
          };
          ProductList.push(ProductItem);
        }
        is_product = true;
      } else {
        message = "Insufficient Stock";
      }
    } else {
      message = "Product not found with this barcode";
    }
  }

  return [Details, is_product, message, is_enter, values];
};

export const get_ItemWiseBillDisc = (Details, BillDiscPercent) => {
  Details.map((i, index) => {
    let GrossAmount = Details[index]["GrossAmount"];
    let DiscountAmount = Number((GrossAmount * BillDiscPercent) / 100);
    Details[index]["DiscountAmount"] = DiscountAmount;
    Details[index]["DiscountPerc"] = BillDiscPercent;
  });

  return Details;
};

export const get_tax_details = async (
  CompanyID,
  user_id,
  BranchID,
  ProductTaxID,
  index,
  PriceRounding,
  Details,
  access,
  type
) => {
  let GST_Tax = 0;
  let Vat_Tax = 0;
  let GST_Inclusive = false;
  let Vat_Inclusive = false;
  let taxDetails = await fetch(getTaxDetailsUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      ProductTaxID: ProductTaxID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());

  if (type == "sales") {
    GST_Tax = taxDetails.GST_SalesTax;
    Vat_Tax = taxDetails.Vat_SalesTax;
  } else {
    GST_Tax = taxDetails.GST_PurchaseTax;
    Vat_Tax = taxDetails.Vat_PurchaseTax;
  }
  GST_Inclusive = taxDetails.GST_Inclusive;
  Vat_Inclusive = taxDetails.Vat_Inclusive;
  let half_gst = Number(GST_Tax / 2);
  Details[index]["ProductTaxID"] = ProductTaxID;
  Details[index]["VATPerc"] = Vat_Tax;
  Details[index]["SGSTPerc"] = half_gst;
  Details[index]["CGSTPerc"] = half_gst;
  Details[index]["IGSTPerc"] = GST_Tax;

  Details[index]["Vat_Inclusive"] = taxDetails.Vat_Inclusive;
  Details[index]["GST_Inclusive"] = taxDetails.GST_Inclusive;

  return Details;
};

export const get_salesSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_sales = await fetch(salesViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_sales;
};

export const get_salesOrderSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_salesOrder = await fetch(salesOrderViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_salesOrder;
};

export const get_salesEstimateSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_salesEstimate = await fetch(
    salesEstimateViewURL + unq_id + "/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
      }),
    }
  ).then((response) => response.json());
  return single_datas_salesEstimate;
};

export const get_salesReturnSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_salesReturn = await fetch(
    salesReturnViewURL + unq_id + "/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
      }),
    }
  ).then((response) => response.json());
  return single_datas_salesReturn;
};

export const get_purchaseSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_purchase = await fetch(purchaseViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      QtyRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_purchase;
};

export const get_purchaseReturnSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_purchase = await fetch(
    purchaseReturnViewURL + unq_id + "/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
        QtyRounding: PriceRounding,
      }),
    }
  ).then((response) => response.json());
  return single_datas_purchase;
};

export const get_purchaseOrderSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_purchase = await fetch(purchaseOrderViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      QtyRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_purchase;
};

export const get_workOrderSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_workOrder = await fetch(workOrderViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_workOrder;
};

// users list
export const get_usersList = (CompanyID, BranchID, access, PriceRounding) => {
  let users = fetch(usersUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return users;
};

export const get_expenseSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_expense = await fetch(expnseViewUrl + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      QtyRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_expense;
};

export const AddItemsByBatchcode = async (
  event,
  access,
  CompanyID,
  user_id,
  BranchID,
  PriceRounding,
  Details,
  index,
  AllowNegativeStock,
  ProductList,
  type
) => {
  let is_product = false;
  let message = "";
  let is_enter = false;
  let values = [];
  if (event.key === "Enter") {
    is_enter = true;
    let item_detail = await fetch(getProductBatchcodeURL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        BatchCode: event.target.value,
        PriceRounding: Number(PriceRounding),
      }),
    }).then((response) => response.json());

    if (item_detail.StatusCode == 6000) {
      let itemData = item_detail.data;
      let ProductID = itemData.ProductID;
      let PriceListID = itemData.PriceListID;
      let ProductName = itemData.ProductName;
      let Stock = itemData.Stock;
      let is_inclusive = itemData.is_inclusive;
      let ProductCode = itemData.ProductCode;
      let HSNCode = itemData.HSNCode;
      let SalesPrice = itemData.SalesPrice;
      let PurchasePrice = itemData.PurchasePrice;
      let BarCode = itemData.BarCode;
      let MRP = itemData.MRP;
      let MinimumSalesPrice = itemData.MinimumSalesPrice;
      let SalesPrice1 = itemData.SalesPrice1;
      let SalesPrice2 = itemData.SalesPrice2;
      let SalesPrice3 = itemData.SalesPrice3;
      let is_GST_inclusive = itemData.is_GST_inclusive;
      let is_VAT_inclusive = itemData.is_VAT_inclusive;
      let VatID = itemData.VatID;
      let GST = itemData.GST;
      let GSTTax = itemData.GST_SalesTax;
      let VAtTax = itemData.SalesTax;
      let UnitList = itemData.UnitList;
      let BatchList = itemData.BatchList;
      let ProductTaxID = item_detail.ProductTaxID;

      if (type == "Purchase" || AllowNegativeStock == true || Stock > 1) {
        Details[index]["PriceListID"] = PriceListID;
        Details[index]["ProductID"] = ProductID;
        Details[index]["ProductName"] = ProductName;
        Details[index]["Stock"] = Stock;
        Details[index]["is_inclusive"] = is_inclusive;
        Details[index]["Qty"] = 1;
        Details[index]["ProductCode"] = ProductCode;
        Details[index]["Vat_Inclusive"] = is_VAT_inclusive;
        Details[index]["GST_Inclusive"] = is_GST_inclusive;
        Details[index]["Tax1_Inclusive"] = false;
        Details[index]["Tax2_Inclusive"] = false;
        Details[index]["Tax3_Inclusive"] = false;

        let half_gst = Number(GSTTax / 2);
        Details[index]["ProductTaxID"] = ProductTaxID;
        Details[index]["VATPerc"] = VAtTax;
        Details[index]["SGSTPerc"] = half_gst;
        Details[index]["CGSTPerc"] = half_gst;
        Details[index]["IGSTPerc"] = GSTTax;
        Details[index]["TAX1Perc"] = 0;
        Details[index]["TAX2Perc"] = 0;
        Details[index]["TAX3Perc"] = 0;

        Details[index]["MinimumSalesPrice"] = MinimumSalesPrice;
        Details[index]["is_kfc"] = false;
        Details[index]["HSNCode"] = HSNCode;

        Details[index]["SalesPrice"] = SalesPrice;
        Details[index]["SalesPrice1"] = SalesPrice1;
        Details[index]["SalesPrice2"] = SalesPrice2;
        Details[index]["SalesPrice3"] = SalesPrice3;
        Details[index]["MRP"] = MRP;
        Details[index]["PurchasePrice"] = PurchasePrice;
        Details[index]["CostPerPrice"] = PurchasePrice;
        Details[index]["Barcode"] = BarCode;

        Details[index]["UnitList"] = UnitList;
        Details[index]["BatchList"] = BatchList;

        let pros = [];
        ProductList.map((i) => {
          pros.push(i.ProductID);
        });
        let is_exist = pros.includes(ProductID);
        if (!is_exist) {
          let ProductItem = {
            ProductID: ProductID,
            ProductName: ProductName,
          };
          ProductList.push(ProductItem);
        }
        is_product = true;
        if (type != "Purchase" || Stock < 1) {
          message = "Insufficient Stock";
        }
      } else {
        message = "Insufficient Stock";
      }
    } else {
      message = "Product not found with this batchcode";
    }
  }

  return [Details, is_product, message, is_enter, values];
};

export const get_detailbyBatch = async (
  BatchCode,
  access,
  CompanyID,
  user_id,
  BranchID,
  PriceRounding,
  Details,
  index,
  AllowNegativeStock,
  ProductList,
  type
) => {
  let is_product = false;
  let message = "";
  let item_detail = await fetch(getProductBatchcodeURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      BatchCode: BatchCode,
      PriceRounding: Number(PriceRounding),
    }),
  }).then((response) => response.json());

  if (item_detail.StatusCode == 6000) {
    let itemData = item_detail.data;
    let product_id = itemData.id;
    let ProductID = itemData.ProductID;
    let PriceListID = itemData.PriceListID;
    let ProductName = itemData.ProductName;
    let Stock = itemData.Stock;
    let is_inclusive = itemData.is_inclusive;
    let ProductCode = itemData.ProductCode;
    let HSNCode = itemData.HSNCode;
    let SalesPrice = itemData.SalesPrice;
    let PurchasePrice = itemData.PurchasePrice;
    let BarCode = itemData.BarCode;
    let MRP = itemData.MRP;
    let MinimumSalesPrice = itemData.MinimumSalesPrice;
    let SalesPrice1 = itemData.SalesPrice1;
    let SalesPrice2 = itemData.SalesPrice2;
    let SalesPrice3 = itemData.SalesPrice3;
    let is_GST_inclusive = itemData.is_GST_inclusive;
    let is_VAT_inclusive = itemData.is_VAT_inclusive;
    let VatID = itemData.VatID;
    let GST = itemData.GST;
    let GSTTax = itemData.GST_SalesTax;
    let VAtTax = itemData.SalesTax;
    let UnitList = itemData.UnitList;
    let BatchList = itemData.BatchList;
    let ProductTaxID = item_detail.ProductTaxID;
    let MultiFactor = itemData.MultiFactor;

    if (type == "Purchase" || AllowNegativeStock == true || Stock > 1) {
      Details[index]["product_id"] = product_id;
      Details[index]["PriceListID"] = PriceListID;
      Details[index]["ProductID"] = ProductID;
      Details[index]["ProductName"] = ProductName;
      Details[index]["Stock"] = Stock;
      Details[index]["is_inclusive"] = is_inclusive;
      Details[index]["Qty"] = 1;
      Details[index]["ProductCode"] = ProductCode;
      Details[index]["Vat_Inclusive"] = is_VAT_inclusive;
      Details[index]["GST_Inclusive"] = is_GST_inclusive;
      Details[index]["Tax1_Inclusive"] = false;
      Details[index]["Tax2_Inclusive"] = false;
      Details[index]["Tax3_Inclusive"] = false;

      let half_gst = Number(GSTTax / 2);
      Details[index]["ProductTaxID"] = ProductTaxID;
      Details[index]["VATPerc"] = VAtTax;
      Details[index]["SGSTPerc"] = half_gst;
      Details[index]["CGSTPerc"] = half_gst;
      Details[index]["IGSTPerc"] = GSTTax;
      Details[index]["TAX1Perc"] = 0;
      Details[index]["TAX2Perc"] = 0;
      Details[index]["TAX3Perc"] = 0;

      Details[index]["MinimumSalesPrice"] = MinimumSalesPrice;
      Details[index]["is_kfc"] = false;
      Details[index]["HSNCode"] = HSNCode;

      Details[index]["SalesPrice"] = SalesPrice;
      Details[index]["SalesPrice1"] = SalesPrice1;
      Details[index]["SalesPrice2"] = SalesPrice2;
      Details[index]["SalesPrice3"] = SalesPrice3;
      Details[index]["MRP"] = MRP;
      Details[index]["PurchasePrice"] = PurchasePrice;
      Details[index]["CostPerPrice"] = PurchasePrice;
      Details[index]["Barcode"] = BarCode;

      Details[index]["UnitList"] = UnitList;
      Details[index]["BatchList"] = BatchList;
      Details[index]["BatchCode"] = BatchCode;
      console.log("MultiFactor||||||||||||||||||||");
      console.log(MultiFactor);
      Details[index]["MultiFactor"] = MultiFactor;

      let pros = [];
      ProductList.map((i) => {
        pros.push(i.ProductID);
      });
      let is_exist = pros.includes(ProductID);
      if (!is_exist) {
        let ProductItem = {
          id: product_id,
          ProductID: ProductID,
          ProductName: ProductName,
          Stock: Stock,
          BatchCode: BatchCode,
        };
        ProductList.push(ProductItem);
      }
      is_product = true;
      if (type != "Purchase" && AllowNegativeStock == false && Stock < 1) {
        message = "Insufficient Stock";
      }
    } else {
      message = "Insufficient Stock";
    }
  } else {
    message = "Batch not found with this Product";
  }
  return [Details, message];
};

export const get_SingleUnitDetailsbyBatch = async (
  CompanyID,
  index,
  user_id,
  BranchID,
  PriceListID,
  BatchCode,
  PriceRounding,
  access,
  Details
) => {
  let unit_detail = await fetch(singleUnitbyBatchURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceListID: PriceListID,
      BatchCode: BatchCode,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  let SalesPrice1 = unit_detail.SalesPrice1;
  let SalesPrice2 = unit_detail.SalesPrice2;
  let SalesPrice3 = unit_detail.SalesPrice3;
  let SalesPrice = unit_detail.SalesPrice;
  let MRP = unit_detail.MRP;
  let PurchasePrice = unit_detail.PurchasePrice;
  let Barcode = unit_detail.Barcode;
  Details[index]["SalesPrice"] = SalesPrice;
  Details[index]["SalesPrice1"] = SalesPrice1;
  Details[index]["SalesPrice2"] = SalesPrice2;
  Details[index]["SalesPrice3"] = SalesPrice3;
  Details[index]["MRP"] = MRP;
  Details[index]["PurchasePrice"] = PurchasePrice;
  Details[index]["CostPerPrice"] = PurchasePrice;
  Details[index]["Barcode"] = Barcode;
  return Details;
};

export const get_batchSearchList = (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  BatchCode,
  length
) => {
  let BatchList = fetch(getsearchBatchcodeURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: Number(PriceRounding),
      BatchCode: BatchCode,
      length: length,
    }),
  }).then((response) => response.json());
  return BatchList;
};

export const get_filteredOpeningStock = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  filterValue,
  GroupID,
  page_no,
  items_per_page
) => {
  let DetailsList = [];
  let ProductList = [];
  let TotalQty = 0;
  let GrandTotal = 0;
  let total_count = 0;
  let Details = await fetch(openingStockFilterURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: Number(PriceRounding),
      filterValue: filterValue,
      GroupID: GroupID,
      page_no: page_no,
      items_per_page: items_per_page,
    }),
  }).then((response) => response.json());
  if (Details.StatusCode == 6000) {
    DetailsList = Details.data;
    ProductList = Details.product_list;
    TotalQty = Details.TotalQty;
    GrandTotal = Details.GrandTotal;
    total_count = Details.count;
  }
  return [DetailsList, ProductList, TotalQty, GrandTotal, total_count];
};

export const get_OpeningStockSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_purchase = await fetch(openingStockViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      QtyRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return single_datas_purchase;
};

export const get_StockTransferSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_stocktransfer = await fetch(
    viewStockTransferURL + unq_id + "/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
        QtyRounding: PriceRounding,
      }),
    }
  ).then((response) => response.json());
  return single_datas_stocktransfer;
};

export const AddItemsByProductCode = async (
  value,
  access,
  CompanyID,
  user_id,
  BranchID,
  PriceRounding,
  Details,
  index,
  AllowNegativeStock,
  ProductList,
  type
) => {
  let is_product = false;
  let message = "";
  let is_enter = false;
  let values = [];
  if (value.ProductCode) {
    is_enter = true;
    let item_detail = await fetch(getProductBarcodeURL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        BarCode: value.ProductCode,
        PriceRounding: Number(PriceRounding),
      }),
    }).then((response) => response.json());

    if (item_detail.StatusCode == 6000) {
      let itemData = item_detail.data;
      let ProductID = itemData.ProductID;
      let PriceListID = itemData.PriceListID;
      let ProductName = itemData.ProductName;
      let Stock = itemData.Stock;
      let is_inclusive = itemData.is_inclusive;
      let ProductCode = itemData.ProductCode;
      let BatchList = itemData.BatchList;
      let product_id = itemData.id;
      let BatchCode = 0;
      if (BatchList.length) {
        BatchCode = BatchList[0].BatchCode;
      }
      values = [
        {
          ProductID: ProductID,
          PriceListID: PriceListID,
          ProductName: ProductName,
          Stock: Stock,
          is_inclusive: is_inclusive,
          ProductCode: ProductCode,
          product_id: product_id,
        },
      ];
      if (
        type == "Purchase" ||
        (type == "Sales" && AllowNegativeStock == true) ||
        Stock > 1
      ) {
        Details[index]["PriceListID"] = PriceListID;
        Details[index]["ProductID"] = ProductID;
        Details[index]["ProductName"] = ProductName;
        Details[index]["Stock"] = Stock;
        Details[index]["is_inclusive"] = is_inclusive;
        Details[index]["Qty"] = 1;
        Details[index]["ProductCode"] = ProductCode;
        Details[index]["BatchList"] = BatchList;
        Details[index]["BatchCode"] = BatchCode;
        let pros = [];
        ProductList.map((i) => {
          pros.push(i.ProductID);
        });
        let is_exist = pros.includes(ProductID);
        if (!is_exist) {
          let ProductItem = {
            ProductID: ProductID,
            ProductName: ProductName,
          };
          ProductList.push(ProductItem);
        }
        is_product = true;
      } else {
        message = "Insufficient Stock";
      }
    } else {
      message = "Product not found with this Product code";
    }
  }

  return [Details, is_product, message, is_enter, values];
};

export const get_OrderSales = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  OrderNo
) => {
  let single_datas_sales = await fetch(getSalesOrderURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      OrderNo: OrderNo,
    }),
  }).then((response) => response.json());
  return single_datas_sales;
};

export const get_filtered_orders = (
  CompanyID,
  user_id,
  BranchID,
  type_invoice,
  access,
  PriceRounding,
  OrderCustomerID,
  OrderFromDate,
  OrderToDate
) => {
  let orderDetails = fetch(getfilterdSalesOrderURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      type_invoice: type_invoice,
      PriceRounding: PriceRounding,
      OrderCustomerID: OrderCustomerID,
      OrderFromDate: OrderFromDate,
      OrderToDate: OrderToDate,
    }),
  }).then((response) => response.json());
  return orderDetails;
};

export const get_OrderDetailsSales = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  voucher_list
) => {
  let single_datas_sales_bycustomers = await fetch(getSalesByCustomerOrderURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      order_vouchers: voucher_list,
    }),
  }).then((response) => response.json());
  return single_datas_sales_bycustomers;
};

export const get_EstimateSales = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  EstimateNo
) => {
  let single_datas_sales = await fetch(getSalesEstimateURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      EstimateNo: EstimateNo,
    }),
  }).then((response) => response.json());
  return single_datas_sales;
};

export const get_filtered_estimates = (
  CompanyID,
  user_id,
  BranchID,
  type_invoice,
  access,
  PriceRounding,
  EstimateCustomerID,
  EstimateFromDate,
  EstimateToDate
) => {
  let estimateDetails = fetch(getfilterdSalesEstimateURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      type_invoice: type_invoice,
      PriceRounding: PriceRounding,
      EstimateCustomerID: EstimateCustomerID,
      EstimateFromDate: EstimateFromDate,
      EstimateToDate: EstimateToDate,
    }),
  }).then((response) => response.json());
  return estimateDetails;
};

export const get_EstimateDetailsSales = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  voucher_list
) => {
  let single_datas_sales_bycustomers = await fetch(
    getSalesByCustomerEstimateURL,
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
        estimate_vouchers: voucher_list,
      }),
    }
  ).then((response) => response.json());
  return single_datas_sales_bycustomers;
};

export const get_StockManagementSingle = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  unq_id
) => {
  let single_datas_stockManagement = await fetch(
    StockManagementViewURL + unq_id + "/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        CompanyID: CompanyID,
        CreatedUserID: user_id,
        BranchID: BranchID,
        PriceRounding: PriceRounding,
        QtyRounding: PriceRounding,
      }),
    }
  ).then((response) => response.json());
  return single_datas_stockManagement;
};

export const get_ProductSalesHistory = async (
  CompanyID,
  user_id,
  BranchID,
  access,
  PriceRounding,
  ProductIDs,
  LedgerID
) => {
  let product_sales_history = await fetch(getproductHistoryURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      CreatedUserID: user_id,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
      ProductIDs: ProductIDs,
      LedgerID: LedgerID,
    }),
  }).then((response) => response.json());
  return product_sales_history;
};

export const get_reconciliationDatas = async (
  access,
  CompanyID,
  BranchID,
  BankID,
  ClosingDate
) => {
  let reconciliation_datas = await fetch(reconciliationDatasURL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      BankID: BankID,
      BranchID: BranchID,
      ClosingDate: ClosingDate,
    }),
  }).then((response) => response.json());
  return reconciliation_datas;
};

export const get_reconciliationSingleData = async (
  access,
  CompanyID,
  BranchID,
  unq_id,
  PriceRounding
) => {
  let reconciliation_datas = await fetch(reconciliationViewURL + unq_id + "/", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      // "accept": "application/json"
    },
    body: JSON.stringify({
      CompanyID: CompanyID,
      BranchID: BranchID,
      PriceRounding: PriceRounding,
    }),
  }).then((response) => response.json());
  return reconciliation_datas;
};
