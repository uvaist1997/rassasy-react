import { createSlice } from "@reduxjs/toolkit";
import swal from "sweetalert";
import * as base from "../../settings";
import history from "../../components/history";
import { Redirect } from "react-router-dom";
import store from "../store";

// Slice

const initialUser = localStorage.getItem("user")
  ? JSON.parse(localStorage.getItem("user"))
  : null;

const initialIs_Auth = localStorage.getItem("is_Auth")
  ? JSON.parse(localStorage.getItem("is_Auth"))
  : null;

const initialIs_home = localStorage.getItem("Is_home")
  ? JSON.parse(localStorage.getItem("Is_home"))
  : null;

const initialLanguage = localStorage.getItem("language")
  ? JSON.parse(localStorage.getItem("language"))
  : null;

const slice = createSlice({
  name: "user",
  initialState: {
    user: initialUser,
    is_Auth: initialIs_Auth,
    Is_home: initialIs_home,
    language: initialLanguage,
  },
  // name: 'settings',
  // initialState: {
  //   settings: initialsettings,
  // },
  reducers: {
    loginSuccess: (state, action) => {
      console.log(action.payload, "LOGINSUCCESS");
      state.user = action.payload;
      localStorage.setItem("user", JSON.stringify(action.payload));
      localStorage.setItem("is_Auth", true);
    },
    switchLanguageSuccess: (state, action) => {
      console.log(action.payload);
      state.language = action.payload;
      localStorage.setItem("language", JSON.stringify(action.payload));
    },
    logoutSuccess: (state, action) => {
      state.user = null;
      localStorage.removeItem("user");
      localStorage.removeItem("language");
      localStorage.removeItem("is_Auth");
      localStorage.removeItem("Is_home");
    },
    homeSuccess: (state, action) => {
      console.log(action.payload, "LOGINSUCCESS");
      // localStorage.setItem("Is_home", state.Is_home);
      localStorage.setItem("Is_home", JSON.stringify(action.payload));
    },
  },
});

export default slice.reducer;

// Actions

const {
  loginSuccess,
  logoutSuccess,
  homeSuccess,
  settingsSuccess,
  companySuccess,
  switchLanguageSuccess,
} = slice.actions;

export const login = ({
  username,
  access,
  role,
  is_Profile,
  is_expired,
  defaultlanguage,
  multylanguage,
}) => async (dispatch) => {
  try {
    console.log(access, username, "USERNAME");
    dispatch(
      loginSuccess({
        username,
        access,
        role,
        is_Profile,
        is_expired,
      })
    );
    dispatch(switchLanguageSuccess({ defaultlanguage, multylanguage }));
    // history.push("/");

    // window.location.reload();
    // await api.post('/api/auth/login/', { username, password })
  } catch (e) {
    return console.error(e.message);
  }
};

export const logout = () => async (dispatch) => {
  try {
    history.push("/");
    window.location.reload();
    // await api.post('/api/auth/logout/')
    return dispatch(logoutSuccess());
  } catch (e) {
    return console.error(e.message);
  }
};
export const logout1 = () => async (dispatch) => {
  try {
    history.push("/sign-in");
    window.location.reload();
    // await api.post('/api/auth/logout/')
    return dispatch(logoutSuccess());
  } catch (e) {
    return console.error(e.message);
  }
};
export const home_page = ({ Is_home }) => async (dispatch) => {
  try {
    history.push("/");

    window.location.reload();
    return dispatch(homeSuccess({ Is_home }));
  } catch (e) {
    return console.error(e.message);
  }
};
export const home_page1 = ({ Is_home }) => async (dispatch) => {
  try {
    return dispatch(homeSuccess({ Is_home }));
  } catch (e) {
    return console.error(e.message);
  }
};
export const switchLanguage = ({
  defaultlanguage,
  multylanguage,
  activelanguage,
}) => async (dispatch) => {
  console.log(defaultlanguage, multylanguage);
  try {
    return dispatch(
      switchLanguageSuccess({ defaultlanguage, multylanguage, activelanguage })
    );
  } catch (e) {
    return console.error(e.message);
  }
};
// export const ProfileSuccess = () => async (dispatch) => {
//   console.log("ProfileSuccess");
// };

export const ProfileSuccess = ({
  name,
  arabicname,
  address,
  Image,
  phone,
  token,
  arabicaddress,
  spotimage,
  defaultlanguage,
  multylanguage,
  country,
  location,
  lng,
  lat,
}) => async (dispatch) => {
  try {
    swal({
      title: "Please wait ",
      text: "The Profile is Creating..",
      icon: "warning",
      button: false,
    });
    const user_data = store.getState();
    const formData = new FormData();
    console.log(token, "ttokenokenname");
    console.log(defaultlanguage, "defaultlanguage");
    console.log(multylanguage, "multylanguage");
    console.log(Image, "Image");
    formData.append("defaultlanguage", defaultlanguage);
    formData.append("multylanguage", multylanguage);
    formData.append("name", name);
    formData.append("arabicname", arabicname);
    formData.append("address", address);
    formData.append("arabicaddress", arabicaddress);
    formData.append("image", Image);
    formData.append("phone", phone);
    formData.append("country", country);
    formData.append("spotimage", spotimage);
    formData.append("location", location);
    formData.append("lng", lng);
    formData.append("lat", lat);
    fetch(base.BASE_URL + "users/create-hotel-profile/", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        // "accept": "application/json"
      },
      body: formData,
    })
      .then((response) => response.json())
      .then((response) => {
        console.log(token);
        let username = user_data.user.user.username;
        let access = user_data.user.user.access;
        let role = user_data.user.user.role;
        let is_Profile = true;
        console.log(response.success, "LOGIN@@@@@@@@@@@@@@@@@!!!!!!#######");

        if (response.success === 6000) {
          swal({
            title: "success",
            text: "Profile Created SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });

          history.push("/");
          window.location.reload();

          dispatch(
            loginSuccess({
              username,
              access,
              role,
              is_Profile,
            })
          );
        } else {
          swal({
            title: "failed",
            text: response.error,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
    // await api.post('/api/auth/login/', { username, password })
  } catch (e) {
    console.log("sadsad@@@");
    return console.error(e.message);
  }
};

// company
