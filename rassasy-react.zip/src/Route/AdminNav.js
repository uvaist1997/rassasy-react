import { Layout, Menu, Breadcrumb } from "antd";
import React, { useState, useEffect, lazy } from "react";
import {
  BrowserRouter as Router,
  Routes as Switch,
  useNavigate,
  Route,
  Link,
  NavLink,
} from "react-router-dom";
import {
  UserOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  VideoCameraOutlined,
  AuditOutlined,
  ContainerOutlined,
  HddOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import "../App.css";
import CreateCategory from "../Screens/CreateCategory";
import CreateProduct from "../Screens/CreateProduct";
import Login from "../Screens/Login";
import store from "../redux/store";
import { useDispatch } from "react-redux";
import { login, logout } from "../redux/store/user";
import logo from "../assets/images/lg.png"; // wherever is it.
import view from "../assets/images/view.png"; // wherever is it.
import cat from "../assets/images/category.png"; // wherever is it.
import prod from "../assets/images/product.png"; // wherever is it.
import prof from "../assets/images/profile.png"; // wherever is it.
import CreateProfile from "../Screens/CreateProfile";
import Categories from "../Screens/Categories";
import ProductMenu from "../Screens/Menu";
import Products from "../Screens/Products";
import EditCategory from "../Screens/EditCategory";
import EditProduct from "../Screens/EditProduct";
import EditProfile from "../Screens/EditProfile";
import HotelMenu from "../Screens/HotelMenu";
import QRcode from "../Screens/QRcode";
import CommonHeader from "../components/CommonHeader";
import scan from "../assets/images/scan.png"; // wherever is it.
import InfiniteUsers from "../components/InfiniteUsers";

const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;

// function CustomerSideNav() {
const Users = lazy(() => import("../Screens/Users"));
const Countries = lazy(() => import("../Screens/Countries"));
const LoginActivity = lazy(() => import("../Screens/LoginActivity"));

export default function AdminNav() {
  let user = store.getState();
  let role = "";
  let is_profile = "";
  if (user.user.is_Auth) {
    role = user.user.user.role;
    is_profile = user.user.user.is_profile;
  }
  const [state, setState] = useState({
    collapsed: false,
  });
  const history = useNavigate();
  const dispatch = useDispatch();
  const styles = {
    left_logo: {
      width: "70px",
    },
  };
  function toggle() {
    setState((prevState) => {
      return { collapsed: !state.collapsed };
    });
  }

  return (
    <Layout>
      <CommonHeader />
      <Layout>
        <div className="all-side-nav">
          <Sider width={50} className="site-layout-background">
            <Menu
              mode="inline"
              defaultSelectedKeys={["1"]}
              defaultOpenKeys={["sub1"]}
              style={{ height: "99vh" }}
              className="short-cut-menu sticky-top"
            >
              <div className="round-side-menu">
                <Menu.Item key="4" className="p-0 shortcut">
                  <Link to="/users-list">
                    <img src={prof} alt="view" width={50} />
                  </Link>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>Users</p>
              </div>
              <div className="round-side-menu">
                <Menu.Item key="4" className="p-0 shortcut">
                  <Link to="/countries">
                    <img src={prof} alt="view" width={50} />
                  </Link>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>Country</p>
              </div>
              <div className="round-side-menu">
                <Menu.Item key="4" className="p-0 shortcut">
                  <Link to="/login-activities">
                    <img src={prof} alt="view" width={50} />
                  </Link>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>
                  LoginActivity
                </p>
              </div>
            </Menu>
          </Sider>
        </div>
        <Layout style={{ padding: "0 24px 24px" }}>
          <Switch>
            <Route path="/" element={<Users />} />
            <Route path="/users-list" element={<Users />} />
            <Route path="/countries" element={<Countries />} />
            <Route path="/login-activities" element={<LoginActivity />} />
          </Switch>
        </Layout>
      </Layout>

      <div id="bottom-fixed-menu" className="bottom-fixed-nav">
        <nav class="navbar navbar-light ">
          <form class="form-inline">
            <Menu className="short-cut-menu sticky-top">
              <div className="round-side-menu">
                <Menu.Item key="2" className="p-0 shortcut">
                  <NavLink exact to="/" activeClassName="active">
                    <img src={prof} alt="view" width={50} />
                  </NavLink>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>Users</p>
              </div>
              <div className="round-side-menu">
                <Menu.Item key="3" className="p-0 shortcut">
                  <NavLink
                    style={{ display: "inline-block" }}
                    exact
                    to="/countries"
                  >
                    <img src={cat} alt="view" width={50} />
                  </NavLink>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>Country</p>
              </div>
              <div className="round-side-menu">
                <Menu.Item key="4" className="p-0 shortcut">
                  <NavLink
                    style={{ display: "inline-block" }}
                    to="/login-activities"
                  >
                    <img src={prod} alt="view" width={50} />
                  </NavLink>
                </Menu.Item>
                <p style={{ color: "#fff", marginTop: "15px" }}>
                  Login Activity
                </p>
              </div>
            </Menu>
          </form>
        </nav>
      </div>
    </Layout>
  );
}
