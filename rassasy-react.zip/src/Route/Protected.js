import React from "react";

import { Outlet, Navigate } from "react-router-dom";
import UserExpired from "../components/UserExpired";
import store from "../redux/store";
import AdminNav from "./AdminNav";
import SideNav from "./SideNav";

const Protected = () => {
  const user = store.getState();
  let is_Auth = null;
  let is_expired = false;
  let role = "";
  if (user.user.is_Auth) {
    is_Auth = user.user.is_Auth;
    if (user.user.user.is_expired) {
      is_expired = user.user.user.is_expired[0];
    }
    role = user.user.user.role;
  }
  console.log(user.user.is_Auth, "user.user.is_Auth");
  console.log(is_expired, "is_expired");
  console.log(role, "role");
  return user.user.is_Auth == null ? (
    <Outlet />
  ) : role === "user" && is_expired === true ? (
    <UserExpired />
  ) : role === "user" ? (
    <SideNav />
  ) : role === "superuser" ? (
    <AdminNav />
  ) : (
    <Navigate to="/" />
  );
};

export default Protected;
