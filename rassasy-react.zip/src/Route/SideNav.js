import { Layout, Menu, Breadcrumb } from "antd";
import React, { useState, useEffect, lazy } from "react";
import {
  BrowserRouter as Router,
  Routes as Switch,
  useNavigate,
  Route,
  Link,
  NavLink,
} from "react-router-dom";
import {
  UserOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  VideoCameraOutlined,
  AuditOutlined,
  ContainerOutlined,
  HddOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import "../App.css";
// import CreateCategory from "../../src/Screens/CreateCategory";
// import CreateProduct from "../../src/Screens/CreateProduct";
import Users from "../../src/Screens/Users";
import Login from "../../src/Screens/Login";
import store from "../redux/store";
import { useDispatch } from "react-redux";
import { login, logout } from "../redux/store/user";
import logo from "../assets/images/lg.png"; // wherever is it.
import view from "../assets/images/view.png"; // wherever is it.
import cat from "../assets/images/category.png"; // wherever is it.
import prod from "../assets/images/product.png"; // wherever is it.
import prof from "../assets/images/profile.png"; // wherever is it.
import scan from "../assets/images/scan.png"; // wherever is it.
// import CreateProfile from "../Screens/CreateProfile";
// import Categories from "../Screens/Categories";
// import ProductMenu from "../Screens/Menu";
// import Products from "../Screens/Products";
// import EditCategory from "../Screens/EditCategory";
// import EditProduct from "../Screens/EditProduct";
// import EditProfile from "../Screens/EditProfile";
// import QRcode from "../Screens/QRcode";
// import CommonHeader from "../components/CommonHeader";
import { useTranslation } from "react-i18next";
// import HotelMenu from "../Screens/HotelMenu";
import Home from "../Screens/Home";
// import ComponentToPrint from "../components/ComponentToPrint";

const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;

// function CustomerSideNav() {
const ComponentToPrint = lazy(() => import("../components/ComponentToPrint"));
const CommonHeader = lazy(() => import("../components/CommonHeader"));
const QRcode = lazy(() => import("../Screens/QRcode"));
const HotelMenu = lazy(() => import("../Screens/HotelMenu"));
const EditProfile = lazy(() => import("../Screens/EditProfile"));
const EditCategory = lazy(() => import("../Screens/EditCategory"));
const EditProduct = lazy(() => import("../Screens/EditProduct"));
const CreateProfile = lazy(() => import("../Screens/CreateProfile"));
const Categories = lazy(() => import("../Screens/Categories"));
const ProductMenu = lazy(() => import("../Screens/Menu"));
const Products = lazy(() => import("../Screens/Products"));
const CreateCategory = lazy(() => import("../../src/Screens/CreateCategory"));
const CreateProduct = lazy(() => import("../../src/Screens/CreateCategory"));

export default function SideNav() {
  let user = store.getState();
  let role = "";
  let is_profile = "";
  if (user.user.is_Auth) {
    role = user.user.user.role;
    is_profile = user.user.user.is_Profile;
  }
  const [state, setState] = useState({
    collapsed: false,
  });
  const history = useNavigate();
  const [t, i18n] = useTranslation("common");
  const dispatch = useDispatch();
  const styles = {
    left_logo: {
      width: "70px",
    },
  };
  const checkActive = (match, location) => {
    //some additional logic to verify you are in the home URI
    if (!location) return false;
    const { pathname } = location;
    console.log(pathname);
    return pathname === "/";
  };
  function toggle() {
    setState((prevState) => {
      return { collapsed: !state.collapsed };
    });
  }
  // if (is_profile) {
  console.log("^^^^^^^^^^^^^^^^^^^*********************");
  return (
    // <Router basename="/" history={history}>
    <>
      {is_profile == true ? (
        <Layout>
          <CommonHeader />
          <Layout>
            <div id="fixed-side-menu" className="all-side-nav">
              <Sider width={50} className="site-layout-background">
                <Menu
                  mode="inline"
                  defaultSelectedKeys={["1"]}
                  defaultOpenKeys={["sub1"]}
                  style={{ height: "99vh" }}
                  className="short-cut-menu sticky-top"
                >
                  <div className="round-side-menu">
                    <Menu.Item key="2" className="p-0 shortcut">
                      <NavLink to="/edit-profile">
                        <img src={prof} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("profile")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="3" className="p-0 shortcut">
                      <NavLink to="/" activeClassName="active">
                        <img src={cat} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("categories")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="4" className="p-0 shortcut">
                      <NavLink to="/products">
                        <img src={prod} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("items")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="4" className="p-0 shortcut">
                      <NavLink to="/menu-qrcode">
                        <img src={scan} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("qrcode")}
                    </p>
                  </div>
                  {/* <div className="round-side-menu">
                      <Menu.Item key="4" className="p-0 shortcut">
                        <NavLink to="/menu-qrcode">
                          <img src={scan} alt="view" width={50} />
                        </NavLink>
                      </Menu.Item>
                      <p style={{ color: "#fff", marginTop: "15px" }}>
                        {t("qrcode")}
                      </p>
                    </div> */}
                </Menu>
              </Sider>
              <div className="priview-menu">
                <Sider width={50} className="site-layout-background">
                  <Menu
                    mode="inline"
                    defaultSelectedKeys={["1"]}
                    defaultOpenKeys={["sub1"]}
                    style={{ height: "99vh" }}
                    className="short-cut-menu sticky-top"
                  >
                    <div className="view-menu">
                      <Link to="/menu">
                        <img src={view} alt="view" width={50} />
                      </Link>
                    </div>
                  </Menu>
                </Sider>
              </div>
            </div>

            <Layout style={{ padding: "0 24px 24px" }}>
              <Switch>
                <Route path="/" element={<Categories />} />
                <Route path="/hotel-menu/:id/" element={<HotelMenu />} />
                <Route path="/create-category" element={<CreateCategory />} />
                <Route path="/edit-category/:id/" element={<EditCategory />} />
                <Route
                  path="/single-edit-product/:id/"
                  element={<EditProduct />}
                />
                <Route path="/create-products" element={<CreateProduct />} />
                <Route path="/create-profile" element={<CreateProfile />} />
                <Route path="/menu" element={<ProductMenu />} />
                <Route path="/products" element={<Products />} />
                <Route path="/edit-profile" element={<EditProfile />} />
                <Route path="/menu-qrcode" element={<QRcode />} />
                <Route path="/qrcode" element={<ComponentToPrint />} />
                {/* <Route  path="/home" component={Home} /> */}
              </Switch>
            </Layout>
          </Layout>

          <div id="bottom-fixed-menu" className="bottom-fixed-nav">
            <nav class="navbar navbar-light ">
              <form class="form-inline">
                <Menu className="short-cut-menu sticky-top">
                  <div className="round-side-menu">
                    <Menu.Item key="2" className="p-0 shortcut">
                      <NavLink to="/edit-profile" activeClassName="active">
                        <img src={prof} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("profile")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="3" className="p-0 shortcut">
                      <NavLink style={{ display: "inline-block" }} to="/">
                        <img src={cat} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("categories")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="4" className="p-0 shortcut">
                      <NavLink
                        style={{ display: "inline-block" }}
                        to="/products"
                      >
                        <img src={prod} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("items")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="4" className="p-0 shortcut">
                      <NavLink style={{ display: "block" }} to="/menu-qrcode">
                        <img src={scan} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("qrcode")}
                    </p>
                  </div>
                  <div className="round-side-menu">
                    <Menu.Item key="4" className="p-0 shortcut">
                      <NavLink style={{ display: "inline-block" }} to="/menu">
                        <img src={view} alt="view" width={50} />
                      </NavLink>
                    </Menu.Item>
                    <p style={{ color: "#fff", marginTop: "15px" }}>
                      {t("View")}
                    </p>
                  </div>
                </Menu>
              </form>
            </nav>
          </div>
        </Layout>
      ) : (
        <CreateProfile />
      )}
    </>
  );
}
