const Compress = require("compress.js");
const compress = new Compress();

async function resizeImageFn(file) {
  const compress = new Compress();
  const resizedImage = await compress.compress([file], {
    size: 4, // the max size in MB, defaults to 2MB
    quality: 0.75, // the quality of the image, max is 1,
    maxWidth: 1920, // the max width of the output image, defaults to 1920px
    maxHeight: 1920, // the max height of the output image, defaults to 1920px
    resize: true, // defaults to true, set false if you do not want to resize the image width and height
  });

  const img = resizedImage[0];
  const base64str = img.data;
  const imgExt = img.ext;
  const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
  //   setState({ ...state, img: URL.createObjectURL(resizedFiile) });
  let file1 = [
    {
      uid: "1",
      url: URL.createObjectURL(resizedFiile),
    },
  ];
  // let s = new File([resizedImage], file.name);
  var s = new File([resizedFiile], file.name, {
    type: file.type,
    lastModified: new Date().getTime(),
  });

  return s;
}
