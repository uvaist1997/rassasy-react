// export const BASE_URL = "http://localhost:8000/api/v1/";
// export const MEDIA_URL = "http://localhost:8000";

// export const BASE_URL = "http://207.154.193.180:8000/api/v1/";

export const URL = "https://rassasy.vikncodes.in/";
export const BASE_URL = "https://www.api.rassasy.vikncodes.in/api/v1/";
export const MEDIA_URL = "https://www.api.rassasy.vikncodes.in";
