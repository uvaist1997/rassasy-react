import React from "react";
import {
  Route,
  BrowserRouter as Router,
  Switch,
  Link,
  // HashRouter as Router,
} from "react-router-dom";
import SideNav from "../src/Route/SideNav";

function dashboard() {
  return (
    <Router>
      <SideNav />
    </Router>
  );
}

export default dashboard;
