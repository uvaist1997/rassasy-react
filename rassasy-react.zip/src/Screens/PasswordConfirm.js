import React, { useState, useEffect, Component } from "react";
import { Button } from "react-bootstrap";
import history from "../components/history";
import TextField from "@material-ui/core/TextField";
import "../assets/css/Login.css";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import viknlogo from "../assets/images/vikn.png";
import { Modal, Form, Input } from "antd";
import { useParams } from "react-router-dom";
import { EyeOutlined, EyeInvisibleOutlined } from "@ant-design/icons";
import InputAdornment from "@material-ui/core/InputAdornment";
import IconButton from "@material-ui/core/IconButton";

function PasswordConfirm(props) {
  const { id } = useParams();
  const [state, setState] = useState({
    is_button: false,
    email: "",
    message: "",
    token: id,
    error: false,
    showPassword: false,
  });

  const handleClickShowPassword = (e) => {
    console.log(e, "EEEEEEEEEEEE");
    setState({ ...state, showPassword: !state.showPassword });
  };
  function handleChange(e) {
    setState((prevState) => {
      return { ...prevState, [e.target.name]: e.target.value, message: "" };
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    fetch(base.BASE_URL + `reset-password/confirm/`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        password: state.password,
        token: state.token,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.status === "OK") {
          swal({
            title: "Successful",
            text: "Your password changed successfully",
            icon: "success",
            button: true,
          });
          history.push("/");
          window.location.reload();
        } else {
          console.log(response["password"], "response");
          let message = "Please check your Token";
          let title = "Error";
          if (response["password"]) {
            message = response["password"][0];
            title = "Password Validation";
          } else if ((response.status = "notfound")) {
            message = "Invalid Token";
            title = "Invalid Token";
          }
          setState({
            ...state,
            message: message,
            // is_button: false,
          });
          // swal({
          //   title: title,
          //   text: message,
          //   icon: "warning",
          //   button: true,
          // });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }

  console.log(state);
  return (
    <div className="registration-page common-card">
      <div className="user-card">
        <div className="d-flex justify-content-center form_container login-form">
          <form onSubmit={handleSubmit} onChange={handleChange}>
            <div className="imageclick top-logo">
              <img src={logo} alt="Logo" width="100%" />
            </div>
            <h3>Change password fo Rassasy</h3>

            <div className="">
              <TextField
                required
                type={state.showPassword ? "text" : "password"}
                InputLabelProps={{ required: false }}
                className="test"
                label="Password"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="password"
                helperText={
                  state.message == "This password is too common." ||
                  state.message == "This password is entirely numeric."
                    ? state.message
                    : null
                }
                error={
                  state.message == "This password is too common." ||
                  state.message == "This password is entirely numeric."
                    ? true
                    : false
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        style={{ color: "#fff", fontSize: "18px" }}
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        edge="end"
                      >
                        {state.showPassword ? (
                          <EyeInvisibleOutlined />
                        ) : (
                          <EyeOutlined />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </div>
            {/* <div className="">
              <TextField
                required
                InputLabelProps={{ required: false }}
                className="test"
                label="Token"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="token"
                helperText={
                  state.message == "Invalid Token" ? state.message : null
                }
                error={state.message == "Invalid Token" ? true : false}
              />
            </div> */}

            <Button
              disabled={state.is_button}
              className="mt-2 login-button btn btn-block"
              variant="primary"
              type="submit"
              htmlType="submit"
            >
              Submit
            </Button>
            {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
          </form>
        </div>
      </div>
      <p className="mt-3">
        Already Have An Account? <Link to="/">Login</Link>
      </p>
      <div>
        <h5 className="pt-5">
          Powerd By{" "}
          <span>
            <img
              src={viknlogo}
              loading="lazy"
              width="116"
              alt=""
              className="image-24"
            />
          </span>
        </h5>
      </div>
    </div>
  );
}

export default PasswordConfirm;
