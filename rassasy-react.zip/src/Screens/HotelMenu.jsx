import React, { useState, useEffect, Component } from "react";
import { Link, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import "../assets/css/menu.css";
import Carousel from "react-elastic-carousel";
import store from "../redux/store";
import swal from "sweetalert";
import * as base from "../settings";
import "../assets/css/Login.css";
import viknlogo from "../assets/images/vikn.png";
import location from "../assets/images/location.png";
import { Spin, Switch } from "antd";
import {
  EditOutlined,
  EllipsisOutlined,
  SettingOutlined,
} from "@ant-design/icons";
import { useTranslation } from "react-i18next";
import phone from "../assets/images/phone.png";
import pagenotfound from "../assets/lottie/error.json"; // wherever is it.
import Lottie from "react-lottie";
import viknlottie from "../assets/lottie/logo.json";

const breakPoints = [
  { width: 1, itemsToShow: 4, focusOnSelect: true, showArrows: false },
  {
    width: 550,
    itemsToShow: 4,
    itemsToScroll: 2,
    focusOnSelect: true,
    showArrows: false,
  },
  { width: 768, itemsToShow: 4, focusOnSelect: true, showArrows: false },
  { width: 1200, itemsToShow: 5 },
];

function handleChange() {
  console.log(window.location.href, "AAAAAAAAAAAAAS");
}
function HotelMenu(props) {
  const { id } = useParams();

  const [t, i18n] = useTranslation("common");
  const [state, setState] = useState({
    loading: true,
    language: "en",
    data: [],
    hotelname: "",
    hotelphone: "",
    hoteladdress: "",
    hotellogo: "",
    index: "",
    categoryname: "",
    categoryname_arabic: "",
    active: false,
    product_datas: [],
    hotel_soptlight: "",
    hotelname_arabic: "",
    hoteladdress_arabic: "",
    is_expired: "",
    country: "",
  });
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: pagenotfound,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  let user = store.getState();

  useEffect(async () => {
    let bottom_nav = document.getElementById("bottom-fixed-menu");
    if (bottom_nav) {
      document.getElementById("bottom-fixed-menu").style.display = "none";
    }
    if (document.getElementById("fixed-side-menu")) {
      document.getElementById("fixed-side-menu").style.display = "none";
    }
    // let token = user.user.user.access;
    let token = "";
    let handle = id;
    console.log(handle, "HANDLE");
    let data = state.data;
    await fetch(base.BASE_URL + `products/list-category-menu?${handle}`, {
      method: "GET",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
          hotelname: response.profile_data.name,
          hotelname_arabic: response.profile_data.arabic_name,
          hotelphone: response.profile_data.phone,
          hoteladdress: response.profile_data.address,
          hoteladdress_arabic: response.profile_data.arabic_address,
          hotellogo: response.profile_data.image,
          hotel_soptlight: response.profile_data.spotimage,
          is_expired: response.is_expired,
          loading: false,
          language: response.profile_data.defaultlanguage,
          multylanguage: response.profile_data.multylanguage,
          country: response.profile_data.country,
          location: response.profile_data.location,
          lat: response.profile_data.lat,
          lng: response.profile_data.lng,
        });
        console.log(response.is_expired, "LOOOOOOOOOOOOOOOOOOOOOGGGGGGGG");
        if (response.profile_data.defaultlanguage) {
          i18n.changeLanguage(response.profile_data.defaultlanguage);
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  const dispatch = useDispatch();
  function onChange(a, b, c) {
    console.log(a, b, c);
  }

  function languageClick(lan) {
    setState({
      ...state,
      language: lan,
    });
  }
  function globalSwich(e) {
    console.log(e, "EEEEEEEEEEEEEEEEENNNGLISH");
    if (e == true) {
      i18n.changeLanguage("de");
      setState({
        ...state,
        language: "de",
      });
    } else {
      console.log(e, "ENGLISH");
      i18n.changeLanguage("en");
      setState({
        ...state,
        language: "en",
      });
    }
  }
  function menuClick(i) {
    // setState({
    //   ...state,
    //   index: i.id,
    //   });
    console.log(i, "asd");
    const category_datas = state.data;
    category_datas.filter((category_data) => category_data.id !== i.id);
    // let token = user.user.user.access;
    fetch(base.BASE_URL + "products/menu-products", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        pk: i.id,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          setState({
            ...state,
            product_datas: response.data,
            categoryname: i.name,
            categoryname_arabic: i.arabicname,
            index: i.id,
          });
          console.log("SUCCESSS");
        } else {
          swal({
            title: "faild",
            text: "id is not exists",
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  const viknLogolottie = {
    loop: true,
    autoplay: true,
    animationData: viknlottie,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "100vh",
            width: "100vw",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    if (state.is_expired == false) {
      const category_datas = state.data;
      const products = state.product_datas;
      console.log(state, "OOOOOOOOOOOOOOOOOOOOOOO");
      return (
        <div className="menu-header">
          <div className="nav">
            <div className="pl-2 div-block-77">
              <img
                style={{ height: "45px", width: "auto" }}
                src={base.MEDIA_URL + state.hotellogo}
                loading="lazy"
                sizes="(max-width: 479px) 100vw, 57.98828125px"
                width="58"
                srcset={base.MEDIA_URL + state.hotellogo}
                alt=""
                className="logoimg"
              />
              {state.multylanguage ? (
                <div className="text-block-41">
                  {/* <a onClick={() => {i18n.changeLanguage("en");languageClick("en");}}>
              EN
            </a>

            |{" "}
            <a onClick={() => {i18n.changeLanguage("de");languageClick("de");}} className="link-14">
              AR
            </a> */}
                  <Switch
                    className="ml-3"
                    checkedChildren="AR"
                    unCheckedChildren="EN"
                    onChange={globalSwich}
                    // checked={lang}
                  />
                </div>
              ) : null}
            </div>
            <div className="contact">
              <div className="d-flex align-items-center phone-number">
                <a
                  target="_blank"
                  href={`https://www.google.com/maps/search/${state.lat},${state.lng}+(${state.location})/@${state.lat},${state.lng},21z`}
                  className="mr-2 w-inline-block"
                >
                  {/* <a target="_blank" href={`https://www.google.com/maps/@${state.lat},${state.lng},17z`} className="mr-2 w-inline-block"> */}
                  <img src={location} loading="lazy" width="31" alt="" />
                </a>
                <a href={`tel:${state.hotelphone}`} className="link-15">
                  <img src={phone} loading="lazy" width="25" alt="" />
                </a>
              </div>
              {/* <div className="phone-number">
            <a href={`tel:${state.hotelphone}`} className="link-15">
              {state.hotelphone}
            </a>
          </div> */}
            </div>
          </div>

          <div className="div-block-64">
            <div
              style={{
                backgroundImage: `url("${
                  base.MEDIA_URL + state.hotel_soptlight + "/"
                }")`,
              }}
              className="div-block-65"
            >
              <div className="text-block-36">
                {state.language == "de"
                  ? state.hotelname_arabic
                  : state.hotelname}
              </div>
            </div>
          </div>
          <div className="div-block-72">
            <div className="text-block-38">{t("title")}</div>
          </div>
          {category_datas ? (
            <Carousel
              className="header-slider"
              breakPoints={breakPoints}
              afterChange={onChange}
            >
              {category_datas.map((i, index) => (
                <div
                  style={{ cursor: "pointer", outline: "none" }}
                  onClick={() => {
                    menuClick(i);
                  }}
                  id={i.id}
                  className={
                    state.index == i.id ? "active div-block-70" : "div-block-70"
                  }
                >
                  <div
                    style={{
                      backgroundImage: `url("${
                        base.MEDIA_URL + i.image + "/"
                      }")`,
                    }}
                    className="div-block-71 _1"
                  ></div>
                  <div className="text-block-37">
                    {state.language == "de" ? i.arabicname : i.name}
                  </div>
                </div>
              ))}
            </Carousel>
          ) : null}

          <div className="div-block-72">
            <div className="text-block-38">
              {state.language == "de"
                ? state.categoryname_arabic
                : state.categoryname}
            </div>
          </div>
          <div className="div-block-73">
            {products.map((i, index) => (
              <div className="div-block-74">
                <div
                  style={{
                    backgroundImage: `url("${base.MEDIA_URL + i.image + "/"}")`,
                  }}
                  className="div-block-75"
                ></div>
                <div className="text-block-39">
                  {state.language == "de" ? i.arabicname : i.name}
                </div>
                <div className="text-block-40">
                  {i.price}
                  {state.country == "SA" ? (
                    <span> {state.country}</span>
                  ) : (
                    <span> {state.country}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
          <div style={{ borderRadius: "5px 5px 0 0" }} className="div-block-78">
            <div className="text-block-42">
              {state.language == "de"
                ? state.hoteladdress_arabic
                : state.hoteladdress}
            </div>
          </div>
          <div className="div-block-80">
            <Lottie
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
              options={viknLogolottie}
              width={150}
            />
          </div>
        </div>
      );
    } else {
      return (
        <Lottie
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          options={defaultOptions}
          height={500}
          width={500}
        />
      );
    }
  }
}

export default HotelMenu;
