import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import swal from "sweetalert";
import {
  EditFilled,
  DeleteFilled,
  PlusCircleOutlined,
  LogoutOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Spin } from "antd";
import "../App.css";
import CreateBtn from "../assets/images/view.png";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";

export default function Categories() {
  const [state, setState] = useState({
    collapsed: false,
    loading: true,
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: "",
    Image: "",
    data: [
      {
        id: "",
        name: "",
        arabicname: "",
      },
    ],
  });
  const [t, i18n] = useTranslation("common");
  let user = store.getState();
  let defaultlanguage = "";
  let multylanguage = "";
  useEffect(async () => {
    let token = user.user.user.access;
    try {
      defaultlanguage = user.user.language.defaultlanguage;
    } catch (error) {
      defaultlanguage = "";
    }
    try {
      multylanguage = user.user.language.multylanguage;
    } catch (error) {
      multylanguage = "";
    }
    console.log(defaultlanguage, "AAAAAAAAAAAAA", multylanguage);
    await fetch(base.BASE_URL + "products/list-category", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
          loading: false,
          defaultlanguage: defaultlanguage,
          multylanguage: multylanguage,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  console.log(state, "Data");

  // const columns = [
  //   {
  //     title: t("image"),
  //     dataIndex: "image",
  //     key: "image",
  //     render: (text, record) => (
  //       <div className="img-container">
  //         <img src={base.MEDIA_URL + text + "/"} width="50px" height="50px" />
  //       </div>
  //     ),
  //   },
  //   state.multylanguage == true
  //     ? ({
  //         title: t("name"),
  //         dataIndex: "name",
  //         key: "name",
  //         render: (text, record) => <a>{text}</a>,
  //       },
  //       {
  //         title: t("arabicname"),
  //         dataIndex: "arabicname",
  //         key: "arabicname",
  //       })
  //     : [
  //         state.defaultlanguage == "en"
  //           ? {
  //               title: t("name"),
  //               dataIndex: "name",
  //               key: "name",
  //               render: (text, record) => <a>{text}</a>,
  //             }
  //           : {
  //               title: t("arabicname"),
  //               dataIndex: "arabicname",
  //               key: "arabicname",
  //             },
  //       ],

  //   {
  //     title: t("action"),
  //     key: "action",
  //     render: (text, record) => (
  //       <Space size="middle">
  //         {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
  //         <EditFilled />
  //       </Link> */}
  //         <Link to={`/edit-category/${text.id}/`}>
  //           {/* <EditFilled /> */}
  //           <img src={EditBtn} width="30px" />
  //         </Link>

  //         <a onClick={() => deleteItem(text.id)}>
  //           {/* <DeleteFilled /> */}
  //           <img src={DeleteBtn} width="30px" />
  //         </a>
  //       </Space>
  //     ),
  //   },
  // ];
  let columns = [];
  if (state.multylanguage == true) {
    columns = [
      {
        title: t("image"),
        dataIndex: "image",
        key: "image",
        render: (text, record) => (
          <div className="img-container">
            <img src={base.MEDIA_URL + text + "/"} width="50px" height="50px" />
          </div>
        ),
      },
      {
        title: t("name"),
        dataIndex: "name",
        key: "name",
        render: (text, record) => <a>{text}</a>,
      },
      {
        title: t("arabicname"),
        dataIndex: "arabicname",
        key: "arabicname",
      },
      {
        title: t("action"),
        key: "action",
        render: (text, record) => (
          <Space size="middle">
            {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
          <EditFilled />
        </Link> */}
            <Link to={`/edit-category/${text.id}/`}>
              {/* <EditFilled /> */}
              <img src={EditBtn} width="30px" />
            </Link>

            <a onClick={() => deleteItem(text.id)}>
              {/* <DeleteFilled /> */}
              <img src={DeleteBtn} width="30px" />
            </a>
          </Space>
        ),
      },
    ];
  } else {
    if (state.defaultlanguage == "en") {
      columns = [
        {
          title: t("image"),
          dataIndex: "image",
          key: "image",
          render: (text, record) => (
            <div className="img-container">
              <img
                src={base.MEDIA_URL + text + "/"}
                width="50px"
                height="50px"
              />
            </div>
          ),
        },
        {
          title: t("name"),
          dataIndex: "name",
          key: "name",
          render: (text, record) => <a>{text}</a>,
        },
        {
          title: t("action"),
          key: "action",
          render: (text, record) => (
            <Space size="middle">
              {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
            <EditFilled />
          </Link> */}
              <Link to={`/edit-category/${text.id}/`}>
                {/* <EditFilled /> */}
                <img src={EditBtn} width="30px" />
              </Link>

              <a onClick={() => deleteItem(text.id)}>
                {/* <DeleteFilled /> */}
                <img src={DeleteBtn} width="30px" />
              </a>
            </Space>
          ),
        },
      ];
    } else {
      columns = [
        {
          title: t("image"),
          dataIndex: "image",
          key: "image",
          render: (text, record) => (
            <div className="img-container">
              <img
                src={base.MEDIA_URL + text + "/"}
                width="50px"
                height="50px"
              />
            </div>
          ),
        },
        {
          title: t("arabicname"),
          dataIndex: "arabicname",
          key: "arabicname",
        },
        {
          title: t("action"),
          key: "action",
          render: (text, record) => (
            <Space size="middle">
              {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
            <EditFilled />
          </Link> */}
              <Link to={`/edit-category/${text.id}/`}>
                {/* <EditFilled /> */}
                <img src={EditBtn} width="30px" />
              </Link>

              <a onClick={() => deleteItem(text.id)}>
                {/* <DeleteFilled /> */}
                <img src={DeleteBtn} width="30px" />
              </a>
            </Space>
          ),
        },
      ];
    }
  }
  function handleCancel() {
    setState({ previewVisible: false });
  }
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        arabicname: e.target.value,
      });
    }
  }
  function handleImageChange({ fileList }) {
    console.log(fileList, "originFileObj");
    if (!fileList.length == 0) {
      console.log("KER");
      setState({ fileList, Image: fileList[0]["originFileObj"] });
    } else {
      setState({ fileList: "", Image: "" });
    }
  }
  function deleteItem(id) {
    // e.preventDefault();
    let token = user.user.user.access;
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this  data",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        fetch(base.BASE_URL + `products/delete-category/${id}/`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${token}`,
            // "accept": "application/json"
          },
          // body: JSON.stringify({
          //   DataBase: this.state.DataBase,
          //   CreatedUserID: this.state.CreatedUserID,
          //   BranchID: this.state.BranchID,
          //   CompanyID: CompanyID,
          // }),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.success === 6000) {
              var icon = "success";
            } else {
              icon = "warning";
            }
            console.log(response, "asd");
            swal({
              title: response.title,
              text: response.message,
              icon: icon,
              button: false,
              timer: 1500,
            });
            window.location.reload();
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        swal("Category is not deleted");
      }
    });
  }
  document.getElementById("root").style.marginTop = "60px";
  const { previewVisible, previewImage, fileList, previewTitle } = state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "40vh",
            // width: "100vw",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div
        className="list-page-style content site-card-border-less-wrapper"
        style={{ marginTop: 20 }}
      >
        <div className="d-flex justify-content-between align-items-center">
          <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
            <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
              {t("categories11")}
            </Breadcrumb.Item>
          </Breadcrumb>
          <div className="add-button">
            <Link
              to="/create-category"
              style={{ fontSize: 30, color: "#fff" }}
              className=""
            >
              <PlusCircleOutlined />
            </Link>
          </div>
        </div>
        <form>
          <Row
            style={{
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Row
              style={{
                alignItems: "center",
                justifyContent: "space-between",
                width: 600,
              }}
            ></Row>
            {/* <Row>
            <Col>
              <div className="form-group ">
                <button
                  style={{ background: "#1eaa97", color: "#fff" }}
                  type="submit"
                  className="btn text-center mr-3"
                >
                  Submit
                </button>
              </div>
              <div className="create-plus form-group ">
                <Link style={{ fontSize: 30, color: "#fff" }} className="">
                  <PlusCircleOutlined />
                </Link>
              </div>
            </Col>
          </Row> */}
          </Row>
        </form>
        <div className="table-content">
          <Table
            columns={columns}
            dataSource={state.data}
            className="time-table-row-select"
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50"],
            }}
          />
        </div>
      </div>
    );
  }
}
