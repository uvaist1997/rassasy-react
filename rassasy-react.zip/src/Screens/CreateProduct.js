import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import TextField from "@material-ui/core/TextField";
import Autocomplete from "@material-ui/lab/Autocomplete";
import store from "../redux/store";
import * as base from "../settings";
import swal from "sweetalert";
import { Image, Form, Input, Button, Row, Col, Select } from "antd";
import "../App.css";
// function CustomerSideNav() {

export default function CreateCategory() {
  const [state, setState] = useState({
    categories: [{ name: "", id: "" }],
    categoryId: "",
    name: "",
    arabicname: "",
    Image: "",
    price: "",
  });
  const user = store.getState();

  useEffect(async () => {
    let token = user.user.user.access;
    await fetch(base.BASE_URL + "products/list-category", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        // "accept": "application/json"
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        console.log(response.data);
        setState({
          ...state,
          categories: response.data,
          name: response.data.name,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);
  console.log(state);
  function handleChange(e) {
    console.log("Kayary");
    console.log(e.target.value);
    if (e.target.name == "name") {
      setState({
        ...state,
        name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        arabicname: e.target.value,
      });
    } else if (e.target.name == "Image") {
      console.log("IMAGESSSSSSSS", e.target.files[0]);
      // this.setState({ CompanyLogo: e.target.files[0] });
      setState({
        ...state,
        Image: URL.createObjectURL(e.target.files[0]),
      });
    } else if (e.target.name == "price") {
      setState({
        ...state,
        price: e.target.value,
      });
    }
  }
  function handleSelectChange(event, value, name) {
    if (name == "category") {
      setState({
        ...state,
        categoryId: value.id,
      });
    }
  }
  function handleSubmit(e) {
    e.preventDefault();
    console.log(state.Image);
    let token = user.user.user.access;
    fetch(base.BASE_URL + `products/create-product`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        name: state.name,
        arabic_name: state.arabicname,
        image: state.Image,
        price: state.price,
        category: state.categoryId,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode == 6000) {
          swal({
            title: "success",
            text: "Product Created SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          // this.props.history.push("/dashboard/list-accountLedger");
        } else {
          swal({
            title: "failed",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 3000,
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const formItemLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 8 },
  };
  const formTailLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 8, offset: 4 },
  };
  const { Option } = Select;

  const [form] = Form.useForm();

  return (
    <form onSubmit={handleSubmit} onChange={handleChange}>
      <Row
        style={{
          alignItems: "center",
          justifyContent: "space-between",
          width: 600,
        }}
      >
        <Col>
          <div className="form-group ">
            <TextField
              label="Name"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              value={state.name}
              name="name"
            />
          </div>
        </Col>
        <Col>
          <div className="form-group ">
            <TextField
              label="Arabic Name"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              value={state.arabicname}
              name="arabicname"
            />
          </div>
        </Col>
      </Row>
      <Row
        style={{
          alignItems: "center",
          justifyContent: "space-between",
          width: 600,
        }}
      >
        <Col>
          <div className="form-group ">
            <TextField
              label="Price"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              value={state.price}
              name="price"
            />
          </div>
        </Col>

        <Col>
          <Autocomplete
            size="small"
            id="size-small-otlined"
            options={state.categories}
            getOptionLabel={(option) => option.name}
            style={{ width: 300 }}
            onChange={(event, value) =>
              handleSelectChange(event, value, "category")
            }
            renderInput={(params) => (
              <TextField {...params} label="Category" variant="outlined" />
            )}
          />
        </Col>
      </Row>
      <Col>
        <Form.Item name="Image" label="Product Image">
          <Image width={200} src="" />
        </Form.Item>
        <Form.Item name={["Image"]} label="Image">
          <input name="Image" type="file" />
        </Form.Item>
      </Col>
      <div className="form-group ">
        <button type="submit" className="btn btn-primary text-center mr-3">
          Submit
        </button>
      </div>
    </form>
  );
}
