import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import store from "../redux/store";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import { Link } from "react-router-dom";
import { LogoutOutlined, PlusOutlined } from "@ant-design/icons";
import { Upload, Modal, Spin, Radio, Switch } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { switchLanguage } from "../../src/redux/store/user";
import { useTranslation } from "react-i18next";
import LocationSearchInput from "../components/LocationSearchInput";

import Autocomplete from "@material-ui/lab/Autocomplete";

const Compress = require("compress.js");
const compress = new Compress();

function EditProfile(props) {
  const user = store.getState();
  let activelanguage = "";
  let defaultlanguage = "";
  // if (user.user.language.activelanguage) {
  //   activelanguage = user.user.language.activelanguage;
  // } else {
  // }
  try {
    defaultlanguage = user.user.language.defaultlanguage;
  } catch (error) {
    defaultlanguage = "";
  }

  const [t, i18n] = useTranslation("common");
  const [state, setState] = useState({
    loading: true,
    cuntry_datas: [],
    defaultlanguage: defaultlanguage,
    activelanguage: activelanguage,
    multylanguage: "true",
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: [],
    Image: "",
    token: "",
    country: "",
    name: "",
    phone: "",
    a_name: "",
    address: "",
    a_address: "",
    pageload: true,
    spotimage: "",
    spotimage_url: "",
    location: "",
    lat: "",
    lng: "",
  });
  const dispatch = useDispatch();

  let token = user.user.user.access;
  useEffect(async () => {
    let token = user.user.user.access;
    const formData = new FormData();

    formData.append("name", state.name);
    formData.append("arabicname", state.a_name);
    formData.append("address", state.address);
    formData.append("arabicaddress", state.a_address);
    formData.append("image", state.Image);
    formData.append("image", state.Image);
    console.log(state.Image, "VAXXXAAAAAA");
    await fetch(base.BASE_URL + "users/single-profile/", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      // body: formData,
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success == 6000) {
          let image = response.data.image;
          console.log(
            response.data.arabic_address,
            "SUC###########SEESS",
            response.data
          );
          let url = base.MEDIA_URL + image + "/";
          let file = [
            {
              uid: "1",
              url: url,
            },
          ];
          setState({
            ...state,
            loading: false,
            multylanguage: response.data.multylanguage,
            defaultlanguage: response.data.defaultlanguage,
            name: response.data.name,
            a_name: response.data.arabic_name,
            address: response.data.address,
            phone: response.data.phone,
            a_address: response.data.arabic_address,
            spotimage_url: response.data.spotimage,
            country: response.data.country,
            location: response.data.location,
            fileList: file,
            pageload: false,
            cuntry_datas: response.country_datas,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  function countryChange(e, val) {
    if (val) {
      setState({
        ...state,
        country: val.currency_code,
      });
    }
  }
  // Redux
  useEffect(async () => {
    dispatch(switchLanguage(state));
    i18n.changeLanguage(state.defaultlanguage);
  }, [state]);
  // Redux
  document.getElementById("root").style.marginTop = "60px";
  function handleChange(e) {
    console.log("HANDLEIMAGWESDDD");
    if (e.target.name == "spotimage") {
      console.log(e.target.files[0]);
      let resizedimage = resizeImageFn(e.target.files[0]);
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, spotimage: result });
      });
    } else {
      setState({ ...state, [e.target.name]: e.target.value });
    }
  }
  function onChange(e) {
    console.log("radio checked", e.target.value);
    let defaultlanguage = e.target.value;
    console.log("LOOOOOP", defaultlanguage);
    setState({ ...state, defaultlanguage: defaultlanguage });
    dispatch(switchLanguage(state));
  }

  var index_Country = state.cuntry_datas.findIndex(
    (p) => p.currency_code == state.country
  );
  console.log(index_Country);
  function multySwich(e) {
    setState({ ...state, multylanguage: e });
    console.log(e, "multySwich", state);
  }

  function handleSubmit(e) {
    e.preventDefault();
    swal({
      title: "Please wait ",
      text: "The Profile is Updating..",
      icon: "warning",
      button: false,
    });
    console.log("KAYRYImage", state);
    const formData = new FormData();
    formData.append("defaultlanguage", defaultlanguage);
    formData.append("multylanguage", state.multylanguage);
    formData.append("name", state.name);
    formData.append("arabicname", state.a_name);
    formData.append("address", state.address);
    formData.append("arabicaddress", state.a_address);
    formData.append("image", state.Image);
    formData.append("phone", state.phone);
    formData.append("country", state.country);
    formData.append("spotimage", state.spotimage);
    formData.append("location", state.location);
    formData.append("lng", state.lng);
    formData.append("lat", state.lat);

    let token = user.user.user.access;
    fetch(base.BASE_URL + "users/create-hotel-profile/", {
      // fetch(base.BASE_URL + "products/create-category", {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          swal({
            title: "success",
            text: "Profile Updated SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          // props.history.push("/");
          window.location.reload();
          dispatch(switchLanguage(state));
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function handleCancel() {
    setState({ ...state, previewVisible: false });
  }
  function logoImageChange({ fileList }) {
    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, fileList, Image: file });
      });
      console.log("KER", resizedimage);
    } else {
      setState({ ...state, fileList: [], Image: "" });
    }
  }
  async function resizeImageFn(file) {
    const compress = new Compress();
    const resizedImage = await compress.compress([file], {
      size: 4, // the max size in MB, defaults to 2MB
      quality: 0.75, // the quality of the image, max is 1,
      maxWidth: 1920, // the max width of the output image, defaults to 1920px
      maxHeight: 1920, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });

    const img = resizedImage[0];
    const base64str = img.data;
    const imgExt = img.ext;
    const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
    setState({ ...state, img: URL.createObjectURL(resizedFiile) });
    let file1 = [
      {
        uid: "1",
        url: URL.createObjectURL(resizedFiile),
      },
    ];
    // let s = new File([resizedImage], file.name);
    var s = new File([resizedFiile], file.name, {
      type: file.type,
      lastModified: new Date().getTime(),
    });

    return s;
  }
  function initAutocomplete() {
    const google = window.google;
    const map = new google.maps.Map(document.getElementById("map"), {
      center: { lat: -33.8688, lng: 151.2195 },
      zoom: 13,
      mapTypeId: "roadmap",
    });
    // Create the search box and link it to the UI element.
    const input = document.getElementById("pac-input");
    const searchBox = new google.maps.places.SearchBox(input);
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
    // Bias the SearchBox results towards current map's viewport.
    map.addListener("bounds_changed", () => {
      searchBox.setBounds(map.getBounds());
    });
    let markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener("places_changed", () => {
      const places = searchBox.getPlaces();

      if (places.length == 0) {
        return;
      }
      // Clear out the old markers.
      markers.forEach((marker) => {
        marker.setMap(null);
      });
      markers = [];
      // For each place, get the icon, name and location.
      const bounds = new google.maps.LatLngBounds();
      places.forEach((place) => {
        if (!place.geometry || !place.geometry.location) {
          console.log("Returned place contains no geometry");
          return;
        }
        const icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25),
        };
        // Create a marker for each place.
        markers.push(
          new google.maps.Marker({
            map,
            icon,
            title: place.name,
            position: place.geometry.location,
          })
        );

        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      map.fitBounds(bounds);
    });
  }
  function getValue(address, latLng) {
    setState({ ...state, location: address, lng: latLng.lng, lat: latLng.lat });
    console.log(latLng, "JASMAL.............");
  }
  console.log(state, "OIUYTREERTYUIO");
  const styles = {
    left_logo: {
      width: "70px",
    },
    wrapper: {
      width: "95%",
      margin: "0 auto",
      paddingTop: "10px",
    },
  };
  // Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
  const top100Films = [
    { title: "The Shawshank Redemption", year: 1994 },
    { title: "The Godfather", year: 1972 },
    { title: "The Godfather: Part II", year: 1974 },
    { title: "The Dark Knight", year: 2008 },
    { title: "12 Angry Men", year: 1957 },
    { title: "Schindler's List", year: 1993 },
  ];
  const { previewVisible, previewImage, fileList, previewTitle } = state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("Upload")}</div>
    </div>
  );
  function onFocus(event) {
    if (event.target.autocomplete) {
      event.target.autocomplete = "whatever";
    }
  }
  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "40vh",
            // width: "100vw",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div className="edit-profile">
        <div className="profile-card">
          <div>
            <form
              autoComplete={false}
              onSubmit={handleSubmit}
              onChange={handleChange}
            >
              {/* <div className="top-logo">
              <img src={logo} alt="Logo" width="100%" />
            </div> */}
              <h3>{t("profile")}</h3>

              <div className="topper-continer">
                <div className="top-img-container form-group">
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <div>
                      <p className="m-0">{t("logo")}</p>
                      <Upload
                        action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                        listType="picture-card"
                        fileList={fileList}
                        onChange={logoImageChange}
                      >
                        {fileList.length >= 1 ? null : uploadButton}
                      </Upload>
                    </div>
                    <Modal
                      visible={previewVisible}
                      title={previewTitle}
                      footer={null}
                      onCancel={handleCancel}
                    >
                      <img
                        alt="example"
                        style={{ width: "100%" }}
                        src={previewImage}
                      />
                    </Modal>
                  </div>
                  {/* <p>Menu Image</p>
                <div>
                  <Image
                    width={100}
                    src={base.MEDIA_URL + state.spotimage_url + "/"}
                  />
                </div> */}
                </div>
                <div className="cover-image form-group">
                  <label name="spotimage">{t("coverimage")}</label>
                  <input name="spotimage" type="file"></input>
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div className="form-group d-flex flex-column font-weight-bold">
                  <label>{t("defaultlang")}</label>
                  <Radio.Group
                    value={defaultlanguage}
                    name="defaultlanguage"
                    onChange={onChange}
                  >
                    <Radio style={{ color: "#fff" }} value={"en"}>
                      EN
                    </Radio>
                    <Radio style={{ color: "#fff" }} value={"de"}>
                      AR
                    </Radio>
                  </Radio.Group>
                </div>
                <div className="form-group d-flex flex-column font-weight-bold">
                  <label>{t("multyang")}</label>
                  <div>
                    <Switch
                      checked={state.multylanguage}
                      onChange={multySwich}
                      name="multylang"
                      checkedChildren="YES"
                      unCheckedChildren="NO"
                    />
                  </div>
                </div>
              </div>
              {state.multylanguage == false ? (
                <div className="d-flex justify-content-between">
                  {state.defaultlanguage == "en" ? (
                    <div style={{ width: "100%" }}>
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("companyname")}
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        name="name"
                        // {state.name =="zxczxc"?value=state.name:null}
                        value={state.name}
                        rules={[
                          {
                            required: true,
                            message: "Company Name required",
                          },
                        ]}
                      />
                    </div>
                  ) : (
                    <div className="" style={{ width: "100%" }}>
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("companyname")}
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        name="a_name"
                        value={state.a_name}
                        rules={[
                          {
                            required: true,
                            message: "Arabic Name required",
                          },
                        ]}
                      />
                    </div>
                  )}
                </div>
              ) : (
                <div className="d-flex justify-content-between">
                  <div style={{ width: "100%" }}>
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      label={t("companyname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      name="name"
                      // {state.name =="zxczxc"?value=state.name:null}
                      value={state.name}
                      rules={[
                        {
                          required: true,
                          message: "Company Name required",
                        },
                      ]}
                    />
                  </div>
                  <div className="ml-2" style={{ width: "100%" }}>
                    <TextField
                      required
                      label={t("companyname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      InputLabelProps={{ required: false }}
                      name="a_name"
                      value={state.a_name}
                      rules={[
                        {
                          required: true,
                          message: "Arabic Name required",
                        },
                      ]}
                    />
                  </div>
                </div>
              )}
              <div className="d-flex justify-content-between">
                <div style={{ width: "100%" }}>
                  <TextField
                    required
                    label={t("phone")}
                    id="outlined-margin-dense"
                    InputLabelProps={{ required: false }}
                    margin="dense"
                    variant="outlined"
                    value={state.phone}
                    name="phone"
                  />
                </div>
                <div className="mt-2 ml-2" style={{ width: "100%" }}>
                  {/* <TextField
                    required
                    fullWidth
                    size="small"
                    id="country"
                    InputLabelProps={{ required: false }}
                    select
                    name="country"
                    label={t("country")}
                    value={state.country}
                    onChange={(event, value) =>
                      countryChange(event, value, "country")
                    }
                    variant="outlined"
                  >
                    <MenuItem key={1} value="IN">
                      India
                    </MenuItem>
                    <MenuItem key={2} value="SA">
                      Saudi Arabia
                    </MenuItem>
                  </TextField> */}
                  <Autocomplete
                    id="combo-box-demo"
                    size="small"
                    onChange={(event, value) =>
                      countryChange(event, value, "country")
                    }
                    options={state.cuntry_datas}
                    value={state.cuntry_datas[index_Country]}
                    getOptionLabel={(option) => option.name}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Country"
                        variant="outlined"
                        autoComplete="off"
                        onFocus={onFocus}
                      />
                    )}
                  />
                </div>
              </div>
              {state.multylanguage == false ? (
                <div className="d-flex justify-content-between">
                  {state.defaultlanguage == "en" ? (
                    <div className="" style={{ width: "100%" }}>
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("address")}
                        id="outlined-margin-dense"
                        multiline
                        rows={4}
                        margin="dense"
                        variant="outlined"
                        value={state.address}
                        name="address"
                      />
                    </div>
                  ) : (
                    <div style={{ width: "100%" }} className="">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("arabicaddress")}
                        id="outlined-margin-dense"
                        multiline
                        rows={4}
                        margin="dense"
                        variant="outlined"
                        name="a_address"
                        value={state.a_address}
                      />
                    </div>
                  )}
                </div>
              ) : (
                <div className="d-flex justify-content-between">
                  <div style={{ width: "100%" }}>
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      label={t("address")}
                      id="outlined-margin-dense"
                      multiline
                      rows={4}
                      margin="dense"
                      variant="outlined"
                      value={state.address}
                      name="address"
                    />
                  </div>
                  <div style={{ width: "100%" }} className="ml-2">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      label={t("arabicaddress")}
                      id="outlined-margin-dense"
                      multiline
                      rows={4}
                      margin="dense"
                      variant="outlined"
                      name="a_address"
                      value={state.a_address}
                    />
                  </div>
                </div>
              )}
              <LocationSearchInput
                initialvalue={state.location}
                getvalue={getValue}
              />
              <Button
                className="login-button btn btn-block"
                variant="primary"
                type="submit"
                htmlType="submit"
              >
                {t("save")}
              </Button>
              {/* <p className="forgot-password text-right">
              Forgot <a href="#">password?</a>
            </p> */}
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default EditProfile;
