import React, { useState, useEffect } from "react";
import swal from "sweetalert";

import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button, Spin } from "antd";
import "../App.css";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";

export default function LoginActivity() {
  const [state, setState] = useState({
    collapsed: false,
    loading: true,
  });

  useEffect(async () => {
    await fetch(base.BASE_URL + "users/login-activities/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
          loading: false,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);

  const columns = [
    {
      title: "username",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "date_added",
      dataIndex: "date_added",
      key: "date_added",
      render: (text, record) => <a>{text}</a>,
    },
    {
      title: "ip",
      dataIndex: "ip",
      key: "ip",
    },
    // {
    //   title: "location",
    //   dataIndex: "location",
    //   key: "location",
    // },
    {
      title: "device",
      dataIndex: "device",
      key: "device",
    },

    // {
    //   title: "action",
    //   key: "action",
    //   render: (text, record) => (
    //     <Space size="middle">
    //       <a onClick={() => deleteItem(text.id)}>
    //         {/* <DeleteFilled /> */}
    //         <img src={DeleteBtn} width="30px" />
    //       </a>
    //     </Space>
    //   ),
    // },
  ];

  function deleteItem(id) {
    // e.preventDefault();
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this  data",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        fetch(base.BASE_URL + `users/delete-activity/${id}/`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            // "accept": "application/json"
          },
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.StatusCode === 6000) {
              var icon = "success";
            } else {
              icon = "warning";
            }
            swal({
              title: response.title,
              text: response.message,
              icon: icon,
              button: false,
              timer: 1500,
            });
            window.location.reload();
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        swal("Brand is not deleted");
      }
    });
  }

  document.getElementById("root").style.marginTop = "60px";

  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "100vh",
            width: "100vw",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div
        className="list-page-style content site-card-border-less-wrapper"
        style={{ marginTop: 20 }}
      >
        <div className="d-flex justify-content-between align-items-center">
          <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
            <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
              Login Activities
            </Breadcrumb.Item>
          </Breadcrumb>
          {/* <div className="add-button">
            <div
              onClick={() => setModal2Visible(true)}
              style={{ cursor: "pointer", fontSize: 30, color: "#fff" }}
              className=""
            >
              <PlusCircleOutlined />
            </div>
          </div> */}
        </div>
        <div>
          <Table
            columns={columns}
            dataSource={state.data}
            className="time-table-row-select"
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50"],
            }}
          />
        </div>
      </div>
    );
  }
}
