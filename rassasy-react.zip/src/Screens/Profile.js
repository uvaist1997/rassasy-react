import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Upload, message } from "antd";
import { LoadingOutlined, PlusOutlined } from "@ant-design/icons";

import logo from "../assets/images/lg.png"; // wherever is it.
// import "../../src/Profile.css";

function Profile() {
  const [state, setState] = useState({
    loading: false,
  });
  const dispatch = useDispatch();

  const styles = {
    card: {
      padding: "25px",
      borderRadius: "10px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      position: "relative",
      background: "#fff",
      border: ".5px solid rgba(0,0,0,.1)",
    },
    auth_bg: {
      //   backgroundImage: `url(${bg_auth})`,
      backgroundSize: "cover",
      boxSizing: "border-box",
    },
    text_position: {
      position: "absolute",
      bottom: 0,
    },
    container_height: {
      height: "100vh",
    },
  };

  const validateMessages = {
    required: "${label} is required!",
    types: {
      email: "${label} is not valid email!",
      username: "${label} is not a valid username!",
      password: "${label} is not a valid password!",
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };

  //   function handleChange(e) {
  //     console.log("AAAAAAAAAAAAAS");
  //     setState((prevState) => {
  //       return { ...prevState, [e.target.name]: e.target.value };
  //     });
  //   }
  function getBase64(img, callback) {
    const reader = new FileReader();
    reader.addEventListener("load", () => callback(reader.result));
    reader.readAsDataURL(img);
  }
  function beforeUpload(file) {
    console.log("BEFOREUP");
    const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
    if (!isJpgOrPng) {
      message.error("You can only upload JPG/PNG file!");
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error("Image must smaller than 2MB!");
    }
    return isJpgOrPng && isLt2M;
  }

  function handleChange(info) {
    console.log("HANDLE");
    if (info.file.status === "uploading") {
      setState({ ...state, loading: true });
      return;
    }
    console.log(info.file);
    if (info.file.status === "done") {
      // Get this url from response in real world.
      getBase64(info.file.originFileObj, (imageUrl) =>
        setState({
          ...state,
          imageUrl,
          loading: false,
        })
      );
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    dispatch(login(state));
  }
  const { loading, imageUrl } = state;
  const uploadButton = (
    <div>
      {loading ? <LoadingOutlined /> : <PlusOutlined />}
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );

  return (
    <div className="profile-card">
      <div>
        <form onSubmit={handleSubmit}>
          {/* <div className="top-logo">
            <img src={logo} alt="Logo" width="100%" />
          </div> */}
          <h3>Profile</h3>

          <div className="form-group">
            <Upload
              name="avatar"
              listType="picture-card"
              className="avatar-uploader"
              showUploadList={false}
              action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
              beforeUpload={beforeUpload}
              onChange={handleChange}
            >
              {imageUrl ? (
                <img src={imageUrl} alt="avatar" style={{ width: "100%" }} />
              ) : (
                uploadButton
              )}
            </Upload>
          </div>
          <div className="">
            <TextField
              label="Company Name"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              name="name"
              rules={[
                {
                  required: true,
                  message: "Company Name required",
                },
              ]}
            />
          </div>

          <div className="">
            <TextField
              label="Arabic Name"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              name="arabicname"
            />
          </div>
          <div className="">
            <TextField
              label="Phone"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              name="phone"
            />
          </div>
          <div className="">
            <TextField
              label="Address"
              id="outlined-margin-dense"
              multiline
              rows={4}
              margin="dense"
              variant="outlined"
              name="address"
            />
          </div>
          <div className="form-group">
            <TextField
              label="Arabic Address"
              id="outlined-margin-dense"
              multiline
              rows={4}
              margin="dense"
              variant="outlined"
              name="arabicaddress"
            />
          </div>

          <Button
            className="login-button btn btn-block"
            variant="primary"
            type="submit"
            htmlType="submit"
          >
            Save
          </Button>
          {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
        </form>
      </div>
    </div>
  );
}

export default Profile;
