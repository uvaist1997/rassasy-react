import React, { useState, useEffect, Component } from "react";
import { Button } from "react-bootstrap";
import history from "../components/history";
import TextField from "@material-ui/core/TextField";
import "../assets/css/Login.css";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import viknlogo from "../assets/images/vikn.png";
import { Modal, Form, Input } from "antd";

function ForgotPassword(props) {
  const [state, setState] = useState({
    is_button: false,
    email: "",
    error: false,
  });
  function handleChange(e) {
    setState((prevState) => {
      return { ...prevState, [e.target.name]: e.target.value, message: "" };
    });
  }
  function handleSubmit(e) {
    e.preventDefault();
    swal({
      title: "Please wait.",
      text: " The token is generating...",
      icon: "info",
      button: false,
    });
    fetch(base.BASE_URL + `reset-password/`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        email: state.email,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.status === "OK") {
          swal({
            title: "The token is send to your email.",
            text: "Please check your email.",
            icon: "success",
            button: true,
          });
          history.push("/");
          window.location.reload();
        } else {
          swal({
            title: "Failed",
            text: response.email[0],
            icon: "error",
            button: true,
          });
          // this.props.history.push("/signup");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }

  console.log(state);
  return (
    <div className="registration-page common-card">
      <div className="user-card">
        <div className="d-flex justify-content-center form_container login-form">
          <form onSubmit={handleSubmit} onChange={handleChange}>
            <div className="imageclick top-logo">
              <Link to="/">
                <img src={logo} alt="Logo" width="100%" />
              </Link>
            </div>
            <h3>Forgotten password?</h3>

            <div className="">
              <TextField
                required
                InputLabelProps={{ required: false }}
                className="test"
                label="Email"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="email"
              />
            </div>

            <Button
              disabled={state.is_button}
              className="mt-2 login-button btn btn-block"
              variant="primary"
              type="submit"
              htmlType="submit"
            >
              Submit
            </Button>
            {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
          </form>
        </div>
      </div>
      <p className="mt-3">
        Already Have An Account? <Link to="/sign-in">Login</Link>
      </p>
      <div>
        <h5 className="pt-5">
          Powerd By{" "}
          <span>
            <img
              src={viknlogo}
              loading="lazy"
              width="116"
              alt=""
              className="image-24"
            />
          </span>
        </h5>
      </div>
    </div>
  );
}

export default ForgotPassword;
