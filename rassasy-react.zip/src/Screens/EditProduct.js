import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import { ProfileSuccess, logout } from "../../src/redux/store/user";
import store from "../redux/store";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import { Link } from "react-router-dom";
import { LogoutOutlined, PlusOutlined } from "@ant-design/icons";
import { Upload, Modal } from "antd";
import { useDispatch, useSelector } from "react-redux";

const EditProduct = (props) => {
  const [state, setState] = useState({
    loading: false,
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: "",
    Image: "",
    token: "",
    name: "",
    arabicname: "",
    price: "",
  });
  const dispatch = useDispatch();
  const user = store.getState();
  let token = user.user.user.access;

  useEffect(async () => {
    let token = user.user.user.access;
    let data = state.data;
    let handle = props.match.params.id;
    await fetch(base.BASE_URL + "products/show-edit-product", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        pk: handle,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        console.log(response.data[0].name, "SUCSEESS");
        let image = response.data[0].image;
        let url = base.MEDIA_URL + image + "/";
        let file = [
          {
            uid: "1",
            url: url,
          },
        ];
        setState({
          ...state,
          name: response.data[0].name,
          arabicname: response.data[0].arabic_name,
          price: response.data[0].price,
          fileList: file,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  console.log(state);
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        arabicname: e.target.value,
      });
    } else if (e.target.name == "price") {
      setState({
        ...state,
        price: e.target.value,
      });
    }
  }
  function handleSubmit(e) {
    let handle = props.match.params.id;
    e.preventDefault();
    const formData = new FormData();
    formData.append("name", state.name);
    formData.append("arabicname", state.arabicname);
    formData.append("price", state.price);
    formData.append("image", state.Image);
    // fetch(base.BASE_URL + `products/single-edit-product/${handle}/`, {
    //   method: "POST",
    //   headers: {
    //     Authorization: `Bearer ${token}`,
    //   },
    //   body: formData,
    // })
    //   .then((response) => response.json())
    //   .then((response) => {
    //     console.log(response.data[0].name, "SUCSEESS");
    //     let image = response.data[0].image;
    //     let url = base.MEDIA_URL + image + "/";
    //     let file = [
    //       {
    //         uid: "1",
    //         url: url,
    //       },
    //     ];

    //     if (response.success === 6000) {
    //       swal({
    //         title: "success",
    //         text: "Category Created SuccessFully",
    //         icon: "success",
    //         button: false,
    //         timer: 1000,
    //       });
    //       setState({
    //         ...state,
    //         name: response.data[0].name,
    //         arabicname: response.data[0].arabic_name,
    //         price: response.data[0].price,
    //         fileList: file,
    //       });
    //       this.props.history.push("/");
    //     } else {
    //       swal({
    //         title: "faild",
    //         text: response.message,
    //         icon: "warning",
    //         button: false,
    //         timer: 1000,
    //       });
    //     }
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //   });
    fetch(base.BASE_URL + `products/single-edit-product/${handle}/`, {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          swal({
            title: "success",
            text: "Updated SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          props.history.push("/products");
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function handleCancel() {
    setState({ previewVisible: false });
  }
  function logoImageChange({ fileList }) {
    console.log(fileList, "originFileObj");
    if (!fileList.length == 0) {
      console.log("KER");
      setState({ ...state, fileList, Image: fileList[0]["originFileObj"] });
    } else {
      setState({ ...state, fileList: "", Image: "" });
    }
  }

  const styles = {
    left_logo: {
      width: "70px",
    },
    wrapper: {
      width: "95%",
      margin: "0 auto",
      paddingTop: "10px",
    },
  };
  const { previewVisible, previewImage, fileList, previewTitle } = state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  return (
    <div className="edit-product-card">
      <div className="profile-card">
        <div>
          <form onSubmit={handleSubmit} onChange={handleChange}>
            {/* <div className="top-logo">
            <img src={logo} alt="Logo" width="100%" />
          </div> */}
            <h3>Edit Product</h3>

            <div className="form-group">
              <Upload
                action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                listType="picture-card"
                fileList={fileList}
                onChange={logoImageChange}
              >
                {fileList.length >= 1 ? null : uploadButton}
              </Upload>
              <Modal
                visible={previewVisible}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
              >
                <img
                  alt="example"
                  style={{ width: "100%" }}
                  src={previewImage}
                />
              </Modal>
            </div>
            <div className="">
              <TextField
                label="Name"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="name"
                value={state.name}
                rules={[
                  {
                    required: true,
                    message: "Name required",
                  },
                ]}
              />
            </div>

            <div className="">
              <TextField
                label="Arabic Name"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="arabicname"
                value={state.arabicname}
              />
            </div>
            <div className="">
              <TextField
                label="Price"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                value={state.price}
                name="price"
              />
            </div>

            <Button
              className="login-button btn btn-block"
              variant="primary"
              type="submit"
              htmlType="submit"
            >
              Save
            </Button>
            {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
