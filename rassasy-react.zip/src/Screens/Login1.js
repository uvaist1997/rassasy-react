import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import "../assets/css/Login.css";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, home_page } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import logo from "../assets/images/lg.png"; // wherever is it.
import viknlogo from "../assets/images/vikn.png";
import { EyeOutlined, EyeInvisibleOutlined } from "@ant-design/icons";
import Lottie from "react-lottie";
import Starburst from "../assets/lottie/loading.json";
import InputAdornment from "@material-ui/core/InputAdornment";
import IconButton from "@material-ui/core/IconButton";
import swal from "sweetalert";
import * as base from "../settings";
import history from "../components/history";

function Login1() {
  const [state, setState] = useState({
    error_message: "",
    username: "",
    password: "",
    loading: false,
    showPassword: false,
    access: "",
    is_Profile: "",
    is_expired: "",
    role: "",
    defaultlanguage: "",
    multylanguage: "",
  });

  const dispatch = useDispatch();
  const defaultOptions = {
    loop: false,
    autoplay: true,
    animationData: Starburst,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  const styles = {
    card: {
      padding: "25px",
      borderRadius: "10px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      position: "relative",
      background: "#fff",
      border: ".5px solid rgba(0,0,0,.1)",
    },
    auth_bg: {
      //   backgroundImage: `url(${bg_auth})`,
      backgroundSize: "cover",
      boxSizing: "border-box",
    },
    text_position: {
      position: "absolute",
      bottom: 0,
    },
    container_height: {
      height: "100vh",
    },
  };
  const handleClickShowPassword = (e) => {
    console.log(e, "EEEEEEEEEEEE");
    setState({ ...state, showPassword: !state.showPassword });
  };
  const validateMessages = {
    required: "${label} is required!",
    types: {
      email: "${label} is not valid email!",
      username: "${label} is not a valid username!",
      password: "${label} is not a valid password!",
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };

  function handleChange(e) {
    console.log("AAAAAAAAAAAAAS");
    setState((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
        error_message: "",
      };
    });
  }
  function handleSubmit(e) {
    e.preventDefault();
    fetch(base.BASE_URL + "users/user-login/", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        username: state.username,
        password: state.password,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        console.log("RESPONSE", response, "LOGIN");
        console.log(response.is_expired, "is_expired");

        if (response.success === 6000) {
          let access = response.data.access;
          let is_Profile = response.is_profile;
          let is_expired = response.is_expired;
          let role = response.data.role;
          let defaultlanguage = response.defaultlanguage;
          let multylanguage = response.multylanguage;
          // setState({
          //   ...state,
          //   access: access,
          //   is_Profile: is_Profile,
          //   is_expired: is_expired,
          //   role: role,
          //   defaultlanguage: defaultlanguage,
          //   multylanguage: multylanguage,
          // });
          let dic = {
            username: state.username,
            access: access,
            is_Profile: is_Profile,
            is_expired: is_expired,
            role: role,
            defaultlanguage: defaultlanguage,
            multylanguage: multylanguage,
          };
          dispatch(login(dic));
          history.push("/");
          window.location.reload();
        } else {
          // swal({
          //   title: "failed",
          //   text: response.error,
          //   icon: "warning",
          //   button: false,
          //   timer: 1000,
          // });

          setState({ ...state, error_message: response.error });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  if (state.loading) {
    return (
      <Lottie
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        options={defaultOptions}
        height={400}
        width={400}
      />
    );
  } else {
    return (
      <div className="common-card">
        <div className="user-card">
          <div className="d-flex justify-content-center form_container login-form">
            <form onSubmit={handleSubmit} onChange={handleChange}>
              <div className="top-logo">
                <Link to="/">
                  <img
                    style={{ cursor: "pointer" }}
                    // onClick={() => dispatch(home_page(state))}
                    src={logo}
                    alt="Logo"
                    width="100%"
                  />
                </Link>
              </div>
              <h3>Login</h3>

              <div className="form-group">
                <TextField
                  required
                  InputLabelProps={{ required: false }}
                  label="Username or Email"
                  id="outlined-margin-dense"
                  margin="dense"
                  variant="outlined"
                  name="username"
                  inputProps={{
                    autocomplete: "new-password",
                  }}
                  error={state.error_message ? true : false}
                  helperText={state.error_message ? state.error_message : null}
                  rules={[
                    {
                      required: true,
                      message: "Username Name required",
                    },
                  ]}
                />
              </div>

              <div className="">
                <TextField
                  InputLabelProps={{ required: false }}
                  required
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          style={{ color: "#fff", fontSize: "18px" }}
                          aria-label="toggle password visibility"
                          onClick={handleClickShowPassword}
                          edge="end"
                        >
                          {state.showPassword ? (
                            <EyeInvisibleOutlined />
                          ) : (
                            <EyeOutlined />
                          )}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                  label="Password"
                  id="outlined-margin-dense"
                  margin="dense"
                  variant="outlined"
                  type={state.showPassword ? "text" : "password"}
                  name="password"
                />
              </div>

              <div className="form-group">
                <p style={{ textAlign: "right" }} className="m-0">
                  <Link to="/forgot-password">Forgotten password?</Link>
                </p>
              </div>

              <Button
                className="login-button btn btn-block"
                variant="primary"
                type="submit"
                htmlType="submit"
              >
                Login
              </Button>
              {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
            </form>
          </div>
        </div>
        <p className="mt-3">
          Don't have an account?<Link to="/sign-up"> Sign Up</Link>
        </p>
        <div>
          <h5 className="pt-5">
            {/* Powerd By{" "} */}
            <span>
              <img
                src={viknlogo}
                loading="lazy"
                width="116"
                alt=""
                className="image-24"
              />
            </span>
          </h5>
        </div>
      </div>
    );
  }
}

export default Login1;
