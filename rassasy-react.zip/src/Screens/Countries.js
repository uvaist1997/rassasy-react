import React, { useState, useEffect } from "react";
import swal from "sweetalert";
import { PlusOutlined, PlusCircleOutlined } from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button, Spin } from "antd";
import "../App.css";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import Starburst from "../assets/lottie/demo.json";
import { TextBlock, RectShape } from "react-placeholder/lib/placeholders";

const Compress = require("compress.js");
const compress = new Compress();

export default function Countries() {
  const [state, setState] = useState({
    collapsed: false,
    loading: true,
    id: "",
    name: "",
    currency_code: "",
  });

  useEffect(async () => {
    await fetch(base.BASE_URL + "users/countries/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
          loading: false,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);

  const columns = [
    {
      title: "name",
      dataIndex: "name",
      key: "name",
      render: (text, record) => <a>{text}</a>,
    },
    {
      title: "currency_code",
      dataIndex: "currency_code",
      key: "currency_code",
    },
    {
      title: "action",
      key: "action",
      render: (text, record) => (
        <Space size="middle">
          {/* <Link to={`/single-edit-product/${text.id}/`}>
              <img src={EditBtn} width="30px" />
            </Link> */}
          <a id={text.id} onClick={() => editProduct(text.id)}>
            <img src={EditBtn} width="30px" />
          </a>

          <a onClick={() => deleteItem(text.id)}>
            {/* <DeleteFilled /> */}
            <img src={DeleteBtn} width="30px" />
          </a>
        </Space>
      ),
    },

    // {
    //   title: (text, record) => (
    //     <Space size="middle">
    //       <a id={text.id} onClick={() => setModal2Visible(true)}>
    //         <img src={EditBtn} width="30px" />
    //       </a>
    //     </Space>
    //   ),
    // },
  ];
  function handleSubmit(e) {
    e.preventDefault();

    console.log("KAYRYImage", state);
    const formData = new FormData();
    formData.append("name", state.name);
    formData.append("currency_code", state.currency_code);

    fetch(base.BASE_URL + "users/create-countries/", {
      method: "POST",
      body: formData,
      //   headers: {
      //     Authorization: `Bearer ${token}`,
      //   },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          swal({
            title: "success",
            text: "Created SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          window.location.reload();
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function handleEditSubmit(e) {
    e.preventDefault();

    console.log("KAYRYImage", state);
    const formData = new FormData();
    formData.append("pk", state.id);
    formData.append("name", state.name);
    formData.append("currency_code", state.currency_code);

    fetch(base.BASE_URL + "users/edit-country/", {
      method: "POST",
      body: formData,
      //   headers: {
      //     Authorization: `Bearer ${token}`,
      //   },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          swal({
            title: "success",
            text: "Updated SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          window.location.reload();
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function handleChange(e) {
    console.log(e, "HANDLEIMAGWESDDD");
    setState({ ...state, [e.target.name]: e.target.value });
  }
  function setModal2Visible(modal2Visible) {
    setState({ ...state, modal2Visible, name: "", currency_code: "", id: "" });
    // editProduct();
  }
  function setModal1Visible(modal1Visible) {
    setState({ ...state, modal1Visible });
    // editProduct();
  }
  function editProduct(pk) {
    console.log(pk);

    fetch(base.BASE_URL + "users/single-country/", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify({
        pk,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          setState({
            ...state,
            modal1Visible: true,
            currency_code: response.data.currency_code,
            name: response.data.name,
            id: response.data.id,
          });
        } else {
          swal({
            title: "faild",
            text: "id is not exists",
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
    // setState({ ...state, modal2Visible });
  }

  function deleteItem(id) {
    // e.preventDefault();
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this  data",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        fetch(base.BASE_URL + `users/delete-country/${id}/`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            // "accept": "application/json"
          },
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.StatusCode === 6000) {
              var icon = "success";
            } else {
              icon = "warning";
            }
            swal({
              title: response.title,
              text: response.message,
              icon: icon,
              button: false,
              timer: 1500,
            });
            window.location.reload();
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        swal("Brand is not deleted");
      }
    });
  }

  document.getElementById("root").style.marginTop = "60px";

  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "100vh",
            width: "100vw",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div
        className="list-page-style content site-card-border-less-wrapper"
        style={{ marginTop: 20 }}
      >
        <div className="d-flex justify-content-between align-items-center">
          <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
            <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
              Countries
            </Breadcrumb.Item>
          </Breadcrumb>
          <div className="add-button">
            <div
              onClick={() => setModal2Visible(true)}
              style={{ cursor: "pointer", fontSize: 30, color: "#fff" }}
              className=""
            >
              <PlusCircleOutlined />
            </div>
          </div>
        </div>
        <div>
          <Table
            columns={columns}
            dataSource={state.data}
            className="time-table-row-select"
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50"],
            }}
          />
        </div>
        {/* =====Product Modal Start Heare ======= */}
        <Modal
          className="product-modal"
          title="Create Country"
          centered
          visible={state.modal2Visible}
          onOk={() => setModal2Visible(false)}
          onCancel={() => setModal2Visible(false)}
          footer={null}
          cancelButtonProps={{ style: { display: "none" } }}
        >
          <form onSubmit={handleSubmit} id="product-validation">
            <Col md={8} style={{ margin: "0 auto" }}>
              <div>
                <div className="form-group ">
                  <TextField
                    onChange={handleChange}
                    required
                    InputLabelProps={{ required: false }}
                    className="required-field"
                    label="Name"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.name}
                    name="name"
                  />
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    onChange={handleChange}
                    InputLabelProps={{ required: false }}
                    className="required-field"
                    label="Currency Code"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.currency_code}
                    name="currency_code"
                  />
                </div>
              </div>
              <div style={{ textAlign: "center" }} className="form-group">
                <Button
                  // onClick={() => onProductEditSubmit()}
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  Save
                </Button>
              </div>
            </Col>
          </form>
        </Modal>
        {/* =====Edit Modal Start Heare ======= */}
        <Modal
          className="product-modal"
          title="Update Country"
          centered
          visible={state.modal1Visible}
          onOk={() => setModal1Visible(false)}
          onCancel={() => setModal1Visible(false)}
          footer={null}
          cancelButtonProps={{ style: { display: "none" } }}
        >
          <form onSubmit={handleEditSubmit} id="product-validation">
            <Col md={8} style={{ margin: "0 auto" }}>
              <div>
                <div className="form-group ">
                  <TextField
                    onChange={handleChange}
                    required
                    InputLabelProps={{ required: false }}
                    className="required-field"
                    label="Name"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.name}
                    name="name"
                  />
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    onChange={handleChange}
                    InputLabelProps={{ required: false }}
                    className="required-field"
                    label="Currency Code"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.currency_code}
                    name="currency_code"
                  />
                </div>
              </div>
              <div style={{ textAlign: "center" }} className="form-group">
                <Button
                  // onClick={() => onProductEditSubmit()}
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  Save
                </Button>
              </div>
            </Col>
          </form>
        </Modal>
      </div>
    );
  }
}
