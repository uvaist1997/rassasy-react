import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import swal from "sweetalert";
import { EditFilled, DeleteFilled } from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button } from "antd";
import "../App.css";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import InfiniteUsers from "../components/InfiniteUsers";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";

export default function Users() {
  const [state, setState] = useState({
    collapsed: false,
    loading: true,
    modal2Visible: false,

    singledata: {
      id: "",
      name: "",
      arabicname: "",
      price: "",
      productimage: "",
    },
    data: [
      {
        id: "",
        BrandName: "",
        Notes: "",
      },
    ],
  });
  let user = store.getState();
  console.log(state, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  useEffect(async () => {
    // let token = user.user.user.access;
    // console.log(token);
    await fetch(base.BASE_URL + "users/users/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  document.getElementById("root").style.marginTop = "60px";

  const columns = [
    {
      title: "Name",
      dataIndex: "username",
      key: "username",
      render: (text, record) => <a>{text}</a>,
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => (
        <Space size="middle">
          {/* <Link to={`/single-edit-product/${text.id}/`}>
            <img src={EditBtn} width="30px" />
          </Link> */}
          <a id={text.id}>
            <img src={EditBtn} width="30px" />
          </a>

          <a>
            {/* <DeleteFilled /> */}
            <img src={DeleteBtn} width="30px" />
          </a>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <InfiniteUsers instances={columns} />
    </div>
  );
}
