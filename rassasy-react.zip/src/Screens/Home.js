import React, { useState, useEffect } from "react";
import styled from "styled-components";
import logo from "../assets/images/logo.png";
import user_logo from "../assets/images/user-logo.png";
import desktop_image from "../assets/images/mobile_desktop.png";
import mobile_image from "../assets/images/mobile.png";
import mobile_image_2 from "../assets/images/mobile_2.png";
import * as base from "../settings";
import swal from "sweetalert";
import { home_page1 } from "../redux/store/user";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { TextField, withStyles } from "@material-ui/core";
import store from "../redux/store";
import { Spin } from "antd";

const CssTextField = withStyles({
  root: {
    background: "transparent",
    "& placeholder": { color: "#fff" },
    "& input": {
      color: "#fff",
    },
    "& textarea": {
      color: "#fff",
    },
    // "& label.MuiFormLabel-root.MuiInputLabel-root.MuiInputLabel-formControl.MuiInputLabel-animated": {
    //   color: "#fff",
    // },
    "& label": {
      color: "#fff",
      background: "transparent",
    },
    "& label.Mui-focused": {
      color: "#fff",
    },
    "& .MuiInput-underline:before": {
      borderBottomColor: "#fff",
      width: "95%",
    },
    "& .MuiInput-underline:after": {
      borderBottomColor: "#fff",
      width: "95%",
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "red",
      },
      "&:hover fieldset": {
        borderColor: "yellow",
      },
      "&.Mui-focused fieldset": {
        borderColor: "#fff",
      },
    },
  },
})(TextField);
document.body.style.height = "auto";
document.body.style.background = "#000";
const HomeContents = styled.div`
  scroll-behavior: smooth;
  height: 200vh;
  background: #000;
  width: 96%;
  padding-top: 5vh;
  margin: 0 auto;
  text-align: center;
  text-transform: capitalize;
  /* .content-1 {
    display: ${({ count }) => (count <= 32 ? "block" : "none")};
    opacity: ${({ count }) => (count <= 32 ? "1" : "0")};
    transition: opacity 0.9s ease-in-out;
    transition: display 0.9s ease-in-out;
  }
  .content-2 {
    display: ${({ count }) => (count >= 33 ? "block" : "none")};
    opacity: ${({ count }) => (count >= 33 ? "1" : "0")};
    transition: opacity 0.9s ease-in-out;
    transition: display 0.9s ease-in-out;
  } */
  div.contents {
    background: #131313;
  }
  p {
    font-size: 35px;
    color: #fff;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    height: 250vh;
    padding-top: 2vh;
  }
`;
const Spotlight = styled.div`
  height: 90vh;
  width: 96%;
  position: fixed;
  background: #131313;
  text-align: center;
  border-radius: 35px;
  padding: 2%;
  text-transform: capitalize;
  p {
    font-size: 35px;
    color: #fff;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    border-radius: 15px;
    height: 96vh;
  }
`;
const Header = styled.div`
  display: flex;
  padding: 2%;
  background: #000;
  justify-content: space-between;
  border-radius: 20px;
  a {
    text-decoration: none;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    border-radius: 10px;
  }
`;

const User = styled.div`
  display: flex;
  p {
    font-size: 15px;
    margin-right: 15px;
    font-family: "poppinsregular";
    color: #9d9d9d;
    margin-bottom: 0;
  }
  align-items: center;
  div.user-logo {
    width: 35px;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
  }
`;
const Logo = styled.h1`
  width: 180px;
  cursor: pointer;
  margin-bottom: 0;
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    width: 150px;
  }
`;
const ContentOne = styled.div`
  background: #131313;
  position: relative;
  z-index: 10;
  /* transform: ${({ count }) =>
    (count >= 0 && count <= 25) || count >= 33
      ? "translateY(0)"
      : "translateY(-45%)"}; */
  display: ${({ count }) => (count < 33 ? "flex" : "none")};
  transform: ${({ count }) =>
    count >= 30 ? "translateY(-45%)" : "translateY(0)"};
  opacity: ${({ count }) => (count < 30 ? "1" : "0.1")};
  transition: all 0.9s ease-in-out;
  /* transition: display 0.9s ease-in-out;
  transition: opacity 0.9s ease-in-out; */
  flex-direction: column;
  text-transform: capitalize;
  background: transparent;

  color: #fff;
  width: 60%;
  padding: 2%;
  margin: 8% 0;
  h2 {
    font-size: 45px;
    font-weight: bold;
    background: transparent;
    text-align: left;
    margin-bottom: 20px;
    color: #fff;
  }
  p {
    width: 90%;
    background: transparent;
    text-align: left;
    font-size: 12px;
    line-height: 25px;
    font-family: "poppinsregular";
  }
  p.key {
    font-size: 25px;
    margin-bottom: 4%;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    margin: 10% 0;
    width: 100%;
    h2 {
      font-size: 30px;
      text-align: center;
      line-height: 45px;
    }
    p {
      width: 100%;
      text-align: center;
      line-height: 20px;
    }
    p.key {
      font-size: 20px;
    }
  }
  @media (max-width: 320px) {
    h2 {
      font-size: 22px;
      line-height: 35px;
    }
  }
`;
const ContentTwo = styled.div`
  position: relative;
  z-index: 10;
  display: ${({ count }) => (count >= 33 ? "flex" : "none")};
  transform: ${({ count }) =>
    count >= 38 ? "translateY(0)" : "translateY(45%)"};
  opacity: ${({ count }) => (count > 38 ? "1" : "0.1")};
  transition: all 0.9s ease-in-out;
  /* transition: transform 0.5s ease-in-out;
  transition: opacity 0.9s ease-in-out; */
  flex-direction: column;
  text-transform: capitalize;
  background: transparent;

  color: #fff;
  width: 60%;
  padding: 2%;
  margin: 8% 0;
  h2 {
    font-size: 45px;
    font-weight: bold;
    background: transparent;
    text-align: left;
    margin-bottom: 20px;
    color: #fff;
  }
  p {
    width: 90%;
    background: transparent;
    text-align: left;
    font-size: 12px;
    line-height: 25px;
    font-family: "poppinsregular";
  }
  p.key {
    font-size: 25px;
    margin-bottom: 4%;
  }
  img {
    display: block;
    margin: 0 auto;
  }
  @media (max-width: 768px) {
    margin: 10% 0;
    width: 100%;
    h2 {
      font-size: 30px;
      text-align: center;
      line-height: 45px;
    }
    p {
      width: 100%;
      text-align: center;
      line-height: 20px;
    }
    p.key {
      font-size: 20px;
    }
  }
  @media (max-width: 320px) {
    h2 {
      font-size: 22px;
      line-height: 20px;
    }
  }
`;
const SignUpCard = styled.div`
  z-index: 10;
  position: absolute;
  bottom: 0;
  padding-bottom: 2%;
  width: 35%;
  background: transparent;
  div.signup-description {
    background: transparent;
  }
  div.signup-description p {
    font-size: 15px;
    margin-bottom: 20px;
    color: #c6c6c6;
    background: transparent;
  }
  p {
    text-align: left;
    text-transform: capitalize;
    background: transparent;
  }

  @media (max-width: 768px) {
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    bottom: 25vh;
    div.signup-description p {
      background: transparent;
    }
  }
`;
const ButtonGroup = styled.div`
  display: flex;
  background: transparent;
  .sign-in {
    text-decoration: none;
    color: #fff;
    padding: 10px 32px;
    border: 1px solid #fff;
    border-radius: 20px;
    margin-right: 10px;
    font-family: "poppinsregular";
    background: #000;
  }
  .sign-up {
    text-decoration: none;
    background: #fff;
    color: #000;
    padding: 10px 32px;
    border: 1px solid #000;
    border-radius: 20px;
    font-family: "poppinsregular";
  }
  @media (max-width: 768px) {
  }
`;
const MobileImageOne = styled.div`
  display: ${({ count }) => (count < 33 ? "flex" : "none")};
  opacity: ${({ count }) => (count < 28 ? "1" : "0")};
  transition: all 0.9s ease-in-out;
  background: transparent;
  width: 690px;
  position: absolute;
  bottom: 0;
  right: -20px;
  img {
    background: transparent;
    width: 100%;
  }
  @media (max-width: 768px) {
    z-index: 1;
    width: 350px;
    right: -5px;
    margin: auto 0;
    opacity: ${({ count }) => (count < 28 ? "50%" : "0")};
  }
  @media (max-width: 320px) {
    opacity: ${({ count }) => (count < 28 ? "30%" : "0")};
  }
`;
const MobileImageTwo = styled.div`
  display: ${({ count }) => (count >= 33 ? "flex" : "none")};
  opacity: ${({ count }) => (count > 38 ? "1" : "0")};
  transition: all 0.9s ease-in-out;
  background: transparent;
  width: 500px;
  position: absolute;
  bottom: 0;
  right: 130px;
  height: auto;
  img {
    background: transparent;
    width: 100%;
  }
  @media (max-width: 768px) {
    z-index: 1;
    width: 350px;
    right: -5px;
    opacity: 50%;
    left: 0;
    right: 0;
    margin: 0 auto;
    height: auto;
  }
  @media (max-width: 375px) {
    opacity: ${({ count }) => (count > 38 ? "30%" : "0")};
    width: 250px;
    height: 50vh;
    margin: 0 auto;
    left: 0;
    right: 0;
  }
  @media (max-width: 320px) {
    opacity: ${({ count }) => (count > 38 ? "30%" : "0")};
    width: 250px;
    margin: 0 auto;
    left: 0;
    right: 0;
  }
`;
const Scroll = styled.div`
  z-index: 10;
  width: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  background: transparent;
  position: absolute;
  bottom: 15px;
  left: 0;
  right: 0;
  margin: 0 auto;
  background: transparent;
  div.scroll-down {
    color: #fff;
    background: transparent;
    margin-bottom: 10px;
  }
  div.down-arrow {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-weight: bold;
    border: 2px solid #fff;
    width: 25px;
    height: 25px;
    background: transparent;
    border-radius: 4px;
  }
  @media (max-width: 768px) {
    bottom: 80px;
  }
`;
const Contact = styled.div`
  opacity: ${({ count }) => (count >= 75 ? "1" : 0)};
  display: ${({ count }) => (count >= 60 ? "block" : "none")};
  transform: ${({ count }) =>
    count >= 85 ? "translateY(0)" : "translateY(45%)"};
  transition: all 0.5s ease-in-out;
  padding: 2%;
  background: #000000;
  z-index: 20;
  bottom: 10px;
  width: 96%;
  border-radius: 20px;
  position: absolute;

  .contact-scroll {
    position: initial;
    margin-bottom: 25px;
  }
  h3 {
    color: #fff;
    font-weight: bold;
  }
  @media (max-width: 768px) {
  }
  @media (max-width: 320px) {
    display: ${({ count }) => (count >= 50 ? "block" : "none")};
    h3 {
      font-size: 14px;
    }
  }
`;
const Details = styled.div`
  background: #131313;
  padding: 2%;
  border-radius: 10px;
  div {
    color: #fff;
    background: transparent;
    text-align: center;
    width: 33%;
  }
  div.social {
    text-align: left;
  }
  div.product a:hover {
    font-weight: bold;
    transition: font-weight 0.2s ease-in-out;
  }
  div.product {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  div.address {
    text-align: right;
  }
  div.address a:hover {
    font-weight: bold;
    transition: font-weight 0.2s ease-in-out;
  }
  p.place {
    margin-bottom: 15px;
  }
  p.email {
    margin-bottom: 15px;
  }
  p.contact-heading {
    font-size: 13px;
    font-weight: bold;
  }
  p {
    font-size: 13px;
    color: #fff;
    background: transparent;
    margin-bottom: 8px;
  }
  a {
    text-decoration: none;
    color: #fff;
    background: transparent;
  }
  div.social-group {
    text-align: left;
    margin-bottom: 10px;
  }
  div.social-group a:hover {
    font-weight: bold;
    transition: font-weight 0.2s ease-in-out;
  }
  display: flex;
  justify-content: space-between;
  @media (max-width: 768px) {
    flex-direction: column-reverse;
    justify-content: center;
    align-items: center;
    padding: 5%;
    p.contact-heading {
      margin-bottom: 20px;
    }
    div {
      width: 100%;
    }
    div.social {
      text-align: center;
    }
    div.address {
      text-align: center;
    }
    div.social-group {
      display: flex;
      justify-content: center;
      justify-content: space-between;
    }
  }
  @media (max-width: 768px) {
    padding: 2%;
  }
`;
const InputGroup = styled.div`
  width: 85%;
  margin: 0 auto;
  display: flex;
  margin-bottom: 25px;
  justify-content: space-between;
  /* Change the white to any color */
  input:-webkit-autofill,
  input:-webkit-autofill:hover,
  input:-webkit-autofill:focus,
  input:-webkit-autofill:active {
    -webkit-box-shadow: 0 0 0 30px #000 inset !important;
  }
  /*Change text in autofill textbox*/
  input:-webkit-autofill {
    -webkit-text-fill-color: rgb(255, 255, 255) !important;
  }
  div.submit-button {
    width: initial;
    display: flex;
    align-items: flex-end;
  }
  button {
    outline: none;
    color: #fff;
    font-size: 15px;
    padding: 0px 25px;
    background: #131313;
    border: 1px solid #fff;
    border-radius: 20px;
    height: 35px;
    cursor: pointer;
  }
  @media (max-width: 768px) {
    flex-direction: column;
    left: 0;
    right: 0;
  }
  @media (max-width: 320px) {
    margin-bottom: 10px;
    input {
      font-size: 12px;
    }
  }

  div.submit-button {
    margin-top: 20px;
    justify-content: center;
  }
`;
const Home = () => {
  const [count, setCount] = useState(0);
  const [state, setState] = useState({
    loading: true,
    name: "",
    email: "",
    phone: "",
    message: "",
    is_button: false,
    Is_home: false,
  });
  const dispatch = useDispatch();
  const updateScrollPercentage = function () {
    const heightOfWindow = window.innerHeight,
      contentScrolled = window.pageYOffset,
      bodyHeight = document.body.offsetHeight;

    if (bodyHeight - contentScrolled <= heightOfWindow) {
      setCount(100);
    } else {
      const total = bodyHeight - heightOfWindow,
        got = contentScrolled,
        percent = parseInt((got / total) * 100);
      setCount(percent);
    }
  };

  function set_Is_home() {
    dispatch(home_page1(state));
  }
  window.addEventListener("scroll", updateScrollPercentage);
  function handleSubmit(e) {
    e.preventDefault();
    setState({
      ...state,
      is_button: true,
    });
    console.log("KAYRYImage", state);
    const formData = new FormData();
    formData.append("email", state.email);
    formData.append("name", state.name);
    formData.append("phone", state.phone);
    formData.append("message", state.message);

    fetch(base.BASE_URL + "users/create-user-enquiry/", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode === 6000) {
          swal({
            title: "success",
            text: "Profile Updated SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          window.location.reload();
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
          setState({
            ...state,
            is_button: false,
            message: response.message,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  // useEffect(async () => {
  //   let bottom_nav = document.getElementById("bottom-fixed-menu");
  //   if (bottom_nav) {
  //     document.getElementById("bottom-fixed-menu").style.display = "none";
  //   }
  //   if (document.getElementById("fixed-side-menu")) {
  //     document.getElementById("fixed-side-menu").style.display = "none";
  //   }
  // }, []);

  function handleChange(e) {
    setState({ ...state, [e.target.name]: e.target.value });
  }
  function handleHome() {
    // setCount(0);
    window.scroll(0, 0);
  }
  console.log(state);
  let user = store.getState();
  let Is_home = "";
  let is_Auth = "";
  let username = "";
  if (user.user.Is_home) {
    Is_home = user.user.Is_home.Is_home;
  }
  if (user.user.is_Auth) {
    is_Auth = user.user.is_Auth;
    username = user.user.user.username;
  }

  return (
    <HomeContents count={count}>
      <Spotlight>
        <Header>
          <Logo>
            <img src={logo} alt="logo" width="100%" onClick={handleHome} />
          </Logo>
          <User>
            <div className="username">
              {is_Auth ? <p>{username}</p> : <p>Sign in</p>}
            </div>
            {Is_home ? (
              <a onClick={set_Is_home} href="/">
                <div className="user-logo">
                  <img src={user_logo} alt="user-logo" width="100%" />
                </div>
              </a>
            ) : (
              <Link onClick={set_Is_home} to="/sign-in">
                <div className="user-logo">
                  <img src={user_logo} alt="user-logo" width="100%" />
                </div>
              </Link>
            )}
          </User>
        </Header>
        <div className="contents">
          <ContentOne count={count}>
            <h2>get caught with a sweet tooth.</h2>
            <p>
              Lorem, ipsum dolor sit amet consectetur, adipisicing elit.
              Impedit, praesentium voluptates ut accusamus consectetur, qui
              mollitia voluptas earum dolorem quibusdam tempora velit omnis iure
              dolores quo harum quis est minima.
            </p>
          </ContentOne>
          <ContentTwo count={count}>
            <p className="key">Key Feature</p>
            <h2>scan to see the menu.</h2>
            <p>
              Lorem, ipsum dolor sit amet consectetur, adipisicing elit.
              Impedit, praesentium voluptates ut accusamus consectetur, qui
              mollitia voluptas earum dolorem quibusdam tempora velit omnis iure
              dolores quo harum quis est minima.
            </p>
          </ContentTwo>
        </div>
        <SignUpCard>
          <div className="signup-description">
            <p>sign up for 7-days free trial</p>
          </div>
          <ButtonGroup>
            {/* <Link className="sign-in" to="/sign-in">
              sign in
            </Link> */}

            {Is_home ? (
              <a onClick={set_Is_home} href="/">
                <div className="sign-up">sign up</div>
              </a>
            ) : (
              <Link className="sign-up" to="/sign-up">
                sign up
              </Link>
            )}
          </ButtonGroup>
        </SignUpCard>
        <MobileImageOne count={count}>
          {window.innerWidth <= 760 ? (
            <img src={mobile_image} alt="mobile" />
          ) : (
            <img src={desktop_image} alt="mobile" />
          )}
        </MobileImageOne>
        <MobileImageTwo count={count}>
          <img src={mobile_image_2} alt="mobile-2" />
        </MobileImageTwo>

        {count === 100 ? (
          <Scroll>
            <div className="scroll-down">
              {window.innerWidth <= 760 ? "Swipe Up" : "Scroll Up"}
            </div>
            <div className="down-arrow">↑</div>
          </Scroll>
        ) : (
          <Scroll>
            <div className="scroll-down">
              {" "}
              {window.innerWidth <= 760 ? "Swipe Down" : "Scroll Down"}
            </div>
            <div className="down-arrow">↓</div>
          </Scroll>
        )}
        <Contact count={count}>
          <Scroll className="contact-scroll">
            <div className="scroll-down">
              {window.innerWidth <= 760 ? "Swipe Up" : "Scroll Up"}
            </div>
            <div className="down-arrow">↑</div>
          </Scroll>
          <h3>for any queries</h3>
          <form
            onSubmit={handleSubmit}
            onChange={handleChange}
            autoComplete="off"
          >
            <InputGroup>
              <CssTextField
                InputLabelProps={{ required: false }}
                required
                name="name"
                id="name"
                label="Name"
              />
              <CssTextField
                required
                InputLabelProps={{ required: false }}
                type="email"
                name="email"
                id="email"
                label="Email"
              />
              <CssTextField
                InputLabelProps={{ required: false }}
                required
                type="number"
                name="phone"
                id="phone"
                label="Phone"
              />
              <CssTextField
                InputLabelProps={{ required: false }}
                required
                name="message"
                id="message"
                label="Messege"
                multiline
              />
              <div className="submit-button">
                {state.is_button ? (
                  <div style={{ padding: "0 35px" }}>
                    <Spin size="small" />
                  </div>
                ) : (
                  <button disabled={state.is_button} type="submit">
                    save
                  </button>
                )}
              </div>
            </InputGroup>
          </form>
          <Details>
            {window.innerWidth <= 760 ? (
              <div className="product">
                a product of{"  "}
                <a
                  href="https://www.vikncodes.com"
                  rel="noreferrer"
                  style={{ marginLeft: "5px" }}
                  target="_blank"
                >
                  {" "}
                  {"  "}vikncodes
                </a>
              </div>
            ) : null}
            <div className="social">
              <p className="contact-heading">socials</p>
              <div className="social-group">
                <p>
                  <a href="!#">instagram</a>
                </p>
                <p>
                  <a href="!#">facebook</a>
                </p>
                <p>
                  <a href="!#">snapchat</a>
                </p>
                <p>
                  <a href="!#">twitter</a>
                </p>
              </div>
            </div>
            {window.innerWidth >= 760 ? (
              <div className="product">
                a product of{"      "}
                <a
                  rel="noreferrer"
                  href="https://www.vikncodes.com"
                  style={{ marginLeft: "5px" }}
                  target="_blank"
                >
                  {" "}
                  {"  "}vikncodes
                </a>
              </div>
            ) : null}
            <div className="address">
              <p className="contact-heading">Address</p>
              <p>Building No. UP 9/1230 B</p>
              <p className="place">Unnikulam Poonoor, Kerala 673574</p>
              <p>
                Phone: <a href="tel:+919577500400">+919577500400</a>
              </p>
              <p className="email">
                Email:{" "}
                <a
                  href="mailto:info@vikncodes.com"
                  rel="noreferrer"
                  target="_blank"
                >
                  info@vikncodes.com
                </a>
              </p>
            </div>
          </Details>
        </Contact>
      </Spotlight>
    </HomeContents>
  );
};

export default Home;
