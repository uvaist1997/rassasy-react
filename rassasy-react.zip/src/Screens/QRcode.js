import React, { useState, useEffect, useRef } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import { ProfileSuccess, logout } from "../../src/redux/store/user";
import store from "../redux/store";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import test from "../assets/images/l.png"; // wherever is it.
import { Link, useParams } from "react-router-dom";
import { LogoutOutlined, PlusOutlined } from "@ant-design/icons";
import { Spin } from "antd";
import { useDispatch, useSelector } from "react-redux";
import ComponentToPrint from "../components/ComponentToPrint";
import { useReactToPrint } from "react-to-print";
import qrImage from "../assets/images/qr.png";
import { useTranslation } from "react-i18next";
import Pdf from "react-to-pdf";

const options = {};

const ref = React.createRef();

const QRcode = (props) => {
  const { id } = useParams();

  const componentRef = useRef();
  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
  });
  const [state, setState] = useState({
    loading: true,
    previewVisible: false,
    logo_url: "",
    name: "",
    arabic_name: "",
    language: "",
  });
  const [t, i18n] = useTranslation("common");

  const dispatch = useDispatch();
  const user = store.getState();
  let token = user.user.user.access;

  document.getElementById("root").style.marginTop = "60px";

  useEffect(async () => {
    let token = user.user.user.access;
    let language = user.user.language.defaultlanguage;
    let data = state.data;
    let handle = id;
    await fetch(base.BASE_URL + "users/qr-code/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      //   body: JSON.stringify({
      //     pk: handle,
      //   }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success == 6000) {
          let qr_code = response.data.qr_code;
          let name = response.data.name;
          let arabic_name = response.data.arabic_name;
          let logo_image = response.data.image;
          let user_code = response.data.user_code;
          let url = base.MEDIA_URL + qr_code + "/";
          let logo_url = base.MEDIA_URL + logo_image + "/";

          //   let file = [
          //     {
          //       uid: "1",
          //       url: url,
          //     },
          //   ];
          setState({
            ...state,
            language: language,
            loading: false,
            Image: url,
            logo_url: logo_url,
            name: name,
            arabic_name: arabic_name,
            copyurl: `${base.URL}hotel-menu/id=` + user_code,
          });
        } else {
          console.log("ERROR");
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  console.log(state);
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        arabicname: e.target.value,
      });
    } else if (e.target.name == "price") {
      setState({
        ...state,
        price: e.target.value,
      });
    }
  }

  function copyCodeToClipboard() {
    navigator.clipboard.writeText(state.copyurl);
    document.getElementById("custom-tooltip").style.display = "inline";
    setTimeout(function () {
      document.getElementById("custom-tooltip").style.display = "none";
    }, 500);
  }
  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "40vh",
            // width: "100vw",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div className="edit-product-card qr-scan-card">
        <div className="profile-card">
          <div>
            <form className="qrcode-form">
              <div
                style={{
                  backgroundImage: `url("${qrImage}")`,
                  width: "313px",
                  height: "442px",
                  backgroundSize: "cover",
                  backgroundRepeat: "no-repeat",
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                  position: "relative",
                  margin: "0 auto",
                }}
                className="thumb-line qr-container"
              >
                <div style={{ width: "50px" }} className="mt-2 logo-img">
                  <img src={state.logo_url} alt="Logo" width="100%" />
                </div>
                <p
                  style={{
                    fontWeight: "bold",
                    color: "#000",
                    fontSize: "17px",
                    marginTop: "10px",
                  }}
                >
                  {state.language == "de" ? state.arabic_name : state.name}
                </p>
                <div
                  style={{
                    position: "absolute",
                    top: "153px",
                    right: " 96px",
                    width: "130px",
                  }}
                  className="top-logo"
                >
                  <img src={state.Image} alt="Logo" width="100%" />
                </div>
              </div>
              <div style={{ display: "none" }}>
                <ComponentToPrint ref={componentRef} />
              </div>
              {/* <h3>QR CODE</h3> */}

              {/* <Button
                onClick={handlePrint}
                className="mt-4 login-button btn btn-block"
                variant="primary"
                type="button"
                htmlType="submit"
              >
                {t("Print")}
              </Button> */}
              <Pdf targetRef={ref} filename="code-example.pdf">
                {({ toPdf }) => (
                  <button
                    variant="primary"
                    type="button"
                    htmlType="submit"
                    className="mt-4 login-button btn btn-block"
                    onClick={toPdf}
                  >
                    {t("Download")}
                  </button>
                )}
              </Pdf>
              <Button
                onClick={() => copyCodeToClipboard()}
                className="mb-2 mt-2 login-button btn btn-block"
                style={{ background: "#000", border: "unset" }}
              >
                {t("Copy Url")}
              </Button>
              <span id="custom-tooltip">copied!</span>
            </form>
          </div>
        </div>

        <div
          style={{
            display: "block",
            position: "absolute",
            top: "-335px",
            zIndex: "-1",
            right: "400px",
          }}
          ref={ref}
        >
          <ComponentToPrint />
        </div>
      </div>
    );
  }
};

export default QRcode;
