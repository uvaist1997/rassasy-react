import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import swal from "sweetalert";
import {
  EditFilled,
  DeleteFilled,
  PlusCircleOutlined,
  LogoutOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button, Spin } from "antd";
import "../App.css";
import CreateBtn from "../assets/images/view.png";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import LottieLoder from "../components/Lottie";
import Lottie from "react-lottie";
import Starburst from "../assets/lottie/demo.json";
import { TextBlock, RectShape } from "react-placeholder/lib/placeholders";
import Autocomplete from "@material-ui/lab/Autocomplete";

const Compress = require("compress.js");
const compress = new Compress();

export default function Products(props) {
  const [state, setState] = useState({
    collapsed: false,
    index_category: "",
    loading: true,
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: [],
    Image: "",
    singledata: {
      id: "",
      name: "",
      arabicname: "",
      price: "",
      productimage: "",
    },
    category: "",
    data: [
      {
        id: "",
        name: "",
        arabicname: "",
      },
    ],
    cat_datas: [],
  });
  const MyPlaceholder = () => (
    <div>
      <br />
      <RectShape color="#272727" style={{ width: 400, height: 90 }} />
      <br />
      <TextBlock rows={3} color="#272727" />
      <br />
      <RectShape color="#272727" style={{ width: 400, height: 30 }} />
      <br />
      <TextBlock rows={3} color="#272727" />
    </div>
  );
  const [t, i18n] = useTranslation("common");
  let user = store.getState();
  let multylanguage = "";
  let defaultlanguage = "";
  if (user.user.user) {
    multylanguage = user.user.language.multylanguage;
    defaultlanguage = user.user.language.defaultlanguage;
    console.log(
      multylanguage,
      "multylanguage!!!!!!!!!!!!!!!!",
      defaultlanguage
    );
  }
  useEffect(async () => {
    let token = user.user.user.access;
    console.log(token);
    await fetch(base.BASE_URL + "products/list-products", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          data: response.data,
          cat_datas: response.cat_data,
          loading: false,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  let columns = [];
  if (multylanguage == true) {
    columns = [
      {
        title: t("image"),
        dataIndex: "image",
        key: "image",
        render: (text, record) => (
          <div className="img-container">
            <img src={base.MEDIA_URL + text + "/"} width="50px" height="50px" />
          </div>
        ),
      },
      {
        title: t("name"),
        dataIndex: "name",
        key: "name",
        render: (text, record) => <a>{text}</a>,
      },
      {
        title: t("arabicname"),
        dataIndex: "arabicname",
        key: "arabicname",
      },
      {
        title: t("action"),
        key: "action",
        render: (text, record) => (
          <Space size="middle">
            {/* <Link to={`/single-edit-product/${text.id}/`}>
              <img src={EditBtn} width="30px" />
            </Link> */}
            <a id={text.id} onClick={() => editProduct(text.id)}>
              <img src={EditBtn} width="30px" />
            </a>

            <a onClick={() => deleteItem(text.id)}>
              {/* <DeleteFilled /> */}
              <img src={DeleteBtn} width="30px" />
            </a>
          </Space>
        ),
      },
    ];
  } else {
    if (defaultlanguage == "en") {
      columns = [
        {
          title: t("image"),
          dataIndex: "image",
          key: "image",
          render: (text, record) => (
            <div className="img-container">
              <img
                src={base.MEDIA_URL + text + "/"}
                width="50px"
                height="50px"
              />
            </div>
          ),
        },
        {
          title: t("name"),
          dataIndex: "name",
          key: "name",
          render: (text, record) => <a>{text}</a>,
        },
        {
          title: t("action"),
          key: "action",
          render: (text, record) => (
            <Space size="middle">
              {/* <Link to={`/single-edit-product/${text.id}/`}>
                <img src={EditBtn} width="30px" />
              </Link> */}
              <a id={text.id} onClick={() => editProduct(text.id)}>
                <img src={EditBtn} width="30px" />
              </a>

              <a onClick={() => deleteItem(text.id)}>
                {/* <DeleteFilled /> */}
                <img src={DeleteBtn} width="30px" />
              </a>
            </Space>
          ),
        },
      ];
    } else {
      columns = [
        {
          title: t("image"),
          dataIndex: "image",
          key: "image",
          render: (text, record) => (
            <div className="img-container">
              <img
                src={base.MEDIA_URL + text + "/"}
                width="50px"
                height="50px"
              />
            </div>
          ),
        },

        {
          title: t("arabicname"),
          dataIndex: "arabicname",
          key: "arabicname",
        },
        {
          title: t("action"),
          key: "action",
          render: (text, record) => (
            <Space size="middle">
              {/* <Link to={`/single-edit-product/${text.id}/`}>
                <img src={EditBtn} width="30px" />
              </Link> */}
              <a id={text.id} onClick={() => editProduct(text.id)}>
                <img src={EditBtn} width="30px" />
              </a>

              <a onClick={() => deleteItem(text.id)}>
                {/* <DeleteFilled /> */}
                <img src={DeleteBtn} width="30px" />
              </a>
            </Space>
          ),
        },
      ];
    }
  }
  function handleCancel() {
    setState({ previewVisible: false });
  }
  function setModal2Visible(modal2Visible) {
    setState({ ...state, modal2Visible });
    editProduct();
  }
  function setModal1Visible(modal1Visible) {
    setState({
      ...state,
      modal1Visible,
      singledata: {},
      fileList: [],
      category: "",
    });
  }
  function editProduct(pk) {
    console.log(pk);
    let token = user.user.user.access;
    fetch(base.BASE_URL + "products/show-edit-product", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        pk,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          let product_data = state.singledata;
          product_data["id"] = response.data[0].id;
          product_data["name"] = response.data[0].name;
          product_data["arabicname"] = response.data[0].arabicname;
          product_data["price"] = response.data[0].price;
          let image = response.data[0].image;
          let url = base.MEDIA_URL + image + "/";
          let file = [
            {
              uid: "1",
              url: url,
            },
          ];
          product_data["productimage"] = file;
          let category = response.data[0].category;

          setState({
            ...state,
            singledata: product_data,
            modal2Visible: true,
            fileList: file,
            category: category,
            // index_category: index_category,
          });
          console.log(response.data[0].name, "SUCCESSS", url);
        } else {
          //   swal({
          //     title: "faild",
          //     text: "id is not exists",
          //     icon: "warning",
          //     button: false,
          //     timer: 1000,
          //   });
          console.log("Sss");
        }
      })
      .catch((err) => {
        console.log("err");
      });
    // setState({ ...state, modal2Visible });
  }
  function onProductCreateSubmit(e) {
    e.preventDefault();
    console.log("KIIIU");

    // swal({
    //   title: "Please wait ",
    //   text: "The Product is Create..",
    //   icon: "warning",
    //   button: false,
    // });
    let product_data = state.singledata;
    console.log(state.Image, "===========EDITSUBMIT=============");
    let token = user.user.user.access;
    const formData = new FormData();
    formData.append("pk", product_data.id);
    formData.append("name", product_data.name);
    formData.append("price", product_data.price);
    formData.append("arabicname", product_data.arabicname);
    formData.append("category", state.category);
    formData.append("multylanguage", multylanguage);
    formData.append("defaultlanguage", defaultlanguage);

    formData.append("image", state.Image);

    fetch(base.BASE_URL + `products/create-product`, {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success == 6000) {
          swal({
            title: "success",
            text: "Created SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });

          // props.history.push("/products");
          window.location.reload();
        } else {
          // swal({
          //   title: "failed",
          //   text: response.message,
          //   icon: "warning",
          //   button: false,
          //   timer: 3000,
          // });
          setState({
            ...state,
            error_message: response.message,
            // index_category: index_category,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }

  function onProductEditSubmit(e) {
    e.preventDefault();
    console.log("KIIIU");

    swal({
      title: "Please wait ",
      text: "The Product is Updating..",
      icon: "warning",
      button: false,
    });
    let product_data = state.singledata;
    console.log(state.Image, "===========EDITSUBMIT=============");
    let token = user.user.user.access;
    const formData = new FormData();
    formData.append("pk", product_data.id);
    formData.append("name", product_data.name);
    formData.append("price", product_data.price);
    formData.append("arabicname", product_data.arabicname);
    formData.append("image", state.Image);
    formData.append("category", state.category);

    fetch(base.BASE_URL + `products/edit-product`, {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success == 6000) {
          swal({
            title: "success",
            text: "Updated SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });

          // props.history.push("/products");
          window.location.reload();
        } else {
          swal({
            title: "failed",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 3000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function ProhandleImageChange({ fileList }) {
    console.log(fileList, "pro");
    let product_data = state.singledata;
    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      console.log(resizedimage, "resizedimage");
      resizedimage.then(function (result) {
        product_data["productimage"] = result;
        let demo = URL.createObjectURL(result);
        console.log(demo, "KER");
        setState({
          ...state,
          fileList: fileList,
          singledata: product_data,
          Image: result,
        });
      });
    } else {
      setState({ ...state, fileList: [], Image: "" });
    }
  }
  function ProducthandleChange(e) {
    let product_data = state.singledata;

    console.log("LOO");

    if (e.target.name == "product_name") {
      product_data["name"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    } else if (e.target.name == "product_arabicname") {
      console.log(state);
      // product_data[index]["arabicname"] = e.target.value;
      product_data["arabicname"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    } else if (e.target.name == "product_price") {
      product_data["price"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    }
  }
  console.log(state);
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        arabicname: e.target.value,
      });
    }
  }
  function handleImageChange({ fileList }) {
    console.log(fileList, "originFileObj");
    if (!fileList.length == 0) {
      console.log("KER");
      setState({ fileList, Image: fileList[0]["originFileObj"] });
    } else {
      setState({ fileList: "", Image: "" });
    }
  }
  function onFocus(event) {
    console.log("ENENT>>>>>");
    if (event.target.autocomplete) {
      event.target.autocomplete = "whatever";
    }
  }
  function categoryChange(e, val) {
    if (val) {
      setState({
        ...state,
        category: val.id,
      });
    }
  }
  function deleteItem(id) {
    // e.preventDefault();
    let token = user.user.user.access;
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this  data",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        fetch(base.BASE_URL + `products/delete-product/${id}/`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${token}`,
            // "accept": "application/json"
          },
          // body: JSON.stringify({
          //   DataBase: this.state.DataBase,
          //   CreatedUserID: this.state.CreatedUserID,
          //   BranchID: this.state.BranchID,
          //   CompanyID: CompanyID,
          // }),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.StatusCode === 6000) {
              var icon = "success";
            } else {
              icon = "warning";
            }
            swal({
              title: response.title,
              text: response.message,
              icon: icon,
              button: false,
              timer: 1500,
            });
            window.location.reload();
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        swal("Brand is not deleted");
      }
    });
  }
  async function resizeImageFn(file) {
    const compress = new Compress();
    const resizedImage = await compress.compress([file], {
      size: 4, // the max size in MB, defaults to 2MB
      quality: 0.75, // the quality of the image, max is 1,
      maxWidth: 1920, // the max width of the output image, defaults to 1920px
      maxHeight: 1920, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });

    const img = resizedImage[0];
    const base64str = img.data;
    const imgExt = img.ext;
    const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
    setState({ ...state, img: URL.createObjectURL(resizedFiile) });
    let file1 = [
      {
        uid: "1",
        url: URL.createObjectURL(resizedFiile),
      },
    ];
    // let s = new File([resizedImage], file.name);
    var s = new File([resizedFiile], file.name, {
      type: file.type,
      lastModified: new Date().getTime(),
    });

    return s;
  }
  document.getElementById("root").style.marginTop = "60px";

  const { previewVisible, previewImage, fileList, previewTitle } = state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: Starburst,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  let index_category = 0;
  if (state.category) {
    index_category = state.cat_datas.findIndex((p) => p.id == state.category);
  }
  console.log(index_category);
  if (state.loading == true) {
    return (
      <div>
        <div
          style={{
            height: "40vh",
            // width: "100vw",
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
          className="example"
        >
          <Spin size="large" />
        </div>
      </div>
    );
  } else {
    return (
      <div
        className="list-page-style content site-card-border-less-wrapper"
        style={{ marginTop: 20 }}
      >
        <div className="d-flex justify-content-between align-items-center">
          <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
            <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
              {t("Products")}
            </Breadcrumb.Item>
          </Breadcrumb>
          <div className="add-button">
            <div
              onClick={() => setModal1Visible(true)}
              style={{ cursor: "pointer", fontSize: 30, color: "#fff" }}
              className=""
            >
              <PlusCircleOutlined />
            </div>
          </div>
        </div>
        <form>
          <Row
            style={{
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Row
              style={{
                alignItems: "center",
                justifyContent: "space-between",
                width: 600,
              }}
            ></Row>
          </Row>
        </form>
        <div>
          <Table
            columns={columns}
            dataSource={state.data}
            className="time-table-row-select"
            pagination={{
              defaultPageSize: 10,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50"],
            }}
          />
        </div>
        {/* =====Product Edit Modal Start Heare ======= */}
        <Modal
          className="product-modal"
          title="Edit Product"
          centered
          visible={state.modal2Visible}
          onOk={() => setModal2Visible(false)}
          onCancel={() => setModal2Visible(false)}
          footer={null}
          cancelButtonProps={{ style: { display: "none" } }}
        >
          <form onSubmit={onProductEditSubmit} id="product-validation">
            <Col md={8} style={{ margin: "0 auto" }}>
              <div className="form-group">
                {/* <label>Image</label> */}
                <Upload
                  action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  listType="picture-card"
                  fileList={fileList}
                  onChange={ProhandleImageChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewVisible}
                  title={previewTitle}
                  footer={null}
                  onCancel={handleCancel}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>

              {multylanguage ? (
                <div>
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      className="required-field"
                      onChange={ProducthandleChange}
                      label="Product Name"
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.name}
                      name="product_name"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product name exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      className="required-field"
                      onChange={ProducthandleChange}
                      label="Arabic Name"
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.arabicname}
                      name="product_arabicname"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product arabicname exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                </div>
              ) : (
                [
                  defaultlanguage == "en" ? (
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        className="required-field"
                        onChange={ProducthandleChange}
                        label="Product Name"
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.singledata.name}
                        name="product_name"
                      />
                      <p style={{ color: "red", textAlign: "center" }}>
                        {state.error_message == "Product name exists"
                          ? state.error_message
                          : null}{" "}
                      </p>
                    </div>
                  ) : (
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        className="required-field"
                        onChange={ProducthandleChange}
                        label="Arabic Name"
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.singledata.arabicname}
                        name="product_arabicname"
                      />
                      <p style={{ color: "red", textAlign: "center" }}>
                        {state.error_message == "Product arabicname exists"
                          ? state.error_message
                          : null}{" "}
                      </p>
                    </div>
                  ),
                ]
              )}
              <div className="form-group">
                <Autocomplete
                  id="combo-box-demo"
                  size="small"
                  onChange={(event, value) =>
                    categoryChange(event, value, "country")
                  }
                  options={state.cat_datas}
                  value={
                    state.cat_datas ? state.cat_datas[index_category] : null
                  }
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      InputLabelProps={{ required: false }}
                      label="Category"
                      variant="outlined"
                      autoComplete="off"
                      // onFocus={onFocus}
                    />
                  )}
                />
              </div>
              <div className="form-group ">
                <TextField
                  required
                  InputLabelProps={{ required: false }}
                  className="required-field"
                  onChange={ProducthandleChange}
                  label="Price"
                  type="number"
                  id="outlined-margin-dense"
                  margin="dense"
                  variant="outlined"
                  value={state.singledata.price}
                  name="product_price"
                />
              </div>
              <div style={{ textAlign: "center" }} className="form-group">
                <Button
                  // onClick={() => onProductEditSubmit()}
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  Save
                </Button>
              </div>
            </Col>
          </form>
        </Modal>
        {/* =====Product Create Modal Start Heare ======= */}
        <Modal
          className="product-modal"
          title="Create Product"
          centered
          visible={state.modal1Visible}
          onOk={() => setModal1Visible(false)}
          onCancel={() => setModal1Visible(false)}
          footer={null}
          cancelButtonProps={{ style: { display: "none" } }}
        >
          <form onSubmit={onProductCreateSubmit} id="product-validation">
            <Col md={8} style={{ margin: "0 auto" }}>
              <div className="form-group">
                {/* <label>Image</label> */}
                <Upload
                  action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  listType="picture-card"
                  fileList={fileList}
                  onChange={ProhandleImageChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewVisible}
                  title={previewTitle}
                  footer={null}
                  onCancel={handleCancel}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>

              {multylanguage ? (
                <div>
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      className="required-field"
                      onChange={ProducthandleChange}
                      label="Product Name"
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.name}
                      name="product_name"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product name exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      className="required-field"
                      onChange={ProducthandleChange}
                      label="Arabic Name"
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.arabicname}
                      name="product_arabicname"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product arabicname exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                </div>
              ) : (
                [
                  defaultlanguage == "en" ? (
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        className="required-field"
                        onChange={ProducthandleChange}
                        label="Product Name"
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.singledata.name}
                        name="product_name"
                      />
                      <p style={{ color: "red", textAlign: "center" }}>
                        {state.error_message == "Product name exists"
                          ? state.error_message
                          : null}{" "}
                      </p>
                    </div>
                  ) : (
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        className="required-field"
                        onChange={ProducthandleChange}
                        label="Arabic Name"
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.singledata.arabicname}
                        name="product_arabicname"
                      />
                      <p style={{ color: "red", textAlign: "center" }}>
                        {state.error_message == "Product arabicname exists"
                          ? state.error_message
                          : null}{" "}
                      </p>
                    </div>
                  ),
                ]
              )}
              <div className="form-group">
                <Autocomplete
                  id="combo-box-demo"
                  size="small"
                  onChange={(event, value) => categoryChange(event, value)}
                  options={state.cat_datas}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      required
                      InputLabelProps={{ required: false }}
                      label="Category"
                      variant="outlined"
                      autoComplete="off"
                      onFocus={onFocus}
                    />
                  )}
                />
              </div>
              <div className="form-group ">
                <TextField
                  required
                  InputLabelProps={{ required: false }}
                  className="required-field"
                  onChange={ProducthandleChange}
                  label="Price"
                  type="number"
                  id="outlined-margin-dense"
                  margin="dense"
                  variant="outlined"
                  value={state.singledata.price}
                  name="product_price"
                />
              </div>
              <div style={{ textAlign: "center" }} className="form-group">
                <Button
                  // onClick={() => onProductEditSubmit()}
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  Save
                </Button>
              </div>
            </Col>
          </form>
        </Modal>
      </div>
    );
  }
}
