import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import swal from "sweetalert";
import {
  EditFilled,
  DeleteFilled,
  PlusCircleOutlined,
  LogoutOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button } from "antd";
import "../App.css";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";

const Compress = require("compress.js");
const compress = new Compress();

export default function CreateCategory(props) {
  const [state, setState] = useState({
    is_create: false,
    is_edit: false,
    error_message: "",
    is_product_edit: false,
    collapsed: false,
    modal2Visible: false,
    visible: false,
    loading: false,
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: [],
    fileList1: [],
    cat_name: "",
    cat_arabicname: "",
    Image: "",
    singledata: {
      id: "",
      name: null,
      arabicname: null,
      price: "",
      productimage: "",
      img: [],
    },
    data: [],
  });
  const [t, i18n] = useTranslation("common");
  let user = store.getState();
  let multylanguage = "";
  let defaultlanguage = "";
  if (user.user.user) {
    multylanguage = user.user.language.multylanguage;
    defaultlanguage = user.user.language.defaultlanguage;
    console.log(
      multylanguage,
      "multylanguage!!!!!!!!!!!!!!!!",
      defaultlanguage
    );
  }

  useEffect(async () => {
    let token = user.user.user.access;
    let data = state.data;
    console.log(data, "TOKENt");
    // await fetch(base.BASE_URL + "products/list-category", {
    //   method: "GET",
    //   headers: {
    //     "content-type": "application/json",
    //     Authorization: `Bearer ${token}`,
    //     accept: "application/json",
    //   },
    //   // body: JSON.stringify({
    //   //   CompanyID: CompanyID,
    //   // }),
    // })
    //   .then((response) => response.json())
    //   .then((response) => {
    //     setState({
    //       ...state,
    //       data: response.data,
    //     });
    //   })
    //   .catch((err) => {
    //     console.log("err");
    //   });
  }, []);
  const columns = [
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      render: (text, record) => (
        <div className="img-container">
          <img src={base.MEDIA_URL + text + "/"} width="50px" height="50px" />
        </div>
      ),
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      render: (text, record) => <a>{text}</a>,
    },
    {
      title: "Arabic Name",
      dataIndex: "arabicname",
      key: "arabicname",
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => (
        <Space size="middle">
          {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
          <EditFilled />
        </Link> */}
          <a>
            {/* <EditFilled /> */}
            <img src={EditBtn} width="30px" />
          </a>

          <a>
            {/* <DeleteFilled /> */}
            <img src={DeleteBtn} width="30px" />
          </a>
        </Space>
      ),
    },
  ];
  // function handleCancel() {
  //   console.log("AAAAAAAAAAAAAAAAAAAAAADAAAAAA");
  //   setState({ previewVisible: false });
  // }
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        cat_name: e.target.value,
      });
      console.log(e.target.name);
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        cat_arabicname: e.target.value,
      });
    }
  }
  function ProducthandleChange(e) {
    console.log("KALPETTAAAAAAAAA");
    setState({
      ...state,
      error_message: "",
    });
    let product_data1 = state.data;
    let index = Number(product_data1.length) - 1;
    let product_data = state.singledata;

    if (e.target.name == "product_name") {
      product_data["name"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    } else if (e.target.name == "product_arabicname") {
      // product_data[index]["arabicname"] = e.target.value;
      product_data["arabicname"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    } else if (e.target.name == "product_price") {
      product_data["price"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    }
  }
  function CathandleImageChange({ fileList }) {
    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      console.log(resizedimage, "resizedimage");
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, fileList, Image: result });
      });
      console.log("KER");
      // setState({ ...state, fileList, Image: fileList[0]["originFileObj"] });
    } else {
      setState({ ...state, fileList: [], Image: "" });
    }
  }
  function ProhandleImageChange({ fileList }) {
    console.log(fileList, "pro");
    let product_data = state.singledata;
    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      console.log(resizedimage, "resizedimage");
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        product_data["productimage"] = result;
        product_data["img"] = fileList;
        let demo = URL.createObjectURL(fileList[0]["originFileObj"]);
        console.log(demo, "KER");
        setState({
          ...state,
          error_message: "",
          fileList1: fileList,
          singledata: product_data,
        });
      });
    } else {
      setState({ ...state, fileList1: [], ProImage: "" });
    }
  }
  const showModal = () => {
    setIsModalVisible(true);
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
  const [isModalVisible, setIsModalVisible] = useState(false);
  document.getElementById("root").style.marginTop = "60px";
  const { previewVisible, previewImage, fileList, fileList1, previewTitle } =
    state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("Upload")}</div>
    </div>
  );
  function onProductSubmit(e) {
    e.preventDefault();
    let data = state.data;

    let product_detail = state.singledata;
    let exists = Object.values(data).includes(product_detail.name);
    console.log(
      product_detail.name,
      "UVAAAAAAproduct_detailproduct_detailAVISSSS"
    );
    if (multylanguage == false && defaultlanguage == "de") {
      if (product_detail.productimage == "") {
        setState({
          ...state,
          error_message: "image is required",
        });
      } else if (data.some((e) => e.arabicname == product_detail.arabicname)) {
        data.some((e) =>
          console.log(e.arabicname, "RASSASYTESTING", product_detail.arabicname)
        );
        setState({
          ...state,
          error_message: "Product arabicname is Exists",
        });
        console.log(
          "SAME ARABIC EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          productimage: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
        setIsModalVisible(false);
      }
    } else if (multylanguage == false && defaultlanguage == "en") {
      if (product_detail.productimage == "") {
        setState({
          ...state,
          error_message: "image is required",
        });
      } else if (data.some((e) => e.name == product_detail.name)) {
        data.some((e) =>
          console.log(e.name, "RASSASYTESTING", product_detail.name)
        );
        setState({
          ...state,
          error_message: "Product name is Exists",
        });
        console.log(
          "SAME ARABIC EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          productimage: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
        setIsModalVisible(false);
      }
    } else {
      if (product_detail.productimage == "") {
        setState({
          ...state,
          error_message: "image is required",
        });
      } else if (data.some((e) => e.name == product_detail.name)) {
        data.some((e) => console.log(e, "RASSASYTESTING", product_detail.name));
        setState({
          ...state,
          error_message: "Product name is Exists",
        });
        console.log(
          "SAME NAME EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else if (data.some((e) => e.arabicname == product_detail.arabicname)) {
        data.some((e) =>
          console.log(e.arabicname, "RASSASYTESTING", product_detail.arabicname)
        );
        setState({
          ...state,
          error_message: "Product arabicname is Exists",
        });
        console.log(
          "SAME ARABIC EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          productimage: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
        setIsModalVisible(false);
      }
    }
  }
  function onProductEditSubmit(e) {
    e.preventDefault();
    let data = state.data;
    let product_detail = state.singledata;
    console.log(product_detail);
    let index = product_detail.id;
    let name = product_detail.name;
    let price = product_detail.price;
    let productimage = product_detail.productimage;
    let img = product_detail.img;
    if (
      // product_detail.name == "" ||
      // product_detail.arabicname == "" ||
      // product_detail.price == "" ||
      product_detail.productimage == ""
    ) {
      console.log("ERROR");
      swal({
        title: "Please fill required field",
        text: "field is required",
        icon: "warning",
        button: false,
        timer: 2000,
      });
    } else {
      // data.push(product_detail);
      data[index]["name"] = name;
      data[index]["price"] = price;
      data[index]["productimage"] = productimage;
      data[index]["img"] = img;

      console.log(product_detail);
      let singledata = {
        id: "",
        name: "",
        arabicname: "",
        price: "",
        productimage: "",
        img: [],
      };
      setState({
        ...state,
        data,
        singledata,
        modal2Visible: false,
        is_product_edit: false,
        fileList1: [],
      });
      setIsModalVisible(false);
    }
  }
  console.log(state, "DERRRRRRRRRRR");
  // ======
  function setModal2Visible(modal2Visible) {
    console.log(state, "JAYAM", modal2Visible);
    // setState({ ...state, modal2Visible });
  }
  function productDelete(index) {
    let data = state.data;
    delete data[index];
    console.log(data);
    setState({ ...state, data });
  }
  function productCreate() {
    console.log("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
    // showModal();
    setIsModalVisible(true);
    let singledata = {
      id: "",
      name: "",
      arabicname: "",
      price: "",
      productimage: "",
      img: [],
    };
    setState({
      ...state,
      singledata,
      is_product_edit: false,
      fileList1: [],
    });
  }
  function productEdit(index) {
    showModal();
    let data = state.data;
    let indexID = index;

    let name = data[indexID]["name"];
    let arabicname = data[indexID]["arabicname"];
    let price = data[indexID]["price"];
    let productimage = data[indexID]["productimage"];
    let img = data[indexID]["img"];
    console.log(img, "@#@#@#");

    let product_data = state.singledata;
    product_data["id"] = index;
    product_data["name"] = name;
    product_data["arabicname"] = arabicname;
    product_data["price"] = price;
    product_data["productimage"] = productimage;
    product_data["img"] = img;
    setState({
      ...state,
      singledata: product_data,
      modal2Visible: true,
      fileList1: img,
      is_product_edit: true,
    });
  }
  async function resizeImageFn(file) {
    const compress = new Compress();
    const resizedImage = await compress.compress([file], {
      size: 4, // the max size in MB, defaults to 2MB
      quality: 0.75, // the quality of the image, max is 1,
      maxWidth: 1920, // the max width of the output image, defaults to 1920px
      maxHeight: 1920, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });

    const img = resizedImage[0];
    const base64str = img.data;
    const imgExt = img.ext;
    const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
    setState({ ...state, img: URL.createObjectURL(resizedFiile) });
    let file1 = [
      {
        uid: "1",
        url: URL.createObjectURL(resizedFiile),
      },
    ];
    // let s = new File([resizedImage], file.name);
    var s = new File([resizedFiile], file.name, {
      type: file.type,
      lastModified: new Date().getTime(),
    });

    return s;
  }
  function handleSubmit(e) {
    e.preventDefault();
    swal({
      title: "Please wait ",
      text: "The Category is Creating..",
      icon: "warning",
      button: false,
    });
    console.log("Submit");
    const formData = new FormData();
    formData.append("name", state.cat_name);
    formData.append("arabicname", state.cat_arabicname);
    console.log(state.Image, "=============image1111111111111111");
    formData.append("image", state.Image);
    for (let index = 0; index < state.data.length; index++) {
      const element = state.data[index];
      if (element) {
        // formData.append(element.name, element.productimage);
        // console.log(element.name, "element");
        // if (element.name) {
        // } else {
        //   formData.append(element.arabicname, element.productimage);
        // }
        if (multylanguage == false && defaultlanguage == "de") {
          formData.append(element.arabicname, element.productimage);
        } else {
          formData.append(element.name, element.productimage);
        }
      }
    }
    // formData.append("data", state.data);
    formData.append("data", JSON.stringify(state.data));
    let token = user.user.user.access;
    fetch(base.BASE_URL + "products/create-category", {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode === 6000) {
          swal({
            title: "success",
            text: "Category Created SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          props.history.push("/");
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  // ====
  return (
    <div
      className="list-page-style content site-card-border-less-wrapper"
      style={{ marginTop: 20 }}
    >
      <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
        <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
          {t("Add Category")}
        </Breadcrumb.Item>
      </Breadcrumb>
      <form onSubmit={handleSubmit}>
        <Row
          className="category-container"
          style={{
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Row
            className="category-inner-container"
            style={{
              alignItems: "center",
              justifyContent: "space-between",
              width: 600,
            }}
          >
            <Col>
              <div className="form-group">
                {/* <label>Image</label> */}
                <Upload
                  action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  listType="picture-card"
                  fileList={fileList}
                  onChange={CathandleImageChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewVisible}
                  title={previewTitle}
                  footer={null}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>
            </Col>
            {multylanguage ? (
              <Col>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    label={t("name")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.cat_name}
                    onChange={(e) => {
                      handleChange(e);
                    }}
                    name="name"
                  />
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    label={t("arabicname")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.cat_arabicname}
                    onChange={(e) => {
                      handleChange(e);
                    }}
                    name="arabicname"
                  />
                </div>
              </Col>
            ) : (
              [
                defaultlanguage == "en" ? (
                  <Col>
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      label={t("name")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.cat_name}
                      onChange={handleChange}
                      name="name"
                    />
                  </Col>
                ) : (
                  <div className="form-group ">
                    <Col>
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("arabicname")}
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.cat_arabicname}
                        onChange={handleChange}
                        name="arabicname"
                      />
                    </Col>
                  </div>
                ),
                // <div key="1">body</div>,
              ]
            )}
          </Row>
          <Row className="category-bottom-container">
            <Col className="category-col">
              <div className="form-group ">
                <button
                  style={{ background: "#1eaa97", color: "#fff" }}
                  type="submit"
                  className="btn text-center mr-3"
                >
                  {t("save")}
                </button>
              </div>
              {state.cat_name || state.cat_arabicname ? (
                <div
                  className="create-plus form-group "
                  onClick={productCreate}
                >
                  <Link
                    to=""
                    style={{ fontSize: 30, color: "#fff" }}
                    className=""
                  >
                    <PlusCircleOutlined />
                  </Link>
                  {/* <p className="m-0">Add Products</p> */}
                </div>
              ) : null}
            </Col>
          </Row>
        </Row>
      </form>
      <div>
        {/* <Table
          columns={columns}
          dataSource={state.data}
          className="time-table-row-select"
          pagination={{
            defaultPageSize: 10,
            showSizeChanger: true,
            pageSizeOptions: ["5", "10", "20", "50"],
          }}
        /> */}

        <table className="product-table table table-dark">
          <thead>
            <tr>
              {multylanguage == true
                ? [
                    <th scope="col">{t("name")}</th>,
                    <th scope="col">{t("arabicname")}</th>,
                  ]
                : [
                    defaultlanguage == "en" ? (
                      <th scope="col">{t("name")}</th>
                    ) : (
                      <th scope="col">{t("arabicname")}</th>
                    ),
                  ]}

              <th scope="col">{t("Price")}</th>
              <th scope="col">{t("action")}</th>
            </tr>
          </thead>
          <tbody>
            {state.data.map((i, index) => (
              <tr>
                {multylanguage == true
                  ? [<td>{i.name}</td>, <td>{i.arabicname}</td>]
                  : [
                      defaultlanguage == "en" ? (
                        <td>{i.name}</td>
                      ) : (
                        <td>{i.arabicname}</td>
                      ),
                    ]}

                <td>{i.price}</td>
                <td>
                  <a className="mr-2">
                    <img
                      onClick={() => productEdit(index, i.id)}
                      src={EditBtn}
                      width="30px"
                    />
                  </a>
                  <a>
                    <img
                      onClick={() => productDelete(index, i.id)}
                      src={DeleteBtn}
                      width="30px"
                    />
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* =====Product Modal Start Heare ======= */}
      <Modal
        className="product-modal"
        title={t("Add Product")}
        visible={isModalVisible}
        onOk={handleOk}
        onCancel={handleCancel}
        footer={null}
        cancelButtonProps={{ style: { display: "none" } }}
      >
        <form
          onSubmit={
            state.is_create
              ? onProductSubmit
              : state.is_edit
              ? onProductEditSubmit
              : null
          }
        >
          <Col md={8} style={{ margin: "0 auto" }}>
            <div className="form-group">
              {/* <label>Image</label> */}
              <Upload
                action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                listType="picture-card"
                fileList={fileList1}
                onChange={ProhandleImageChange}
              >
                {fileList1.length >= 1 ? null : uploadButton}
              </Upload>
              <p style={{ color: "red", textAlign: "center" }}>
                {state.error_message == "image is required"
                  ? state.error_message
                  : null}{" "}
              </p>
              <Modal
                visible={previewVisible}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
              >
                <img
                  alt="example"
                  style={{ width: "100%" }}
                  src={previewImage}
                />
              </Modal>
            </div>
            {multylanguage ? (
              <div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    onChange={ProducthandleChange}
                    label={t("Product Name")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.singledata.name}
                    name="product_name"
                  />
                  <p style={{ color: "red", textAlign: "center" }}>
                    {state.error_message == "Product name is Exists"
                      ? state.error_message
                      : null}{" "}
                  </p>
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    onChange={ProducthandleChange}
                    label={t("arabicname")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.singledata.arabicname}
                    name="product_arabicname"
                  />
                  <p style={{ color: "red", textAlign: "center" }}>
                    {state.error_message == "Product arabicname is Exists"
                      ? state.error_message
                      : null}{" "}
                  </p>
                </div>
              </div>
            ) : (
              [
                defaultlanguage == "en" ? (
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      onChange={ProducthandleChange}
                      label={t("Product Name")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.name}
                      name="product_name"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product name is Exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                ) : (
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      onChange={ProducthandleChange}
                      label={t("arabicname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.arabicname}
                      name="product_arabicname"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product arabicname is Exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                ),
                // <div key="1">body</div>,
              ]
            )}

            <div className="form-group ">
              <TextField
                required
                InputLabelProps={{ required: false }}
                onChange={ProducthandleChange}
                label={t("Price")}
                id="outlined-margin-dense"
                margin="dense"
                type="number"
                variant="outlined"
                value={state.singledata.price}
                name="product_price"
              />
            </div>
            <div style={{ textAlign: "center" }} className="form-group">
              {state.is_product_edit ? (
                <Button
                  onClick={() =>
                    setState({
                      ...state,
                      is_create: false,
                      is_edit: true,
                    })
                  }
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  {t("Update")}
                </Button>
              ) : (
                <Button
                  onClick={() =>
                    setState({
                      ...state,
                      is_create: true,
                      is_edit: false,
                    })
                  }
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  {t("save")}
                </Button>
              )}
            </div>
          </Col>
        </form>
      </Modal>
    </div>
  );
}
