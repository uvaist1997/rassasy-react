import React, { useState, useEffect, Component } from "react";
import { Button } from "react-bootstrap";
import history from "../components/history";
import TextField from "@material-ui/core/TextField";
import "../assets/css/Login.css";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import viknlogo from "../assets/images/vikn.png";
import { Modal, Form, Input } from "antd";
import { EyeOutlined } from "@ant-design/icons";
import FormControl from "@material-ui/core/FormControl";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import InputLabel from "@material-ui/core/InputLabel";
import InputAdornment from "@material-ui/core/InputAdornment";
import IconButton from "@material-ui/core/IconButton";

function Registration(props) {
  const [state, setState] = useState({
    is_button: false,
    username: "",
    password1: "",
    password2: "",
    firstname: "",
    lastname: "",
    email: "",
    error: false,
    modal2Visible: false,
    verified_code: "",
    admin_code: "",
    key: "",
    showPassword: false,
  });
  const layout = {
    // labelCol: {
    //   span: 8,
    // },
    // wrapperCol: {
    //   span: 16,
    // },
  };
  const tailLayout = {
    // wrapperCol: {
    //   offset: 8,
    //   span: 16,
    // },
  };
  const [passwordShown, setPasswordShown] = useState(false);
  const togglePasswordVisiblity = () => {
    setPasswordShown(passwordShown ? false : true);
  };
  const handleClickShowPassword = (e) => {
    console.log(e, "EEEEEEEEEEEE");
    setState({ ...state, showPassword: !state.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  const styles = {
    card: {
      padding: "25px",
      borderRadius: "10px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      position: "relative",
      background: "#fff",
      border: ".5px solid rgba(0,0,0,.1)",
    },
    auth_bg: {
      //   backgroundImage: `url(${bg_auth})`,
      backgroundSize: "cover",
      boxSizing: "border-box",
    },
    text_position: {
      position: "absolute",
      bottom: 0,
    },
    container_height: {
      height: "100vh",
    },
  };

  const validateMessages = {
    required: "${label} is required!",
    types: {
      email: "${label} is not valid email!",
      username: "${label} is not a valid username!",
      password: "${label} is not a valid password!",
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };

  function handleChange(e) {
    setState((prevState) => {
      return { ...prevState, [e.target.name]: e.target.value, message: "" };
    });
  }

  function handleSubmit(e) {
    e.preventDefault();
    setState({
      ...state,
      error: true,
      is_button: true,
    });
    console.log(e, state);

    fetch(base.BASE_URL + `users/user-registration/`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${token}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        username: state.username,
        password1: state.password1,
        password2: state.password2,
        firstname: state.firstname,
        lastname: state.lastname,
        email: state.email,
        verified: false,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode == 6009) {
          console.log(response.code, "cccccccc");
          setState(
            {
              ...state,
              admin_code: response.code,
              key: response.key,
              modal2Visible: true,
              is_button: false,
            }
            // function () {
            //   setModal2Visible(true);
            // }
          );
          // swal({
          //   title: "success",
          //   text: "Registered SuccessFully",
          //   icon: "success",
          //   button: false,
          //   timer: 1000,
          // });
          // history.push("/");
          // window.location.reload();
        } else {
          console.log(response.message);

          // swal({
          //   title: "failed",
          //   text: response.message,
          //   icon: "warning",
          //   button: false,
          //   timer: 3000,
          // });
          setState({
            ...state,
            message: response.message,
            is_button: false,
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
  function VarifyhandleSubmit(e) {
    console.log("handleSubmit111111111111111111");
    // e.preventDefault();
    setState({
      ...state,
      error: true,
    });
    console.log(state);

    fetch(base.BASE_URL + `users/user-registration/`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${token}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        username: state.username,
        password1: state.password1,
        password2: state.password2,
        firstname: state.firstname,
        lastname: state.lastname,
        email: state.email,
        verified: true,
        verified_code: state.verified_code,
        admin_code: state.admin_code,
        key: state.key,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode == 6000) {
          setModal2Visible(false);
          swal({
            title: "success",
            text: "Registered SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });
          history.push("/sign-in");
          window.location.reload();
        } else {
          console.log(response.message);

          swal({
            title: "Re-send Code?",
            text: response.message,
            icon: "warning",
            buttons: true,
            dangerMode: true,
          }).then((willDelete) => {
            if (willDelete) {
              setModal2Visible(false);
              // handleSubmit();
              swal("Please Check Your Email!", {
                icon: "success",
              });
            } else {
              swal("Please enter verification code!");
            }
          });
          setState({
            ...state,
            message: response.message,
          });
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
  function setModal2Visible(modal2Visible) {
    setState({ ...state, modal2Visible });
  }
  function onChangeCode(e) {
    setState({ ...state, verified_code: e.target.value });
  }
  return (
    <div className="registration-page common-card">
      <div className="user-card">
        <div className="d-flex justify-content-center form_container login-form">
          <form onSubmit={handleSubmit} onChange={handleChange}>
            <div className="imageclick top-logo">
              <Link to="/">
                <img src={logo} alt="Logo" width="100%" />
              </Link>
            </div>
            <h3>Sign Up</h3>

            <div className="">
              <TextField
                required
                InputLabelProps={{ required: false }}
                className="test"
                label="First Name"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="firstname"
              />
            </div>

            <div className="">
              <TextField
                label="Last Name"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="lastname"
                required
                InputLabelProps={{ required: false }}
              />
            </div>

            <div className="">
              <TextField
                label="Email"
                id="outlined-margin-dense"
                type="email"
                margin="dense"
                variant="outlined"
                name="email"
                helperText={
                  state.message == "Email address already in use."
                    ? state.message
                    : null
                }
                error={
                  state.email.length < 6 && state.email.length > 0
                    ? true
                    : state.message == "Email address already in use."
                    ? true
                    : false
                }
                required
                InputLabelProps={{ required: false }}
              />
            </div>

            <div className=""></div>

            <div className="">
              <TextField
                label="Username"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                name="username"
                required
                InputLabelProps={{ required: false }}
                helperText={
                  state.username.length < 6 && state.username.length > 0
                    ? "Username should have 6 character"
                    : state.message == "Username already exists."
                    ? state.message
                    : null
                }
                error={
                  state.username.length < 6 && state.username.length > 0
                    ? true
                    : state.message == "Username already exists."
                    ? true
                    : false
                }
              />
            </div>

            <div className="">
              <TextField
                helperText={
                  state.password1.length < 6 && state.password1.length > 0
                    ? "password should have 6 character"
                    : null
                }
                error={
                  state.password1.length < 6 && state.password1.length > 0
                    ? true
                    : false
                }
                label="Password"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                type={passwordShown ? "text" : "password"}
                name="password1"
                required
                InputLabelProps={{ required: false }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        style={{ color: "#fff", fontSize: "18px" }}
                        aria-label="toggle password visibility"
                        onClick={togglePasswordVisiblity}
                        edge="end"
                      >
                        {state.showPassword ? <EyeOutlined /> : <EyeOutlined />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </div>

            <div className="form-group">
              <TextField
                error={
                  state.password2 == state.password1 ||
                  state.password2.length == 0
                    ? false
                    : true
                }
                label="Confirm Password"
                id="outlined-margin-dense"
                margin="dense"
                variant="outlined"
                type={state.showPassword ? "text" : "password"}
                name="password2"
                required
                InputLabelProps={{ required: false }}
                helperText={
                  state.password2 == state.password1 ||
                  state.password2.length == 0
                    ? null
                    : "password mismatch"
                }
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        style={{ color: "#fff", fontSize: "18px" }}
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {state.showPassword ? <EyeOutlined /> : <EyeOutlined />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </div>

            <Button
              disabled={state.is_button}
              className="login-button btn btn-block"
              variant="primary"
              type="submit"
              htmlType="submit"
            >
              Submit
            </Button>
            {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
          </form>
        </div>

        <Modal
          title="Email Verification Code"
          className="registraion-modal"
          visible={state.modal2Visible}
          onCancel={() => setModal2Visible(false)}
          footer={null}
        >
          <Form
            {...layout}
            name="basic"
            initialValues={{
              remember: true,
            }}
            onFinish={VarifyhandleSubmit}
          >
            <div className="">
              <div style={{ margin: "0 auto" }} className="col-8 form-group">
                <TextField
                  onChange={onChangeCode}
                  label="Code"
                  id="outlined-margin-dense"
                  margin="dense"
                  required
                  variant="outlined"
                  type="text"
                  name="code"
                  InputLabelProps={{ required: false }}
                />
              </div>
              <div className="">
                <Form.Item {...tailLayout}>
                  <Button
                    type="primary"
                    htmlType="submit"
                    style={{
                      background: "#1eaa97",
                      fontSize: "12px !important",
                    }}
                  >
                    Submit
                  </Button>
                </Form.Item>
              </div>
            </div>
          </Form>
        </Modal>
      </div>
      <p className="mt-3">
        Already Have An Account? <Link to="/sign-in">Login</Link>
      </p>
      <div>
        <h5 className="pt-5">
          {/* Powerd By{" "} */}
          <span>
            <img
              src={viknlogo}
              loading="lazy"
              width="116"
              alt=""
              className="image-24"
            />
          </span>
        </h5>
      </div>
    </div>
  );
}

export default Registration;
