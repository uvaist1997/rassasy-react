import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import {
  ProfileSuccess,
  logout,
  switchLanguage,
} from "../../src/redux/store/user";
import store from "../redux/store";
import * as base from "../settings";
import swal from "sweetalert";
import logo from "../assets/images/lg.png"; // wherever is it.
import { Link } from "react-router-dom";
import { LogoutOutlined, PlusOutlined } from "@ant-design/icons";
import { Upload, Modal, Radio, Switch } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { useTranslation } from "react-i18next";
import LocationSearchInput from "../components/LocationSearchInput";
import Autocomplete from "@material-ui/lab/Autocomplete";

const Compress = require("compress.js");
const compress = new Compress();

function CreateProfile() {
  const [t, i18n] = useTranslation("common");
  const user = store.getState();
  const [state, setState] = useState({
    loading: false,
    multylanguage: true,
    defaultlanguage: "en",
    activelanguage: "en",
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: [],
    Image: "",
    token: user.user.user.access,
    name: "",
    arabicname: "",
    address: "",
    arabicaddress: "",
    phone: "",
    spotimage: "",
    country: "",
    lat: "",
    lng: "",
    location: "",
    cuntry_datas: "",
  });
  const dispatch = useDispatch();

  useEffect(async () => {
    dispatch(switchLanguage(state));
  }, [state]);

  function loadContent() {
    let token = user.user.user.access;
    setState({ ...state, token: user.user.user.access });
    console.log(token, "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
  }
  useEffect(async () => {
    await fetch(base.BASE_URL + "users/countries/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
    })
      .then((response) => response.json())
      .then((response) => {
        setState({
          ...state,
          cuntry_datas: response.data,
          loading: false,
        });
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);

  async function resizeImageFn(file) {
    const compress = new Compress();
    const resizedImage = await compress.compress([file], {
      size: 4, // the max size in MB, defaults to 2MB
      quality: 0.75, // the quality of the image, max is 1,
      maxWidth: 1920, // the max width of the output image, defaults to 1920px
      maxHeight: 1920, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });

    const img = resizedImage[0];
    const base64str = img.data;
    const imgExt = img.ext;
    const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
    setState({ ...state, img: URL.createObjectURL(resizedFiile) });
    let file1 = [
      {
        uid: "1",
        url: URL.createObjectURL(resizedFiile),
      },
    ];
    // let s = new File([resizedImage], file.name);
    var s = new File([resizedFiile], file.name, {
      type: file.type,
      lastModified: new Date().getTime(),
    });

    return s;
  }
  function countryChange(e, val) {
    if (val) {
      setState({
        ...state,
        country: val.currency_code,
      });
    }
  }
  function handleChange(e) {
    if (e.target.name == "spotimage") {
      console.log("POLICESSS", e.target.files[0]);
      let resizedimage = resizeImageFn(e.target.files[0]);
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, spotimage: result });
      });
      console.log(typeof resizedimage, "KALLAN");
      console.log(resizedimage, "KALLAN");
    } else {
      if (e.target.name == "defaultlanguage") {
        console.log(e.target.value);
        i18n.changeLanguage(e.target.value);
        setState({ ...state, [e.target.name]: e.target.value });
      } else {
        setState({ ...state, [e.target.name]: e.target.value });
      }
    }
  }
  function handleSubmit(e) {
    e.preventDefault();
    let token = user.user.user.access;
    setState({ ...state, token: token });
    console.log(state.spotimage, "TOKENSSSSS=========spotimage==");
    dispatch(ProfileSuccess(state));
  }
  function handleCancel() {
    setState({ previewVisible: false });
  }
  function logoImageChange({ fileList }) {
    console.log(fileList, "originFileObj");
    if (!fileList.length == 0) {
      console.log("KER");
      let resizedimage = resizeImageFn(fileList[0]["originFileObj"]);
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, fileList, Image: fileList[0]["originFileObj"] });
        // setState({ ...state, fileList, Image: result });
      });
    } else {
      setState({ ...state, fileList: [], Image: "" });
    }
  }
  function getValue(address, latLng) {
    setState({ ...state, location: address, lng: latLng.lng, lat: latLng.lat });
    console.log(state, "JASMAL.............state");
  }
  const styles = {
    left_logo: {
      width: "70px",
    },
    wrapper: {
      width: "95%",
      margin: "0 auto",
      paddingTop: "10px",
    },
  };
  console.log(state, "KAYARYYYYYYYYYYYYY");
  const { previewVisible, previewImage, fileList, previewTitle } = state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>{t("Upload")}</div>
    </div>
  );
  console.log(state, "aaaaaa");

  const [value, setValue] = React.useState(1);

  function multySwich(e) {
    console.log(e, "multySwich");
    setState({ ...state, multylanguage: e });
  }
  function onChange(e) {
    console.log("radio checked", e.target.value);
    let defaultlanguage = e.target.value;
    console.log(defaultlanguage);
    dispatch(switchLanguage(state));
  }
  function onFocus(event) {
    if (event.target.autocomplete) {
      event.target.autocomplete = "whatever";
    }
  }
  return (
    <div className="">
      <div
        style={styles.wrapper}
        className="d-flex justify-content-between align-items-center header-container"
      >
        <div style={styles.left_logo}>
          <img src={logo} alt="Logo" width="100%" />
        </div>
        <div className="create-log-out text-right log-out">
          <LogoutOutlined key="0" onClick={() => dispatch(logout())} />
        </div>
      </div>

      <div className="profile-card">
        <div>
          <form onSubmit={handleSubmit} onChange={handleChange}>
            {/* <div className="top-logo">
            <img src={logo} alt="Logo" width="100%" />
          </div> */}
            <h3>{t("profile")}</h3>
            <div className="topper-continer">
              <div className="form-group">
                <p style={{ textAlign: "center" }} className="m-0">
                  {t("logo")}
                </p>
                <Upload
                  action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  listType="picture-card"
                  fileList={fileList}
                  onChange={logoImageChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewVisible}
                  title={previewTitle}
                  footer={null}
                  onCancel={handleCancel}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>
              <div
                style={{ fontWeight: "bold" }}
                className="cover-image form-group"
              >
                <label>{t("coverimage")}</label>
                <input name="spotimage" type="file"></input>
              </div>
            </div>
            <div className="d-flex justify-content-between">
              <div className="form-group d-flex flex-column font-weight-bold">
                <label>{t("defaultlang")}</label>
                <Radio.Group
                  value={state.defaultlanguage}
                  name="defaultlanguage"
                  onClick={onChange}
                >
                  <Radio style={{ color: "#fff" }} value={"en"}>
                    EN
                  </Radio>
                  <Radio style={{ color: "#fff" }} value={"de"}>
                    AR
                  </Radio>
                </Radio.Group>
              </div>
              <div className="form-group d-flex flex-column font-weight-bold">
                <label>{t("multyang")}</label>
                <div>
                  <Switch
                    onChange={multySwich}
                    name="multylang"
                    checkedChildren="YES"
                    unCheckedChildren="NO"
                    // value={state.multylanguage}
                    checked={state.multylanguage}
                  />
                </div>
              </div>
            </div>
            {state.multylanguage == false ? (
              <div className="d-flex justify-content-between">
                {state.defaultlanguage == "en" ? (
                  <div style={{ width: "100%" }}>
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      label={t("companyname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      name="name"
                      // {state.name =="zxczxc"?value=state.name:null}
                      value={state.name}
                      rules={[
                        {
                          required: true,
                          message: "Company Name required",
                        },
                      ]}
                    />
                  </div>
                ) : (
                  <div className="" style={{ width: "100%" }}>
                    <TextField
                      InputLabelProps={{ required: false }}
                      required
                      label={t("companyname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      name="a_name"
                      value={state.a_name}
                      rules={[
                        {
                          required: true,
                          message: "Arabic Name required",
                        },
                      ]}
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="d-flex justify-content-between">
                <div style={{ width: "100%" }}>
                  <TextField
                    InputLabelProps={{ required: false }}
                    required
                    label={t("companyname")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    name="name"
                    // {state.name =="zxczxc"?value=state.name:null}
                    value={state.name}
                    rules={[
                      {
                        required: true,
                        message: "Company Name required",
                      },
                    ]}
                  />
                </div>
                <div className="ml-2" style={{ width: "100%" }}>
                  <TextField
                    InputLabelProps={{ required: false }}
                    required
                    label={t("arabicname")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    name="a_name"
                    value={state.a_name}
                    rules={[
                      {
                        required: true,
                        message: "Arabic Name required",
                      },
                    ]}
                  />
                </div>
              </div>
            )}
            <div className="d-flex justify-content-between">
              <div style={{ width: "100%" }} className="">
                <TextField
                  InputLabelProps={{ required: false }}
                  required
                  label={t("phone")}
                  id="outlined-margin-dense"
                  margin="dense"
                  variant="outlined"
                  name="phone"
                  onChange={handleChange}
                />
              </div>
              <div className="mt-2 ml-2" style={{ width: "100%" }}>
                <Autocomplete
                  id="combo-box-demo"
                  size="small"
                  onChange={(event, value) =>
                    countryChange(event, value, "country")
                  }
                  options={state.cuntry_datas}
                  getOptionLabel={(option) => option.name}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Country"
                      variant="outlined"
                      autoComplete="off"
                      onFocus={onFocus}
                    />
                  )}
                />
              </div>
            </div>
            {state.multylanguage == false ? (
              <div className="d-flex justify-content-between">
                {state.defaultlanguage == "en" ? (
                  <div className="" style={{ width: "100%" }}>
                    <TextField
                      InputLabelProps={{ required: false }}
                      required
                      label={t("address")}
                      id="outlined-margin-dense"
                      multiline
                      rows={4}
                      margin="dense"
                      variant="outlined"
                      value={state.address}
                      name="address"
                    />
                  </div>
                ) : (
                  <div style={{ width: "100%" }} className="">
                    <TextField
                      InputLabelProps={{ required: false }}
                      required
                      label={t("arabicaddress")}
                      id="outlined-margin-dense"
                      multiline
                      rows={4}
                      margin="dense"
                      variant="outlined"
                      name="a_address"
                      value={state.a_address}
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="d-flex justify-content-between">
                <div style={{ width: "100%" }}>
                  <TextField
                    InputLabelProps={{ required: false }}
                    required
                    label={t("address")}
                    id="outlined-margin-dense"
                    multiline
                    rows={4}
                    margin="dense"
                    variant="outlined"
                    value={state.address}
                    name="address"
                  />
                </div>
                <div style={{ width: "100%" }} className="ml-2">
                  <TextField
                    InputLabelProps={{ required: false }}
                    required
                    label={t("arabicaddress")}
                    id="outlined-margin-dense"
                    multiline
                    rows={4}
                    margin="dense"
                    variant="outlined"
                    name="a_address"
                    value={state.a_address}
                  />
                </div>
              </div>
            )}
            <LocationSearchInput
              initialvalue={state.location}
              getvalue={getValue}
            />
            <Button
              className="login-button btn btn-block"
              variant="primary"
              type="submit"
              htmlType="submit"
            >
              {t("save")}
            </Button>
            {/* <p className="forgot-password text-right">
            Forgot <a href="#">password?</a>
          </p> */}
          </form>
        </div>
      </div>
    </div>
  );
}

export default CreateProfile;
