import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useParams,
} from "react-router-dom";
import swal from "sweetalert";
import {
  EditFilled,
  DeleteFilled,
  PlusCircleOutlined,
  LogoutOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import store from "../redux/store";
import * as base from "../settings";
import { Breadcrumb, Table, Space, Upload, Modal, Button } from "antd";
import "../App.css";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TextField from "@material-ui/core/TextField";
import { Row, Col } from "react-bootstrap";
import { useTranslation } from "react-i18next";

const Compress = require("compress.js");
const compress = new Compress();

const EditCategory = (props) => {
  const { id } = useParams();

  const [state, setState] = useState({
    is_create: false,
    is_edit: false,
    collapsed: false,
    is_product_edit: false,
    deleted_products: [],
    modal2Visible: false,
    visible: false,
    loading: false,
    previewVisible: false,
    previewImage: "",
    previewTitle: "",
    fileList: [],
    fileList1: [],
    cat_name: "",
    cat_arabicname: "",
    Image: "",
    singledata: {
      id: "",
      name: "",
      arabicname: "",
      price: "",
      image: "",
      img: "",
      index: "",
    },
    data: [
      // {
      //   id: "",
      //   name: "uvais",
      //   arabicname: "AR_uvais",
      //   price: "100",
      //   image: "",
      // },
    ],
  });
  const [t, i18n] = useTranslation("common");

  let user = store.getState();
  let multylanguage = "";
  let defaultlanguage = "";
  if (user.user.user) {
    multylanguage = user.user.language.multylanguage;
    defaultlanguage = user.user.language.defaultlanguage;
    console.log(
      multylanguage,
      "multylanguage!!!!!!!!!!!!!!!!",
      defaultlanguage
    );
  }
  useEffect(async () => {
    let token = user.user.user.access;
    let data = state.data;
    console.log("!!!!!!!!!!!!!!!!@@@@@@@@@@@@@@");
    let handle = id;
    await fetch(base.BASE_URL + `products/sigle-category/${handle}/`, {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      // body: JSON.stringify({
      //   CompanyID: CompanyID,
      // }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          let image = response.data.image;
          let url = base.MEDIA_URL + image + "/";
          let file = [
            {
              uid: "1",
              url: url,
            },
          ];
          setState({
            ...state,
            cat_name: response.data.name,
            cat_arabicname: response.data.arabicname,
            fileList: file,
            data: response.pro_data,
          });
        } else {
          console.log("ERROR");
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }, []);
  const columns = [
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      render: (text, record) => (
        <div className="img-container">
          <img src={base.MEDIA_URL + text + "/"} width="50px" height="50px" />
        </div>
      ),
    },
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      render: (text, record) => <a>{text}</a>,
    },
    {
      title: "Arabic Name",
      dataIndex: "arabicname",
      key: "arabicname",
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => (
        <Space size="middle">
          {/* <Link to={`/dashboard/edit-brand/${item.id}/`}>
          <EditFilled />
        </Link> */}
          <a>
            {/* <EditFilled /> */}
            <img src={EditBtn} width="30px" />
          </a>

          <a>
            {/* <DeleteFilled /> */}
            <img src={DeleteBtn} width="30px" />
          </a>
        </Space>
      ),
    },
  ];

  function handleCancel() {
    console.log("AAAAAAAAAAAAAAAAAAAAAADAAAAAA");
    setState({ ...state, previewVisible: false });
  }
  function handleChange(e) {
    if (e.target.name == "name") {
      setState({
        ...state,
        cat_name: e.target.value,
      });
    } else if (e.target.name == "arabicname") {
      setState({
        ...state,
        cat_arabicname: e.target.value,
      });
    }
  }
  function change(e) {}
  function ProducthandleChange(e) {
    let product_data1 = state.data;
    let product_data = state.singledata;

    if (e.target.name == "product_name") {
      product_data["name"] = e.target.value;
      setState({
        ...state,
        singledata: product_data,
        error_message: "",
      });
    } else if (e.target.name == "product_arabicname") {
      console.log(state, "ArabicNAme", e.target.value);
      // product_data[index]["arabicname"] = e.target.value;
      product_data["arabicname"] = e.target.value;
      setState({
        ...state,
        error_message: "",
        singledata: product_data,
      });
    } else if (e.target.name == "product_price") {
      product_data["price"] = e.target.value;
      setState({
        ...state,
        singledata: product_data,
      });
    }
  }
  function CathandleImageChange({ fileList }) {
    console.log(fileList, "cat");
    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      console.log(resizedimage, "resizedimage");
      resizedimage.then(function (result) {
        console.log(result); // "Some User token"
        setState({ ...state, fileList, Image: result });
      });
      console.log("KER");
      // setState({ ...state, fileList, Image: fileList[0]["originFileObj"] });
    } else {
      setState({ ...state, fileList: [], Image: "" });
    }
  }
  function ProhandleImageChange({ fileList }) {
    console.log(fileList, "pro");
    let product_data = state.singledata;

    if (!fileList.length == 0) {
      let file = fileList[0]["originFileObj"];
      let resizedimage = resizeImageFn(file);
      resizedimage.then(function (result) {
        let url = URL.createObjectURL(result);
        let file1 = [
          {
            uid: "1",
            url: url,
          },
        ];
        product_data["image"] = result;
        product_data["img"] = fileList;
        console.log(file1, "file1");
        setState({
          ...state,
          fileList1: fileList,
          singledata: product_data,
        });
      });
    } else {
      setState({ ...state, fileList1: [], ProImage: "" });
    }
  }
  async function resizeImageFn(file) {
    const compress = new Compress();
    const resizedImage = await compress.compress([file], {
      size: 4, // the max size in MB, defaults to 2MB
      quality: 0.75, // the quality of the image, max is 1,
      maxWidth: 1920, // the max width of the output image, defaults to 1920px
      maxHeight: 1920, // the max height of the output image, defaults to 1920px
      resize: true, // defaults to true, set false if you do not want to resize the image width and height
    });

    const img = resizedImage[0];
    const base64str = img.data;
    const imgExt = img.ext;
    const resizedFiile = await Compress.convertBase64ToFile(base64str, imgExt);
    setState({ ...state, img: URL.createObjectURL(resizedFiile) });
    let file1 = [
      {
        uid: "1",
        url: URL.createObjectURL(resizedFiile),
      },
    ];
    // let s = new File([resizedImage], file.name);
    var s = new File([resizedFiile], file.name, {
      type: file.type,
      lastModified: new Date().getTime(),
    });

    return s;
  }

  const showModal = () => {
    setState({
      ...state,
      modal2Visible: true,
    });
  };
  document.getElementById("root").style.marginTop = "60px";
  const { previewVisible, previewImage, fileList, fileList1, previewTitle } =
    state;
  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );
  function onProductSubmit(e) {
    e.preventDefault();
    let data = state.data;
    let product_detail = state.singledata;
    console.log(
      product_detail.name,
      "111111111111111111111111111111.............."
    );
    if (multylanguage == false && defaultlanguage == "de") {
      if (data.some((e) => e.arabicname == product_detail.arabicname)) {
        setState({
          ...state,
          error_message: "Product arabicname is Exists",
        });
        console.log(
          product_detail.name,
          "SAME NAME EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          image: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
      }
    } else if (multylanguage == false && defaultlanguage == "en") {
      if (data.some((e) => e.name == product_detail.name)) {
        setState({
          ...state,
          error_message: "Product name is Exists",
        });
        console.log(
          product_detail.name,
          "SAME NAME EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          image: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
      }
    } else {
      if (data.some((e) => e.name == product_detail.name)) {
        setState({
          ...state,
          error_message: "Product name is Exists",
        });
        console.log(
          product_detail.name,
          "SAME NAME EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else if (data.some((e) => e.arabicname == product_detail.arabicname)) {
        setState({
          ...state,
          error_message: "Product arabicname is Exists",
        });
        console.log(
          product_detail.arabicname,
          "SAME arabicname EXISTSsssssssssssssssssssssssssssssss.............."
        );
      } else {
        data.push(product_detail);
        console.log(product_detail);
        let singledata = {
          id: "",
          name: "",
          arabicname: "",
          price: "",
          image: "",
        };
        setState({
          ...state,
          data,
          singledata,
          modal2Visible: false,
          fileList1: [],
        });
      }
    }
  }
  function onProductEditSubmit(e) {
    e.preventDefault();
    let data = state.data;
    let product_detail = state.singledata;
    console.log(product_detail, "LOOOOOOP");
    let index = product_detail.index;
    let name = product_detail.name;
    let price = product_detail.price;
    let productimage = product_detail.productimage;
    let image = product_detail.image;
    let img = product_detail.img;
    let arabicname = product_detail.arabicname;
    console.log(productimage, "=====================", data);
    if (product_detail.productimage == "") {
      console.log("ERROR");
      swal({
        title: "failed",
        text: "image is required",
        icon: "warning",
        button: false,
        timer: 2000,
      });
    } else {
      // data.push(product_detail);
      data[index]["name"] = name;
      data[index]["price"] = price;
      data[index]["productimage"] = productimage;
      data[index]["arabicname"] = arabicname;
      data[index]["image"] = image;
      data[index]["img"] = img;

      console.log(product_detail);
      let singledata = {
        id: "",
        name: "",
        arabicname: "",
        price: "",
        productimage: "",
        img: [],
      };
      setState({
        ...state,
        data,
        singledata,
        modal2Visible: false,
        is_product_edit: false,
        fileList1: [],
      });
    }
  }
  console.log(state, "DERRRRRRRRRRR");
  // ======
  function setModal2Visible(modal2Visible) {
    setState({ ...state, modal2Visible });
  }
  function productDelete(index, id) {
    let data = state.data;
    let deleted_products = state.deleted_products;
    deleted_products.push(id);
    delete data[index];
    setState({ ...state, data, deleted_products });
    console.log(deleted_products, state);
  }
  function handleSubmit(e) {
    e.preventDefault();
    swal({
      title: "Please wait ",
      text: "The Category is Updating..",
      icon: "warning",
      button: false,
    });
    console.log("Submit");
    const formData = new FormData();
    formData.append("multylanguage", multylanguage);
    formData.append("defaultlanguage", defaultlanguage);
    formData.append("name", state.cat_name);
    formData.append("arabicname", state.cat_arabicname);
    console.log(state.Image, "image1111111111111111");
    formData.append("image", state.Image);
    for (let index = 0; index < state.data.length; index++) {
      const element = state.data[index];
      if (element) {
        console.log(
          element.name,
          "elem ENGLISH ent",
          element.arabicname,
          "ARABIC"
        );
        if (multylanguage == false && defaultlanguage == "de") {
          formData.append(element.arabicname, element.image);
        } else {
          formData.append(element.name, element.image);
        }
      }
    }
    // formData.append("data", state.data);
    formData.append("data", JSON.stringify(state.data));
    formData.append("deleted_products", JSON.stringify(state.deleted_products));
    let token = user.user.user.access;
    let handle = id;
    fetch(base.BASE_URL + `products/edit-category/${handle}/`, {
      method: "POST",
      body: formData,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode === 6000) {
          swal({
            title: "success",
            text: "Category Created SuccessFully",
            icon: "success",
            button: false,
            timer: 2000,
          });
          props.history.push("/");
        } else {
          swal({
            title: "faild",
            text: response.message,
            icon: "warning",
            button: false,
            timer: 1000,
          });
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  function productCreate() {
    let singledata = {
      id: "",
      name: "",
      arabicname: "",
      price: "",
      productimage: "",
      img: [],
    };
    setState({
      ...state,
      singledata,
      is_product_edit: false,
      modal2Visible: true,
      fileList1: [],
    });
  }
  function productEdit(index) {
    let data = state.data;
    let indexID = index;

    let id = data[indexID]["id"];
    let name = data[indexID]["name"];
    let arabicname = data[indexID]["arabicname"];
    let price = data[indexID]["price"];
    let image = data[indexID]["image"];
    let img = data[indexID]["img"];

    console.log(id, "@#@#@#", indexID, "####", img);
    let url = base.MEDIA_URL + image + "/";
    let file = [];
    if (id != "") {
      console.log("########");
      file = [
        {
          uid: "1",
          url: url,
        },
      ];
    } else {
      console.log("!!!!!!!!!!");
      file = img;
    }
    let product_data = state.singledata;
    product_data["productimage"] = file;
    product_data["name"] = name;
    product_data["arabicname"] = arabicname;
    product_data["price"] = price;
    product_data["index"] = indexID;
    setState({
      ...state,
      singledata: product_data,
      modal2Visible: true,
      fileList1: file,
      is_product_edit: true,
    });
  }
  // ====
  return (
    <div
      className="list-page-style content site-card-border-less-wrapper"
      style={{ marginTop: 20 }}
    >
      <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
        <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
          {t("Edit Category")}
        </Breadcrumb.Item>
      </Breadcrumb>
      <form onSubmit={handleSubmit}>
        <Row
          className="category-container"
          style={{
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Row
            className="category-inner-container"
            style={{
              alignItems: "center",
              justifyContent: "space-between",
              width: 600,
            }}
          >
            <Col>
              <div className="form-group">
                {/* <label>Image</label> */}
                <Upload
                  action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                  listType="picture-card"
                  fileList={fileList}
                  onChange={CathandleImageChange}
                >
                  {fileList.length >= 1 ? null : uploadButton}
                </Upload>
                <Modal
                  visible={previewVisible}
                  title={previewTitle}
                  footer={null}
                >
                  <img
                    alt="example"
                    style={{ width: "100%" }}
                    src={previewImage}
                  />
                </Modal>
              </div>
            </Col>
            {multylanguage == true ? (
              <Col>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    label="Name"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.cat_name}
                    onChange={handleChange}
                    name="name"
                  />
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    label="Arabic Name"
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.cat_arabicname}
                    onChange={handleChange}
                    name="arabicname"
                  />
                </div>
              </Col>
            ) : (
              [
                defaultlanguage == "en" ? (
                  <Col>
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("name")}
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.cat_name}
                        onChange={handleChange}
                        name="name"
                      />
                    </div>
                  </Col>
                ) : (
                  <Col>
                    <div className="form-group ">
                      <TextField
                        required
                        InputLabelProps={{ required: false }}
                        label={t("arabicname")}
                        id="outlined-margin-dense"
                        margin="dense"
                        variant="outlined"
                        value={state.cat_arabicname}
                        onChange={handleChange}
                        name="arabicname"
                      />
                    </div>
                  </Col>
                ),
              ]
            )}
          </Row>
          <Row className="category-bottom-container">
            <Col className="category-col">
              <div className="form-group ">
                <button
                  style={{ background: "#1eaa97", color: "#fff" }}
                  type="submit"
                  className="btn text-center mr-3"
                >
                  {t("save")}
                </button>
              </div>
              <div
                onClick={() => productCreate()}
                className="create-plus form-group "
              >
                <Link
                  to=""
                  style={{ fontSize: 30, color: "#fff" }}
                  className=""
                >
                  <PlusCircleOutlined />
                </Link>
                {/* <p className="m-0">Add Products</p> */}
              </div>
            </Col>
          </Row>
        </Row>
      </form>
      <div>
        <table className="product-table table table-dark">
          <thead>
            <tr>
              {multylanguage == true
                ? [
                    <th scope="col">{t("name")}</th>,
                    <th scope="col">{t("arabicname")}</th>,
                  ]
                : [
                    defaultlanguage == "en" ? (
                      <th scope="col">{t("name")}</th>
                    ) : (
                      <th scope="col">{t("arabicname")}</th>
                    ),
                  ]}

              <th scope="col">{t("Price")}</th>
              <th scope="col">{t("action")}</th>
            </tr>
          </thead>
          <tbody>
            {state.data.map((i, index) => (
              <tr>
                {multylanguage == true
                  ? [<td>{i.name}</td>, <td>{i.arabicname}</td>]
                  : [
                      defaultlanguage == "en" ? (
                        <td>{i.name}</td>
                      ) : (
                        <td>{i.arabicname}</td>
                      ),
                    ]}

                <td>{i.price}</td>
                <td>
                  <a className="mr-2">
                    <img
                      onClick={() => productEdit(index, i.id)}
                      src={EditBtn}
                      width="30px"
                    />
                  </a>
                  <a>
                    <img
                      onClick={() => productDelete(index, i.id)}
                      src={DeleteBtn}
                      width="30px"
                    />
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* =====Product Modal Start Heare ======= */}
      <Modal
        className="product-modal"
        title={t("Add Product")}
        centered
        visible={state.modal2Visible}
        onOk={() => setModal2Visible(false)}
        onCancel={() => setModal2Visible(false)}
        footer={null}
        cancelButtonProps={{ style: { display: "none" } }}
      >
        <form
          onSubmit={
            state.is_create
              ? onProductSubmit
              : state.is_edit
              ? onProductEditSubmit
              : null
          }
        >
          <Col md={8} style={{ margin: "0 auto" }}>
            <div className="form-group">
              {/* <label>Image</label> */}
              <Upload
                action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                listType="picture-card"
                fileList={fileList1}
                onChange={ProhandleImageChange}
              >
                {fileList1.length >= 1 ? null : uploadButton}
              </Upload>
              <Modal
                visible={previewVisible}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
              >
                <img
                  alt="example"
                  style={{ width: "100%" }}
                  src={previewImage}
                />
              </Modal>
            </div>
            {multylanguage ? (
              <div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    onChange={ProducthandleChange}
                    label={t("Product Name")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.singledata.name}
                    name="product_name"
                  />
                  <p style={{ color: "red", textAlign: "center" }}>
                    {state.error_message == "Product name is Exists"
                      ? state.error_message
                      : null}{" "}
                  </p>
                </div>
                <div className="form-group ">
                  <TextField
                    required
                    InputLabelProps={{ required: false }}
                    onChange={ProducthandleChange}
                    label={t("arabicname")}
                    id="outlined-margin-dense"
                    margin="dense"
                    variant="outlined"
                    value={state.singledata.arabicname}
                    name="product_arabicname"
                  />
                  <p style={{ color: "red", textAlign: "center" }}>
                    {state.error_message == "Product arabicname is Exists"
                      ? state.error_message
                      : null}{" "}
                  </p>
                </div>
              </div>
            ) : (
              [
                defaultlanguage == "en" ? (
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      onChange={ProducthandleChange}
                      label={t("Product Name")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.name}
                      name="product_name"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product name is Exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                ) : (
                  <div className="form-group ">
                    <TextField
                      required
                      InputLabelProps={{ required: false }}
                      onChange={ProducthandleChange}
                      label={t("arabicname")}
                      id="outlined-margin-dense"
                      margin="dense"
                      variant="outlined"
                      value={state.singledata.arabicname}
                      name="product_arabicname"
                    />
                    <p style={{ color: "red", textAlign: "center" }}>
                      {state.error_message == "Product arabicname is Exists"
                        ? state.error_message
                        : null}{" "}
                    </p>
                  </div>
                ),
                // <div key="1">body</div>,
              ]
            )}
            <div className="form-group ">
              <TextField
                required
                InputLabelProps={{ required: false }}
                onChange={ProducthandleChange}
                label={t("Price")}
                id="outlined-margin-dense"
                margin="dense"
                type="number"
                variant="outlined"
                value={state.singledata.price}
                name="product_price"
              />
            </div>
            <div style={{ textAlign: "center" }} className="form-group">
              {state.is_product_edit ? (
                <Button
                  onClick={() =>
                    setState({
                      ...state,
                      is_create: false,
                      is_edit: true,
                    })
                  }
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  {t("Update")}
                </Button>
              ) : (
                <Button
                  onClick={() =>
                    setState({
                      ...state,
                      is_create: true,
                      is_edit: false,
                    })
                  }
                  type="submit"
                  htmlType="submit"
                  className="product-modal-button"
                >
                  {t("save")}
                </Button>
              )}
            </div>
          </Col>
        </form>
      </Modal>
    </div>
  );
};
export default EditCategory;
