import React, { useState, useEffect } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

function Login() {
  const [state, setState] = useState({
    username: "",
    password: "",
  });
  const dispatch = useDispatch();

  const styles = {
    card: {
      padding: "25px",
      borderRadius: "10px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      position: "relative",
      background: "#fff",
      border: ".5px solid rgba(0,0,0,.1)",
    },
    auth_bg: {
      //   backgroundImage: `url(${bg_auth})`,
      backgroundSize: "cover",
      boxSizing: "border-box",
    },
    text_position: {
      position: "absolute",
      bottom: 0,
    },
    container_height: {
      height: "100vh",
    },
  };

  const validateMessages = {
    required: "${label} is required!",
    types: {
      email: "${label} is not valid email!",
      username: "${label} is not a valid username!",
      password: "${label} is not a valid password!",
    },
    number: {
      range: "${label} must be between ${min} and ${max}",
    },
  };

  function handleChange(e) {
    console.log("AAAAAAAAAAAAAS");
    setState((prevState) => {
      return { ...prevState, [e.target.name]: e.target.value };
    });
  }
  function handleSubmit(e) {
    e.preventDefault();
    dispatch(login(state));
  }
  return (
    <React.Fragment>
      <Row style={styles.container_height}>
        <Col style={styles.auth_bg}>
          <div className="text-center p-5" style={styles.text_position}>
            <h1 className="text-light">I love the color!</h1>
            <p className="text-light">
              {" "}
              I've been using your theme from the previous developer for our web
              app, once I knew new version is out, I immediately bought with no
              hesitation. Great themes, good documentation with lots of
              customization available and sample app that really fit our need.{" "}
            </p>
          </div>
        </Col>
        <Col xs lg="4" style={{ background: "#fff" }}>
          <Card className="p-5 border-0">
            <form onSubmit={handleSubmit} onChange={handleChange}>
              <Form.Group role="form" controlId="formBasicEmail">
                <Form.Label>Username</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter username"
                  name={["username"]}
                  label="username"
                  rules={[
                    {
                      required: true,
                      message: "Username Name required",
                    },
                  ]}
                />
                <Form.Text className="text-muted">
                  We'll never share your email with anyone else.
                </Form.Text>
              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control
                  type="password"
                  placeholder="Password"
                  name={["password"]}
                  label="password"
                  rules={[
                    {
                      required: true,
                      message: "password required",
                    },
                  ]}
                />
              </Form.Group>
              <Button
                className="rounded-0 px-5 mb-5"
                variant="primary"
                type="submit"
                htmlType="submit"
              >
                Login
              </Button>
            </form>
            <div className="text-center">
              <Link to="/Signup">Signup</Link>
            </div>
          </Card>
        </Col>
      </Row>
    </React.Fragment>
  );
}

export default Login;
