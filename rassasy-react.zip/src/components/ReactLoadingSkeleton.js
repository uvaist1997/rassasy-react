import React from "react";
import Skeleton, { SkeletonTheme } from "react-loading-skeleton";

const ReactLoadingSkeleton = () => (
  <SkeletonTheme color="#0e0e0e">
    <section
      style={{ background: "#272727", padding: "5px", borderRadius: "10px" }}
      className="placeholder-container"
    >
      <div className="p-2">
        <Skeleton reactangle={true} height={100} style={{ width: "100%" }} />
      </div>
      <div className="pl-2 pb-1">
        <Skeleton reactangle={true} height={50} style={{ width: "100%" }} />
      </div>
      <div
        style={{ display: ":flex", alignItems: "center" }}
        className="pl-2 top-list mb-1"
      >
        <Skeleton className="mr-3" reactangle={true} height={80} width={80} />
        <Skeleton reactangle={true} height={80} style={{ width: "85%" }} />
      </div>

      <div
        style={{ display: ":flex", alignItems: "center" }}
        className="pl-2 top-list mb-1"
      >
        <Skeleton className="mr-3" reactangle={true} height={80} width={80} />
        <Skeleton reactangle={true} height={80} style={{ width: "85%" }} />
      </div>
      <div
        style={{ display: ":flex", alignItems: "center" }}
        className="pl-2 top-list mb-1"
      >
        <Skeleton className="mr-3" reactangle={true} height={80} width={80} />
        <Skeleton reactangle={true} height={80} style={{ width: "85%" }} />
      </div>
      <div
        style={{ display: ":flex", alignItems: "center" }}
        className="pl-2 top-list mb-1"
      >
        <Skeleton className="mr-3" reactangle={true} height={80} width={80} />
        <Skeleton reactangle={true} height={80} style={{ width: "85%" }} />
      </div>
    </section>
  </SkeletonTheme>
);

export default ReactLoadingSkeleton;
