import { Layout, Menu, Switch } from "antd";
import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Link, useNavigate } from "react-router-dom";
import { LogoutOutlined } from "@ant-design/icons";
import "../App.css";
import store from "../redux/store";
import { useDispatch } from "react-redux";
import { home_page, logout, logout1 } from "../redux/store/user";
import logo from "../assets/images/lg.png"; // wherever is it.
import langicon from "../assets/images/lang.png"; // wherever is it.
import { switchLanguage } from "../../src/redux/store/user";
import { useTranslation } from "react-i18next";

const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;
// function CustomerSideNav() {

export default function CommonHeader() {
  let user = store.getState();
  let role = "";
  let is_profile = "";
  let globlang = "";
  let globmultylang = "";
  let lang = "";
  if (user.user.is_Auth) {
    role = user.user.user.role;
    is_profile = user.user.user.is_profile;
    if (user.user.language) {
      globlang = user.user.language.defaultlanguage;
      console.log(globlang, "globlang");
      if (globlang == "de") {
        lang = true;
      } else if (globlang == "en") {
        lang = false;
      }
    }
    if (user.user.language) {
      globmultylang = user.user.language.multylanguage;
      console.log(globmultylang, "globmultylang");
    }
  }
  const [state, setState] = useState({
    collapsed: false,
    defaultlanguage: "",
    multylanguage: "",
    Is_home: true,
  });
  const [t, i18n] = useTranslation("common");
  const history = useNavigate();
  const dispatch = useDispatch();
  const styles = {
    left_logo: {
      width: "70px",
    },
  };
  function globalSwich(e) {
    console.log(e, "EEEEEEEEEEEEEEEEENNNGLISH");
    if (e == true) {
      console.log(e, "ARABIC");
      setState({
        ...state,
        defaultlanguage: "de",
        multylanguage: globmultylang,
      });
    } else {
      console.log(e, "ENGLISH");
      setState({
        ...state,
        defaultlanguage: "en",
        multylanguage: globmultylang,
      });
    }
  }
  useEffect(async () => {
    console.log(state);
    i18n.changeLanguage(state.defaultlanguage);
    // dispatch(switchLanguage(state));
  }, [state]);
  function toggle() {
    setState((prevState) => {
      return { collapsed: !state.collapsed };
    });
  }

  return (
    <Header className="top-fixed-head header">
      {/* <a onClick={() => dispatch(home_page())} rel="noreferrer" href="/"> */}
      <img
        style={{ cursor: "pointer" }}
        onClick={() => dispatch(home_page(state))}
        className="logo"
        src={logo}
        alt="Logo"
        width="100%"
      />
      {/* </a> */}
      {globmultylang == true ? (
        <Switch
          className="ml-3"
          checkedChildren="AR"
          unCheckedChildren="EN"
          onChange={globalSwich}
          // checked={lang}
        />
      ) : null}

      <div className="text-right float-right log-out">
        <LogoutOutlined key="0" onClick={() => dispatch(logout1())} />
      </div>
    </Header>
  );
}
