import React, { Component, Fragment } from "react";
import { render } from "react-dom";
import request from "superagent";
import debounce from "lodash.debounce";
import { DatePicker, Table, Breadcrumb, Space, Spin, Modal } from "antd";
import DeleteBtn from "../assets/images/delete.svg";
import EditBtn from "../assets/images/edit.svg";
import TableScrollbar from "react-table-scrollbar";
import $ from "jquery";
import * as base from "../settings";
import Draggable from "react-draggable";
import store from "../redux/store";
import swal from "sweetalert";
import moment from "moment";

let user = store.getState();

class InfiniteUsers extends Component {
  constructor(props) {
    super(props);
    console.log(props.instances);
    // Sets up our initial state
    this.state = {
      error: false,
      exp_date: "2021/08/21",
      hasMore: true,
      isLoading: false,
      users: [],
      page_number: 1,
      count: 0,
      item_per_page: 7,
      visible: false,
      disabled: true,
      active_pk: "",
      bounds: { left: 0, top: 0, bottom: 0, right: 0 },
    };

    window.addEventListener("scroll", function () {
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
        console.log("you're at the bottom of the page");
        // Show loading spinner and make fetch request to api
      }
    });
    window.onscroll = debounce(() => {
      const {
        loadUsers,
        state: { error, isLoading, hasMore },
      } = this;

      // Bails early if:
      // * there's an error
      // * it's already loading
      // * there's nothing left to load
      if (error || isLoading || !hasMore) return;
      let tableid = document.getElementById("table-scroll-top");
      console.log(tableid);
      // Checks that the page has scrolled to the bottom
      console.log(
        window.innerHeight + document.documentElement.scrollTop,
        "!!!!!!!!!!",
        $("#table-scroll-top").height()
      );
      console.log(document.body.offsetHeight, "@@@@@@@@@@@@@222");
      if (
        window.innerHeight + document.documentElement.scrollTop ===
        $(document).height()
      ) {
        let user_length = this.state.users.length;
        let count = this.state.count;
        let balance = 5;
        if (user_length <= count) {
          let balance_count = count - user_length;
          if (balance_count < 5) {
            balance = balance_count;
          }
          loadUsers(balance);
        }
      }
    }, 100);
  }
  onChangeDate = (date, dateString) => {
    console.log(dateString, "222222222222222222");
    this.setState({
      exp_date: dateString,
    });
  };
  componentWillMount() {
    // Loads some users on initial load
    this.loadUsers(5);
  }

  loadUsers = (b) => {
    console.log(b, "BBBBBBBBBBB");
    if (b > 0) {
      console.log(this.state.users.length, this.state.count, "WWWWWWWWWWWWW");
      let page_number = this.state.page_number;

      this.setState({ isLoading: true }, () => {
        request
          .get(
            base.BASE_URL +
              `users/list-users/?results=${15}&&page_number=${page_number}`
          )
          .then((results) => {
            console.log(results.body.data, "DATA00000000000");
            // Creates a massaged array of user data
            const nextUsers = results.body.data.map((user) => ({
              id: user.id,

              is_expired: user.is_expired,

              username: user.arabic_name,
              company_name: user.name,
              exp_date: user.exp_date,
              phone: user.phone,
            }));
            console.log("nextUser", nextUsers);

            // Merges the next users into our existing users
            page_number += 1;
            this.setState({
              // Note: Depending on the API you're using, this value may
              // be returned as part of the payload to indicate that there
              // is no additional data to be loaded
              page_number,
              hasMore: this.state.users.length < 100,
              isLoading: false,
              users: [...this.state.users, ...nextUsers],
              count: results.body.count,
            });
          })
          .catch((err) => {
            this.setState({
              error: err.message,
              isLoading: false,
            });
          });
      });
    }
  };
  showModal = () => {
    this.setState({
      visible: true,
    });
  };
  onClickEdit = (pk) => {
    this.showModal();
    this.setState({
      active_pk: pk,
    });
    let token = user.user.user.access;
    console.log(token, "AAAAAAAAAAAAAAAAAAAAAAA");
    fetch(base.BASE_URL + "users/user-expiry-date", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        pk,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success === 6000) {
          let exp_date = response.data.exp_date;
          console.log(exp_date, "%%%%%%%%%%%%%%%%%%%%%%");
          this.setState({
            modal2Visible: true,
            exp_date: exp_date,
          });
          console.log(response.data[0].name, "SUCCESSS");
        } else {
          console.log("6001");
        }
      })
      .catch((err) => {
        console.log("err");
      });
    // setState({ ...state, modal2Visible });
  };

  handleOk = (e) => {
    console.log(e, "ahndleok");
    let token = user.user.user.access;
    console.log(token);
    fetch(base.BASE_URL + "users/edit-expiry-date", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        pk: this.state.active_pk,
        date: this.state.exp_date,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        console.log(response.success, "exp_date", "++++++++++++++++++");
        if (response.success === 6000) {
          this.setState({
            active_pk: "",
            exp_date: "",
            visible: false,
          });
          swal({
            title: "success",
            text: "Edited SuccessFully",
            icon: "success",
            button: false,
            timer: 1000,
          });

          window.location.reload();
          console.log("SUC######################CESSS");
        } else {
          console.log("6001");
        }
      });
    // .catch((err) => {
    //   console.log("err");
    // });
    // setState({ ...state, modal2Visible });
  };

  handleCancel = (e) => {
    console.log(e);
    this.setState({
      visible: false,
    });
  };

  handleRemove = (id) => {
    console.log(id);
    //  e.preventDefault();
    let token = user.user.user.access;
    swal({
      title: "Are you sure?",
      text: "Once deleted, you will not be able to recover this  data",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    }).then((willDelete) => {
      if (willDelete) {
        fetch(base.BASE_URL + `users/delete-hotel-user/${id}/`, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${token}`,
            // "accept": "application/json"
          },
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.StatusCode === 6000) {
              var icon = "success";
            } else {
              icon = "warning";
            }
            swal({
              title: response.title,
              text: response.message,
              icon: icon,
              button: false,
              timer: 1500,
            });
            window.location.reload();
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        // swal("User is not deleted");
      }
    });
  };

  onStart = (event, uiData) => {
    const { clientWidth, clientHeight } = window?.document?.documentElement;
    const targetRect = this.draggleRef?.current?.getBoundingClientRect();
    this.setState({
      bounds: {
        left: -targetRect?.left + uiData?.x,
        right: clientWidth - (targetRect?.right - uiData?.x),
        top: -targetRect?.top + uiData?.y,
        bottom: clientHeight - (targetRect?.bottom - uiData?.y),
      },
    });
  };

  render() {
    const { error, hasMore, isLoading, users, exp_date } = this.state;
    console.log(users, "USETRS");
    const columns = [
      {
        title: "id",
        dataIndex: "id",
        key: "id",
        render: (text, record) => <a>{text}</a>,
      },
      {
        title: "Expired",
        dataIndex: "is_expired",
        key: "is_expired",
      },
      {
        title: "Name",
        dataIndex: "username",
        key: "username",
        render: (text, record) => <a>{text}</a>,
      },
      // {
      //   title: "Email",
      //   dataIndex: "email",
      //   key: "email",
      // },
      {
        title: "Company Name",
        dataIndex: "company_name",
        key: "company_name",
      },
      {
        title: "Expiry Date",
        dataIndex: "exp_date",
        key: "exp_date",
      },
      {
        title: "Phone Number",
        dataIndex: "phone",
        key: "phone",
      },

      {
        title: "Action",
        key: "action",
        render: (text, record) => (
          <Space size="middle">
            {/* <Link to={`/single-edit-product/${text.id}/`}>
              <img src={EditBtn} width="30px" />
            </Link> */}
            <a onClick={() => this.onClickEdit(text.id)}>
              <img src={EditBtn} width="30px" />
            </a>

            <a onClick={() => this.handleRemove(text.id)}>
              {/* <DeleteFilled /> */}
              <img src={DeleteBtn} width="30px" />
            </a>
          </Space>
        ),
      },
    ];
    // =============
    const { RangePicker } = DatePicker;
    const dateFormat = "YYYY/MM/DD";
    const monthFormat = "YYYY/MM";
    const testDate = "01/01/2015";
    const dateFormatList = ["DD/MM/YYYY", "DD/MM/YY"];

    const customFormat = (value) =>
      `custom format: ${value.format(dateFormat)}`;
    // =================
    return (
      <div>
        <div>
          <div
            className="table-responsive list-page-style content site-card-border-less-wrapper"
            style={{ marginTop: 20 }}
          >
            <Breadcrumb style={{ margin: "16px 0", fontSize: 35 }}>
              <Breadcrumb.Item style={{ color: "#fff", fontWeight: "bold" }}>
                Users
              </Breadcrumb.Item>
            </Breadcrumb>
            <Table pagination={false} columns={columns} dataSource={users} />
          </div>
          <hr />
          {error && <div style={{ color: "#900" }}>{error}</div>}
          {isLoading && (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Spin size="large" />
            </div>
          )}
          {!hasMore && <div>You did it! You reached the end!</div>}
        </div>
        <Modal
          title={
            <div
              style={{
                width: "100%",
                cursor: "move",
              }}
              onMouseOver={() => {
                if (this.state.disabled) {
                  this.setState({
                    disabled: false,
                  });
                }
              }}
              onMouseOut={() => {
                this.setState({
                  disabled: true,
                });
              }}
              // fix eslintjsx-a11y/mouse-events-have-key-events
              // https://github.com/jsx-eslint/eslint-plugin-jsx-a11y/blob/master/docs/rules/mouse-events-have-key-events.md
              onFocus={() => {}}
              onBlur={() => {}}
              // end
            >
              User Expiry Datesss
            </div>
          }
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          modalRender={(modal) => (
            <Draggable
              disabled={this.state.disabled}
              bounds={this.state.bounds}
              onStart={(event, uiData) => this.onStart(event, uiData)}
            >
              <div ref={this.draggleRef}>{modal}</div>
            </Draggable>
          )}
        >
          <label className="mr-3">Expiry Date</label>
          <DatePicker
            value={moment(exp_date, dateFormat)}
            format="YYYY-MM-DD"
            onChange={this.onChangeDate}
          />
          {/* ================== */}
        </Modal>
      </div>
    );
  }
}
export default InfiniteUsers;
