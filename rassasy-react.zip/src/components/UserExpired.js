import React, { useState, useEffect, Component } from "react";
import {
  Container,
  Form,
  Row,
  Col,
  Button,
  Image,
  Card,
} from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import "../assets/css/Login.css";
// import bg_auth from "../../assets/images/bg-auth.jpg";
import { login, logout } from "../redux/store/user";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import expired_lottie from "../assets/lottie/exp.json"; // wherever is it.
import Lottie from "react-lottie";
import CommonHeader from "./CommonHeader";

function UserExpired() {
  const [state, setState] = useState({});
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: expired_lottie,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  return (
    <div className="common-card">
      <CommonHeader />
      <div style={{ background: "#fff" }} className="expired-card user-card">
        <div className="expired-widget d-flex justify-content-center form_container login-form">
          <Lottie
            className="clock-lottie"
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            options={defaultOptions}
            height={200}
            width={200}
          />
        </div>
        <p
          style={{ fontSize: "19px", fontWeight: "bold", color: "#000" }}
          className="lottie-content mt-3"
        >
          Time Flies When You're Having Fun
        </p>
        <p className="lottie-content1 m-0">
          You're 7-Days Free Trail Has Ended
        </p>
        <p className="lottie-content1">Ready To Make It Official?</p>
        <h5
          style={{ fontWeight: "bold", color: "#091440" }}
          className="lottie-content pt-2"
        >
          Contact Us
        </h5>
        <p style={{ color: "#000" }} className="m-0">
          <span style={{ fontWeight: "bold" }}>Email</span> : Info@vikncodes.com
        </p>
        <p style={{ color: "#000" }} className="m-0">
          <span style={{ fontWeight: "bold" }}>Phone</span> : +91 95775 00400
        </p>
      </div>
    </div>
  );
}

export default UserExpired;
