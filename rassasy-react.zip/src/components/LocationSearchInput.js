import React from "react";
import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
} from "react-places-autocomplete";
import TextField from "@material-ui/core/TextField";

class LocationSearchInput extends React.Component {
  constructor(props) {
    super(props);
    this.state = { address: props.initialvalue, location: "" };
  }

  handleChange = (address) => {
    this.setState({ address });
  };
  getValue = (e) => {
    console.log(e, "eeeeYESSSSSSSeeeee");
  };

  handleSelect = (address) => {
    let { getvalue } = this.props;

    console.log(this.state, address);
    geocodeByAddress(address)
      .then((results) => getLatLng(results[0]))
      .then((latLng) => {
        getvalue(address, latLng);
        this.setState({ address });
        // console.log("Success", latLng, address), console.log(latLng);
        // getvalue(address), this.setState({ address });
      })
      .catch((error) => console.error("Error", error));
  };
  render(props) {
    return (
      <PlacesAutocomplete
        value={this.state.address}
        onChange={this.handleChange}
        onSelect={this.handleSelect}
      >
        {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
          <div className="form-group">
            {/* <input
              style={{ color: "#000" }}
              {...getInputProps({
                placeholder: "Search Places ...",
                className: "location-search-input",
              })}
            /> */}
            <TextField
              InputLabelProps={{ required: false }}
              autoComplete="off"
              required
              label="Location"
              id="outlined-margin-dense"
              margin="dense"
              variant="outlined"
              name="location"
              {...getInputProps({
                placeholder: "Search Places ...",
                className: "location-search-input",
              })}
            />

            <div className="autocomplete-dropdown-container">
              {loading && <div>Loading...</div>}
              {suggestions.map((suggestion) => {
                const className = suggestion.active
                  ? "suggestion-item--active"
                  : "suggestion-item";
                // inline style for demonstration purpose
                const style = suggestion.active
                  ? { backgroundColor: "#0a0a0a", cursor: "pointer" }
                  : { backgroundColor: "#0000", cursor: "pointer" };
                return (
                  <div
                    // onClick={(value, e) => this.props.getValue()}
                    // onClick={this.getValue(suggestion)}
                    {...getSuggestionItemProps(suggestion, {
                      className,
                      style,
                    })}
                  >
                    <span>{suggestion.description}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </PlacesAutocomplete>
    );
  }
}

export default LocationSearchInput;
