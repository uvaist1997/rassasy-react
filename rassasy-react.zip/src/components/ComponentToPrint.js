import store from "../redux/store";
import React, { useState, useEffect, Component } from "react";
import * as base from "../settings";
import qrImage from "../assets/images/qr.png";

const user = store.getState();
export class ComponentToPrint extends React.PureComponent {
  state = {
    Image: "",
    logo_url: "",
    name: "",
    language: "",
    arabic_name: "",
  };
  async componentDidMount() {
    let user = store.getState();
    let is_Auth = user.user.is_Auth;
    let language = user.user.language.defaultlanguage;
    let token = user.user.user.access;

    await fetch(base.BASE_URL + "users/qr-code/", {
      method: "GET",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${token}`,
        accept: "application/json",
      },
      //   body: JSON.stringify({
      //     pk: handle,
      //   }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.success == 6000) {
          let image = response.data.qr_code;
          let name = response.data.name;
          let arabic_name = response.data.arabic_name;
          let logo_image = response.data.image;
          let url = base.MEDIA_URL + image + "/";
          let logo_url = base.MEDIA_URL + logo_image + "/";
          console.log(url, "SUCCESS");

          this.setState({
            Image: url,
            logo_url: logo_url,
            name: name,
            arabic_name: arabic_name,
            language: language,
          });
        } else {
          console.log("ERROR");
        }
      })
      .catch((err) => {
        console.log("err");
      });
  }
  render() {
    return (
      // <div
      //   style={{
      //     backgroundImage: `url("${qrImage}")`,
      //     width: "1240px",
      //     height: "1585px",
      //     backgroundSize: "cover",
      //     display: "flex",
      //     alignItems: "center",
      //   }}
      //   className="qr-container"
      // >
      //   <div style={{ position: "relative" }}>
      //     <div
      //       style={{ position: "absolute", width: "50px" }}
      //       className="mt-2 logo-img"
      //     >
      //       <img src={this.state.logo_url} alt="Logo" width="100%" />
      //       <p
      //         style={{
      //           fontWeight: "bold",
      //           color: "#000",
      //           fontSize: "37px",
      //           marginTop: "10px",
      //         }}
      //       >
      //         ViknCodes
      //       </p>
      //     </div>
      //   </div>
      //   <div style={{ width: "500px" }} className="top-logo">
      //     <img src={this.state.Image} alt="Logo" width="100%" />
      //   </div>
      // </div>
      <div
        style={{
          backgroundImage: `url("${qrImage}")`,
          width: "795px",
          height: "1141px",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          display: "flex",
          alignItems: "center",
          flexDirection: "column",
          position: "relative",
          // margin: "0 auto",
        }}
        className="qr-container"
      >
        <div style={{ width: "200px" }} className="mt-4 logo-img">
          <img src={this.state.logo_url} alt="Logo" width="100%" />
        </div>
        <p
          style={{
            fontWeight: "bold",
            color: "#000",
            fontSize: "60px",
            marginTop: "30px",
          }}
        >
          {this.state.language == "de"
            ? this.state.arabic_name
            : this.state.name}
        </p>
        <div
          style={{
            position: "absolute",
            // top: "550px",
            // right: "310px",
            // width: "500px",
            top: "390px",
            right: "210px",
            width: "363px",
          }}
          className="top-logo"
        >
          <img src={this.state.Image} alt="Logo" width="100%" />
        </div>
      </div>
    );
  }
}

export default ComponentToPrint;
