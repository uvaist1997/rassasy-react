import React, { useState, useEffect, Suspense, lazy } from "react";
import {
  BrowserRouter as Router,
  Routes as Switch,
  Route,
  Link,
} from "react-router-dom";
import styled from "styled-components/macro";
import { CircularProgress } from "@mui/material";

import { Layout, Menu } from "antd";
import store from "./redux/store";
import SideNav from "./Route/SideNav";
import "./App.css";
import Login from "./Screens/Login";
// import Login1 from "./Screens/Login1";
import Profile from "./Screens/Profile";
import CreateProfile from "./Screens/CreateProfile";
import CreateCategory from "./Screens/CreateCategory";
import CreateProduct from "./Screens/CreateProduct";
import AdminNav from "./Route/AdminNav";
import ProductMenu from "./Screens/Menu";
// import HotelMenu from "./Screens/HotelMenu";
import { TranslatorProvider, useTranslate } from "react-translate";
import Categories from "./Screens/Categories";
import { useTranslation } from "react-i18next";
// import Registration from "./Screens/Registration";
import Users from "./Screens/Users";
import Starburst from "../src/assets/lottie/loading.json";
import Lottie from "react-lottie";
// import UserExpired from "./components/UserExpired";
// import ForgotPassword from "./Screens/ForgotPassword";
// import PasswordConfirm from "./Screens/PasswordConfirm";
// import Home from "./Screens/Home";

function About() {
  return <h2 style={{ color: "#fff" }}>About</h2>;
}

// function CustomerSideNav() {

const NoMatchPage = () => {
  return <h3 style={{ color: "#fff" }}>404 - Not found</h3>;
};

const Protected = lazy(() => import("./Route/Protected"));
const Home = lazy(() => import("./Screens/Home"));
const PasswordConfirm = lazy(() => import("./Screens/PasswordConfirm"));
const ForgotPassword = lazy(() => import("./Screens/ForgotPassword"));
const Registration = lazy(() => import("./Screens/Registration"));
const HotelMenu = lazy(() => import("./Screens/HotelMenu"));
const Login1 = lazy(() => import("./Screens/Login1"));
const UserExpired = lazy(() => import("./components/UserExpired"));

export default function App() {
  let user = store.getState();

  console.log(user, "HALOOOIU");
  let is_Auth = "";
  let Is_home = "";
  let is_expired = "";
  let role = "";
  if (user.user.Is_home) {
    Is_home = user.user.Is_home.Is_home;
  }
  if (user.user.is_Auth) {
    is_Auth = user.user.is_Auth;

    is_expired = user.user.user.is_expired;
    role = user.user.user.role;
  }
  console.log(is_expired, "**************************");
  const [state, setState] = useState({
    collapsed: false,
    loading: false,
  });
  console.log(role, user.user.is_Auth, "is_auth===========");
  const { Header, Sider } = Layout;
  const defaultOptions = {
    loop: false,
    autoplay: true,
    animationData: Starburst,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  function toggle() {
    setState((prevState) => {
      return { collapsed: !state.collapsed };
    });
  }
  // useEffect(async () => {
  //   if (state.loading == true) {
  //     setInterval(() => {
  //       setState({ loading: false });
  //     }, 3000);
  //   }
  // }, []);

  if (state.loading) {
    return (
      <div className="firsttime-lottie">
        <Lottie
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
          options={defaultOptions}
          height={300}
          width={300}
        />
      </div>
    );
  } else {
    return (
      <Suspense
        fallback={
          <Box>
            <h2>UVAIS</h2>
          </Box>
        }
      >
        <Router>
          <div>
            {/* A <Switch> looks through its children <Route>s and
          renders the first one that matches the current URL. */}
            <Switch>
              {/* <Route exact path="/hotel-menu/:id/" component={HotelMenu} />
              <Route exact path="/password-confirm/:id/">
                <PasswordConfirm />
              </Route>
              <Route exact path="/forgot-password">
                <ForgotPassword />
              </Route>
              <Route exact path="/sign-up">
                <Registration />
              </Route> */}
              <Route path="/hotel-menu/:id/" element={<HotelMenu />} />
              <Route path="/sign-in" element={<Login1 />} />
              <Route path="/sign-up" element={<Registration />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route
                path="/password-confirm/:id/"
                element={<PasswordConfirm />}
              />
              <Route element={<Protected />}>
                <Route path="/*" element={<Home />} />
              </Route>
              {/* <Route path="/home" element={<Home />} /> */}
              {/* <Home />
              </Route> */}
              {/* <Route exact path="/sign-in">
                <Login1 />
              </Route>
              <Route component={NoMatchPage} /> */}
            </Switch>
          </div>
        </Router>
      </Suspense>
    );
  }
}

const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;
