import axios from "axios";

// export const BASE_URL = axios.create({
//   baseURL: "https://accountsapi.vikncodes.com/api/v1",
// });

export const BASE_URL = axios.create({
  baseURL: "http://localhost:8000/api/v1",
});
