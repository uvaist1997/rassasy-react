import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import styled from "styled-components/macro";
import { Button, CircularProgress, IconButton } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import AccountDeleteConfermation from "./AccountDeleteConfermation";
import { companiesUrl } from "../../api/CompanyAPI";
import { useSelector } from "react-redux";
import { getAvatar, getCookie } from "../../functions/utils";
import {
  accountServiceStatusUrl,
  listAccountServicesUrl,
} from "../../api/AccountServicesAPI";
import { useTranslation } from "react-i18next";
import ChangeOwnership from "./ChangeOwnership";
import { useNavigate } from "react-router-dom";
import Skeleton from "@mui/material/Skeleton";

function AccountInfo() {
  const [t] = useTranslation("common");
  const navigate = useNavigate();
  const [access, setAccess] = useState(getCookie("VBID"));
  const { user_id } = useSelector((state) => state.user);
  const [value, setValue] = useState("1");
  const [loading, setLoader] = useState(false);

  const [list, setList] = useState({
    data: [
      {
        companyName: "Vikn codes LLP",
        status: "Owner",
      },
      {
        companyName: "archipro",
        status: "Member",
      },
    ],

    acivate: [
      {
        service: "Services 1",
        status: "Deactive",
      },
      {
        service: "Services",
        status: "Reactivate",
      },
    ],
  });
  const [showOptionList, setOptionList] = useState(0);
  const handleOption = (e) => {
    if (e.currentTarget.dataset.optionId === showOptionList) {
      setOptionList(0);
    } else {
      setOptionList(e.currentTarget.dataset.optionId);
    }
  };
  const changeOwnership = (companyid) => {
    navigate(`/change-ownership/${companyid}`);
  };

  const fetchCompanyData = async () => {
    setLoader(true);

    let company_list_response = await fetch(companiesUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${access_token}`,
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        userId: user_id,
      }),
    }).then((response) => response.json());

    setList((prevState) => {
      return {
        ...prevState,
        data: company_list_response.data,
      };
    });
    setLoader(false);
  };
  const fetchAccountServiceData = async () => {
    setLoader(true);
    let list_account_services_response = await fetch(listAccountServicesUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        // Authorization: `Bearer ${access_token}`,
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: JSON.stringify({
        userId: user_id,
      }),
    }).then((response) => response.json());
    setList((prevState) => {
      return {
        ...prevState,
        acivate: list_account_services_response.data,
      };
    });
    setLoader(false);
  };

  useEffect(() => {
    fetchCompanyData();
    fetchAccountServiceData();
  }, []);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Box1 sx={{ typography: "body1" }}>
      <TabContext value={value}>
        <HeaderContainer>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleChange} aria-label="lab API tabs example">
              <Tab1 label={t("Organizations")} value="1" />
              <Tab1 label={t("Deactivation/Reactivation")} value="2" />
            </TabList>
          </Box>
        </HeaderContainer>
        <TabPanel1 value="1">
          <>
            <FirstContainer>
              <SecondContainer>
                <HeadContainer>
                  <P_SubscriptionTXT>{t("Organizations")}</P_SubscriptionTXT>
                  <SmallTXT>
                    {t(
                      "This Page Shows All The Organizations Linked To Your Account"
                    )}
                  </SmallTXT>
                </HeadContainer>

                <ScrollContainer>
                  {loading ? (
                    <CircularProgress size={18} color="info" />
                  ) : (
                    list.data.map((item) => (
                      <Apps>
                        <Card1>
                          <Rassasy2>
                            <RassasyContainer>
                              <ImgLogo
                                src={
                                  item.CompanyLogo
                                    ? item.CompanyLogo
                                    : getAvatar(item.id)
                                }
                              />
                            </RassasyContainer>
                            <ViknTxt>{item.CompanyName}</ViknTxt>
                          </Rassasy2>
                          <Button_Container>
                            <StyledButton
                              variant="text"
                              status={
                                item.CreatedUserID === user_id
                                  ? "Owner"
                                  : "Member"
                              }
                            >
                              {item.CreatedUserID === user_id
                                ? t("Owner")
                                : t("Member")}
                            </StyledButton>

                            <EditionContainer
                              data-option-id={item.id}
                              onClick={(e) => handleOption(e)}
                            >
                              <MoreVertIcon />
                              {item.id === showOptionList ? (
                                <OptionListContainer showOption={true}>
                                  <OptionList
                                    onClick={() => changeOwnership(item.id)}
                                  >
                                    {t("Change Ownership")}
                                  </OptionList>

                                  <OptionList
                                    onClick={() =>
                                      navigate(
                                        `/delete-organisation/${item.id}`
                                      )
                                    }
                                  >
                                    {t("Delete")}
                                  </OptionList>
                                </OptionListContainer>
                              ) : null}
                            </EditionContainer>
                          </Button_Container>
                        </Card1>
                      </Apps>
                    ))
                  )}
                </ScrollContainer>
              </SecondContainer>
            </FirstContainer>
          </>
        </TabPanel1>
        <TabPanel1 value="2">
          <>
            <FirstContainer>
              <SecondContainer>
                <HeadContainer>
                  <P_SubscriptionTXT>
                    {t("Deactivation/Reactivation")}
                  </P_SubscriptionTXT>
                  <SmallTXT>
                    {t(
                      "You Can Deactivate And Reactivate Or Delete Your Account From Here"
                    )}
                  </SmallTXT>
                  <ServiceTxt>{t("Services")}</ServiceTxt>
                </HeadContainer>

                <WhiteBox>
                  <ScrollContainer1>
                    {list.acivate.map((item) => (
                      <Apps1>
                        <Card1>
                          <Rassasy2>
                            <RassasyContainer>
                              <ImgLogo src={item.logo} />
                            </RassasyContainer>
                            <ViknTxt>{item.service}</ViknTxt>
                          </Rassasy2>
                          <Button_Container>
                            <StyledButton1
                              onClick={() =>
                                navigate(
                                  `/deactivate-application/${item.service}`
                                )
                              }
                              variant="text"
                              status={
                                item.status == true ? "Deactive" : "Reactivate"
                              }
                            >
                              {item.status == true
                                ? t("Deactive")
                                : t("Reactivate")}
                            </StyledButton1>
                          </Button_Container>
                        </Card1>
                      </Apps1>
                    ))}
                  </ScrollContainer1>
                </WhiteBox>

                <App2>
                  <DeleteContainer>
                    <ViknTxt>{t("Delete your account")}</ViknTxt>
                    <Tab3
                      value="3"
                      onChange={handleChange}
                      label={t("Delete")}
                    ></Tab3>
                  </DeleteContainer>
                </App2>
              </SecondContainer>
            </FirstContainer>
          </>
        </TabPanel1>
        <TabPanel value="3">
          {/* --------------------next page---------------------------------- */}
          <AccountDeleteConfermation />
        </TabPanel>
      </TabContext>
    </Box1>
  );
}

export default AccountInfo;
const Tab3 = styled(Tab)`
  && {
    background-color: #840000;
    font-family: "poppins", sans-serif;
    border-radius: 12px;
    opacity: unset;
    color: white;
    padding: 8px 16px;
    min-height: 30px;
    width: 31vw;
    font-size: 13px;
    max-width: 164px;
  }
`;
const DeleteContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StyledButton2 = styled(Button)`
  && {
    height: 30px;
    width: 31vw;
    max-width: 164px;

    background-color: #840000;

    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    font-family: "Poppins", sans-serif;
  }
`;
const WhiteBox = styled.div`
  background-color: white;
  border-radius: 23px;
`;
const ServiceTxt = styled.div`
  font-size: 21px;
  margin-top: 10px;
`;
const TabPanel1 = styled(TabPanel)`
  && {
    padding: unset;
    font-family: "poppins", sans-serif;
  }
`;

const ScrollContainer = styled.div`
  height: 572px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const ScrollContainer1 = styled(ScrollContainer)`
  height: 400px;
`;

const BottomContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: space-between;
  max-width: 642px;
  width: 80vw;
  @media (max-width: 738px) {
    width: 87vw;
  }
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    width: 100%;
  }
`;
const Left = styled.div`
  max-width: 261px;
  height: 307px;
  background-color: white;
  border-radius: 23px;
  padding: 15px 25px;
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    /* width: 614px; */
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;
const ViknTxt = styled.h4`
  font-size: 16px;
  margin: 0px;
  font-weight: 500;
  @media (max-width: 446px) {
    font-size: 13px;
  }
`;

const EditionContainer = styled(IconButton)`
  && {
    padding: 3px;
  }
`;

const Button_Container = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
`;
const StyledButton = styled(Button)`
  && {
    font-family: "poppins", sans-serif;
    background-color: ${({ status }) =>
      status === "Owner" ? "#cde9dc" : status === "Member" ? "#FFE5D1" : null};
    padding: 2px 2px;
    width: 86px;
    color: ${({ status }) =>
      status === "Owner" ? " #004e2f" : status === "Member" ? "#975009" : null};
    border-radius: 15px 15px 15px 15px;
    text-transform: capitalize;

    /* @media (max-width: 446px) {
      font-size: 12px;
      padding: 6px 8px;
      height: 32px;
    } */

    font-size: 13px;
    &:hover {
      background-color: #cde9dc;
    }
  }
`;

const StyledButton1 = styled(Button)`
  && {
    font-family: "poppins", sans-serif;
    background-color: ${({ status }) =>
      status === "Deactive"
        ? "#111111"
        : status === "Reactivate"
        ? "#033631"
        : null};
    padding: 2px 2px;
    width: 86px;
    color: #ffffff;
    border-radius: 5px 5px 5px 5px;
    text-transform: capitalize;

    font-size: 13px;
    &:hover {
      background-color: ${({ status }) =>
        status === "Deactive"
          ? "#111111"
          : status === "Reactivate"
          ? "#033631"
          : null};
    }
  }
`;
const RassayButton = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    color: black !important;
    text-transform: unset !important;
    /* width: 100%; */
    padding: 0px;
    min-height: 40px;
    min-width: 42px;

    border-radius: 22px;
  }

  align-items: center;
  border-radius: 4px;
`;

const SmallCard = styled.div`
  width: 100%;
  text-align: left;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
`;

const RassasyContainer = styled.div`
  width: 35px;
  height: 35px;
`;
const RassasyContainer2 = styled.div`
  width: 25px;
  height: 25px;
`;

const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  @media (max-width: 446px) {
    gap: 0px;
  }
`;
const Card1 = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;
const FreeTxt = styled.span`
  font-size: 9px;
  font-family: "poppins", sans-serif;
  color: #9e9e9e;
`;

const FreeTxt1 = styled.span`
  color: ${({ status }) => (status === "Active" ? "#008E26" : "#9A9A9A")};

  font-family: "poppins", sans-serif;
`;

const RevenueTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const RevenueTxt = styled.h4`
  font-size: 15px;
  font-weight: bold;
`;
const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  gap: 20px;
`;
const ApplicationTxt = styled.span`
  font-size: 12px;
  color: #919191;
`;
const Apps = styled.div`
  background-color: white;

  border-radius: 23px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }

  padding: 20px;

  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
`;
const App2 = styled(Apps)`
  padding: 10px 20px;
`;
const Apps1 = styled(Apps)`
  margin-top: unset;
  border-radius: 10px;

  background-color: unset;
`;

const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
  /* gap: 10px; */
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 16px;
`;

const Tab1 = styled(Tab)`
  font-size: 13px !important;

  @media (max-width: 495px) {
    font-size: 11px !important;
  }
`;
const HeaderContainer = styled.div`
  background-color: white;
  max-width: 619px;
  padding: 5px;
  border-radius: 22px 22px 0px 0px;
  @media (max-width: 495px) {
    height: 38px;
  }
  button {
    color: #033631 !important;
  }
`;
const Box1 = styled(Box)`
  && {
    .css-1gsv261 {
      @media (max-width: 495px) {
        height: 38px;
      }
    }
    width: 91vw;
    max-width: 620px;
    button {
      text-transform: capitalize;
      font-family: "poppins", sans-serif;
    }

    .css-1aquho2-MuiTabs-indicator {
      background-color: green !important;
      @media (max-width: 495px) {
        bottom: 9px;
      }
    }
  }
`;
const OptionListContainer = styled.div`
  opacity: ${({ showOption }) => (showOption ? "1" : "0")};
  /* transform: ${({ showOption }) =>
    showOption ? "translateY(0)" : "translateY(-200%)"}; */

  /* visibility: ${({ showOption }) => (showOption ? "unset" : "hidden")}; */
  transition: all ease-in-out 0.3s;
  background: #fff;
  position: absolute;
  width: 150px;
  border-radius: 3px;
  top: 0;
  right: 25px;
  box-shadow: 0px 0px 3px 0px #ccc;
  z-index: 10;
`;
const OptionList = styled.div`
  text-align: left;
  display: block;
  padding: 7px;
  /* margin: 5px; */
  color: #000;
  background: #fff;
  transition: background ease-in-out 0.3s;
  font-size: 12px;

  &:hover {
    cursor: pointer;
    background: hsl(0deg 0% 92%);
    transition: background ease-in-out 0.3s;
  }
`;
