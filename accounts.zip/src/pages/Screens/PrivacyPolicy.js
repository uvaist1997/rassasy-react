import React, { useState } from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import styled from "styled-components/macro";
import { Button, IconButton } from "@mui/material";

import Header from "../../components/Header/Header";
import PrivacyPolicySidebar from "../../components/Buttons/PrivacyPolicySidebar/PrivacyPolicySidebar";
import { useTranslation } from "react-i18next";

function PrivacyPolicy() {
  const [t] = useTranslation("common");
  const [value, setValue] = useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const [privacyData, setPrivacyData] = useState({
    heading: [
      t("What user data we collect"),
      t("Why we collect your data"),
      t("Device Information"),
      t("Changes to this privacy policy"),
      t("Contact us"),
      // t("Restricting the collection of your personal data"),
      // t("data retention"),
      // t("changes to this privacy policy"),
      // t("jurisdiction"),
      // t("contact us"),
    ],
    termsHead: [
      t("Intellectual Property Rights"),
      t("Restrictions"),
      t("Your Content"),
      t("Indemnification"),
      t("Variation Of Terms"),
      t("Governing Law and Jurisdiction"),
    ],
  });
  const [terms, setTerms] = useState({
    heading: [
      t("Intellectual Property Rights"),
      t("Restrictions"),
      t("Your Content"),
      t("Indemnification"),
      t("Variation Of Terms"),
      t("Entire Agreement"),
      t("Governing Law and Jurisdiction"),
    ],
  });
  return (
    <Container>
      <Header hidemenu="hideMenu" />

      <Box1 sx={{ typography: "body1" }}>
        <TabContext value={value}>
          <HeaderContainer>
            <Box2 sx={{ borderBottom: 1, borderColor: "divider" }}>
              <TabList
                onChange={handleChange}
                aria-label="lab API tabs example"
              >
                <Tab1 label={t("Privacy Policy")} value="1" />
                <Tab1 label={t("Terms and Conditions")} value="2" />
              </TabList>
            </Box2>
          </HeaderContainer>
          <TabPanel1 value="1">
            <>
              {/* ............................................................... */}

              <PrivacyPolicySidebar
                headline={t("Our Privacy Policy")}
                menuss={privacyData}
                image1={"../../images/icons/PrivacyImage.svg"}
              />

              {/* ............................................................... */}
              {/* <FirstContainer>
                <SecondContainer>
                  <HeadContainer>
                    <P_SubscriptionTXT>Organizations</P_SubscriptionTXT>
                    <SmallTXT>
                      This Page Shows All The Organizations Linked To Your
                      Account
                    </SmallTXT>
                  </HeadContainer>

                  <ScrollContainer></ScrollContainer>
                </SecondContainer>
              </FirstContainer> */}
            </>
          </TabPanel1>
          <TabPanel1 value="2">
            <PrivacyPolicySidebar
              headline={t("Our Terms and Conditions")}
              image1={"../../images/icons/Accept.svg"}
              menuss={terms}
            />
          </TabPanel1>
          <TabPanel value="3">
            {/* --------------------next page---------------------------------- */}
          </TabPanel>
        </TabContext>
      </Box1>
    </Container>
  );
}

export default PrivacyPolicy;

const Box2 = styled(Box)`
  margin-top: 60px;
  button {
    color: #033631 !important;
  }
`;
const Container = styled.div`
  width: 100%;
  min-height: 100vh;

  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const Tab3 = styled(Tab)`
  && {
    background-color: #840000;
    font-family: "poppins", sans-serif;
    border-radius: 12px;
    opacity: unset;
    color: white;
    padding: 8px 16px;
    min-height: 30px;
    width: 31vw;
    font-size: 13px;
    max-width: 164px;
  }
`;
const DeleteContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StyledButton2 = styled(Button)`
  && {
    height: 30px;
    width: 31vw;
    max-width: 164px;

    background-color: #840000;

    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    font-family: "Poppins", sans-serif;
  }
`;
const WhiteBox = styled.div`
  background-color: white;
  border-radius: 23px;
`;
const ServiceTxt = styled.div`
  font-size: 21px;
  margin-top: 10px;
`;
const TabPanel1 = styled(TabPanel)`
  && {
    font-family: "poppins", sans-serif;
    padding: 24px 24px 0px 24px;
  }
`;

const ScrollContainer = styled.div`
  height: 572px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const ScrollContainer1 = styled(ScrollContainer)`
  height: 400px;
`;

const FreeTxt1 = styled.span`
  color: ${({ status }) => (status === "Active" ? "#008E26" : "#9A9A9A")};

  font-family: "poppins", sans-serif;
`;

const RevenueTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const RevenueTxt = styled.h4`
  font-size: 15px;
  font-weight: bold;
`;
const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  gap: 20px;
`;
const ApplicationTxt = styled.span`
  font-size: 12px;
  color: #919191;
`;
const Apps = styled.div`
  background-color: white;

  border-radius: 23px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }

  padding: 20px;

  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
`;
const App2 = styled(Apps)`
  padding: 10px 20px;
`;
const Apps1 = styled(Apps)`
  margin-top: unset;
  border-radius: 10px;

  background-color: unset;
`;

const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
  /* gap: 10px; */
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 16px;
`;

const Tab1 = styled(Tab)`
  font-size: 13px !important;

  @media (max-width: 495px) {
    font-size: 11px !important;
  }
`;
const HeaderContainer = styled.div`
  padding: 10px;
`;
const Box1 = styled(Box)`
  && {
    .css-1gsv261 {
      @media (max-width: 495px) {
        height: 38px;
      }
    }

    button {
      text-transform: capitalize;
      font-family: "poppins", sans-serif;
    }

    .css-1aquho2-MuiTabs-indicator {
      background-color: #033631 !important;
      @media (max-width: 495px) {
        bottom: 9px;
      }
    }
  }
`;
