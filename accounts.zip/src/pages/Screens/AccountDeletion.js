import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";

import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import Snackbar from "@mui/material/Snackbar";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { accountDeleteUrl } from "../../api/AccountServicesAPI";
import { getCookie } from "../../functions/utils";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { VisibilityOff } from "@material-ui/icons";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import DletePasswordInput from "../../components/InputField/DletePasswordInput";
import { logoutSuccess } from "../../slices/user/userSlice";
import { useDispatch, useSelector } from "react-redux";
import { domain } from "../../settings";

function AccountDeletion() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const { username } = useSelector((state) => state.user);
  const [access, setAccess] = useState(getCookie("VBID"));
  const [visibleEye1, setvisibleEye1] = useState(false);

  const [state, setState] = useState({
    open: false,
    vertical: "top",
    horizontal: "center",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
  });
  const { vertical, horizontal, open } = state;

  const handleSuccessPopup = (newState) => (e) => {
    e.preventDefault();
    setState({ open: true, ...newState });
  };

  const handleClearAccount = () => {
    dispatch(logoutSuccess());
    document.cookie = `VBID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;domain=${domain}`;
    navigate("/signin");
  };
  const handleClose = () => {
    setState({ ...state, open: false });
  };
  const onSubmit = async (data) => {
    console.log(data);
    const { current_password, password1 } = data;
    setLoading(true);

    const deleteAccountResponse = await fetch(accountDeleteUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        username: username,
        current_password: current_password,
      }),
    }).then((response) => response.json());
    if (deleteAccountResponse.StatusCode == 6000) {
      setLoading(false);
      setState({ ...state, open: true });
      handleClearAccount();
    } else {
      setLoading(false);
      setState({
        ...state,
        currentPassword_error: deleteAccountResponse.message,
      });

      console.log("ERROR");
    }
  };
  console.log(errors);
  return (
    <Container>
      <CenterContainer>
        <ImgContainer>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>

        <ForgotTxt>Account Deletion</ForgotTxt>

        <Form onSubmit={handleSubmit(onSubmit)}>
          <PasswordTxt>Enter Your Password</PasswordTxt>
          <InputContainer>
            <DletePasswordInput
              className={
                errors.password
                  ? "text-field-2 w-input outline-red"
                  : "text-field-2 w-input"
              }
              type={visibleEye1 ? "text" : "password"}
              name="password"
              placeholder="Password"
              validationMessage="The password should have a length between 6 and 30 characters."
              // validationMessage="password required."
              validation={register("current_password", {
                required: "password required",
                minLength: {
                  value: 6,
                  message:
                    "The password should have minimum length of 6 characters",
                },
                maxLength: {
                  value: 30,
                  message: "The password should have maximum of 30 characters",
                },
              })}
              errors={errors}
              // disabled={loading}
            />
            {errors.current_password || state.currentPassword_error ? (
              <>
                <Exclamation1 data-tip data-for="sadFace4" />
                <StyledReactTooltip
                  id="sadFace4"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  {errors.current_password ? (
                    <span>{errors.current_password.message}</span>
                  ) : state.currentPassword_error ? (
                    <span>{state.currentPassword_error}</span>
                  ) : null}
                </StyledReactTooltip>
              </>
            ) : (
              <>
                {visibleEye1 ? (
                  <ShowEye onClick={() => setvisibleEye1(false)} />
                ) : (
                  <RemovedEye onClick={() => setvisibleEye1(true)} />
                )}
              </>
            )}
          </InputContainer>
          <ButtonContainer className="div-block-4">
            <ButtonCancel
              onClick={() => navigate(-1)}
              data-wait="Please wait..."
              className="cancel-button w-button"
            >
              Cancel
            </ButtonCancel>
            <StyledButton type="submit" variant="contained" disableElevation>
              Delete
            </StyledButton>
          </ButtonContainer>
        </Form>
      </CenterContainer>
      <Snackbar1
        anchorOrigin={{ vertical, horizontal }}
        open={open}
        onClose={handleClose}
        message="Deleted Successfully"
        key={vertical + horizontal}
      />
    </Container>
  );
}

export default AccountDeletion;

const Snackbar1 = styled(Snackbar)`
  div[role="alert"] {
    background-color: rgb(67, 160, 71) !important;
  }
`;
const InputContainer = styled.div`
  position: relative;
  width: 100%;
`;
const PasswordTxt = styled.span`
  color: #818181;
  font-size: 16px;
`;
const OtpTxt = styled.span`
  width: 100%;
  color: #002f65;
  cursor: pointer;
  font-size: 13px;
  display: flex;
  justify-content: flex-end;
`;
const ButtonContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: space-between;
`;
const ButtonCancel = styled.span`
  font-family: Poppins, sans-serif;
  font-family: Poppins, sans-serif;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  cursor: pointer;
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-color: #000;
  }
`;
const StyledButton = styled(Button)`
  && {
    width: 180px;
    height: 40px;

    background-color: #840000;
    /* background-image: linear-gradient(274deg, #033631, #005049); */
    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    font-family: "Poppins", sans-serif;
  }
`;
const StyledInput = styled.input`
  width: 100%;
  box-sizing: border-box;

  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
  &.outline-red {
    outline: 1px solid red;
  }
`;
const ForgotTxt = styled.span`
  font-size: 16px;

  font-weight: 500;
`;
const Form = styled.form`
  padding: 15px;
  align-items: center;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 18px;
  max-width: 419px;
  width: 80vw;
  padding: 27px;
  border-radius: 23px;

  background-image: linear-gradient(113deg, #ffffff, #ffffff); ;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 149.55px;
  height: 40px;
`;

const CenterContainer = styled.div`
  display: flex;
  flex-direction: column;

  align-items: center;
  gap: 10px;
`;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 5px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const ShowEye = styled(VisibilityOff)`
  position: absolute;
  right: 5px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 5px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
