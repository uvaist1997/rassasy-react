import { Button, Tooltip } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import styled from "styled-components/macro";

import PhoneIphoneOutlinedIcon from "@mui/icons-material/PhoneIphoneOutlined";

import LaptopWindowsRoundedIcon from "@mui/icons-material/LaptopWindowsRounded";
import IconButton from "@mui/material/IconButton";
import Input from "@mui/material/Input";
import FilledInput from "@mui/material/FilledInput";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import TextField from "@mui/material/TextField";
import EditIcon from "@mui/icons-material/Edit";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { Visibility, VisibilityOff } from "@material-ui/icons";
import { deviceListUrl } from "../../api/DeviceAPI";
import { recentActivityListUrl } from "../../api/RecentActivity'API";
import { getCookie } from "../../functions/utils";
import { useForm } from "react-hook-form";
import { changePasswordUrl } from "../../api/AuthAPI";
function Security1() {
  const [access, setAccess] = useState(getCookie("VBID"));
  const [loaing, setLoading] = useState(false);
  const [visibleEye1, setvisibleEye1] = useState(false);
  const [visibleEye2, setvisibleEye2] = useState(false);

  const [values, showPopup] = useState({
    password1: "",
    password2: "",
    password3: "",
    showPassword1: false,
    showPassword2: false,
    showPassword3: false,
    showPopup: false,
    defaultPassword: true,
  });
  const {
    watch,
    register,
    setFocus,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });
  const new_password1 = useRef({});
  new_password1.current = watch("password1", "");

  const handleChange1 = (event) => {
    showPopup({
      ...values,
      password1: event.target.value,
    });
  };
  const handleChange2 = (event) => {
    showPopup({
      ...values,
      password2: event.target.value,
    });
  };
  const handleChange3 = (event) => {
    showPopup({
      ...values,
      password3: event.target.value,
    });
  };

  const handleClickShowPassword2 = () => {
    showPopup({
      ...values,
      showPassword2: !values.showPassword2,
    });
  };

  const handleClickShowPassword1 = () => {
    showPopup({
      ...values,
      showPassword1: !values.showPassword1,
    });
  };
  const handleClickShowPassword3 = () => {
    showPopup({
      ...values,
      showPassword3: !values.showPassword3,
    });
  };
  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  const [state, setState] = useState({
    device: [
      {
        device_name: "Redmi K20 Pro",
        device_os: "Android",
        section: "Current Section",
      },
      {
        device_name: "Google Chrome",
        device_os: "Windows",
      },
      {
        device_name: "Apple Iphone",
        device_os: "iOS",
      },
      {
        device_name: "Microsoft Edge",
        device_os: "Windows",
      },
      {
        device_name: "Google Chrome",
        device_os: "Windows",
      },
      {
        device_name: "Apple Iphone",
        device_os: "iOS",
      },
      {
        device_name: "Microsoft Edge",
        device_os: "Windows",
      },
    ],

    activity: [
      {
        activity: "New Sign in",
        date_place: "7 jul-kerala,india",
        device: "Windows",
      },
      {
        activity: "Reset Password",
        date_place: "8 jul-kerala,india",
        device: "Windows",
      },
      {
        activity: "New Sign in",
        date_place: "9 jul-kerala,india",
        device: "Windows",
      },
      {
        activity: "New Sign in",
        date_place: "2 jul-kerala,india",
        device: "Windows",
      },
      {
        activity: "New Sign in",
        date_place: "6 jul-kerala,india",
        device: "Windows",
      },
      {
        activity: "New Sign in",
        date_place: "10 jul-kerala,india",
        device: "Windows",
      },
    ],
  });
  async function fetchData() {
    const devicesResponse = await fetch(deviceListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
    }).then((response) => response.json());
    const recentActivityResponse = await fetch(recentActivityListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
    }).then((response) => response.json());
    setState((prevState) => {
      return {
        ...prevState,
        device: devicesResponse.data,
        activity: recentActivityResponse.data,
      };
    });
  }
  useEffect(() => {
    console.log("########");
    fetchData();
  }, []);
  const onSubmit = async (data) => {
    console.log(data);
    const { current_password, new_password } = data;
    setLoading(true);

    const changePasswordResponse = await fetch(changePasswordUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        username: "uvaist",
        current_password: current_password,
        new_password: new_password,
      }),
    }).then((response) => response.json());
    if (changePasswordResponse.StatusCode == 6000) {
      setLoading(false);

      // swal({
      //   title: "success",
      //   text: "Registration Completed Successfully.please verify your email to Login",
      //   icon: "success",
      //   button: true,
      //   // timer: 1000,
      // });
    } else {
      setLoading(false);
      setState((prevState) => {
        return {
          ...prevState,
          email_error: changePasswordResponse.message,
        };
      });
    }
  };
  const handlechange = (e, v) => {
    let password1 = e.target.value;
    setState({
      ...state,
      password1,
    });
  };
  console.log("==============================", errors);
  return (
    <FirstContainer>
      <SecondContainer>
        <HeadContainer>
          <P_SubscriptionTXT>Security1</P_SubscriptionTXT>
          <SmallTXT>Settings to help you keep your account secure</SmallTXT>
        </HeadContainer>

        <BottomContainer>
          <Right>
            <InnerContainer>
              <AppTxt>Recent Activities</AppTxt>
              <ScrollContainer1>
                {state.activity.map((t) => (
                  <RecentPayment>
                    <Upgrade>{t.activity}</Upgrade>

                    <NumberTxt>
                      <Number1>{t.date_place}</Number1>
                      <Number2>{t.device}</Number2>
                    </NumberTxt>
                  </RecentPayment>
                ))}
              </ScrollContainer1>
            </InnerContainer>
          </Right>

          <Left>
            <InnerContainer>
              <AppTxt>Your Devices</AppTxt>

              <ScrollContainer>
                {state.device.map((i) => (
                  <RassayButton>
                    <SmallCard>
                      <Card1>
                        <Rassasy2>
                          {i.device_os === "Mobile" ? (
                            <PhoneIphoneOutlinedIcon />
                          ) : (
                            <LaptopWindowsRoundedIcon />
                          )}

                          <RedmiContainer>
                            <Redmi>{i.device_name}</Redmi>

                            {i.section ? <Redmi2>Current Section</Redmi2> : ""}
                          </RedmiContainer>
                        </Rassasy2>
                        <FreeTxt1 device_os={i.device_os}>
                          {i.device_os}
                        </FreeTxt1>
                      </Card1>
                    </SmallCard>
                  </RassayButton>
                ))}
              </ScrollContainer>
            </InnerContainer>
          </Left>
        </BottomContainer>

        <Apps>
          <AppTxt>Password</AppTxt>

          <ApplicationTxt>
            A secure password helps protect your Vikn Account
          </ApplicationTxt>

          <Card2 showpass={values.defaultPassword}>
            <PasswordLabel for="outlined-adornment-password">
              Password
            </PasswordLabel>
            <Form_control sx={{ m: 1, width: "25ch" }} variant="outlined">
              <Input
                disabled
                id="outlined-read-only-input"
                type="password"
                value="notmebutyou"
                endAdornment={
                  <InputAdornment position="end">
                    <Tooltip title="Change password">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={() =>
                          showPopup({
                            ...values,
                            showPopup: !values.showPopup,
                            defaultPassword: false,
                          })
                        }
                      >
                        <Edit />
                      </IconButton>
                    </Tooltip>
                  </InputAdornment>
                }
              />
            </Form_control>
          </Card2>
          <Popup onSubmit={handleSubmit(onSubmit)} showBoxes={values.showPopup}>
            <Card1>
              <PasswordLabel for="outlined-adornment-password">
                Current Password
              </PasswordLabel>
              <Form_control sx={{ m: 1, width: "25ch" }} variant="outlined">
                <CustomInput
                  id="standard-adornment-password"
                  className={
                    errors.current_password
                      ? "text-field _1 w-input outline-red"
                      : "text-field _1 w-input"
                  }
                  type={visibleEye1 ? "text" : "password"}
                  name="current_password"
                  placeholder="Current Password"
                  validation={register("current_password", {
                    required: "password required",
                    minLength: {
                      value: 6,
                      message:
                        "The password should have minimum length of 6 characters",
                    },
                    maxLength: {
                      value: 30,
                      message:
                        "The password should have maximum of 30 characters",
                    },
                    onChange: (e, v) => {
                      handlechange(e, v);
                    },
                  })}
                  errors={errors}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword1}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {values.showPassword1 ? (
                          <VisibilityOff />
                        ) : (
                          <Visibility />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </Form_control>
            </Card1>

            <Card1>
              <PasswordLabel for="outlined-adornment-password">
                New Password
              </PasswordLabel>
              <Form_control sx={{ m: 1, width: "25ch" }} variant="outlined">
                <CustomInput
                  id="standard-adornment-password"
                  className={
                    errors.password1
                      ? "text-field _1 w-input outline-red"
                      : "text-field _1 w-input"
                  }
                  type={visibleEye1 ? "text" : "password"}
                  name="password1"
                  placeholder="New Password"
                  validation={register("password1", {
                    validate: (value) =>
                      value === new_password1.current ||
                      "The passwords do not match",
                    required: "password required",
                    minLength: {
                      value: 6,
                      message:
                        "The password should have minimum length of 6 characters",
                    },
                    maxLength: {
                      value: 30,
                      message:
                        "The password should have maximum of 30 characters",
                    },
                    onChange: (e, v) => {
                      handlechange(e, v);
                    },
                  })}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword2}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {values.showPassword2 ? (
                          <VisibilityOff />
                        ) : (
                          <Visibility />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </Form_control>
            </Card1>
            <Card1>
              <PasswordLabel for="outlined-adornment-password">
                Confirm Password
              </PasswordLabel>
              <Form_control sx={{ m: 1, width: "25ch" }} variant="outlined">
                <CustomInput
                  id="standard-adornment-password"
                  className={
                    errors.password2
                      ? "text-field _1 w-input outline-red"
                      : "text-field _1 w-input"
                  }
                  type={visibleEye1 ? "text" : "password"}
                  name="password2"
                  placeholder="Confirm Password"
                  validation={register("password2", {
                    validate: (value) =>
                      value === new_password1.current ||
                      "The passwords do not match",
                    required: "password required",
                    minLength: {
                      value: 6,
                      message:
                        "The password should have minimum length of 6 characters",
                    },
                    maxLength: {
                      value: 30,
                      message:
                        "The password should have maximum of 30 characters",
                    },
                    onChange: (e, v) => {
                      handlechange(e, v);
                    },
                  })}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword3}
                        onMouseDown={handleMouseDownPassword}
                      >
                        {values.showPassword3 ? (
                          <VisibilityOff />
                        ) : (
                          <Visibility />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                />
              </Form_control>
            </Card1>
            <ButtonContainer>
              <CancelBtn
                variant="text"
                onClick={() =>
                  showPopup({
                    ...values,
                    defaultPassword: true,
                    showPopup: false,
                  })
                }
              >
                Cancel
              </CancelBtn>
              <NewButton type="submit" variant="text">
                Confirm
              </NewButton>
            </ButtonContainer>
          </Popup>
        </Apps>
      </SecondContainer>
    </FirstContainer>
  );
}

export default Security1;

const ButtonContainer = styled.div`
  width: 100%;
  text-align: right;
  margin-top: 8px;
`;
const CancelBtn = styled(Button)`
  && {
    color: black;
    margin-left: auto;
    text-transform: capitalize;
    font-family: "poppins", sans-serif;
    padding: 7px 20px;
    border-radius: 11px;
    font-size: 12px;
  }
`;
const NewButton = styled(Button)`
  && {
    margin-left: 20px;
    padding: 7px 20px;
    border-radius: 11px;
    margin-right: 5px;
    color: white;
    background-color: green;
    font-size: 12px;
    text-transform: capitalize;
    font-family: "poppins", sans-serif;
    &:hover {
      color: white;
      background-color: green;
    }
  }
`;
const Popup = styled.form`
  width: 100%;
  display: ${({ showBoxes }) => (showBoxes ? "" : "none")};
`;

const Edit = styled(EditIcon)`
  && {
    padding: 5px;
    font-size: 1rem;
  }
`;
const Form_control = styled(FormControl)`
  && {
    width: 473px;

    margin-left: 29px;
  }
  @media (max-width: 748px) {
    width: 525px;
  }
  button {
    padding: unset !important;
  }
`;
const PasswordLabel = styled.label`
  font-size: 11px;
  margin-right: 12px;
  min-width: 108px;
  text-align: left;
`;
const RedmiContainer = styled.div`
  font-weight: 400;
`;
const Redmi = styled.div`
  font-size: 11px;

  font-family: "poppins", sans-serif;
`;
const Redmi2 = styled.div`
  font-size: 9px;
  line-height: 8px;
  text-align: left;
  font-family: "poppins", sans-serif;
  color: #0021a5;
`;
const Upgrade = styled.span`
  font-size: 11px;
  font-weight: 400;
`;
const Number1 = styled.span`
  font-size: 11px;
  font-weight: 500;
  font-weight: 400;
  color: #a9a9a9;
`;
const Number2 = styled.span`
  font-size: 11px;
  font-weight: 400;
  color: #a9a9a9;
`;
const NumberTxt = styled.div`
  display: flex;
  line-height: 12px;
  flex-direction: column;

  text-align: right;
`;

const RecentPayment = styled.div`
  width: 100%;
  margin-top: 23px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const ScrollContainer = styled.div`
  height: 260px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const ScrollContainer1 = styled(ScrollContainer)`
  width: 100%;
`;

const BottomContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: space-between;
  max-width: 642px;
  width: 80vw;
  margin: auto;

  @media only screen and (min-width: 360px) and (max-width: 527px) {
    width: 90vw;
  }

  @media (max-width: 738px) {
    width: 87vw;
  }

  @media only screen and (min-width: 739px) and (max-width: 800px) {
    width: 100%;
  }

  @media (max-width: 738px) {
    width: 88vw;
  }
`;
const Left = styled.div`
  max-width: 261px;
  height: 307px;
  background-color: white;
  border-radius: 23px;
  padding: 15px 25px;
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    width: 100% !important;
    max-width: 590px;
    margin: auto;
  }

  @media (max-width: 738px) {
    width: 83vw;
    margin: auto;
    max-width: 627px;
  }

  @media only screen and (min-width: 360px) and (max-width: 535px) {
    width: 77vw !important;
    max-width: 590px;
  }
`;
const InnerContainer = styled.div`
  display: flex;

  align-items: flex-start;
  flex-direction: column;
`;
const Right = styled(Left)`
  width: 261px;

  @media only screen and (min-width: 739px) and (max-width: 800px) {
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;

const RassayButton = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    color: black !important;
    text-transform: unset !important;
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    min-height: 53px;
    border-radius: 22px;
  }

  align-items: center;
  border-radius: 4px;
  height: 41px;
`;

const SmallCard = styled.div`
  width: 100%;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
`;

const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  @media (max-width: 446px) {
    gap: 0px;
  }
`;
const Card1 = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-between;
`;
const Card2 = styled(Card1)`
  display: ${({ showpass }) => (showpass ? "" : "none")};
`;

const FreeTxt1 = styled.span`
  color: #9a9a9a;
  font-size: 11px;
  font-weight: 400;
  font-family: "poppins", sans-serif;
`;

const FirstContainer = styled.div`
  @media (min-width: 1309.09px) and (max-width: 1152px) {
    overflow-y: scroll;
    height: 500px;
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;
const ApplicationTxt = styled.span`
  font-size: 12px;
  text-align: left;
  color: #919191;
`;
const Apps = styled.div`
  margin: auto;
  background-color: white;
  padding: 15px;
  border-radius: 23px;

  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
  width: 83vw;
`;
const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 18px;
`;
const CustomInput = styled(Input)`
  &.outline-red {
    border-bottom: 1px solid red;
  }
  &.outline-red:focus {
    border-bottom: 1px solid red;
  }

  input {
    ::placeholder {
      font-size: 12px;
    }
  }
`;
