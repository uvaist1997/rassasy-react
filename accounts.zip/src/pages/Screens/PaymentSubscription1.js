import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import styled from "styled-components/macro";
import { Button, IconButton } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import AccountDeleteConfermation from "./AccountDeleteConfermation";
import { companiesUrl } from "../../api/CompanyAPI";
import { useSelector } from "react-redux";
import { getAvatar, getCookie } from "../../functions/utils";
import {
  accountServiceStatusUrl,
  accountSubscriptionUrl,
  listAccountServicesUrl,
} from "../../api/AccountServicesAPI";
import { useTranslation } from "react-i18next";


function PaymentSubscription1() {
    const [t] = useTranslation("common");
  const [access, setAccess] = useState(getCookie("VBID"));
  const { user_id } = useSelector((state) => state.user);
  const [value, setValue] = useState("1");

  const [state, setState] = useState({
    apps: [],
  });



  useEffect(() => {
    FetchData();
  }, []);

  const FetchData = async () => {
    const subscription_datas = await fetch(accountSubscriptionUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        user_id: user_id,
      }),
    }).then((response) => response.json());

    if (subscription_datas.StatusCode == 6000) {
      setState({
        ...state,
        apps: subscription_datas.apps,
      });
    }
  };
  

  

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <Box1 sx={{ typography: "body1" }}>
      <TabContext value={value}>
        <HeaderContainer>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleChange} aria-label="lab API tabs example">
              <Tab1 label={t("Payments")} value="1" />
              <Tab1 label={t("Subscriptions")} value="2" />
            </TabList>
          </Box>
        </HeaderContainer>
        <TabPanel1 value="1">
          <>
            <FirstContainer>
              <SecondContainer>
                <HeadContainer>
                  <P_SubscriptionTXT>{t("Payments")}</P_SubscriptionTXT>
                  {/* <SmallTXT>
                    This Page Shows All The Organizations Linked To Your Account
                  </SmallTXT> */}
                </HeadContainer>

                <ScrollContainer>
                  <Apps>
                    <InnerContainer>
                      <AppTxt>{t("Recent Payments")}</AppTxt>

                      <ApplicationTxt>
                        {t("Payment you Made Recently")}
                      </ApplicationTxt>

                      <RecentPayment>
                        <Upgrade>{t("Upgrade")}</Upgrade>

                        <NumberTxt>
                          <Number1>-</Number1>
                          <Number2></Number2>
                        </NumberTxt>
                      </RecentPayment>
                      <RecentPayment>
                        <Upgrade>{t("Added Users")}</Upgrade>

                        <NumberTxt>
                          <Number1>-</Number1>
                          <Number2></Number2>
                        </NumberTxt>
                      </RecentPayment>
                    </InnerContainer>
                  </Apps>
                </ScrollContainer>
              </SecondContainer>
            </FirstContainer>
          </>
        </TabPanel1>
        <TabPanel1 value="2">
          <>
            <FirstContainer>
              <SecondContainer>
                <HeadContainer>
                  <P_SubscriptionTXT>{t("Subscriptions")}</P_SubscriptionTXT>
                </HeadContainer>

                <AppsContainer>
                  {state.apps.map((i) => (
                    <RassayButton>
                      <SmallCard>
                        <Card1>
                          <Rassasy2>
                            <RassasyContainer>
                              <ImgLogo src={i.logo} />
                            </RassasyContainer>
                            {i.addon ? (
                              <AppNameContainer>
                                <ViknTxt>{i.service}</ViknTxt>
                                <ParentContainer>
                                  <ParentLogo src={i.parentlogo} />
                                  <FreeTxt>{t("AddOn")}</FreeTxt>
                                </ParentContainer>
                              </AppNameContainer>
                            ) : (
                              [<ViknTxt>{i.service}</ViknTxt>]
                            )}
                            {i.CompanyName ? (
                              <CompanyName>-{i.CompanyName}</CompanyName>
                            ) : null}
                          </Rassasy2>
                          <Button_Container>
                            {i.Edition ? (
                              <EditionContainer>
                                <FreeTxt>{t("Edition")}</FreeTxt>
                                <ProfessionalTxt>
                                  {t(i.Edition)}
                                </ProfessionalTxt>
                              </EditionContainer>
                            ) : null}

                            {/* <StyledButton
                        type="submit"
                        variant="contained"
                        disableElevation
                      >
                        {t("Upgrade")}
                      </StyledButton> */}
                          </Button_Container>
                        </Card1>
                      </SmallCard>
                    </RassayButton>
                  ))}
                </AppsContainer>
              </SecondContainer>
            </FirstContainer>
          </>
        </TabPanel1>
        <TabPanel value="3">
          {/* --------------------next page---------------------------------- */}
          <AccountDeleteConfermation />
        </TabPanel>
      </TabContext>
    </Box1>
  );
}

export default PaymentSubscription1;
const Tab3 = styled(Tab)`
  && {
    background-color: #840000;
    font-family: "poppins", sans-serif;
    border-radius: 12px;
    opacity: unset;
    color: white;
    padding: 8px 16px;
    min-height: 30px;
    width: 31vw;
    font-size: 13px;
    max-width: 164px;
  }
`;
const DeleteContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StyledButton2 = styled(Button)`
  && {
    height: 30px;
    width: 31vw;
    max-width: 164px;

    background-color: #840000;

    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    font-family: "Poppins", sans-serif;
  }
`;
const WhiteBox = styled.div`
  background-color: white;
  border-radius: 23px;
`;
const ServiceTxt = styled.div`
  font-size: 21px;
  margin-top: 10px;
`;
const TabPanel1 = styled(TabPanel)`
  && {
    padding: unset;
    font-family: "poppins", sans-serif;
  }
`;

const ScrollContainer = styled.div`
  height: 572px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const ScrollContainer1 = styled(ScrollContainer)`
  height: 400px;
`;

const BottomContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: space-between;
  max-width: 642px;
  width: 80vw;
  @media (max-width: 738px) {
    width: 87vw;
  }
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    width: 100%;
  }
`;
const Left = styled.div`
  max-width: 261px;
  height: 307px;
  background-color: white;
  border-radius: 23px;
  padding: 15px 25px;
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    /* width: 614px; */
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;
const ViknTxt = styled.h4`
  font-size: 16px;
  margin: 0px;
  font-weight: 500;
  @media (max-width: 446px) {
    font-size: 13px;
  }
`;

const EditionContainer = styled(IconButton)`
  && {
    padding: 3px;
  }
`;

const Button_Container = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
`;
const StyledButton = styled(Button)`
  && {
    font-family: "poppins", sans-serif;
    background-color: ${({ status }) =>
      status === "Owner" ? "#cde9dc" : status === "Member" ? "#FFE5D1" : null};
    padding: 2px 2px;
    width: 86px;
    color: ${({ status }) =>
      status === "Owner" ? " #004e2f" : status === "Member" ? "#975009" : null};
    border-radius: 15px 15px 15px 15px;
    text-transform: capitalize;

    /* @media (max-width: 446px) {
      font-size: 12px;
      padding: 6px 8px;
      height: 32px;
    } */

    font-size: 13px;
    &:hover {
      background-color: #cde9dc;
    }
  }
`;

const StyledButton1 = styled(Button)`
  && {
    font-family: "poppins", sans-serif;
    background-color: ${({ status }) =>
      status === "Deactive"
        ? "#111111"
        : status === "Reactivate"
        ? "#033631"
        : null};
    padding: 2px 2px;
    width: 86px;
    color: #ffffff;
    border-radius: 5px 5px 5px 5px;
    text-transform: capitalize;

    font-size: 13px;
    &:hover {
      background-color: ${({ status }) =>
        status === "Deactive"
          ? "#111111"
          : status === "Reactivate"
          ? "#033631"
          : null};
    }
  }
`;
const RassayButton = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    color: black !important;
    text-transform: unset !important;
    /* width: 100%; */
    padding: 0px;
    min-height: 40px;
    min-width: 42px;

    border-radius: 22px;
  }

  align-items: center;
  border-radius: 4px;
`;

const SmallCard = styled.div`
  width: 100%;
  text-align: left;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
  padding: 5px;
`;

const RassasyContainer = styled.div`
  width: 35px;
  height: 35px;
`;
const RassasyContainer2 = styled.div`
  width: 25px;
  height: 25px;
`;

const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  @media (max-width: 446px) {
    gap: 0px;
  }
`;
const Card1 = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
`;

const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;

const ParentLogo = styled.img`
  width: 15px;
  height: 15px;
  object-fit: contain;
  margin-right: 4px ;
`;
const FreeTxt = styled.span`
  font-size: 9px;
  font-family: "poppins", sans-serif;
  color: #9e9e9e;
  margin-right: 4px
`;

const FreeTxt1 = styled.span`
  color: ${({ status }) => (status === "Active" ? "#008E26" : "#9A9A9A")};

  font-family: "poppins", sans-serif;
`;

const RevenueTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const RevenueTxt = styled.h4`
  font-size: 15px;
  font-weight: bold;
`;
const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  gap: 20px;
`;
const ApplicationTxt = styled.span`
  font-size: 12px;
  color: #919191;
`;
const Apps = styled.div`
  background-color: white;

  border-radius: 23px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }

  padding: 20px;

  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
`;
const App2 = styled(Apps)`
  padding: 10px 20px;
`;
const Apps1 = styled(Apps)`
  margin-top: unset;
  border-radius: 10px;

  background-color: unset;
`;

const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
  /* gap: 10px; */
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 16px;
`;

const Tab1 = styled(Tab)`
  font-size: 13px !important;

  @media (max-width: 495px) {
    font-size: 11px !important;
  }
`;
const HeaderContainer = styled.div`
  background-color: white;
  max-width: 619px;
  padding: 5px;
  border-radius: 22px 22px 0px 0px;
  @media (max-width: 495px) {
    height: 38px;
  }
  button {
    color: #033631 !important;
  }
`;
const Box1 = styled(Box)`
  && {
    .css-1gsv261 {
      @media (max-width: 495px) {
        height: 38px;
      }
    }
    width: 91vw;
    max-width: 620px;
    button {
      text-transform: capitalize;
      font-family: "poppins", sans-serif;
    }

    .css-1aquho2-MuiTabs-indicator {
      background-color: green !important;
      @media (max-width: 495px) {
        bottom: 9px;
      }
    }
  }
`;
const AppsContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  background-color: white;
  padding: 15px;
  border-radius: 23px;
  max-width: 593px;
  width: 83vw;
`;

const CompanyName = styled.p`
  margin: 0;
  font-size: 12px;
  font-family: "poppins", sans-serif;
  @media (max-width: 446px) {
    font-size: 11px;
  }
  color: rgba(0, 0, 0, 0.54);
`;

const ProfessionalTxt = styled.p`
  margin: 0;
  font-size: 12px;
  font-family: "poppins", sans-serif;
  @media (max-width: 446px) {
    font-size: 11px;
  }
`;

const InnerContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: flex-start;
  flex-direction: column;
`;

const RecentPayment = styled.div`
  width: 100%;
  margin-top: 23px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Number1 = styled.span`
  font-size: 12px;
  font-weight: 500;
`;
const Number2 = styled.span`
  font-size: 10px;
  color: #606060;
`;

const Upgrade = styled.span`
  font-size: 13px;
  font-weight: 500;
`;

const NumberTxt = styled.div`
  display: flex;
  line-height: 12px;
  flex-direction: column;
  text-align: right;
`;

const AppNameContainer = styled.div`
`
const ParentContainer = styled.div`
display: flex ;
`;