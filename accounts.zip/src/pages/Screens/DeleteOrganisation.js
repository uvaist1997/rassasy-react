import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";

import styled from "styled-components/macro";
import Snackbar from "@mui/material/Snackbar";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  accountDeleteUrl,
  deleteOrganisationUrl,
} from "../../api/AccountServicesAPI";
import { getCookie } from "../../functions/utils";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { VisibilityOff } from "@material-ui/icons";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import DletePasswordInput from "../../components/InputField/DletePasswordInput";
import { logoutSuccess } from "../../slices/user/userSlice";
import { useDispatch, useSelector } from "react-redux";
import { domain } from "../../settings";
import "../../Home.css";
import { getSingleCompanyUrl } from "../../api/CompanyAPI";

function DeleteOrganisation() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();

  const [loading, setLoading] = useState(false);
  const { username, user_id } = useSelector((state) => state.user);
  const [access, setAccess] = useState(getCookie("VBID"));
  const [visibleEye1, setvisibleEye1] = useState(false);

  const [state, setState] = useState({
    open: false,
    vertical: "top",
    horizontal: "center",
    owner_username_error: "",
    password_error: "",
    CompanyLogo: "",
    CompanyName: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
  });

  const handleClearAccount = () => {
    dispatch(logoutSuccess());
    document.cookie = `VBID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;domain=${domain}`;
    navigate("/signin");
  };
  useEffect(() => {
    fetchCompanyDetails();
  }, [id]);
  const fetchCompanyDetails = async () => {
    const getSingleCompanyResponse = await fetch(getSingleCompanyUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        CompanyID: id,
        user_id: user_id,
      }),
    }).then((response) => response.json());
    if (getSingleCompanyResponse.StatusCode == 6000) {
      setState({
        ...state,
        CompanyLogo: getSingleCompanyResponse.data.CompanyLogo,
        CompanyName: getSingleCompanyResponse.data.CompanyName,
      });
    }
  };
  const onSubmit = async (data) => {
    console.log(data);
    const { owner_username, password } = data;
    setLoading(true);

    const deleteOrganisationResponse = await fetch(deleteOrganisationUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        new_owner_username: "uvaist",
        username: username,
        current_password: password,
      }),
    }).then((response) => response.json());
    const StatusCode = deleteOrganisationResponse.StatusCode;

    if (StatusCode == 6000) {
      setLoading(false);
      // handleClearAccount();
      navigate("/");
      setState({ ...state, password_error: "", owner_username_error: "" });
    } else if (StatusCode == 6001) {
      setLoading(false);
      setState({
        ...state,
        password_error: deleteOrganisationResponse.message,
      });
    } else {
      setState({
        ...state,
        owner_username_error: deleteOrganisationResponse.message,
      });
    }
  };
  console.log(errors);
  return (
    <Container>
      <div>
        <TopHead>Delete Organisation</TopHead>
        <MainContainer>
          <CompanyLogo>
            <ImgConatiner>
              <LogoImg
                src={state.CompanyLogo}
                // src="https://uploads-ssl.webflow.com/632eab94c5e7a6cb31737519/632ead4fa3d580fa03608fa1_Group%202812.svg"
                loading="lazy"
                alt=""
              />
            </ImgConatiner>
            <TextBlock2>{state.CompanyName}</TextBlock2>
          </CompanyLogo>

          <FormContainer className="form-block w-form">
            <Form
              onSubmit={handleSubmit(onSubmit)}
              id="email-form"
              name="email-form"
              data-name="Email Form"
              method="get"
              className="change-owner"
            >
              <FormLabel for="Password" className="enter-password">
                Enter Your Password
              </FormLabel>
              <InputContainer>
                <FormInput
                  {...register("password", {
                    required: "Please enter your password.",
                  })}
                  type="password"
                  className={
                    errors.password || state.password_error
                      ? "password w-input outline-red"
                      : "password w-input"
                  }
                  maxlength="256"
                  name="password"
                  data-name="Password"
                  placeholder="Password"
                  id="Password"
                  required=""
                />
                {errors.password || state.password_error ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace" />
                    <StyledReactTooltip
                      id="sadFace"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.password ? (
                        <span>{errors.password.message}</span>
                      ) : state.password_error ? (
                        <span>{state.password_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </InputContainer>
              <ButtonContainer className="div-block-4">
                <ButtonCancel
                  onClick={() => navigate(-1)}
                  data-wait="Please wait..."
                  className="cancel-button w-button"
                >
                  Cancel
                </ButtonCancel>
                <Button
                  type="submit"
                  data-wait="Please wait..."
                  className="save-button w-button"
                >
                  Delete
                </Button>
              </ButtonContainer>
            </Form>
            <FormDone className="w-form-done"></FormDone>
            <FormFail className="w-form-fail"></FormFail>
          </FormContainer>
        </MainContainer>
      </div>
    </Container>
  );
}

export default DeleteOrganisation;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const TopHead = styled.div`
  display: flex;
  width: 419px;
  padding-bottom: 17px;
  flex-direction: column;
  align-items: center;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;
const MainContainer = styled.div`
  width: 100%;
  padding: 26px;
  border-radius: 23px;
  background-color: #fff;
`;
const CompanyLogo = styled.div`
  display: flex;
  margin-right: auto;
  margin-bottom: 18px;
  margin-left: auto;
  align-items: center;
`;
const ImgConatiner = styled.div`
  width: 12%;
`;
const LogoImg = styled.img`
  max-width: 100%;
  vertical-align: middle;
  display: inline-block;
`;
const TextBlock2 = styled.div`
  margin-left: 9px;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;

const Owner = styled.div`
  display: flex;
  margin-bottom: 18px;
  font-family: Poppins, sans-serif;
  font-size: 15px;
`;
const CurrentOwner = styled.div`
  color: #7a7a7a;
`;
const OwnerName = styled.div`
  padding-left: 4px;
  font-weight: 500;
`;
const FormContainer = styled.div`
  margin-bottom: 0px;
`;
const Form = styled.form``;
const FormLabel = styled.label`
  margin-bottom: 9px;
  font-family: Poppins, sans-serif;
  color: #7a7a7a;
  font-size: 16px;
  font-weight: 400;
  text-align: center;
`;
const InputContainer = styled.div`
  position: relative;
`;
const FormInput = styled.input`
  margin-bottom: 16px;
  border: 1px solid #a8a7aa;
  border-radius: 9px;
  font-family: Poppins, sans-serif;
  font-size: 15px;
  &.outline-red {
    outline: 1px solid red;
  }
  &.w-input {
    display: block;
    width: 100%;
    /* height: 38px; */
    padding: 8px 12px;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #333333;
    vertical-align: middle;
    background-color: #ffffff;
    border: 1px solid #cccccc;
  }
  &.password {
    margin-bottom: 27px;
    border: 1px solid #a8a7aa;
    border-radius: 9px;
  }
`;
const ButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const ButtonCancel = styled.span`
  font-family: Poppins, sans-serif;
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-color: #000;
  }

  &.w-button {
    display: inline-block;
    padding: 9px 15px;
    /* background-color: #3898ec; */
    color: white;
    border: 0;
    line-height: inherit;
    text-decoration: none;
    cursor: pointer;
    /* border-radius: 0; */
  }
  &.save-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    /* background-image: linear-gradient(104deg, #033631, #005049); */
    background: #840000 0% 0% no-repeat padding-box;
    font-family: Poppins, sans-serif;
  }
`;
const Button = styled.button`
  font-family: Poppins, sans-serif;
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-color: #000;
  }

  &.w-button {
    display: inline-block;
    padding: 9px 15px;
    /* background-color: #3898ec; */
    color: white;
    border: 0;
    line-height: inherit;
    text-decoration: none;
    cursor: pointer;
    /* border-radius: 0; */
  }
  &.save-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    /* background-image: linear-gradient(104deg, #033631, #005049); */
    background: #840000 0% 0% no-repeat padding-box;
    font-family: Poppins, sans-serif;
  }
`;
const FormDone = styled.div`
  display: none;
  padding: 20px;
  text-align: center;
  background-color: #dddddd;
`;
const FormFail = styled.div`
  display: none;
  margin-top: 10px;
  padding: 10px;
  background-color: #ffdede;
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000; ;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
