import React from "react";
import WhatsNewHeader from "../../components/Header/WhatsNewHeader";
import styled from "styled-components/macro";
function Whatsnew() {
  return (
    <Container>
      <WhatsNewHeader />
      <>
        <TablePanel1>
          <InfoContainer>
            <Element>
              <HeadingContainer>
                <ImageContainer>
                  <ImgLogo src="../../images/icons/whats.svg" />
                </ImageContainer>
                <First>
                  <Image>
                    <ImgLogo src="../../images/icons/erp.svg" />
                  </Image>
                  <Headline>Updation History</Headline>

                  <SmallTxt1>Version 2.22.16.75 - Latest</SmallTxt1>

                  <InlineContainer>
                    <SmallTxt>Last updated : </SmallTxt>
                    <DateTxt>August 3, 2022</DateTxt>
                  </InlineContainer>
                </First>
              </HeadingContainer>
            </Element>
            <NotesContainer>
              <Headline1>Updation History</Headline1>

              <SmallTxt2>Version 2.22.16.75 - Latest</SmallTxt2>

              <Li>Your IP addresses</Li>
              <Li>Your contact information and email address</Li>
              <Li>Other information such as interests and preference</Li>
              <Li>
                Data profile regarding your online behavior on our application.
              </Li>
              {/* ========================Demo========================= */}
              <Element style={{ textAlign: "left" }}>
                <SmallTxt2>Version 2.22.16.74 - DD/MM/YYYY</SmallTxt2>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
              </Element>
              <Element style={{ textAlign: "left" }}>
                <SmallTxt2>Version 2.22.16.73 - DD/MM/YYYY</SmallTxt2>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
              </Element>
              <Element style={{ textAlign: "left" }}>
                <SmallTxt2>Version 2.22.16.75 - Latest</SmallTxt2>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
                <Li>Your IP addresses</Li>
                <Li>Your contact information and email address</Li>
                <Li>Other information such as interests and preference</Li>
                <Li>
                  Data profile regarding your online behavior on our
                  application.
                </Li>
              </Element>
            </NotesContainer>
          </InfoContainer>
        </TablePanel1>
      </>
    </Container>
  );
}

export default Whatsnew;
const Container = styled.div`
  width: 100%;
  min-height: 100vh;

  background-image: linear-gradient(122deg, #ecf2f0, #f5f8f7);
`;

const Li = styled.li`
  font-size: 14px;
  margin-left: 5px;
  color: #7b7b7b;
  text-align: left;
`;

const Image = styled.div`
  width: 131px;
  height: 31px;
  padding: 9px;
  background-color: white;
  border-radius: 9px;
`;
const SubHeading = styled.span`
  font-size: 16px;
  font-weight: 500;
  margin-top: 15px;
  margin-bottom: 10px;
`;
const NotesContainer = styled.div`
  display: grid;
  margin-top: 30px;
  place-items: baseline;
  grid-template-columns: 1fr;
  max-width: 614px;
  width: 83vw;

  padding: 30px;
  background-color: white;
  border-radius: 23px;
`;

const InlineContainer = styled.div`
  display: flex;

  @media (max-width: 1024px) {
    justify-content: center;
  } ;
`;
const DateTxt = styled.span`
  font-size: 14px;
  color: #033631;
  margin-left: 5px;
  font-weight: 500;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;

const First = styled.div`
  align-self: end;
  text-align: left;
  @media (max-width: 1024px) {
    text-align: unset;
  }
`;

const ImageContainer = styled.div`
  width: 208px;
  height: 208px;
`;
const TablePanel1 = styled.div`
  width: 100%;

  display: flex;

  justify-content: center;
`;
const InfoContainer = styled.div`
  margin-top: 69px;
`;

const HeadingContainer = styled.div`
  font-family: "poppins", sans-serif !important;

  max-width: 614px;
  justify-content: center;
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin: auto;
  width: 83vw;
`;
const Headline = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
  color: #000000;
`;
const Headline1 = styled(Headline)`
  font-size: 28px;
`;

const SmallTxt = styled.p`
  color: #7b7b7b;
  font-size: 14px;
  text-align: left;
  display: block;
  margin: 0;
`;
const SmallTxt1 = styled(SmallTxt)`
  color: #0f6d04;
  font-weight: 500;
`;
const SmallTxt2 = styled(SmallTxt)`
  color: #0f6d04;
  margin-top: 10px;
  margin-bottom: 10px;
  font-weight: 500;
`;

const Element = styled.div``;
