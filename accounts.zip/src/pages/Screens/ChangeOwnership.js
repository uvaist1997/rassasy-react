import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";

import styled from "styled-components/macro";
import Snackbar from "@mui/material/Snackbar";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  accountDeleteUrl,
  changeOwnerShipUrl,
} from "../../api/AccountServicesAPI";
import { containsWhitespace, getCookie } from "../../functions/utils";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { VisibilityOff } from "@material-ui/icons";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import DletePasswordInput from "../../components/InputField/DletePasswordInput";
import { logoutSuccess } from "../../slices/user/userSlice";
import { useDispatch, useSelector } from "react-redux";
import { domain } from "../../settings";
import "../../Home.css";
import { checkUsernameUrl } from "../../api/AuthAPI";
import { Box, LinearProgress } from "@mui/material";
import { getSingleCompanyUrl } from "../../api/CompanyAPI";

function ChangeOwnership() {
  const navigate = useNavigate();
  const { companyid } = useParams();

  const [loading, setLoading] = useState(false);
  const { username, user_id } = useSelector((state) => state.user);
  const [access, setAccess] = useState(getCookie("VBID"));

  const [state, setState] = useState({
    is_username: false,
    owner_username_error: "",
    password_error: "",
    CompanyLogo: "",
    CompanyName: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
  });

  const fetchCompanyDetails = async () => {
    const getSingleCompanyResponse = await fetch(getSingleCompanyUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        CompanyID: companyid,
        user_id: user_id,
      }),
    }).then((response) => response.json());
    if (getSingleCompanyResponse.StatusCode == 6000) {
      setState({
        ...state,
        CompanyLogo: getSingleCompanyResponse.data.CompanyLogo,
        CompanyName: getSingleCompanyResponse.data.CompanyName,
      });
    }
  };
  const checkUsername = async (name, e) => {
    let value = e.target.value;
    if (name === "email") {
      setState((prevState) => {
        return {
          ...prevState,
          email_error: "",
        };
      });
    } else {
      if (containsWhitespace(value)) {
        setState((prevState) => {
          return {
            ...prevState,
            is_username: true,
            [name]: value,
            owner_username_error: "you can't use space for username",
          };
        });
        state.is_username = false;
      } else {
        await fetch(checkUsernameUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            accept: "application/json",
          },
          body: JSON.stringify({
            username: value,
          }),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.is_username) {
              setState((prevState) => {
                return {
                  ...prevState,
                  is_username: true,
                  [name]: value,
                  owner_username_error: "",
                };
              });
            } else {
              console.log("####$$%%%%%^^^^^^^");
              setState((prevState) => {
                return {
                  ...prevState,
                  is_username: false,
                  [name]: value,
                  owner_username_error: "Username is not exists.",
                };
              });
            }
          });
      }
    }
  };
  console.log(state, "companyid");
  const onSubmit = async (data) => {
    console.log(data);
    const { owner_username, password } = data;
    setLoading(true);

    const changeOwnerShipResponse = await fetch(changeOwnerShipUrl, {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        companyid: companyid,
        new_owner_username: owner_username,
        username: username,
        current_password: password,
      }),
    }).then((response) => response.json());
    const StatusCode = changeOwnerShipResponse.StatusCode;

    if (StatusCode == 6000) {
      setLoading(false);
      // handleClearAccount();
      // navigate("/");
      setState({ ...state, password_error: "", owner_username_error: "" });
    } else if (StatusCode == 6001) {
      setLoading(false);
      setState({ ...state, password_error: changeOwnerShipResponse.message });
    } else {
      setState({
        ...state,
        owner_username_error: changeOwnerShipResponse.message,
      });
    }
  };
  useEffect(() => {
    fetchCompanyDetails();
  }, [companyid]);
  return (
    <Container>
      <div>
        <TopHead>Change Ownership</TopHead>
        <MainContainer>
          <CompanyLogo>
            <ImgContainer>
              <LogoImg
                // src="https://uploads-ssl.webflow.com/632eab94c5e7a6cb31737519/632ead4fa3d580fa03608fa1_Group%202812.svg"
                src={state.CompanyLogo}
                loading="lazy"
                alt=""
              />
            </ImgContainer>
            <TextBlock2>{state.CompanyName}</TextBlock2>
          </CompanyLogo>
          <Owner className="owner">
            <CurrentOwner className="current-owner">
              Current Owner:
            </CurrentOwner>
            <OwnerName className="owner-name">{username}</OwnerName>
          </Owner>
          <FormContainer className="form-block w-form">
            <Form
              onSubmit={handleSubmit(onSubmit)}
              id="email-form"
              name="email-form"
              data-name="Email Form"
              method="get"
              className="change-owner"
            >
              <FormLabel for="New-Owner" className="new-user">
                New Owner
              </FormLabel>
              <InputContainer>
                <FormInput
                  {...register("owner_username", {
                    required: "Please enter new owner name.",
                    onChange: (e) => {
                      checkUsername("username", e);
                    },
                  })}
                  type="text"
                  className={
                    errors.owner_username || state.owner_username_error
                      ? "search-user w-input outline-red"
                      : "search-user w-input"
                  }
                  autofocus="true"
                  maxlength="256"
                  name="owner_username"
                  data-name="New Owner"
                  placeholder="User/Email"
                  id="New-Owner"
                  required=""
                />
                {errors.owner_username || state.owner_username_error ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace" />
                    <StyledReactTooltip
                      id="sadFace"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.owner_username ? (
                        <span>{errors.owner_username.message}</span>
                      ) : state.owner_username_error ? (
                        <span>{state.owner_username_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </InputContainer>
              <FormLabel for="Password" className="enter-password">
                Enter Your Password
              </FormLabel>
              <InputContainer>
                <FormInput
                  {...register("password", {
                    required: "Please enter your password.",
                  })}
                  type="password"
                  className={
                    errors.password || state.password_error
                      ? "password w-input outline-red"
                      : "password w-input"
                  }
                  maxlength="256"
                  name="password"
                  data-name="Password"
                  placeholder="Password"
                  id="Password"
                  required=""
                />
                {errors.password || state.password_error ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace" />
                    <StyledReactTooltip
                      id="sadFace"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.password ? (
                        <span>{errors.password.message}</span>
                      ) : state.password_error ? (
                        <span>{state.password_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </InputContainer>
              <ButtonContainer className="div-block-4">
                <ButtonCancel
                  onClick={() => navigate(-1)}
                  data-wait="Please wait..."
                  className="cancel-button w-button"
                >
                  Cancel
                </ButtonCancel>
                {!loading && (
                  <Button
                    type="submit"
                    data-wait="Please wait..."
                    className="save-button w-button"
                  >
                    Change Owner
                  </Button>
                )}
              </ButtonContainer>
            </Form>
            {loading ? (
              <ProgressBox sx={{ width: "100%" }}>
                <LinearProgress color="success" />
              </ProgressBox>
            ) : null}
            <FormDone className="w-form-done"></FormDone>
            <FormFail className="w-form-fail"></FormFail>
          </FormContainer>
        </MainContainer>
      </div>
    </Container>
  );
}

export default ChangeOwnership;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const TopHead = styled.div`
  display: flex;
  width: 419px;
  padding-bottom: 17px;
  flex-direction: column;
  align-items: center;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;
const MainContainer = styled.div`
  position: relative;
  width: 100%;
  padding: 26px;
  border-radius: 23px;
  background-color: #fff;
`;
const ProgressBox = styled(Box)`
  position: absolute;
  bottom: 0;
  left: 0;
  span {
    /* background-color: red; */
    border-bottom-left-radius: 23px;
    border-bottom-right-radius: 23px;
    margin: 0 auto;
    width: 396px;
    /* height: 10px; */
  }
`;
const CompanyLogo = styled.div`
  display: flex;
  margin-right: auto;
  margin-bottom: 18px;
  margin-left: auto;
  align-items: center;
`;
const LogoImg = styled.img`
  width: 100%;
  vertical-align: middle;
  display: inline-block;
`;
const ImgContainer = styled.div`
  width: 110px;
`;

const TextBlock2 = styled.div`
  margin-left: 9px;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;

const Owner = styled.div`
  display: flex;
  margin-bottom: 18px;
  font-family: Poppins, sans-serif;
  font-size: 15px;
`;
const CurrentOwner = styled.div`
  color: #7a7a7a;
`;
const OwnerName = styled.div`
  padding-left: 4px;
  font-weight: 500;
`;
const FormContainer = styled.div`
  margin-bottom: 0px;
`;
const Form = styled.form``;
const FormLabel = styled.label`
  margin-bottom: 9px;
  font-family: Poppins, sans-serif;
  color: #7a7a7a;
  font-size: 16px;
  font-weight: 400;
  text-align: center;
`;
const InputContainer = styled.div`
  position: relative;
`;
const FormInput = styled.input`
  margin-bottom: 16px;
  border: 1px solid #a8a7aa;
  border-radius: 9px;
  font-family: Poppins, sans-serif;
  font-size: 15px;
  &.outline-red {
    outline: 1px solid red;
  }
  &.w-input {
    display: block;
    width: 100%;
    /* height: 38px; */
    padding: 8px 12px;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #333333;
    vertical-align: middle;
    background-color: #ffffff;
    border: 1px solid #cccccc;
  }
  &.password {
    margin-bottom: 27px;
    border: 1px solid #a8a7aa;
    border-radius: 9px;
  }
`;
const ButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const ButtonCancel = styled.span`
  font-family: Poppins, sans-serif;
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-color: #000;
  }
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    /* background-image: linear-gradient(104deg, #033631, #005049); */
  }
  &.w-button {
    display: inline-block;
    padding: 9px 15px;
    /* background-color: #3898ec; */
    color: white;
    border: 0;
    line-height: inherit;
    text-decoration: none;
    cursor: pointer;
    /* border-radius: 0; */
  }
  &.save-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-image: linear-gradient(104deg, #033631, #005049);
    font-family: Poppins, sans-serif;
  }
`;
const Button = styled.button`
  font-family: Poppins, sans-serif;
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-color: #000;
  }
  &.cancel-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    /* background-image: linear-gradient(104deg, #033631, #005049); */
  }
  &.w-button {
    display: inline-block;
    padding: 9px 15px;
    /* background-color: #3898ec; */
    color: white;
    border: 0;
    line-height: inherit;
    text-decoration: none;
    cursor: pointer;
    /* border-radius: 0; */
  }
  &.save-button {
    width: 180px;
    height: 40px;
    border-radius: 9px;
    background-image: linear-gradient(104deg, #033631, #005049);
    font-family: Poppins, sans-serif;
  }
`;
const FormDone = styled.div`
  display: none;
  padding: 20px;
  text-align: center;
  background-color: #dddddd;
`;
const FormFail = styled.div`
  display: none;
  margin-top: 10px;
  padding: 10px;
  background-color: #ffdede;
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000; ;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
