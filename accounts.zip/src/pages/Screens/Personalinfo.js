import { Button, IconButton } from "@mui/material";
import React, { useState, useEffect } from "react";
import { TextField } from "@mui/material";
import styled from "styled-components/macro";
import ImageUpload from "../../components/ImageUploader/ImageUpload";
import EditIcon from "@mui/icons-material/Edit";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { useSelector } from "react-redux";
import { feddback_url, getUserDatas, profile_update_url } from "../../api/AuthAPI";
import { getCookie } from "../../functions/utils";
import { dataURLtoFile } from "../../functions/common";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import CustomAutoComplete from "../../components/AutoComplete/CustomAutoComplete";
import { countryUrl } from "../../api/CountryAPI";
import Snackbar, { SnackbarOrigin } from "@mui/material/Snackbar";
import MuiAlert, { AlertProps } from "@mui/material/Alert";
import { languageSuccess } from "../../slices/language/languageSlice";
import { useDispatch } from "react-redux";
import { useTranslation } from "react-i18next";


const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function Personalinfo() {
  const [t, i18n] = useTranslation("common");
  const dispatch = useDispatch();
  const { username, user_id } = useSelector((state) => state.user);
  const { language } = useSelector((state) => state.language);
    const [access, setAccess] = useState(getCookie("VBID"));
  // -------------------------------------------
  const [showBox, setShowBox] = useState({
    firstname: false,
    middlename: false,
    lastname: false,
    email: false,
    country: false,
    phone: false,
    address1: false,
    address2: false,
    languageBox: false,
    laguage: language === 'en'? t("English"): t("Arabic"),
  });

  const [feedBack ,setFeedBack] = useState("")

  const [personalData, setPersonalData] = useState({
    firstname: username,
    middlename: "",
    lastname: "",
    email: "",
    country: "",
    countryName: "",
    phone: "",
    address1: "",
    address2: "",
    call_save: false,
    countries: []
  });

  const [fileList, setFileList] = useState([]);


  const FetchData = async() => {
    const userInformations = await fetch(getUserDatas, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        user_id: user_id,
      }),
    }).then((response) => response.json());

    const countryResponse = await fetch(countryUrl, {
      method: "GET",
      headers: {
        "content-type": "application/json",
      },
    }).then((response) => response.json());


    if (userInformations.StatusCode == 6000) {
      let file = []
      if (userInformations.data.profile_pic) {
        file = await dataURLtoFile(userInformations.data.profile_pic)
        file = file[0].originFileObj;
      }
      setFileList(file);
      setPersonalData({
        ...personalData,
        firstname: userInformations.data.first_name,
        middlename: userInformations.data.middle_name,
        lastname: userInformations.data.last_name,
        email: userInformations.data.email,
        country: userInformations.data.countryid,
        countryName: userInformations.data.countryName,
        phone: userInformations.data.phone,
        address1: userInformations.data.address,
        address2: userInformations.data.address1,
        profile_pic: userInformations.data.profile_pic,
        countries: countryResponse.data,
      });
    }
  }

  const SaveDatas = async() => {
    if (fileList) {
      const formData = new FormData();
      let profile_pic = "";
      if (fileList) {
        profile_pic = fileList;
      }
      formData.append("profile_pic", profile_pic ? profile_pic : "");
      formData.append("user_id", user_id);
      formData.append("firstname", personalData.firstname);
      formData.append("middlename", personalData.middlename);
      formData.append("lastname", personalData.lastname);
      formData.append("email", personalData.email);
      formData.append("country", personalData.country);
      formData.append("phone", personalData.phone);
      formData.append("address1", personalData.address1);
      formData.append("address2", personalData.address2);
      const profile_update = await fetch(profile_update_url, {
        method: "POST",
        headers: {
          // "content-type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: formData,
      }).then((response) => response.json());
      if (profile_update.StatusCode == 6000) {
        
        setPersonalData((prevState) => {
          return {
            ...prevState,
            call_save: false,
          };
        });
      }
    }
  }

  useEffect(() => {
    if (personalData.call_save) {
      SaveDatas()
    }
  }, [personalData.call_save]);

  useEffect(() => {
    FetchData()
  }, []);


  const ReadAllDetails = (e) => {
    console.log(e.target.name);
    setPersonalData({
      ...personalData,
      [e.target.name]: e.target.value,
    });
  };

  const editInput = (e,name="inputs") => {
    if (e.key === "Enter" && name == "inputs") {
      setPersonalData((prevState) => {
        return {
          ...prevState,
          call_save: true,
        };
      });
      setShowBox({
        ...showBox,
        [e.target.name]: false,
      });
    } else if (name === "address1" || name === "address2") {
      setPersonalData((prevState) => {
        return {
          ...prevState,
          call_save: true,
        };
      });
      setShowBox({
        ...showBox,
        [name]: false,
      });
    }
  }

  const handleAutocomplete = (e,val, name) => {
    console.log(e);
    console.log(val);
    console.log(name);
    setPersonalData((prevState) => {
      return {
        ...prevState,
        call_save: true,
        country: val.id,
        countryName: val.Country_Name,
      };
    });
    setShowBox({
      ...showBox,
      country: false,
    });
  }

  const SendFeedBack = async() => {
    setSnack({ ...snack, open: true });
    const feedBackResponse = await fetch(feddback_url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        username: username,
        email: personalData.email,
        phone: personalData.phone,
        feedback: feedBack,
        full_name: personalData.firstname,
      }),
    }).then((response) => response.json());
    if (feedBackResponse.StatusCode === 6000) {
      setFeedBack("");
      setSnack({ ...snack, open: false });
    }
    
  }

  // this code snippet for snack bar
  const [snack, setSnack] = useState({
    open: false,
    vertical: "top",
    horizontal: "center",
  });
  const { vertical, horizontal, open } = snack;
  const handleClose = () => {
    setSnack({ ...snack, open: false });
  };

   const ChangeLanguage = (lg) => {
     setShowBox({
       ...showBox,
       languageBox: !showBox.languageBox,
       laguage: lg,
     });

     dispatch(
       languageSuccess({
         language: lg === "English" ? "en" : "ar",
       })
     );
     i18n.changeLanguage(lg === "English" ? "en" : "ar");
   };

  // --------------------------------------
  return (
    <FirstContainer>
      <SecondContainer>
        <HeadContainer>
          <P_SubscriptionTXT>{t("Personal Informations")}</P_SubscriptionTXT>
          <SmallTXT>
            {t("Info about you and your preferences across All Vikn services")}
          </SmallTXT>
        </HeadContainer>

        <Apps>
          <LeftContainer>
            <ImageUpload
              fileList={fileList}
              setFileList={setFileList}
              personalData={personalData}
              setPersonalData={setPersonalData}
            />
          </LeftContainer>

          <RightContainer>
            <Basic>{t("Basic Info")}</Basic>

            <Table cellSpacing="0px">
              <tbody>
                <SubContainer>
                  <TD1 className="borderBottom">
                    <LabelTxt>{t("FIRST NAME")}</LabelTxt>
                  </TD1>
                  <TD className="borderBottom">
                    {!showBox.firstname ? (
                      <Field1>
                        <EditContainer>
                          <NameTxt>{personalData.firstname}</NameTxt>
                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                firstname: !showBox.firstname,
                              })
                            }
                          />
                        </EditContainer>
                      </Field1>
                    ) : (
                      <Field1>
                        <TextField
                          id="outlined-basic"
                          placeholder="First Name"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          onKeyPress={(e) => editInput(e)}
                          name="firstname"
                          value={personalData.firstname}
                          style={{ width: "100%" }}
                        />
                      </Field1>
                    )}
                  </TD>
                </SubContainer>
                <SubContainer>
                  <TD1 className="borderBottom">
                    <LabelTxt>{t("MIDDLE NAME")}</LabelTxt>
                  </TD1>
                  <TD className="borderBottom">
                    {!showBox.middlename ? (
                      <Field1>
                        <EditContainer>
                          <NameTxt>{personalData.middlename}</NameTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                middlename: !showBox.middlename,
                              })
                            }
                          />
                        </EditContainer>
                      </Field1>
                    ) : (
                      <Field1>
                        <TextField
                          id="outlined-basic"
                          placeholder="Middle Name"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="middlename"
                          onKeyPress={(e) => editInput(e)}
                          style={{ width: "100%" }}
                          value={personalData.middlename}
                        />
                      </Field1>
                    )}
                  </TD>
                </SubContainer>
                <SubContainer>
                  <TD1>
                    <LabelTxt>{t("LAST NAME")}</LabelTxt>
                  </TD1>
                  <TD>
                    {!showBox.lastname ? (
                      <Field1>
                        <EditContainer>
                          <NameTxt>{personalData.lastname}</NameTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                lastname: !showBox.lastname,
                              })
                            }
                          />
                        </EditContainer>
                      </Field1>
                    ) : (
                      <Field1>
                        <TextField
                          id="outlined-basic"
                          placeholder="Last Name"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="lastname"
                          onKeyPress={(e) => editInput(e)}
                          style={{ width: "100%" }}
                          value={personalData.lastname}
                        />
                      </Field1>
                    )}
                  </TD>
                </SubContainer>
              </tbody>
            </Table>
          </RightContainer>
        </Apps>

        <MiddleContainer>
          <Middle>
            <Basic>{t("Basic Info")}</Basic>

            <Table cellSpacing="0px">
              <tbody>
                <SubContainer>
                  <TD1 className="borderBottom">
                    <LabelTxt>{t("EMAIL")}</LabelTxt>
                  </TD1>
                  <TD className="borderBottom">
                    {!showBox.email ? (
                      <Field2>
                        <EditContainer>
                          <NameTxt>{personalData.email}</NameTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                email: !showBox.email,
                              })
                            }
                          />
                        </EditContainer>
                      </Field2>
                    ) : (
                      <Field2>
                        <TextField
                          id="outlined-basic"
                          placeholder="Email"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="email"
                          onKeyPress={(e) => editInput(e)}
                          style={{ width: "100%" }}
                          value={personalData.email}
                        />
                      </Field2>
                    )}
                  </TD>
                </SubContainer>
                <SubContainer>
                  <TD1 className="borderBottom">
                    <LabelTxt>{t("COUNTRY")}</LabelTxt>
                  </TD1>
                  <TD className="borderBottom">
                    {!showBox.country ? (
                      <Field2>
                        <EditContainer>
                          <NameTxt>{personalData.countryName}</NameTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                country: !showBox.country,
                              })
                            }
                          />
                        </EditContainer>
                      </Field2>
                    ) : (
                      <Field2>
                        <CustomAutoComplete
                          handleAutocomplete={handleAutocomplete}
                          list={personalData.countries}
                          id={personalData.country}
                        />
                        {/* <TextField
                          id="outlined-basic"
                          placeholder="County"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="country"
                          onKeyPress={(e) => editInput(e)}
                          style={{ width: "100%" }}
                        /> */}
                      </Field2>
                    )}
                  </TD>
                </SubContainer>
                <SubContainer>
                  <TD1>
                    <LabelTxt>{t("PHONE")}</LabelTxt>
                  </TD1>
                  <TD>
                    {!showBox.phone ? (
                      <Field2>
                        <EditContainer>
                          <NameTxt>{personalData.phone}</NameTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                phone: !showBox.phone,
                              })
                            }
                          />
                        </EditContainer>
                      </Field2>
                    ) : (
                      <Field2>
                        <TextField
                          id="outlined-basic"
                          placeholder="Phone"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="phone"
                          onKeyPress={(e) => editInput(e)}
                          style={{ width: "100%" }}
                          value={personalData.phone}
                        />
                      </Field2>
                    )}
                  </TD>
                </SubContainer>
              </tbody>
            </Table>
          </Middle>
        </MiddleContainer>
        {/* ============================================ */}
        <MiddleContainer2>
          <Middle>
            <Basic>{t("Location Info")}</Basic>

            <Table cellSpacing="0px">
              <tbody>
                <SubContainer>
                  <TD2 className="borderBottom">
                    <LabelTxt>{t("ADDRESS")}</LabelTxt>
                    <SelectContainer>
                      <StyledSelect>
                        <option name="home">{t("Home")}</option>
                        <option name="work">{t("Work")}</option>
                      </StyledSelect>
                    </SelectContainer>
                  </TD2>
                  <TD3
                    className="borderBottom"
                    width={showBox.address1 ? 65 : 70}
                  >
                    {!showBox.address1 ? (
                      <Field3>
                        <EditContainer2>
                          <DefaultTxt>{personalData.address1}</DefaultTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                address1: !showBox.address1,
                              })
                            }
                          />
                        </EditContainer2>
                      </Field3>
                    ) : (
                      <Field3>
                        <TextField
                          id="outlined-basic"
                          placeholder="Address"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="address1"
                          style={{ width: "100%" }}
                          multiline
                          size="small"
                          // onKeyPress={(e) => editInput(e)}
                          value={
                            personalData.address1 ? personalData.address1 : ""
                          }
                        />
                      </Field3>
                    )}
                  </TD3>
                  {showBox.address1 ? (
                    <TD2 className="borderBottom">
                      <AddressButton
                        name="address1"
                        onClick={(e) => editInput(e, "address1")}
                      />
                    </TD2>
                  ) : null}
                </SubContainer>
                <SubContainer>
                  <TD2>
                    <LabelTxt>{t("ADDRESS")}</LabelTxt>
                    <SelectContainer>
                      <StyledSelect>
                        <option name="home">{t("Home")}</option>
                        <option name="work">{t("Work")}</option>
                      </StyledSelect>
                    </SelectContainer>
                  </TD2>
                  <TD3 width={showBox.address2 ? 65 : 70}>
                    {!showBox.address2 ? (
                      <Field3>
                        <EditContainer2>
                          <DefaultTxt>{personalData.address2}</DefaultTxt>

                          <EditIcon
                            onClick={() =>
                              setShowBox({
                                ...showBox,
                                address2: !showBox.address2,
                              })
                            }
                          />
                        </EditContainer2>
                      </Field3>
                    ) : (
                      <Field3>
                        <TextField
                          id="outlined-basic"
                          placeholder="Address"
                          variant="outlined"
                          onChange={ReadAllDetails}
                          name="address2"
                          style={{ width: "100%" }}
                          multiline
                          size="small"
                          // onKeyPress={(e) => editInput(e)}
                          value={
                            personalData.address2 ? personalData.address2 : ""
                          }
                        />
                      </Field3>
                    )}
                  </TD3>
                  {showBox.address2 ? (
                    <TD2 className="borderBottom">
                      <AddressButton
                        name="address2"
                        onClick={(e) => editInput(e, "address2")}
                      />
                    </TD2>
                  ) : null}
                </SubContainer>
              </tbody>
            </Table>
          </Middle>
        </MiddleContainer2>
        {/* =================================================================== */}
        <FinalContainer>
          <Middle1>
            <Left1>
              <Basic>{t("Preference")}</Basic>
              <SubContainer2>
                <Td4>
                  <ImgContainer>
                    <Img src="../../images/icons/language.svg" />
                  </ImgContainer>
                </Td4>
                <Td5>
                  <Field4>
                    <EditContainer3>
                      <LanguageContainer>
                        <DefaultTxt1>{t("LANGUAGE")}</DefaultTxt1>
                        <DefaultTxt2>{showBox.laguage}</DefaultTxt2>
                      </LanguageContainer>

                      <EditIcon
                        onClick={() =>
                          setShowBox({
                            ...showBox,
                            languageBox: !showBox.languageBox,
                          })
                        }
                      />
                    </EditContainer3>

                    <PositionContainer show={showBox.languageBox}>
                      <UL>
                        <Li onClick={() => ChangeLanguage("Arabic")}>{t("Arabic")}</Li>
                        <Li onClick={() => ChangeLanguage("English")}>
                          {t("English")}
                        </Li>
                      </UL>
                    </PositionContainer>
                  </Field4>
                </Td5>
              </SubContainer2>
            </Left1>
          </Middle1>
          <Middle1>
            <Right1>
              <Basic>{t("Send Us Feedback")} </Basic>

              <SmallContainer>
                <Input1
                  type="text"
                  placeholder={t("Type Here")}
                  value={feedBack}
                  onChange={(e) => setFeedBack(e.target.value)}
                />
                <IconButton onClick={() => SendFeedBack()}>
                  <Arrow />
                </IconButton>
              </SmallContainer>
            </Right1>
          </Middle1>
        </FinalContainer>
      </SecondContainer>
      <Snackbar
        anchorOrigin={{ vertical, horizontal }}
        open={open}
        onClose={handleClose}
        message="I love snacks"
        key={vertical + horizontal}
      >
        <Alert severity="success">{t("your feed back is sending...")}</Alert>
      </Snackbar>
    </FirstContainer>
  );
}

export default Personalinfo;

const UL = styled.ul`
  list-style: none;
  padding: 8px;
  font-size: 12px;
`;
const Li = styled.li`
  border-bottom: 1px solid grey;
  cursor: pointer;
  &:hover {
    background-color: #ffff;
    color: #0000008f;
  }
`;
const PositionContainer = styled.div`
  border-radius: 4px;

  /* opacity: ${({ show }) => (show ? "1" : "0")}; */
  display: ${({ show }) => (show ? "block" : "none")};
  transition: 0.3s cubic-bezier(0.17, 0.24, 0.47, 0.7);
  position: absolute;
  top: 38px;
  min-width: 100px;
  color: #ffff;
  background: #0000008f;
  right: 0;
`;

const SmallContainer = styled.div`
  width: 100%;
  svg {
    margin-right: 5px;
  }
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Arrow = styled(ArrowForwardIcon)`
  && {
    font-size: 1rem;
    color: black;
  }
`;

const Input1 = styled.input`
  font-size: 12px;
  padding-left: 0;
  width: 100%;
  border-right: none;
  border-left: none;
  border-top: none;
  border-bottom: 1px solid black;
  outline: unset;
  ::placeholder {
    color: #9e9e9e;
  }
`;
const Td4 = styled.td`
  @media (max-width: 762px) {
    /* width: 2%; */
  }
`;

const Td5 = styled.td`
  width: 100%;
  @media (max-width: 762px) {
    /* width: 48%; */
  }
`;
const LanguageContainer = styled.div`
  text-align: left;
`;
const Img = styled.img`
  width: 100%;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 22px;
  height: 22px;
`;
const Middle1 = styled.div`
  padding: 20px 20px 9px 20px;
  border-radius: 23px;
  background-color: white;
`;
const Left1 = styled.div`
  text-align: left;
`;
const Right1 = styled.div`
  text-align: left;
`;
const FinalContainer = styled.div`
  display: grid;

  width: 100%;

  column-gap: 20px;

  grid-template-columns: 1fr 1fr;
  @media (max-width: 762px) {
    grid-template-columns: 1fr;
    row-gap: 20px;
  }
`;
const DefaultTxt = styled.span`
  font-size: 12px;
  text-align: left;
  width: 167px;
`;
const DefaultTxt1 = styled(DefaultTxt)`
  width: 167px;
  font-size: 12px;
  text-align: left;
  color: #656565;
`;
const DefaultTxt2 = styled.p`
  width: 167px;
  font-size: 12px;
  line-height: 10px;
  text-align: left;
  color: black;
  margin: 0;
`;
const StyledSelect = styled.select`
  outline: none;
  line-height: 8px;
  border: none;
  margin-left: -3px;
  font-size: 11px;
  color: #030d8f;
  background-color: white;
`;

const SelectContainer = styled.div`
  line-height: 8px;
`;

const MiddleContainer = styled.div`
  width: 100%;
  display: grid;
  grid-template-columns: 1fr;
`;

const MiddleContainer2 = styled(MiddleContainer)``;
const Table = styled.table`
  width: 100%;

  .borderBottom {
    border-bottom: 1px solid #dfdfdf;
  }
`;
const TD = styled.td`
  width: 50%;
  text-align: right;
`;
const TD1 = styled(TD)`
  text-align: left;
`;
const TD2 = styled(TD)`
  text-align: left;
  width: 25%;
  vertical-align: top;
`;
const TD3 = styled(TD)`
  /* width: 65%; */
  width: ${({ width }) => (width == 70 ? '70% ': '65%')};
`;
const SubContainer = styled.tr`
  width: 100%;
  border-collapse: collapse;

  width: 100%;
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    top: -6 !important;
  }

  input {
    padding: 8.5px 14px !important;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    /* border: unset !important; */
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  :nth-child(2) {
    border: unset;
  }
`;

const SubContainer4 = styled.tr`
  width: 100%;
  border-collapse: collapse;

  width: 100%;
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    top: -6 !important;
  }

  input {
    padding-left: unset;
  }

  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    /* border: unset !important; */
    border-color: #d4d4d4 !important;
    border-width: 1px !important;
  }
  :nth-child(2) {
    border: unset;
  }
`;
const SubContainer2 = styled(SubContainer)`
  vertical-align: middle;
`;
const LabelTxt = styled.label`
  font-size: 11px;
  color: #656565;
  font-weight: 500;

  text-align: left;

  /* padding-left: 10px; ; */
`;
const Basic = styled.span`
  font-size: 16px;
  width: 100%;
  text-align: left;
  font-weight: 500;
`;
const Field1 = styled.div`
  width: 100%;
  .MuiTextField-root {
    margin-top: 5px;
    input {
      font-size: 12px !important;
    }
    margin-bottom: 5px;
  }
`;
const Field2 = styled(Field1)`
  width: 100%;
`;
const Field3 = styled(Field1)`
  width: 100%;
`;

const Field4 = styled(Field1)`
  width: 100%;
  position: relative;
`;
const EditContainer = styled(Button)`
  && {
    padding: 10px;
    color: black !important;
    text-transform: unset !important;
    width: 100%;
    justify-content: left;
    border-radius: 2px;
    font-family: "poppins", sans-serif;
    display: flex;
    justify-content: space-between;
    padding: 1px 12px;
    align-items: center;
    border-radius: 4px;
    height: 41px;

    /* border: 1px solid #d4d4d4; */
    svg {
      margin-right: 5px;
      font-size: 1rem;
      color: #787878 !important;
    }
  }
`;

const EditContainer2 = styled(EditContainer)`
  && {
    height: unset;
  }
`;
const EditContainer3 = styled(EditContainer)`
  && {
    width: 100%;
  }
`;
const NameTxt = styled.span`
  font-size: 12px;
  text-align: left;
`;
const RightContainer = styled.div`
  background-color: white;
  border-radius: 23px;
  padding: 20px 20px 9px 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 5px;

  margin-left: 20px;
  @media (max-width: 762px) {
    margin-left: unset;
    margin-top: 20px;
  }
  @media (max-width: 400px) {
    padding: 20px 10px 9px 10px;
  }
`;
const Middle = styled(RightContainer)`
  margin-left: unset;
  @media (max-width: 400px) {
    padding: 20px 10px 9px 10px;
  }
`;

const Left = styled.div`
  max-width: 261px;
  height: 307px;
  background-color: white;
  border-radius: 23px;
  padding: 15px 25px;
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    /* width: 614px; */
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;

const LeftContainer = styled.div`
  background-color: white;
  border-radius: 23px;
  padding: 13px;
  padding: 15px 0px;
  display: flex;
  flex-direction: column;
  align-items: center;
  @media (max-width: 762px) {
    width: 189px;
    margin: auto;
  }
  height: 187px;
`;

const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  height: 732px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const Apps = styled.div`
  border-radius: 23px;

  display: grid;
  grid-template-columns: 1.5fr 3fr;

  @media (max-width: 762px) {
    grid-template-columns: 1fr;
  }
`;
const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 18px;
`;

const AddressButton = styled(CheckCircleOutlineIcon)`
  margin-top: 12px;
  cursor: pointer;
`;