import { Button, FormControlLabel } from "@mui/material";
import React from "react";
import styled from "styled-components/macro";
import Checkbox from "@mui/material/Checkbox";
import { useNavigate } from "react-router-dom";

function AccountDeleteConfermation() {
  const navigate = useNavigate();
  return (
    <div>
      <FirstContainer>
        <SecondContainer>
          <HeadContainer>
            <P_SubscriptionTXT>Account Deletion</P_SubscriptionTXT>
            <SmallTXT>Please Read The Below Terms Before You Continue</SmallTXT>
          </HeadContainer>

          <WhiteBox>
            <ScrollContainer1>
              {/* {list.acivate.map((y) => (
                <Apps1>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src="../../images/icons/companylogo.svg" />
                      </RassasyContainer>
                      <ViknTxt>{y.service}</ViknTxt>
                    </Rassasy2>
                    <Button_Container>
                      <StyledButton1 variant="text" status={y.status}>
                        {y.status}
                      </StyledButton1>
                    </Button_Container>
                  </Card1>
                </Apps1>
              ))} */}
            </ScrollContainer1>
          </WhiteBox>

          <Apps>
            <DeleteContainer>
              <Form_controlLabel
                control={<Checkbox defaultChecked color="default" />}
                label="I Agree to the terms"
              />

              <StyledButton2
                type="submit"
                variant="contained"
                disableElevation
                onClick={() => {
                  navigate("/account-deletion");
                }}
              >
                Delete
              </StyledButton2>
            </DeleteContainer>
          </Apps>
        </SecondContainer>
      </FirstContainer>
    </div>
  );
}

export default AccountDeleteConfermation;

const Form_controlLabel = styled(FormControlLabel)`
  && {
    .css-i4bv87-MuiSvgIcon-root {
      font-size: 1.4rem;
      @media (max-width: 488px) {
        font-size: 1rem;
      }
    }
    span {
      font-family: "poppins", sans-serif;
      font-size: 15px;
      @media (max-width: 488px) {
        font-size: 13px;
      }
    }
  }
`;

const DeleteContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StyledButton2 = styled(Button)`
  && {
    height: 30px;
    width: 20vw;
    max-width: 164px;

    background-color: #840000;
    @media (max-width: 488px) {
      font-size: 11px;
      height: 25px;
      width: 17vw;
    }
    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    font-family: "Poppins", sans-serif;
  }
`;
const WhiteBox = styled.div`
  background-color: white;
  border-radius: 23px;
`;

const ScrollContainer = styled.div`
  height: 572px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;
const ScrollContainer1 = styled(ScrollContainer)`
  height: 400px;
`;

const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  font-family: "poppins", sans-serif;

  gap: 20px;
`;

const Apps = styled.div`
  background-color: white;

  border-radius: 23px;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }

  padding: 10px 20px;

  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
`;

const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 16px;
`;
