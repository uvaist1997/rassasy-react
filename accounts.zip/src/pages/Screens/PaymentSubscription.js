import { Button } from "@mui/material";
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useSelector } from "react-redux";
import styled from "styled-components/macro";
import { listAccountServicesUrl } from "../../api/AccountServicesAPI";
import { payment_suscriptionUrl } from "../../api/AuthAPI";
import { getCookie } from "../../functions/utils";

function PaymentSubscription() {
  const [t] = useTranslation("common");
  const [access, setAccess] = useState(getCookie("VBID"));
  const { username, user_id } = useSelector((state) => state.user);
  const [state, setState] = useState({
    apps: [],
    addOns: [],
    data: [
      {
        status: "Active",
      },
      {
        status: "Inactive",
      },
      {
        status: "Inactive",
      },
      {
        status: "Active",
      },
      {
        status: "Active",
      },
      {
        status: "Inactive",
      },
    ],
  });



    useEffect(() => {
      FetchData();
    }, []);
  
  const FetchData = async () => {
    const subscription_datas = await fetch(listAccountServicesUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify({
        user_id: user_id,
      }),
    }).then((response) => response.json());

    if (subscription_datas.StatusCode == 6000) {
      let apps = subscription_datas.data.filter((i) => i.addon == false);
      let addOns = subscription_datas.data.filter((i) => i.addon == true);
      setState({
        ...state,
        apps,
        addOns
      });
    }
  };

  

  console.log("state.apps");
  console.log(state.apps);
  return (
    <FirstContainer>
      <SecondContainer>
        <HeadContainer>
          <P_SubscriptionTXT>{t("Payment & Subscription")}</P_SubscriptionTXT>
          <SmallTXT>{t("Your Subscriptions and Payment Settings")}</SmallTXT>
        </HeadContainer>

        <Apps>
          <AppTxt>{t("Apps")}</AppTxt>

          <ApplicationTxt>{t("Applications You Use")}</ApplicationTxt>

          <AppsContainer>
            {state.apps.map((i) => (
              <RassayButton>
                <SmallCard>
                  <Card1>
                    <Rassasy2>
                      <RassasyContainer>
                        <ImgLogo src={i.logo} />
                      </RassasyContainer>
                      <ViknTxt>{i.service}</ViknTxt>
                    </Rassasy2>
                    <Button_Container>
                      <EditionContainer>
                        <FreeTxt>{t("Edition")}</FreeTxt>
                        <ProfessionalTxt>{t("Professional")}</ProfessionalTxt>
                      </EditionContainer>
                      {/* <StyledButton
                        type="submit"
                        variant="contained"
                        disableElevation
                      >
                        {t("Upgrade")}
                      </StyledButton> */}
                    </Button_Container>
                  </Card1>
                </SmallCard>
              </RassayButton>
            ))}
          </AppsContainer>
        </Apps>

        <BottomContainer>
          <Left>
            <InnerContainer>
              <AppTxt>{t("Add Ons")}</AppTxt>

              <ApplicationTxt>
                {t("Add On Included in your Subscription")}
              </ApplicationTxt>

              <ScrollContainer>
                {state.addOns.map((i) => (
                  <RassayButton>
                    <SmallCard>
                      <Card1>
                        <Rassasy2>
                          <RassasyContainer>
                            <ImgLogo src={i.logo} />
                          </RassasyContainer>
                          <h4 style={{ fontSize: "13px" }}>{i.service}</h4>
                        </Rassasy2>
                        <FreeTxt1 status={i.status}>{i.status}</FreeTxt1>
                      </Card1>
                    </SmallCard>
                  </RassayButton>
                ))}
              </ScrollContainer>
            </InnerContainer>
          </Left>

          <Right>
            <InnerContainer>
              <AppTxt>{t("Recent Payments")}</AppTxt>

              <ApplicationTxt>{t("Payment you Made Recently")}</ApplicationTxt>

              <RecentPayment>
                <Upgrade>{t("Upgrade")}</Upgrade>

                <NumberTxt>
                  <Number1>-</Number1>
                  <Number2></Number2>
                </NumberTxt>
              </RecentPayment>
              <RecentPayment>
                <Upgrade>{t("Added Users")}</Upgrade>

                <NumberTxt>
                  <Number1>-</Number1>
                  <Number2></Number2>
                </NumberTxt>
              </RecentPayment>
            </InnerContainer>
          </Right>
        </BottomContainer>
      </SecondContainer>
    </FirstContainer>
  );
}

export default PaymentSubscription;
const Upgrade = styled.span`
  font-size: 13px;
  font-weight: 500;
`;
const Number1 = styled.span`
  font-size: 12px;
  font-weight: 500;
`;
const Number2 = styled.span`
  font-size: 10px;
  color: #606060;
`;

const AppsContainer = styled.div`
display: flex;
flex-direction: column ;
width: 100%;
`
const NumberTxt = styled.div`
  display: flex;
  line-height: 12px;
  flex-direction: column;
  text-align: right;
`;

const RecentPayment = styled.div`
  width: 100%;
  margin-top: 23px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const ScrollContainer = styled.div`
  height: 260px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const BottomContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: space-between;
  max-width: 642px;
  width: 80vw;
  @media (max-width: 738px) {
    width: 87vw;
  }
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    width: 100%;
  }
`;
const Left = styled.div`
  max-width: 261px;
  height: 307px;
  background-color: white;
  border-radius: 23px;
  padding: 15px 25px;
  @media only screen and (min-width: 739px) and (max-width: 800px) {
    /* width: 129vw; */

    /* width: 614px; */
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;
const InnerContainer = styled.div`
  display: flex;

  align-items: flex-start;
  flex-direction: column;
`;
const Right = styled(Left)`
  width: 261px;

  @media only screen and (min-width: 739px) and (max-width: 800px) {
    max-width: 590px;
  }

  @media (max-width: 738px) {
    width: 83vw;
    max-width: 627px;
  }
`;

const ViknTxt = styled.h4`
  font-size: 15px;
  @media (max-width: 446px) {
    font-size: 13px;
  }
`;

const EditionContainer = styled.div`
  line-height: 12px;
  text-align: right;
`;

const Button_Container = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
`;
const ProfessionalTxt = styled.p`
  margin: 0;
  font-size: 12px;
  font-family: "poppins", sans-serif;
  @media (max-width: 446px) {
    font-size: 11px;
  }
`;
const StyledButton = styled(Button)`
  && {
    height: 40px;
    font-family: "poppins", sans-serif;
    /* background-color: #840000; */
    background-image: linear-gradient(274deg, #033631, #005049);
    border-radius: 9px;
    text-transform: capitalize;
    :hover {
      background-color: #840000;
    }

    @media (max-width: 446px) {
      font-size: 12px;
      padding: 6px 8px;
      height: 32px;
    }
  }
`;
const RassayButton = styled(Button)`
  &.css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background-color: #d4d4d4 !important;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    padding: 1px 8px !important;
  }
  && {
    color: black !important;
    text-transform: unset !important;
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    min-height: 53px;
    border-radius: 22px;
  }

  align-items: center;
  border-radius: 4px;
  height: 41px;
`;

const SmallCard = styled.div`
  width: 100%;
  margin-top: 10px;
  :nth-child(1) {
    margin-top: unset;
  }
`;

const RassasyContainer = styled.div`
  width: 35px;
  height: 35px;
`;

const Rassasy2 = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  @media (max-width: 446px) {
    gap: 0px;
  }
`;
const Card1 = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;
const FreeTxt = styled.span`
  font-size: 9px;
  font-family: "poppins", sans-serif;
  color: #9e9e9e;
`;

const FreeTxt1 = styled.span`
  color: ${({ status }) => (status === "Active" ? "#008E26" : "#9A9A9A")};

  font-family: "poppins", sans-serif;
`;

const RevenueTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const RevenueTxt = styled.h4`
  font-size: 15px;
  font-weight: bold;
`;
const FirstContainer = styled.div``;

const SecondContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;
const ApplicationTxt = styled.span`
  font-size: 12px;
  color: #919191;
`;
const Apps = styled.div`
  background-color: white;
  padding: 15px;
  border-radius: 23px;
  /* gap: 10px; */
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  max-width: 614px;
  width: 83vw;
`;
const AppTxt = styled.span`
  font-size: 16px;
  font-weight: 500;
`;
const HeadContainer = styled.div`
  display: flex;
  flex-direction: column;
  /* gap: 10px; */
`;
const P_SubscriptionTXT = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
`;
const SmallTXT = styled.span`
  color: #7b7b7b;
  font-size: 18px;
`;
