import { TextField } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import styled from "styled-components/macro";
import VisibilityIcon from "@material-ui/icons/Visibility";

import { showPassword } from "../../functions/utils";
import { forgotPasswordConfirmUrl } from "../../api/AuthAPI";
import { useNavigate, useParams } from "react-router-dom";

const ForgotPasswordConfirm = (props) => {
  const navigate = useNavigate();
  // const { token, uidb64 } = useParams();
  const { uidb64 } = useParams();
  console.log(uidb64);
  console.log(useParams());
  const [state, setState] = useState({
    loading: true,
    message: "",
    statusCode: 6000,
    new_password1: "",
    new_password2: "",
    errors: {
      new_password1: "",
      new_password2: "",
    },
  });

  useEffect(() => {
    setState({ ...state, loading: false });
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let is_valid = handleValidation();
    // const token = props.match.params.token;
    // const uidb64 = props.match.params.uidb64;

    const { new_password1, new_password2 } = state;
    console.log(new_password1);
    console.log(new_password1);
    console.log(new_password2);
    if (is_valid) {
      fetch(`${forgotPasswordConfirmUrl}${uidb64}`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          new_password1,
          new_password2,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.success === 6000) {
            setState({ ...state, message: response.message, statusCode: 6000 });
            navigate("/signin");
          } else {
            setState({ ...state, message: response.message, statusCode: 6001 });
          }
        });
    }
  };
  const handleValidation = () => {
    let errors = {};
    let formIsValid = true;

    //new password
    if (!state.new_password1) {
      formIsValid = false;
      errors["new_password1"] = "Cannot be empty";
    } else if (state.new_password1 < 8) {
      formIsValid = false;
      errors["new_password1"] = "Your password must be at least 8 characters";
    } else if (state.new_password1) {
      if (state.new_password1.search(/[a-z]/i) < 0) {
        formIsValid = false;
        errors["new_password1"] =
          "Your password must contain at least one letter";
      }
    }
    if (state.new_password1) {
      if (state.new_password1.search(/[0-9]/) < 0) {
        formIsValid = false;
        errors["new_password1"] =
          "Your password must contain at least one digit";
      }
    }
    //new_password2
    if (!state.new_password2) {
      formIsValid = false;
      errors["new_password2"] = "Cannot be empty";
    }

    // check password same
    if (state.new_password1 && state.new_password2) {
      if (state.new_password1 !== state.new_password2) {
        formIsValid = false;
        errors["new_password1"] = "Not matching";
        errors["new_password2"] = "Not matching";
      }
    }

    setState({ ...state, errors: errors });
    return formIsValid;
  };
  return (
    <Container>
      <CenterContainer>
        <HeadingContainer>
          {/* <Heading>{"nattumuttam"}</Heading>
        <HeadingImageContainer>
          <HeadingImage src="../images/bird.png"></HeadingImage>
        </HeadingImageContainer> */}
        </HeadingContainer>
        <Form onSubmit={(e) => handleSubmit(e)}>
          <InputGroup>
            <Label>{"new password"}</Label>
            <StyledInput
              fullWidth
              id="new_password1"
              name="new_password1"
              size="small"
              variant="outlined"
              type="password"
              onChange={(e) => handleChange(e)}
            />
            <ShowPasswordButton onClick={() => showPassword("new_password1")}>
              <VisibilityIcon />
            </ShowPasswordButton>
            <ErrorText>{state.errors.new_password1}</ErrorText>
          </InputGroup>
          <InputGroup>
            <Label>{"confirm new password"}</Label>
            <StyledInput
              fullWidth
              id="new_password2"
              name="new_password2"
              size="small"
              variant="outlined"
              type="password"
              onChange={(e) => handleChange(e)}
            />
            <ShowPasswordButton onClick={() => showPassword("new_password2")}>
              <VisibilityIcon />
            </ShowPasswordButton>
            <ErrorText>{state.errors.new_password2}</ErrorText>
          </InputGroup>
          <ErrorText statusCode={state.statusCode}>{state.message}</ErrorText>
          <SubmitButtonContainer>
            <SubmitButton>{"submit"}</SubmitButton>
          </SubmitButtonContainer>
          {/* <LeafContainer>
          <Leaf src="../images/leaf.svg" />
        </LeafContainer> */}
        </Form>
      </CenterContainer>
    </Container>
  );
};

export default ForgotPasswordConfirm;

const Container = styled.div`
  background: url("images/login-background.webp");
  background-size: cover;
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  @media only screen and (max-width: 460px) {
    padding-bottom: 100px;
  }
`;
const HeadingContainer = styled.div`
  position: relative;
  margin-bottom: 35px;
`;
const Heading = styled.h1`
  font-family: "fml-nanditharegular";
  color: #136516;
  font-size: 70px;
  text-align: center;
  ${({ language }) =>
    language === "en" &&
    `
    font-size: 45px;
    font-family: Manjari;
    text-transform: capitalize;
  `}
`;
const HeadingImageContainer = styled.div`
  width: 80px;
  position: absolute;
  top: -41px;
  left: -30px;
  ${({ language }) =>
    language === "en" &&
    `
    top: -52px;
    left: unset;
    right: -30px;
    transform: scale(-1, 1);
  `}
  @media only screen and (max-width: 460px) {
    ${({ language }) =>
      language === "en" &&
      `
    top: -47px;
    left: unset;
    right: -30px;
    transform: scale(-1, 1);
  `}
  }
`;
const HeadingImage = styled.img`
  width: 100%;
`;
const Form = styled.form`
  width: 100%;

  position: relative;
  z-index: 10;
`;
const InputGroup = styled.div`
  margin-bottom: 30px;
  text-align: center;
  position: relative;
  z-index: 10;
  &:nth-child(2) {
    margin: 0;
  }
`;
const Label = styled.p`
  text-align: left;
  text-transform: capitalize;
  font-size: 16px;
  margin-bottom: 5px;
`;
const StyledInput = styled(TextField)`
  input {
    color: #000;
  }
  & textarea {
    min-height: 120px;
    max-height: 120px;
    color: #fff;
    font-weight: bold;
  }
  & .MuiOutlinedInput-root {
    border-radius: 5px;
    border: 2px solid #fff;
    background: #e6e6e6;
  }
  fieldset {
    border: 0;
  }
  &::-webkit-input-placeholder {
    color: #fff;
  }
  & .MuiInputBase-input::-webkit-input-placeholder {
    color: #fff;
    opacity: 1;
    font-family: "fml-sruthyregular";
    font-size: 20px;
    font-weight: bold;
    letter-spacing: 1px;
  }
  & .MuiOutlinedInput-inputMarginDense {
    padding-top: 7.5px;
    padding-bottom: 7.5px;
    padding-right: 40px;
  }
`;
const LeafContainer = styled.div`
  width: 250px;
  position: absolute;
  left: -93px;
  top: -44px;
  z-index: 0;
  @media only screen and (max-width: 1250px) {
    width: 200px;
    left: -76px;
    top: -8px;
  }
`;
const Leaf = styled.img`
  width: 100%;
`;
const VillageLogoContainer = styled.div`
  width: 180px;
  position: absolute;
  bottom: 25px;
  left: 25px;
  @media only screen and (max-width: 460px) {
    width: 150px;
    left: 0;
    right: 0;
    margin: 0 auto;
  }
`;
const VillageLogo = styled.img`
  width: 100%;
`;
const SubmitButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 20px;
  position: relative;
  z-index: 5;
`;
const SubmitButton = styled.button`
  cursor: pointer;
  color: #fff;
  background: #1f9100;
  padding: 10px 20px 10px 20px;
  border-radius: 3px;
  outline: none;
  position: relative;
  border: 0;
`;
const ErrorText = styled.p`
  color: ${({ statusCode }) => (statusCode === 6000 ? "green" : "red")};
  text-align: center;
  margin-top: 6px;
  font-size: 12px;
  position: relative;
  z-index: 5;
`;
const ShowPasswordButton = styled.span`
  cursor: pointer;
  position: absolute;
  top: 38px;
  right: 10px;
  svg {
    width: 20px;
  }
`;
const CenterContainer = styled.div`
  width: 23%;
  display: flex;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 0px 6px 1px #ccc;
`;
