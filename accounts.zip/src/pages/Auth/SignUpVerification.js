import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useNavigate, useParams } from "react-router-dom";

import swal from "sweetalert";
import { signupVerificationUrl } from "../../api/AuthAPI";

const SignUpVerification = (props) => {
  const [t, i18n] = useTranslation("common");

  const navigate = useNavigate();
  const { id, token } = useParams();
  // const UserID = props.match.params.id;
  async function verification() {
    await fetch(signupVerificationUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        UserID: id,
        token: token,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response.StatusCode === 6000) {
          navigate("/signin");
        } else {
          swal({
            title: t("failed"),
            text: response.message,
            icon: "warning",
            button: true,
          });
          navigate("/signin");
          //props.navigate("/signup");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }
  useEffect(() => {
    verification();
  }, []);
  return <div>You are verified</div>;
};

export default SignUpVerification;
