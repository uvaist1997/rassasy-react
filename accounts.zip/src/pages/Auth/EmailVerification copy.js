import { TextField } from "@material-ui/core";
import React, { useEffect, useRef, useState } from "react";
import styled from "styled-components/macro";
import { useDispatch } from "react-redux";
import VisibilityIcon from "@material-ui/icons/Visibility";
import swal from "sweetalert";
import { showPassword } from "../../functions/utils";
import {
  resendVarificationUrl,
  signupVerificationUrl,
} from "../../api/AuthAPI";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";

const EmailVerification = (props) => {
  const [t] = useTranslation("common");
  let navigate = useNavigate();
  const location = useLocation();

  const [state, setState] = useState({
    loading: true,
    message: "",
    statusCode: 6000,
    new_password1: "",
    new_password2: "",
    errors: {
      new_password1: "",
      new_password2: "",
    },
    email: "",
  });

  useEffect(() => {
    setState({ ...state, loading: false });
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let is_valid = handleValidation();
    const UserID = location.state.userid;
    console.log(UserID);
    const { new_password1 } = state;
    if (is_valid) {
      fetch(signupVerificationUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          UserID: UserID,
          token: new_password1,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          console.log(response.StatusCode);
          if (response.StatusCode === 6000) {
            navigate("/signin");
          } else {
            swal({
              title: t("failed"),
              text: response.message,
              icon: "warning",
              button: true,
            });
            // navigate("/signin");
            //props.navigate("/signup");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };
  const handleValidation = () => {
    let errors = {};
    let formIsValid = true;
    //new password
    if (!state.new_password1) {
      formIsValid = false;
      errors["new_password1"] = "Cannot be empty";
    } else if (state.new_password1.length != 6) {
      formIsValid = false;
      errors["new_password1"] = "Your OTP must be 6 characters";
    }

    setState({ ...state, errors: errors });
    return formIsValid;
  };
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  useEffect(() => {
    let email = params.q;
    setState({ ...state, loading: false, email });
  }, [params.q]);
  console.log("EMAIL VARIFICATION");
  console.log(state);

  const ResendOTP = async () => {
    const UserID = location.state.userid;
    const resendVerificationResponse = await fetch(resendVarificationUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        UserID: UserID,
        data: state.email,
      }),
    }).then((response) => response.json());
    console.log(resendVerificationResponse);
    if (resendVerificationResponse.success === 6000) {
      alert(resendVerificationResponse.message);
      // navigate(`/email-verification/${resendVerificationResponse.userID}`);
      navigate("/email-verification/", {
        state: { userid: resendVerificationResponse.userID },
      });
    } else {
      alert(resendVerificationResponse.message);
      //   navigate("/signin");
    }
  };
  return (
    <Container>
      <CenterContainer>
        <Form onSubmit={(e) => handleSubmit(e)}>
          <HeadingContainer>
            <Heading>{t("Please check Your Inbox")}</Heading>
            <SubHeading>{t("Account Verification")}</SubHeading>
          </HeadingContainer>
          <InputGroup>
            <StyledInput
              fullWidth
              placeholder="Email"
              value={state.email}
              id="email"
              name="email"
              size="small"
              variant="outlined"
              type="text"
              onChange={(e) => handleChange(e)}
            />
          </InputGroup>
          <InputGroup>
            {/* <Label>{t("One Time Password")}</Label> */}
            <StyledInput
              fullWidth
              placeholder="Enter OTP here"
              id="new_password1"
              name="new_password1"
              size="small"
              variant="outlined"
              type="password"
              onChange={(e) => handleChange(e)}
            />
            <ShowPasswordButton onClick={() => showPassword("new_password1")}>
              <VisibilityIcon />
            </ShowPasswordButton>
            <ErrorText>{state.errors.new_password1}</ErrorText>
          </InputGroup>

          <ErrorText statusCode={state.statusCode}>{state.message}</ErrorText>
          <ResendOTPButton>
            {/* <Link to="/resend-verification">{t("Resend OTP")}</Link> */}
            <ResendLink onClick={ResendOTP}>{t("Resend OTP")}</ResendLink>
          </ResendOTPButton>
          <SubmitButtonContainer>
            <SubmitButton>{"Confirm"}</SubmitButton>
          </SubmitButtonContainer>
        </Form>
      </CenterContainer>
    </Container>
  );
};

export default EmailVerification;

const Container = styled.div`
  background: url("images/login-background.webp");
  background-size: cover;
  height: 100vh;
  width: 100vw;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  @media only screen and (max-width: 460px) {
    padding-bottom: 100px;
  }
`;
const HeadingContainer = styled.div`
  position: relative;
  margin-bottom: 35px;
`;
const Heading = styled.h1`
  font-family: "poppinsregular";
  color: #102d60;
  font-size: 20px;
  text-align: center;
  font-weight: bold;
  margin-bottom: 10px;
`;
const SubHeading = styled.h1`
  font-family: "poppinsregular";
  color: #b0b0b0;
  font-size: 14px;
  text-align: center;
`;
const HeadingImageContainer = styled.div`
  width: 80px;
  position: absolute;
  top: -41px;
  left: -30px;
  ${({ language }) =>
    language === "en" &&
    `
    top: -52px;
    left: unset;
    right: -30px;
    transform: scale(-1, 1);
  `}
  @media only screen and (max-width: 460px) {
    ${({ language }) =>
      language === "en" &&
      `
    top: -47px;
    left: unset;
    right: -30px;
    transform: scale(-1, 1);
  `}
  }
`;
const HeadingImage = styled.img`
  width: 100%;
`;
const Form = styled.form`
  width: 100%;

  position: relative;
  z-index: 10;
`;
const InputGroup = styled.div`
  margin-bottom: 30px;
  text-align: center;
  position: relative;
  z-index: 10;

  &:nth-child(2) {
    margin: 0;
    width: 75%;
    margin: 0 auto;
    margin-bottom: 10px;
  }
  &:nth-child(3) {
    margin: 0;
    width: 75%;
    margin: 0 auto;
  }
`;
const Label = styled.p`
  text-align: center;
  text-transform: capitalize;
  font-size: 16px;
  margin-bottom: 5px;
  color: #102d60;
`;
const StyledInput = styled(TextField)`
  input {
    color: #000;
  }
  & textarea {
    min-height: 120px;
    max-height: 120px;
    color: #fff;
    font-weight: bold;
  }
  & .MuiOutlinedInput-root {
    border-radius: 5px;
    border: 1px solid #000;
  }
  fieldset {
    border: 0;
  }
  &::-webkit-input-placeholder {
    color: black;
  }
  & .MuiInputBase-input::-webkit-input-placeholder {
    color: #b0b0b0;
    opacity: 1;
    font-family: "fml-sruthyregular";
    font-size: 13px;
    /* font-weight: bold; */
    letter-spacing: 1px;
  }
  & .MuiOutlinedInput-inputMarginDense {
    padding-top: 7.5px;
    padding-bottom: 7.5px;
    padding-right: 40px;
  }
  .MuiFormControl-fullWidth {
    width: 75%;
  }
`;
const LeafContainer = styled.div`
  width: 250px;
  position: absolute;
  left: -93px;
  top: -44px;
  z-index: 0;
  @media only screen and (max-width: 1250px) {
    width: 200px;
    left: -76px;
    top: -8px;
  }
`;
const Leaf = styled.img`
  width: 100%;
`;
const VillageLogoContainer = styled.div`
  width: 180px;
  position: absolute;
  bottom: 25px;
  left: 25px;
  @media only screen and (max-width: 460px) {
    width: 150px;
    left: 0;
    right: 0;
    margin: 0 auto;
  }
`;
const VillageLogo = styled.img`
  width: 100%;
`;
const SubmitButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 20px;
  position: relative;
  z-index: 5;
`;
const SubmitButton = styled.button`
  cursor: pointer;
  color: #fff;
  background: #1f9100;
  padding: 10px 20px 10px 20px;
  border-radius: 3px;
  outline: none;
  position: relative;
  border: 0;
`;
const ErrorText = styled.p`
  color: ${({ statusCode }) => (statusCode === 6000 ? "green" : "red")};
  text-align: center;
  margin-top: 6px;
  font-size: 12px;
  position: relative;
  z-index: 5;
`;
const ShowPasswordButton = styled.span`
  cursor: pointer;
  position: absolute;
  top: 8px;
  right: 10px;
  svg {
    width: 20px;
  }
`;
const CenterContainer = styled.div`
  width: 28%;
  display: flex;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0px 0px 6px 1px #ccc;
`;
const ResendLink = styled.a``;
const ResendOTPButton = styled.button`
  border: 0;
  cursor: pointer;
  color: #153263;
  background: transparent;
  margin: 14px auto;
  display: flex;
`;
