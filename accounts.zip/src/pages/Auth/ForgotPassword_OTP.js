import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import ErrorIcon from "@mui/icons-material/Error";

import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import { showPassword } from "../../functions/utils";
import {
  resendVarificationUrl,
  signupVerificationUrl,
} from "../../api/AuthAPI";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import swal from "sweetalert";
import ReactTooltip from "react-tooltip";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

function ForgotPassword_OTP() {
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  const [t] = useTranslation("common");

  let navigate = useNavigate();
  const location = useLocation();
  const [state, setState] = useState({
    loading: true,
    message: "",
    statusCode: 6000,
    new_password1: "",
    new_password2: "",
    errors: {
      new_password1: "",
      new_password2: "",
    },
    email: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
    defaultValues: {
      email: params.q,
    },
  });

  useEffect(() => {
    setState({ ...state, loading: false });
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    let is_valid = handleValidation();
    const UserID = location.state.userid;
    const { new_password1 } = state;
    if (is_valid) {
      fetch(signupVerificationUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          UserID: UserID,
          token: new_password1,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.StatusCode === 6000) {
            navigate("/signin");
          } else {
            swal({
              title: t("failed"),
              text: response.message,
              icon: "warning",
              button: true,
            });
            // navigate("/signin");
            //props.navigate("/signup");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };
  const handleValidation = () => {
    let errors = {};
    let formIsValid = true;
    //new password
    if (!state.new_password1) {
      formIsValid = false;
      errors["new_password1"] = "Cannot be empty";
    } else if (state.new_password1.length != 6) {
      formIsValid = false;
      errors["new_password1"] = "Your OTP must be 6 characters";
    }

    setState({ ...state, errors: errors });
    return formIsValid;
  };
  // const params = new Proxy(new URLSearchParams(window.location.search), {
  //   get: (searchParams, prop) => searchParams.get(prop),
  // });
  // useEffect(() => {
  //   let email = params.q;
  //   setState({ ...state, loading: false, email });
  // }, [params.q]);

  const ResendOTP = async () => {
    const UserID = location.state.userid;
    const resendVerificationResponse = await fetch(resendVarificationUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        UserID: UserID,
        data: state.email,
      }),
    }).then((response) => response.json());
    if (resendVerificationResponse.success === 6000) {
      alert(resendVerificationResponse.message);
      // navigate(`/email-verification/${resendVerificationResponse.userID}`);
      navigate("/email-verification/", {
        state: { userid: resendVerificationResponse.userID },
      });
    } else {
      alert(resendVerificationResponse.message);
      //   navigate("/signin");
    }
  };
  return (
    <Container>
      <CenterContainer>
        <ImgContainer>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>

        <ForgotTxt>Enter the OTP</ForgotTxt>

        <Form onSubmit={handleSubmit(onSubmit)}>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              name="email"
              type="email"
              placeholder="Email"
              {...register("email", {
                required: "Please enter a valid email address.",
                pattern: {
                  value:
                    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
                  message: "enter a valid email address",
                },
              })}
              errors={errors}
            />
            {errors.email && (
              <>
                <Exclamation1 data-tip data-for="sadFace2" />
                <StyledReactTooltip
                  id="sadFace2"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  {errors.email && <span>{errors.email.message}</span>}
                </StyledReactTooltip>
              </>
            )}
          </div>
          <StyledInput
            name="new_password1"
            type="password"
            placeholder="OTP"
            {...register("new_password1", {
              required: "password required",
              minLength: {
                value: 6,
                message:
                  "The password should have minimum length of 6 characters",
              },
              maxLength: {
                value: 30,
                message: "The password should have maximum of 30 characters",
              },
            })}
          />

          <OtpTxt onClick={ResendOTP}>Resend OTP</OtpTxt>
          <StyledButton type="submit" variant="contained" disableElevation>
            Continue
          </StyledButton>
        </Form>
      </CenterContainer>
    </Container>
  );
}

export default ForgotPassword_OTP;

const OtpTxt = styled.span`
  width: 100%;
  color: #002f65;
  cursor: pointer;
  font-size: 13px;
  display: flex;
  justify-content: flex-end;
`;
const StyledButton = styled(Button)`
  && {
    width: 370px;
    height: 40px;
    background-image: linear-gradient(274deg, #033631, #005049);
    border-radius: 9px;
    text-transform: capitalize;

    font-family: "Poppins", sans-serif;
  }
`;
const StyledInput = styled.input`
  width: 100%;
  box-sizing: border-box;

  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
`;
const ForgotTxt = styled.span`
  font-size: 16px;

  font-weight: 500;
`;
const Form = styled.form`
  padding: 15px;
  align-items: center;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 27px;
  border-radius: 23px;

  background-image: linear-gradient(113deg, #ffffff, #ffffff); ;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 149.55px;
  height: 40px;
`;

const CenterContainer = styled.div`
  display: flex;
  flex-direction: column;

  align-items: center;
  gap: 10px;
`;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;

const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const VisibilityOff = styled(VisibilityOffIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;

const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
