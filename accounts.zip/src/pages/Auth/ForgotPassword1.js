import React, { useState } from "react";
import { useForm } from "react-hook-form";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import { forgotPasswordUrl } from "../../api/AuthAPI";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import Snackbar, { SnackbarOrigin } from "@mui/material/Snackbar";
import MuiAlert, { AlertProps } from "@mui/material/Alert";
import { CircularProgress } from "@material-ui/core";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function ForgotPassword1() {
  const [t] = useTranslation("common");
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });
  let navigate = useNavigate();

  const [state, setState] = useState({
    error_msg: "",
    email: "",
    loading: true,
  });
  const [loading, setLoading] = useState(false);
  // const handleChange = (e) => {
  //   setState({ ...state, [e.target.name]: e.target.value });
  // };
  const [snack, setSnack] = useState({
    open: false,
    vertical: "top",
    horizontal: "center",
    message: ""
  });

  const { vertical, horizontal, open } = snack;

  const handleClose = () => {
    setSnack({ ...snack, open: false });
  };



 function snackFunction(newState) {
   setTimeout(function () {
     navigate("/signin");
   }, 2000);
 }


  const onSubmit = async (data) => {
    // e.preventDefault();
    setLoading(true);
    const { email } = data;
    console.log(data, "sssssssssss");
    const forgotPasswordResponse = await fetch(forgotPasswordUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        data: email,
      }),
    }).then((response) => response.json());

    if (forgotPasswordResponse.success === 6000) {
      setSnack({ ...snack,message: "please verify your email", open: true });
      snackFunction();
      // alert(forgotPasswordResponse.message);
      // navigate("/signin");
    } else {
      setLoading(false);
      // alert(forgotPasswordResponse.message);
      setState((prevState) => {
        return {
          ...prevState,
          error_msg: forgotPasswordResponse.message,
        };
      });
    }
  };
  console.log(errors, "DDDDDDDDDDDDDDDD");

  return (
    <Container>
      <CenterContainer>
        <ImgContainer>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>

        <ForgotTxt>Forgotten Password?</ForgotTxt>

        <Form onSubmit={handleSubmit(onSubmit)}>
          <Email_Txt>Enter Your E-Mail Address</Email_Txt>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              className={errors.email || state.error_msg ? "outline-red" : ""}
              type="email"
              name="email"
              placeholder="Your email address"
              validationMessage="Please enter a valid email address."
              message="This will be used for verification."
              // validation={register("email", {
              //   required: "Please enter a valid email address.",

              //   pattern: {
              //     value:
              //       /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
              //     message: "enter a valid email address",
              //   },
              // })}
              {...register("email", {
                required: "Please enter a valid email address.",
                pattern: {
                  value:
                    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
                  message: "enter a valid email address",
                },
              })}
              errors={errors}
            />
            {errors.email || state.error_msg ? (
              <>
                <Exclamation1 data-tip data-for="sadFace1" />
                <StyledReactTooltip
                  id="sadFace1"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  <span>
                    {errors.email
                      ? errors.email.message
                      : state.error_msg
                      ? state.error_msg
                      : null}
                  </span>
                </StyledReactTooltip>
              </>
            ) : null}
          </div>
          <StyledButton type="submit" variant="contained" disableElevation>
            {loading ? <CircularProgress size={18} color="info" /> : "Continue"}
          </StyledButton>
        </Form>
      </CenterContainer>
      <Snackbar
        anchorOrigin={{ vertical, horizontal }}
        open={open}
        onClose={handleClose}
        message="I love snacks"
        key={vertical + horizontal}
      >
        <Alert severity="error">{snack.message}</Alert>
      </Snackbar>
    </Container>
  );
}

export default ForgotPassword1;

const StyledButton = styled(Button)`
  && {
    margin-top: 5px;
    width: 370px;
    height: 40px;
    background-image: linear-gradient(274deg, #033631, #005049);
    border-radius: 9px;
    text-transform: capitalize;

    font-family: "Poppins", sans-serif;
  }
`;
const StyledInput = styled.input`
  width: 100%;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
  &.outline-red {
    outline: 1px solid red;
  }
`;
const ForgotTxt = styled.span`
  font-size: 16px;

  font-weight: 500;
`;
const Email_Txt = styled(ForgotTxt)`
  font-weight: unset;
  color: #818181;
`;
const Form = styled.form`
  padding: 15px;
  align-items: center;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 27px;
  border-radius: 23px;

  background-image: linear-gradient(113deg, #ffffff, #ffffff); ;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 149.55px;
  height: 40px;
`;

const CenterContainer = styled.div`
  display: flex;
  flex-direction: column;

  align-items: center;
  gap: 10px;
`;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
