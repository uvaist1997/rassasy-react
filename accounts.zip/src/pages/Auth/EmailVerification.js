import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import ErrorIcon from "@mui/icons-material/Error";
import Box from "@mui/material/Box";
import LinearProgress from "@mui/material/LinearProgress";

import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import { showPassword } from "../../functions/utils";
import {
  resendVarificationUrl,
  signupVerificationUrl,
} from "../../api/AuthAPI";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import swal from "sweetalert";
import ReactTooltip from "react-tooltip";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import { CircularProgress } from "@material-ui/core";
import Snackbar, { SnackbarOrigin } from "@mui/material/Snackbar";
import MuiAlert, { AlertProps } from "@mui/material/Alert";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function EmailVerification() {
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  const [t] = useTranslation("common");
  const [loading, setLoading] = useState(false);

  let navigate = useNavigate();
  const location = useLocation();
  const [state, setState] = useState({
    loading: true,
    message: "",
    statusCode: 6000,
    new_password1: "",
    new_password2: "",
    errors: {
      new_password1: "",
      new_password2: "",
    },
    error_msg: "",
    email: "",
  });

  const [snack, setSnack] = useState({
    open: true,
    vertical: "top",
    horizontal: "center",
    message: "please verify your email",
  });

  const { vertical, horizontal, open } = snack;

  const handleClick = (newSnack) => {
    setSnack({ open: true, ...newSnack });
  };

  const handleClose = () => {
    setSnack({ ...snack, open: false });
  };


  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
    defaultValues: {
      email: params.q,
    },
  });

  useEffect(() => {
    setState({ ...state, loading: false });
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const onSubmit = (data) => {
    // e.preventDefault();
    let value = params.service;
    let service = null;
    if (value) {
      service = value;
    }
    let is_valid = true;
    const UserID = location.state.userid;
    const { new_password1 } = data;
    if (is_valid) {
      fetch(signupVerificationUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          UserID: UserID,
          token: new_password1,
          service: service,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.StatusCode === 6000) {
            navigate("/signin");
          } else {
            setState((prevState) => {
              return {
                ...prevState,
                error_msg: response.message,
              };
            });
            // swal({
            //   title: t("failed"),
            //   text: response.message,
            //   icon: "warning",
            //   button: true,
            // });
            // navigate("/signin");
            //props.navigate("/signup");
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };
  const handleValidation = () => {
    let errors = {};
    let formIsValid = true;
    //new password
    if (!state.new_password1) {
      formIsValid = false;
      errors["new_password1"] = "Cannot be empty";
    } else if (state.new_password1.length != 6) {
      formIsValid = false;
      errors["new_password1"] = "Your OTP must be 6 characters";
    }

    setState({ ...state, errors: errors });
    return formIsValid;
  };

  useEffect(() => {
    let email = params.q;
    setState({ ...state, loading: false, email });
  }, [params.q]);

  const ResendOTP = async () => {
    setLoading(true);
    const UserID = location.state.userid;
    const resendVerificationResponse = await fetch(resendVarificationUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        UserID: UserID,
        data: state.email,
      }),
    }).then((response) => response.json());
    if (resendVerificationResponse.success === 6001) {
      setLoading(false);
      // alert(resendVerificationResponse.message);
      setSnack({
        ...snack,
        message: resendVerificationResponse.message,
        open: true,
      });
      // navigate(`/email-verification/${resendVerificationResponse.userID}`);
      let value = params.service;
      let service = "viknbooks";
      if (value) {
        service = value;
      }
      navigate(`/email-verification/?q=${state.email}&service=${service}`, {
        state: { userid: resendVerificationResponse.userID },
      });
    } else {
      setLoading(false);
      // alert(resendVerificationResponse.message);
      setSnack({ ...snack,message: "please verify your email", open: true });
      //   navigate("/signin");
    }
  };
  console.log(errors);
  return (
    <Container>
      <CenterContainer>
        <ImgContainer>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>

        <ForgotTxt>Enter the OTP</ForgotTxt>

        <Form onSubmit={handleSubmit(onSubmit)}>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              className={errors.email ? "outline-red" : ""}
              name="email"
              type="email"
              placeholder="Email"
              {...register("email", {
                required: "Please enter a valid email address.",
                pattern: {
                  value:
                    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
                  message: "enter a valid email address",
                },
              })}
              errors={errors}
            />
            {errors.email && (
              <>
                <Exclamation1 data-tip data-for="sadFace2" />
                <StyledReactTooltip
                  id="sadFace2"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  {errors.email && <span>{errors.email.message}</span>}
                </StyledReactTooltip>
              </>
            )}
          </div>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              className={
                errors.new_password1 || state.error_msg ? "outline-red" : ""
              }
              name="new_password1"
              type="text"
              placeholder="OTP"
              {...register("new_password1", {
                required: "OTP Required",
                minLength: {
                  value: 6,
                  message: "The otp should have minimum length of 6 characters",
                },
                maxLength: {
                  value: 6,
                  message: "The otp should have maximum of 6 characters",
                },
              })}
            />

            {errors.new_password1 || state.error_msg ? (
              <>
                <Exclamation1 data-tip data-for="sadFace4" />
                <StyledReactTooltip
                  id="sadFace4"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  <span>
                    {errors.new_password1
                      ? errors.new_password1.message
                      : state.error_msg
                      ? state.error_msg
                      : null}
                  </span>
                </StyledReactTooltip>
              </>
            ) : null}
          </div>
          {loading ? (
            <Box sx={{ width: "100%" }}>
              <LinearProgress color="success" />
            </Box>
          ) : (
            <OtpTxt onClick={ResendOTP}>Resend OTP</OtpTxt>
          )}

          <StyledButton type="submit" variant="contained" disableElevation>
            Continue
          </StyledButton>
          {/* <Button
            className="button w-button"
            color="#fff"
            background="#155e4b"
            text="Continue"
            type="submit"
            loading={loading}
          ></Button> */}
        </Form>
        <Snackbar
          anchorOrigin={{ vertical, horizontal }}
          open={open}
          onClose={handleClose}
          message="I love snacks"
          key={vertical + horizontal}
        >
          <Alert severity="error">{snack.message}</Alert>
        </Snackbar>
      </CenterContainer>
    </Container>
  );
}

export default EmailVerification;

const OtpTxt = styled.span`
  width: 100%;
  color: #002f65;
  cursor: pointer;
  font-size: 13px;
  display: flex;
  justify-content: flex-end;
`;
const StyledButton = styled(Button)`
  && {
    width: 370px;
    height: 40px;
    background-image: linear-gradient(274deg, #033631, #005049);
    border-radius: 9px;
    text-transform: capitalize;

    font-family: "Poppins", sans-serif;
  }
`;
const StyledInput = styled.input`
  width: 100%;
  box-sizing: border-box;

  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
  &.outline-red {
    outline: 1px solid red;
  }
`;
const ForgotTxt = styled.span`
  font-size: 16px;

  font-weight: 500;
`;
const Form = styled.form`
  padding: 15px;
  align-items: center;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 27px;
  border-radius: 23px;

  background-image: linear-gradient(113deg, #ffffff, #ffffff); ;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 149.55px;
  height: 40px;
`;

const CenterContainer = styled.div`
  display: flex;
  flex-direction: column;

  align-items: center;
  gap: 10px;
`;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;

const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const VisibilityOff = styled(VisibilityOffIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;

const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
