import React, { useEffect, useRef, useState } from "react";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import { forgotPasswordConfirmUrl } from "../../api/AuthAPI";
import { useNavigate, useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import ReactTooltip from "react-tooltip";
import ErrorIcon from "@mui/icons-material/Error";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";

function ResetPassWord() {
  const [visibleEye1, setvisibleEye1] = useState(false);
  const [visibleEye2, setvisibleEye2] = useState(false);
  const navigate = useNavigate();
  const {
    watch,
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });
  const password = useRef({});
  password.current = watch("new_password1", "");

  const { uidb64 } = useParams();
  console.log(uidb64);
  console.log(useParams());
  const [state, setState] = useState({
    loading: true,
    message: "",
    statusCode: 6000,
    new_password1: "",
    new_password2: "",
    errors: {
      new_password1: "",
      new_password2: "",
    },
  });

  useEffect(() => {
    setState({ ...state, loading: false });
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const onSubmit = (data) => {
    // e.preventDefault();
    // let is_valid = handleValidation();
    let is_valid = true;

    const { new_password1, new_password2 } = data;
    if (is_valid) {
      fetch(`${forgotPasswordConfirmUrl}${uidb64}`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          new_password1,
          new_password2,
        }),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response.success === 6000) {
            setState({ ...state, message: response.message, statusCode: 6000 });
            navigate("/signin");
          } else {
            setState({ ...state, message: response.message, statusCode: 6001 });
          }
        });
    } else {
      console.log("ERROR");
    }
  };
  const handleValidation = () => {
    let errors = {};
    let formIsValid = true;

    //new password
    if (!state.new_password1) {
      formIsValid = false;
      errors["new_password1"] = "Cannot be empty";
    } else if (state.new_password1 < 8) {
      formIsValid = false;
      errors["new_password1"] = "Your password must be at least 8 characters";
    } else if (state.new_password1) {
      if (state.new_password1.search(/[a-z]/i) < 0) {
        formIsValid = false;
        errors["new_password1"] =
          "Your password must contain at least one letter";
      }
    }
    if (state.new_password1) {
      if (state.new_password1.search(/[0-9]/) < 0) {
        formIsValid = false;
        errors["new_password1"] =
          "Your password must contain at least one digit";
      }
    }
    //new_password2
    if (!state.new_password2) {
      formIsValid = false;
      errors["new_password2"] = "Cannot be empty";
    }

    // check password same
    if (state.new_password1 && state.new_password2) {
      if (state.new_password1 !== state.new_password2) {
        formIsValid = false;
        errors["new_password1"] = "Not matching";
        errors["new_password2"] = "Not matching";
      }
    }

    setState({ ...state, errors: errors });
    return formIsValid;
  };
  console.log(errors);
  console.log(state);
  return (
    <Container>
      <CenterContainer>
        <ImgContainer>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>

        <ForgotTxt>Reset Password</ForgotTxt>

        <Form onSubmit={handleSubmit(onSubmit)}>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              className={errors.new_password1 ? "outline-red" : ""}
              name="new_password1"
              type={visibleEye1 ? "text" : "password"}
              placeholder="New Password"
              {...register("new_password1", {
                required: "password required",
                minLength: {
                  value: 6,
                  message:
                    "The password should have minimum length of 6 characters",
                },
                maxLength: {
                  value: 30,
                  message: "The password should have maximum of 30 characters",
                },
                // onChange: (e, v) => {
                //   handlechange(e, v);
                // },
              })}
              errors={errors}
            />
            {errors.new_password1 || state.message ? (
              <>
                <Exclamation1 data-tip data-for="sadFace4" />
                <StyledReactTooltip
                  id="sadFace4"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  <span>
                    {errors.new_password1
                      ? errors.new_password1.message
                      : state.message
                      ? state.message
                      : null}
                  </span>
                </StyledReactTooltip>
              </>
            ) : (
              <>
                {visibleEye1 ? (
                  <VisibilityOff onClick={() => setvisibleEye1(false)} />
                ) : (
                  <RemovedEye onClick={() => setvisibleEye1(true)} />
                )}
              </>
            )}
          </div>
          <div style={{ position: "relative", width: "100%" }}>
            <StyledInput
              name="new_password2"
              type={visibleEye2 ? "text" : "password"}
              placeholder="Confirm Password"
              {...register("new_password2", {
                validate: (value) =>
                  value === password.current || "The passwords do not match",
                required: "password required",
                minLength: {
                  value: 6,
                  message:
                    "The password should have minimum length of 6 characters",
                },
                maxLength: {
                  value: 30,
                  message: "The password should have maximum of 30 characters",
                },
                // onChange: (e, v) => {
                //   handlechange(e, v);
                // },
              })}
            />
            {errors.new_password2 ? (
              <>
                <Exclamation1 data-tip data-for="sadFace4" />
                <StyledReactTooltip
                  id="sadFace4"
                  effect="solid"
                  place="bottom"
                  tipPointerPosition="Start"
                >
                  {errors.new_password2 && (
                    <span>{errors.new_password2.message}</span>
                  )}
                </StyledReactTooltip>
              </>
            ) : (
              <>
                {visibleEye2 ? (
                  <VisibilityOff onClick={() => setvisibleEye2(false)} />
                ) : (
                  <RemovedEye onClick={() => setvisibleEye2(true)} />
                )}
              </>
            )}
          </div>

          <StyledButton type="submit" variant="contained" disableElevation>
            Done
          </StyledButton>
        </Form>
      </CenterContainer>
    </Container>
  );
}

export default ResetPassWord;

const StyledButton = styled(Button)`
  && {
    margin-top: 5px;
    width: 370px;
    height: 40px;
    background-image: linear-gradient(274deg, #033631, #005049);
    border-radius: 9px;
    text-transform: capitalize;

    font-family: "Poppins", sans-serif;
  }
`;
const StyledInput = styled.input`
  width: 100%;
  box-sizing: border-box;

  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
`;
const ForgotTxt = styled.span`
  font-size: 16px;

  font-weight: 500;
`;
const Form = styled.form`
  padding: 15px;
  align-items: center;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding: 27px;
  border-radius: 23px;

  background-image: linear-gradient(113deg, #ffffff, #ffffff); ;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 149.55px;
  height: 40px;
`;

const CenterContainer = styled.div`
  display: flex;
  flex-direction: column;

  align-items: center;
  gap: 10px;
`;

const Container = styled.div`
  width: 100%;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-image: linear-gradient(180deg, #ecf2f0, #f5f8f7);
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const VisibilityOff = styled(VisibilityOffIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
