import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components/macro";
import swal from "sweetalert";

import InputField from "../../components/InputField/InputField";
import { staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { useNavigate } from "react-router-dom";
import { SignUpSelect } from "../../components/Select/SignUpSelect";
import { countryUrl } from "../../api/CountryAPI";
import { checkUsernameUrl, signupUrl } from "../../api/AuthAPI";
import Loader from "../../components/Loader/Loader";
import { getServiceUrl } from "../../functions/utils";

const SignUp = () => {
  let service = getServiceUrl(window.location.href);
  if (
    service === "task_manager" ||
    service === "payroll" ||
    service === "viknbooks"
  ) {
    console.log(service, "**********************");
  } else {
    service = "accounts";
  }
  const navigate = useNavigate();
  const isLoading = false;
  const [loaing, setLoading] = useState(false);
  const [state, setState] = useState({
    email: "",
    password1: "",
    password2: "",
    first_name: "",
    last_name: "",
    username: "",
    phone: "",
    countries: [],

    loading: true,
    is_username: false,
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });

  const onSubmit = async (data) => {
    const {
      firstname,
      lastname,
      username,
      email,
      password1,
      password2,
      phone,
      country,
    } = data;
    console.log(data);
    setLoading(true);
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const signupResponse = await fetch(signupUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        first_name: firstname,
        last_name: lastname,
        username: username,
        email: email,
        password1: password1,
        password2: password2,
        phone: phone,
        country: !country ? "30f8c506-e27a-476c-8950-b40a6461bf61" : country,
        timezone: timezone,
      }),
    }).then((response) => response.json());
    if (signupResponse.StatusCode == 6000) {
      setLoading(false);

      swal({
        title: "success",
        text: "Registration Completed Successfully.please verify your email to Login",
        icon: "success",
        button: true,
        // timer: 1000,
      });
      if (signupResponse.active == true) {
        navigate(`/signin`);
      } else {
        // navigate(`/email-verification/${signupResponse.userID}`);
        navigate("/email-verification/", {
          state: { userid: signupResponse.userID },
        });
      }
    } else {
      setLoading(false);
      swal({
        title: "failed",
        text: signupResponse.message,
        icon: "warning",
        button: true,
        // timer: 1000,
      });
    }
  };

  const checkUsername = async (name, e) => {
    console.log(name, e.target.value);
    let value = e.target.value;
    await fetch(checkUsernameUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        username: value,
      }),
    })
      .then((response) => response.json())
      .then((response) => {
        console.log(response.is_username);
        if (response.is_username) {
          setState((prevState) => {
            return {
              ...prevState,
              is_username: true,
              [name]: value,
            };
          });
        }
      });
  };

  async function fetchCountries() {
    const countryResponse = await fetch(countryUrl, {
      method: "GET",
      headers: {
        "content-type": "application/json",
      },
    }).then((response) => response.json());
    setState((prevState) => {
      return {
        ...prevState,
        countries: countryResponse.data,
      };
    });
  }
  useEffect(() => {
    fetchCountries();
  }, []);
  if (loaing) {
    return <Loader />;
  } else {
    return (
      <Container>
        <Form
          variants={staggerOne}
          initial="initial"
          animate="animate"
          exit="exit"
          className="SignIn__form"
          onSubmit={handleSubmit(onSubmit)}
        >
          <LogoContainer>
            <Logo src="images/vikncodes.svg" />
          </LogoContainer>
          <SmallHeading text="Create your Vikn account " align="left" />
          <InputTwinGroup>
            <InputField
              width="48%"
              type="text"
              name="firstname"
              placeholder="First Name"
              validationMessage="Please enter your first name."
              validation={register("firstname", {
                required: true,
              })}
              errors={errors}
              disabled={isLoading}
            />
            <InputField
              width="48%"
              type="text"
              name="lastname"
              placeholder="Last Name"
              validationMessage="Please enter your last name."
              validation={register("lastname", {
                required: true,
              })}
              errors={errors}
              disabled={isLoading}
            />
          </InputTwinGroup>
          <InputGroup>
            <InputField
              type="email"
              name="email"
              placeholder="Your Email Address"
              validationMessage="Please enter a valid email address."
              message="This will be used for verification."
              validation={register("email", {
                required: true,
                pattern:
                  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
              })}
              errors={errors}
              disabled={isLoading}
            />
          </InputGroup>
          <InputGroup>
            <InputField
              type="username"
              name="username"
              placeholder="Username"
              validationMessage={
                state.is_username ? "Username already exists." : null
              }
              // message="This will be used for verification."
              validation={register("username", {
                required: true,
                onChange: (e) => {
                  checkUsername("username", e);
                },
              })}
              errors={errors}
              disabled={isLoading}
            />
          </InputGroup>
          <InputTwinGroup>
            <InputField
              width="48%"
              type="password"
              name="password1"
              placeholder="Password"
              validationMessage="The password should have a length between 6 and 30 characters."
              validation={register("password1", {
                required: true,
                minLength: 6,
                maxLength: 30,
              })}
              errors={errors}
              disabled={isLoading}
            />
            <InputField
              width="48%"
              type="password"
              name="password2"
              placeholder="Confirm Password"
              validationMessage="The password should have a length between 6 and 30 characters."
              validation={register("password2", {
                required: true,
                minLength: 6,
                maxLength: 30,
              })}
              errors={errors}
              disabled={isLoading}
            />
          </InputTwinGroup>
          {!errors.password && (
            <MessageText>
              Use 8 or more characters with a mix of letters, numbers & symbols
            </MessageText>
          )}
          <InputTwinGroup>
            {/* <InputField
            width="48%"
            type="text"
            name="country"
            placeholder="Country"
            validationMessage="Please select a country."
            validation={register("country", {
              required: true,
            })}
            errors={errors}
            disabled={isLoading}
          /> */}
            <SignUpSelect
              register={register}
              name="country"
              options={state.countries}
            />

            <InputField
              width="48%"
              type="text"
              name="phone"
              placeholder="Phone"
              validationMessage="Please enter a valid phone number."
              validation={register("phone", {
                required: true,
                pattern:
                  /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im,
              })}
              errors={errors}
              disabled={isLoading}
            />
          </InputTwinGroup>

          <BottomButtonContainer>
            <Button
              background="#fff"
              color="#276eb5"
              text="Sign In Instead"
              onClick={() => navigate(`/signin?service=${service}`)}
              type="button"
            ></Button>
            <Button
              color="#fff"
              background="#155e4b"
              text="Sign up"
              type="submit"
            ></Button>
          </BottomButtonContainer>
        </Form>
      </Container>
    );
  }
};

export default SignUp;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: #fff;
  overflow: hidden;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  background: #fff;
  width: 420px;
  min-height: 300px;
  height: max-content;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 2px;
  @media (max-width: 460px) {
    width: 100%;
    min-width: 200px;
  }
`;
const InputGroup = styled.div``;
const BottomButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 55px;
`;

const Logo = styled.img`
  width: 120px;
`;
const LogoContainer = styled.div`
  text-align: left;
  margin: 10px 0;
`;
const InputTwinGroup = styled.div`
  display: flex;
  justify-content: space-between;
  @media (max-width: 460px) {
    display: block;
  }
`;
const MessageText = styled.p`
  margin-top: 0.4em;
  font-size: 13px;
  color: #727272;
  min-height: 10px;
  margin-bottom: 0;
`;
