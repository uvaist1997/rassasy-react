import React from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components/macro";

import InputField from "../../components/InputField/InputField";
import { staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";
import { getServiceUrl } from "../../functions/utils";
import {
  PAYROLL_FRONT_URL,
  SIGNIN_URL,
  TASK_FRONT_URL,
  URL,
  VIKNBOOKS_FRONT_URL,
} from "../../settings";
import { useDispatch } from "react-redux";
import { loginSuccess } from "../../slices/user/userSlice";

const SignIn = () => {
  const dispatch = useDispatch();
  // const params = new Proxy(new URLSearchParams(window.location.search), {
  //   get: (searchParams, prop) => searchParams.get(prop),
  // });
  // let service = params.service;
  let service = getServiceUrl(window.location.href);
  if (
    service === "task_manager" ||
    service === "payroll" ||
    service === "viknbooks"
  ) {
    console.log(service, "**********************");
  } else {
    service = "accounts";
  }
  const navigate = useNavigate();
  const isLoading = false;
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
  });

  // useEffect(() => {
  //   SIGNIN_URL.get("/users/image").then(function (response) {
  //     // handle success
  //     console.log(response);
  //   });
  // }, []);

  const onSubmit = (data) => {
    const { username, password } = data;
    // let service = getServiceUrl(window.location.href);
    // console.log(service);

    SIGNIN_URL.post(
      `/users/login`,
      { username, password, service },
      { withCredentials: false }
    )
      .then(function (response) {
        // let hashToken = get_HashValue(response.data.data.access);
        // setCookie(
        //   "VBID",
        //   hashToken,
        //   {
        //     path: "/",
        //     location: "https://www.accounts.viknbooks.com",
        //   },
        //   { domain: ".viknbooks.com" }
        // );
        // document.cookie =
        // "VBID" + "=" + hashToken + ";domain=.viknbooks.com;path=/;";
        // if (service && response.data.response_redirect) {
        // window.location.href = response.data.response_redirect;
        // window.location.href = "http://localhost:3001/dashboard/";
        // }
        if (response.data.success === 6000) {
          dispatch(
            loginSuccess({
              ...response.data.data,
              username: response.data.data.username,
              isAuth: true,
            })
          );
          axios
            .get(
              `${URL}api/v1/accounts/accounts?sid=${response.data.data.access}`,
              { withCredentials: true }
            )
            .then(() => {
              const params = new Proxy(
                new URLSearchParams(window.location.search),
                {
                  get: (searchParams, prop) => searchParams.get(prop),
                }
              );
              let value = params.service;
              // console.log("inside payroll", PAYROLL_FRONT_URL);
              // window.open(`${PAYROLL_FRONT_URL}dashboard`, "_self");
              if (value === "viknbooks") {
                console.log("inside viknbooks");
                window.open(`${VIKNBOOKS_FRONT_URL}dashboard/home`, "_self");
                // window.open(
                //   "https://test.viknbooks.com/dashboard/home",
                //   "_self"
                // );
              } else if (value === "payroll") {
                console.log("inside payroll", PAYROLL_FRONT_URL);
                window.open(`${PAYROLL_FRONT_URL}dashboard`, "_self");
              } else if (value === "task_manager") {
                console.log("inside task manager");
                window.open(`${TASK_FRONT_URL}`, "_self");
              } else {
                navigate("/");
              }
            });
        } else {
          window.alert(response.data.error);
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };
  console.log("service", "HUYTR");
  return (
    <Container>
      <Form
        variants={staggerOne}
        initial="initial"
        animate="animate"
        exit="exit"
        className="SignIn__form"
        onSubmit={handleSubmit(onSubmit)}
      >
        <LogoContainer>
          <Logo src="images/vikncodes.svg" />
        </LogoContainer>
        <SmallHeading text="Sign in with Vikn account" align="center" />
        <InputGroup>
          <InputField
            type="text"
            name="username"
            placeholder="Username"
            validationMessage="Please enter a valid username."
            validation={register("username", {
              required: true,
              // pattern: /^[a-z0-9_.]+$/,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputGroup>
        <InputGroup>
          <InputField
            type="password"
            name="password"
            placeholder="Password"
            validationMessage="The password should have a length between 6 and 30 characters."
            validation={register("password", {
              required: true,
              minLength: 6,
              maxLength: 30,
            })}
            errors={errors}
            disabled={isLoading}
          />
        </InputGroup>
        <ForgotPasswordContainer>
          <ForgotPasswordButton
            background="#fff"
            color="#276eb5"
            text="Forgot Password"
            type="button"
          >
            <Link to="/forgot-password">{"Forgotten password?"}</Link>
          </ForgotPasswordButton>
        </ForgotPasswordContainer>
        <BottomButtonContainer>
          <Button
            background="#fff"
            color="#276eb5"
            text="Create Account"
            type="button"
            onClick={() => navigate(`/sign-up?service=${service}`)}
          ></Button>
          <Button
            color="#fff"
            background="#155e4b"
            text="Sign In"
            type="submit"
          ></Button>
        </BottomButtonContainer>
        {/* <iframe
          src="https://juhani.viknbooks.com/"
          style={{ display: "none" }}
        ></iframe> */}
      </Form>
    </Container>
  );
};

export default SignIn;

const Container = styled.div`
  width: 100vw;
  height: 100vh;
  background: #fff;
  overflow: hidden;
  display: grid;
  place-items: center;
`;
const Form = styled.form`
  background: #fff;
  width: 300px;
  min-height: 300px;
  height: max-content;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 2px;
`;
const InputGroup = styled.div``;
const BottomButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
`;
const ForgotPasswordContainer = styled.div`
  text-align: right;
  margin-top: 20px;
`;

const ForgotPasswordButton = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  margin-bottom: 20px;
  border-radius: 3px;
  color: ${({ color }) => color};
  background: ${({ background }) => background};
  a {
    color: #409be0;
  }
`;
const Logo = styled.img`
  width: 120px;
`;
const LogoContainer = styled.div`
  text-align: center;
  margin: 10px 0;
`;
