import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components/macro";
import swal from "sweetalert";

import InputField from "../../components/InputField/InputField";
import { staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { useNavigate } from "react-router-dom";
import { SignUpSelect } from "../../components/Select/SignUpSelect";
import { countryUrl } from "../../api/CountryAPI";
import { checkUsernameUrl, signupUrl } from "../../api/AuthAPI";
import Loader from "../../components/Loader/Loader";
import { containsWhitespace, getServiceUrl } from "../../functions/utils";
import "../../style.css";
import SignupInputField from "../../components/InputField/SignupInputField";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import Snackbar, { SnackbarOrigin } from "@mui/material/Snackbar";
import MuiAlert, { AlertProps } from "@mui/material/Alert";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const SignUp = () => {
  let service = getServiceUrl(window.location.href);
  if (
    service === "task_manager" ||
    service === "payroll" ||
    service === "viknbooks"
  ) {
    console.log(service, "********SERVICE**************");
  } else {
    service = "accounts";
  }

  const navigate = useNavigate();
  const isLoading = false;
  const [loaing, setLoading] = useState(false);
  const [visibleEye1, setvisibleEye1] = useState(false);
  const [visibleEye2, setvisibleEye2] = useState(false);
  const [state, setState] = useState({
    email: "",
    password1: "",
    password2: "",
    first_name: "",
    last_name: "",
    username: "",
    phone: "",
    countries: [],
    country: "India",
    loading: true,
    is_username: false,
    username_error: "",
    error_msg: "",
    email_error: "",
  });

  const [snack, setSnack] = useState({
    open: false,
    vertical: "top",
    horizontal: "center",
  });

  const { vertical, horizontal, open } = snack;

  const handleClick = (newSnack) => {
    setSnack({ open: true, ...newSnack });
  };

  const handleClose = () => {
    setSnack({ ...snack, open: false });
  };

  const {
    watch,
    register,
    setFocus,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onTouched",
  });
  const new_password1 = useRef({});
  new_password1.current = watch("password1", "");

  const [phone, setPhone] = useState("");
  const [isFocused, setisFocused] = useState(true);

  const handleOnChange = (value) => {
    setPhone(value);
  };
  const onSubmit = async (data) => {
    const {
      firstname,
      lastname,
      username,
      email,
      password1,
      password2,
      phone,
      country,
    } = data;
    setLoading(true);
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const params = new Proxy(new URLSearchParams(window.location.search), {
      get: (searchParams, prop) => searchParams.get(prop),
    });
    let value = params.service;
    let service = null;
    if (value) {
      service = value;
    }
    if (state.is_username === false) {
      const signupResponse = await fetch(signupUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify({
          first_name: firstname,
          last_name: lastname,
          username: username,
          email: email,
          password1: password1,
          password2: password2,
          phone: phone,
          country: !country ? "India" : country,
          timezone: timezone,
          service: service,
        }),
      }).then((response) => response.json());
      if (signupResponse.StatusCode == 6000) {
        setLoading(false);
        handleClick({
          vertical: "top",
          horizontal: "center",
        });
        // swal({
        //   title: "success",
        //   text: "Registration Completed Successfully.please verify your email to Login",
        //   icon: "success",
        //   button: true,
        //   // timer: 1000,
        // });
        if (signupResponse.active == true) {
          navigate(`/signin`);
        } else {
          // navigate(`/email-verification/${signupResponse.userID}`);
          navigate(`/email-verification/?q=${email}&service=${service}`, {
            state: {
              userid: signupResponse.userID,
            },
          });
        }
      } else {
        setLoading(false);
        if (
          signupResponse.message === "A user with that email already exists."
        ) {
          setState((prevState) => {
            return {
              ...prevState,
              email_error: signupResponse.message,
            };
          });
        }

        // swal({
        //   title: "failed",
        //   text: signupResponse.message,
        //   icon: "warning",
        //   button: true,
        //   // timer: 1000,
        // });
      }
    } else {
      setLoading(false);
      // swal({
      //   title: "failed",
      //   text: state.username_error,
      //   icon: "warning",
      //   button: true,
      //   // timer: 1000,
      // });
    }
  };

  const checkUsername = async (name, e) => {
    let value = e.target.value;
    if (name === "email") {
      setState((prevState) => {
        return {
          ...prevState,
          email_error: "",
        };
      });
    } else {
      if (containsWhitespace(value)) {
        setState((prevState) => {
          return {
            ...prevState,
            is_username: true,
            [name]: value,
            username_error: "you can't use space for username",
          };
        });
        state.is_username = false;
      } else {
        await fetch(checkUsernameUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            accept: "application/json",
          },
          body: JSON.stringify({
            username: value,
          }),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response.is_username) {
              setState((prevState) => {
                return {
                  ...prevState,
                  is_username: true,
                  [name]: value,
                  username_error: "Username already exists.",
                };
              });
            } else {
              setState((prevState) => {
                return {
                  ...prevState,
                  is_username: false,
                  [name]: value,
                  username_error: "",
                };
              });
            }
          });
      }
    }
  };

  async function fetchCountries() {
    const countryResponse = await fetch(countryUrl, {
      method: "GET",
      headers: {
        "content-type": "application/json",
      },
    }).then((response) => response.json());
    let data = [];
    if (countryResponse.StatusCode == 6000) {
      data = countryResponse.data;
    }
    setState((prevState) => {
      return {
        ...prevState,
        countries: data,
      };
    });
  }
  useEffect(() => {
    fetchCountries();
  }, []);
  const handlechange = (e, v) => {
    let password1 = e.target.value;
    setState({
      ...state,
      password1,
    });
  };
  const handleSelect = (e) => {
    if (e) {
      let name = e.target.name;
      if (name == "country") {
        let value = e.target.value;
        setState({
          ...state,
          country: value,
        });
      }
    }
  };
  const checkPaswd = (e, v) => {
    let password1 = state.password1;
    let password2 = e.target.value;
    let error_msg = "";

    if (password1 != password2) {
      error_msg = "Password Miss match";
    }
    setState({
      ...state,
      error_msg,
    });
  };
  console.log(errors);
  if (loaing) {
    return <Loader />;
  } else {
    return (
      <MainContainer>
        <div className="section login sign-up wf-section">
          <img src="../../images/1.svg" loading="lazy" alt="" />
          <ContainerHead className="text-block-4">
            Create your Vikn account
          </ContainerHead>

          <Form
            variants={staggerOne}
            initial="initial"
            animate="animate"
            exit="exit"
            className="SignIn__form div-block-4"
            onSubmit={handleSubmit(onSubmit)}
            onChange={(e, v) => handleSelect(e, v)}
          >
            <div className="form-block w-form">
              <div className="form sign-up">
                <div style={{ position: "relative", width: "100%" }}>
                  <SignupInputField
                    className={
                      errors.firstname
                        ? "text-field _1 w-input outline-red"
                        : "text-field _1 w-input"
                    }
                    type="text"
                    name="firstname"
                    placeholder="First Name"
                    validationMessage="Please enter your first name."
                    validation={register("firstname", {
                      required: "Please enter your first name.",
                      // required: true,
                    })}
                    errors={errors}
                    disabled={isLoading}
                  />
                  {errors.firstname && (
                    <>
                      <Exclamation1 data-tip data-for="sadFace1" />
                      <StyledReactTooltip
                        id="sadFace1"
                        effect="solid"
                        place="bottom"
                        tipPointerPosition="Start"
                      >
                        {errors.firstname && (
                          <span>{errors.firstname.message}</span>
                        )}
                      </StyledReactTooltip>
                    </>
                  )}
                </div>
                <SignupInputField
                  className="text-field-2 _2 w-input"
                  type="text"
                  name="lastname"
                  placeholder="Last Name"
                  validationMessage="Please enter your last name."
                  validation={register("lastname", {
                    required: false,
                  })}
                  errors={errors}
                  disabled={isLoading}
                />
              </div>
            </div>
            <UserNameDiv className="form-block w-form">
              <div className="form sign-up _2">
                <SignupInputField
                  className={
                    errors.username || state.is_username
                      ? "text-field _1 _2 w-input outline-red"
                      : "text-field _1 _2 w-input"
                  }
                  type="text"
                  name="username"
                  placeholder="Username"
                  validationMessage="username required."
                  validation={register("username", {
                    required: "username required.",
                    minLength: {
                      value: 6,
                      message:
                        "The password should have minimum length of 6 characters",
                    },
                    maxLength: {
                      value: 30,
                      message:
                        "The password should have maximum of 30 characters",
                    },
                    onChange: (e) => {
                      checkUsername("username", e);
                    },
                  })}
                  errors={errors}
                  disabled={isLoading}
                />
                {errors.username || state.is_username ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace" />
                    <StyledReactTooltip
                      id="sadFace"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.username ? (
                        <span>{errors.username.message}</span>
                      ) : state.is_username ? (
                        <span>{state.username_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </div>
              {/* <div className="div-block-6">
                <div className="text-block-7">
                  {state.is_username && (
                    <MessageText className="text-block-7">
                      {state.username_error}
                    </MessageText>
                  )}
                </div>
              </div> */}
            </UserNameDiv>

            <div className="form-block w-form">
              <div
                style={{ position: "relative", width: "100%" }}
                className="form sign-up _2"
              >
                <SignupInputField
                  className={
                    errors.email || state.email_error
                      ? "text-field _1 _2 w-input outline-red"
                      : "text-field _1 _2 w-input"
                  }
                  type="email"
                  name="email"
                  placeholder="Your email address"
                  validationMessage="Please enter a valid email address."
                  // message="This will be used for verification."
                  validation={register("email", {
                    required: "Please enter a valid email address.",
                    onChange: (e) => {
                      checkUsername("email", e);
                    },
                    pattern: {
                      value:
                        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
                      message: "enter a valid email address",
                    },
                  })}
                  errors={errors}
                  disabled={isLoading}
                />
                {errors.email || state.email_error ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace2" />
                    <StyledReactTooltip
                      id="sadFace2"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.email ? (
                        <span>{errors.email.message}</span>
                      ) : state.email_error ? (
                        <span>{state.email_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </div>
            </div>

            <div className="form-block w-form">
              <div className="form sign-up">
                <SignUpSelect
                  handleSelect={handleSelect}
                  className="text-field _1 w-input"
                  register={register}
                  name="country"
                  options={state.countries}
                />
                <div style={{ position: "relative", width: "100%" }}>
                  {phone}
                  <SignupInputField
                    className={
                      errors.firstname
                        ? "text-field-2 _2 w-input outline-red phone-field"
                        : "text-field-2 _2 w-input phone-field"
                    }
                    type="text"
                    name="phone"
                    placeholder="Phone"
                    validationMessage="Enter a valid number."
                    validation={register("phone", {
                      required: "Enter a valid number.",

                      pattern: {
                        value:
                          /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im,
                        message: "Invalid phone number",
                      },
                    })}
                    errors={errors}
                    disabled={isLoading}
                  />
                  <CountryCode>
                    +
                    {state.country == "India"
                      ? 91
                      : state.country == "Kuwait"
                      ? 965
                      : state.country == "Oman"
                      ? 968
                      : state.country == "Qatar"
                      ? 974
                      : state.country == "Saudi Arabia"
                      ? 966
                      : state.country == "United Arab Emirates"
                      ? 971
                      : null}
                  </CountryCode>
                  {errors.phone && (
                    <>
                      <Exclamation1 data-tip data-for="sadFace3" />
                      <StyledReactTooltip
                        id="sadFace3"
                        effect="solid"
                        place="bottom"
                        tipPointerPosition="Start"
                      >
                        {errors.phone && <span>{errors.phone.message}</span>}
                      </StyledReactTooltip>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="form-block w-form">
              <div className="form sign-up">
                <div style={{ position: "relative", width: "100%" }}>
                  <SignupInputField
                    className={
                      errors.password1
                        ? "text-field _1 w-input outline-red"
                        : "text-field _1 w-input"
                    }
                    type={visibleEye1 ? "text" : "password"}
                    name="password1"
                    placeholder="Password"
                    validation={register("password1", {
                      validate: (value) =>
                        value === new_password1.current ||
                        "The passwords do not match",
                      required: "password required",
                      minLength: {
                        value: 6,
                        message:
                          "The password should have minimum length of 6 characters",
                      },
                      maxLength: {
                        value: 30,
                        message:
                          "The password should have maximum of 30 characters",
                      },
                      onChange: (e, v) => {
                        handlechange(e, v);
                      },
                    })}
                    errors={errors}
                    disabled={isLoading}
                  />
                  {errors.password1 ? (
                    <>
                      <Exclamation1 data-tip data-for="sadFace4" />
                      <StyledReactTooltip
                        id="sadFace4"
                        effect="solid"
                        place="bottom"
                        tipPointerPosition="Start"
                      >
                        {errors.password1 && (
                          <span>{errors.password1.message}</span>
                        )}
                      </StyledReactTooltip>
                    </>
                  ) : (
                    <>
                      {visibleEye1 ? (
                        <VisibilityOff onClick={() => setvisibleEye1(false)} />
                      ) : (
                        <RemovedEye onClick={() => setvisibleEye1(true)} />
                      )}
                    </>
                  )}
                </div>
                <div style={{ position: "relative", width: "100%" }}>
                  <SignupInputField
                    className={
                      errors.password2
                        ? "text-field-2 _2 w-input outline-red"
                        : "text-field-2 _2 w-input"
                    }
                    type={visibleEye2 ? "text" : "password"}
                    name="password2"
                    placeholder="Confirm"
                    validation={register("password2", {
                      validate: (value) =>
                        value === new_password1.current ||
                        "The passwords do not match",
                      required: "password required",
                      minLength: {
                        value: 6,
                        message:
                          "The password should have minimum length of 6 characters",
                      },
                      maxLength: {
                        value: 30,
                        message:
                          "The password should have maximum of 30 characters",
                      },
                      onChange: (e, v) => {
                        handlechange(e, v);
                      },
                    })}
                    errors={errors}
                    disabled={isLoading}
                    onFocus={() => setisFocused(!isFocused)}
                    // onBlur={() => console.log(">>>>>>|||||||||||||||")}
                    // onBlur={() => setisBlured(true)}
                  />
                  {errors.password2 ? (
                    isFocused ? (
                      <>
                        {visibleEye2 ? (
                          <VisibilityOff
                            onClick={() => setvisibleEye2(false)}
                          />
                        ) : (
                          <RemovedEye onClick={() => setvisibleEye2(true)} />
                        )}
                      </>
                    ) : (
                      <>
                        <Exclamation1 data-tip data-for="sadFace5" />
                        <StyledReactTooltip
                          id="sadFace5"
                          effect="solid"
                          place="bottom"
                          tipPointerPosition="Start"
                        >
                          {errors.password2 && (
                            <span>{errors.password2.message}</span>
                          )}
                        </StyledReactTooltip>
                      </>
                    )
                  ) : (
                    <>
                      {visibleEye2 ? (
                        <VisibilityOff onClick={() => setvisibleEye2(false)} />
                      ) : (
                        <RemovedEye onClick={() => setvisibleEye2(true)} />
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
            {/* <div className="div-block-6">
              <div className="">
                {!errors.password && (
                  <MessageText className="text-block-7">
                    {state.error_msg
                      ? state.error_msg
                      : errors.password2
                      ? errors.password2.message
                      : null}
                  </MessageText>
                )}
              </div>
            </div> */}
            <div className="div-block-7">
              <GoToSignin
                onClick={() => navigate(`/signin?service=${service}`)}
                className="text-block-8"
              >
                Sign in Instead.
              </GoToSignin>
              <div className="form-block _55 w-form">
                <div className="form _33">
                  <div className="div-block-5"></div>

                  <Button
                    className="button _2 w-button"
                    color="#fff"
                    background="#155e4b"
                    text="Sign up"
                    type="submit"
                  ></Button>
                </div>
              </div>
            </div>

            <div className="div-block-8">
              <div className="text-block-5">
                By clicking the above button, you accept our
              </div>
              <div className="text-block-6">
                <a href="#" className="link">
                  Terms of Service
                </a>{" "}
                And{" "}
                <a href="#" className="link-2">
                  Privacy Statement
                </a>
              </div>
            </div>
          </Form>
          <Snackbar
            anchorOrigin={{ vertical, horizontal }}
            open={open}
            onClose={handleClose}
            message="I love snacks"
            key={vertical + horizontal}
          >
            <Alert severity="success">success!please verify your email</Alert>
          </Snackbar>
        </div>
      </MainContainer>
    );
  }
};

export default SignUp;

const MainContainer = styled.div`
  display: flex;
  -webkit-justify-content: space-around;
  -ms-flex-pack: distribute;
  justify-content: space-around;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  background-color: #ecf2f0;
  height: 100vh;
`;
const ContainerHead = styled.div`
  padding-top: 13px;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;
const Form = styled.form`
  /* @media (max-width: 460px) {
    width: 100%;
    min-width: 200px;
  } */
`;
const MessageText = styled.p`
  margin-top: unset !important;
  margin-bottom: 15px;
  font-size: 13px;
  color: red;
`;
const GoToSignin = styled.div`
  cursor: pointer;
`;
const UserNameDiv = styled.div`
  /* margin-top: 10px !important; */
`;
const CountryCode = styled.span`
  position: absolute;
  left: 20px;
  cursor: pointer;
  outline: none;
  top: 8px;
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;

const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const VisibilityOff = styled(VisibilityOffIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;

const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
