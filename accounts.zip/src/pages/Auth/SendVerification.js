import { TextField } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import styled from "styled-components/macro";
// import SignMenu from "../../components/SignMenu";
// import { useDispatch, useSelector } from "react-redux";
import { resendVarificationUrl } from "../../api/AuthAPI";
import { getCookie } from "../../functions/utils";
import { selectAuthenticated } from "../../slices/user/userSlice";
// import { selectAuthenticated } from "../../slices/user/userSlice";

const SendVerification = () => {
  let navigate = useNavigate();
  // const isAuthenticated = useSelector(selectAuthenticated);
   const [access, setAccess] = useState(
     getCookie("VBID") ? getCookie("VBID") : ""
   );
  // const dispatch = useDispatch();
  const [state, setState] = useState();
  const [loading, setLoading] = useState("true");

  useEffect(() => {
    if (access) {
      navigate("/dashboard/home");
    }
    setLoading("false");
  }, []);
  const handleChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { email } = state;
    const resendVerificationResponse = await fetch(resendVarificationUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify({
        data: email,
      }),
    }).then((response) => response.json());
    console.log(resendVerificationResponse);
    if (resendVerificationResponse.success === 6000) {
      alert(resendVerificationResponse.message);
      // navigate(`/email-verification/${resendVerificationResponse.userID}`);
      navigate("/email-verification/", {
        state: { userid: resendVerificationResponse.userID },
      });
    } else {
      alert(resendVerificationResponse.message);
      //   navigate("/signin");
    }
  };
  console.log(loading, "RESENT VERIFICATION");
  return (
    <MainContainer>
      <Content>
        {/* <SignMenu /> */}
        <Container loading={loading}>
          <LogoContainer>
            <Logo src="images/vikncodes.svg" alt="logo" />
          </LogoContainer>
          <Heading>Resend Your Verification Code ?</Heading>
          <Text>
            enter your registered email address to resend verification code
          </Text>
          <Form
            onSubmit={(e) => handleSubmit(e)}
            onChange={(e) => handleChange(e)}
          >
            <InputContainer>
              <Label>Email Address</Label>
              <Input
                type="email"
                id="email"
                name="email"
                variant="outlined"
                size="small"
              />
            </InputContainer>
            <SignButtonContainer>
              <SignInButton type="submit">Resend Code</SignInButton>
            </SignButtonContainer>
          </Form>
          <BottomInfo>
            <CopyRightText>
              2021. Vikn codes LLP. All Rights Reserved
            </CopyRightText>
          </BottomInfo>
        </Container>
      </Content>
    </MainContainer>
  );
};

export default SendVerification;

const Container = styled.div`
  filter: ${({ loading }) => (loading === "true" ? "blur(2px)" : "blur(0)")};
  opacity: ${({ loading }) => (loading === "true" ? "0.2" : "1")};
  transition: all 0.5s ease-in-out;
  width: 500px;
  min-width: 500px;
  position: relative;
  border: 1px solid #ccc;
  /* border-left: 0; */
  border-radius: 15px;
  padding: 30px;
`;
const LogoContainer = styled.div`
  width: 150px;
`;
const Logo = styled.img`
  width: 100%;
`;
const Heading = styled.h1`
  font-size: 25px;
  font-weight: bold;
  text-align: right;
  color: #0a2150;
  margin: 10px 0;
`;
const InputContainer = styled.div`
  margin-left: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 20px;
`;
const Input = styled(TextField)`
  background: #fff;
  & .MuiOutlinedInput-inputMarginDense {
    font-family: "poppinsregular";
    padding-bottom: 6.5px;
  }
`;

const SignButtonContainer = styled.div`
  margin-top: 10px;
  text-align: right;
`;
const SignInButton = styled.button`
  cursor: pointer;
  color: #fff;
  background: #1f9100;
  padding: 10px 20px 10px 20px;
  border-radius: 3px;
  outline: none;
  position: relative;
  border: 0;
`;

const Label = styled.p`
  margin-right: 10px;
`;
const CopyRightText = styled.p`
  color: #ababab;
  margin: unset;
  font-size: 13px;
`;
const Form = styled.form`
  padding-left: 85px;
`;
const BottomInfo = styled.div`
  position: absolute;
  right: 176px;
  bottom: 5px;
`;
const MainContainer = styled.div`
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  height: 100vh;
`;
const Content = styled.div`
  display: flex;
  justify-content: center;
`;
const Text = styled.p`
  color: #a7a7a7;
  text-transform: capitalize;
  text-align: right;
`;
