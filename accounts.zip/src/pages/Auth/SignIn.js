import React, { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import styled from "styled-components/macro";

import InputField from "../../components/InputField/InputField";
import { staggerOne } from "../../motionUtils";
import SmallHeading from "../../components/SmallHeading/SmallHeading";
import Button from "../../components/Buttons/Button";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";
import {
  Decrypt,
  Encrypt,
  EncryptBase64,
  EncryptBTOA,
  getAvatar,
  getCookie,
  getDecryptedData,
  getServiceUrl,
  getUnqNo,
} from "../../functions/utils";
import {
  COOKIE_API_URL,
  PAYROLL_FRONT_URL,
  SIGNIN_URL,
  TASK_FRONT_URL,
  URL,
  VIKNBOOKS_API_URL,
  VIKNBOOKS_FRONT_URL,
  domain,
} from "../../settings";
import { useDispatch } from "react-redux";
import { loginSuccess } from "../../slices/user/userSlice";
import "../../style.css";
import SigninInputField from "../../components/InputField/SigninInputField";
import {
  Checkbox,
  FormControlLabel,
  FormGroup,
  CircularProgress,
} from "@material-ui/core";
import UserNameCard from "../../components/Card/UserNameCard";
import CloseIcon from "@material-ui/icons/Close";
import {
  getCurrentDetails,
  get_unq_browserID,
  set_BrowserUnqCookies,
  set_RecentLoginUsersCookies,
} from "../../functions/common";
import ErrorIcon from "@mui/icons-material/Error";
import ReactTooltip from "react-tooltip";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import browserSignature from "browser-signature";

// var createGuest = require("cross-domain-storage/guest");
// var createHost = require("cross-domain-storage/host");
// var storageHost = createHost([
//   {
//     origin: "http://localhost:3000/",
//     allowedMethods: ["get", "set", "remove"],
//   },
//   {
//     origin: "http://localhost:3002/",
//     allowedMethods: ["get"],
//   },
// ]);

const SignIn = () => {
  const dispatch = useDispatch();
  const signature = browserSignature();
  const usernameRef = useRef(null);
  const [visibleEye1, setvisibleEye1] = useState(false);

  const [loading, setLoading] = useState(false);
  const [state, setState] = useState({
    username: null,
    username_error: null,
    password: null,
    recent_login_users: [],
    recent_username: null,
    recent_use_image: null,
    remember_me: true,
  });
  // const params = new Proxy(new URLSearchParams(window.location.search), {
  //   get: (searchParams, prop) => searchParams.get(prop),
  // });
  // let service = params.service;
  let service = getServiceUrl(window.location.href);
  if (
    service === "task_manager" ||
    service === "payroll" ||
    service === "viknbooks"
  ) {
    console.log(service, "**********************");
  } else {
    service = "accounts";
  }
  console.log(service, "##############**********************");
  const navigate = useNavigate();
  const isLoading = false;
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    reValidateMode: "onChange",
  });

  useEffect(() => {
    if (service == "viknbooks" && getCookie("VBID")) {
      document.cookie = `VBID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;domain=${domain}`;
    }
  }, [service]);
  useEffect(() => {
    getCurrentDetails();
    let recent_login_users = getCookie("ACCOUNT_CHOOSER");
    let data = [];
    if (recent_login_users) {
      try {
        data = Decrypt(JSON.parse(recent_login_users));
      } catch (error) {
        data = Decrypt(recent_login_users);
      }

      setState((prevState) => {
        return {
          ...prevState,
          recent_login_users: data,
        };
      });
    }
  }, []);
  const handleUserNameCard = (value, type) => {
    let username = document.getElementById("id_username");
    console.log(value);
    console.log(type);
    username.value = value;
    username.type = type;
    setValue("username", value);
  };
  const handleClickRecentUser = (data) => {
    handleUserNameCard(data.username, "hidden");
    setState((prevState) => {
      return {
        ...prevState,
        recent_username: data.username,
        recent_use_image: data.image_url,
        username_error: "",
        password_error: "",
      };
    });
  };
  const handleCloseUsernameCard = () => {
    handleUserNameCard(null, "text");

    setState((prevState) => {
      return {
        ...prevState,
        recent_username: null,
        recent_use_image: null,
      };
    });
  };

  const handleCloseRecentNameCard = (value) => {
    let recent_login_users = state.recent_login_users.filter(
      (i) => i !== value
    );
    set_RecentLoginUsersCookies(recent_login_users);
    setState((prevState) => {
      return {
        ...prevState,
        recent_login_users,
      };
    });
  };
  const handleRemember = (event) => {
    console.log(event.target.value);
    setState((prevState) => {
      return {
        remember_me: event.target.checked,
      };
    });
  };
  const handleChange = (event) => {
    console.log(event.target.checked);
  };
  const onSubmit = async (data) => {
    // --------------------------------------
    // let uqNo = getUnqNo();
    let uqNo = "";
    try {
      uqNo = await get_unq_browserID("device-uid");
    } catch (err) {
      // uqNo = 12345;
      uqNo = await get_unq_browserID("uid");
      //uqNo = getUnqNo();
    }
    // localStorage.setItem("uqNo", uqNo);
    console.log("uqNo||||||||||||||");
    console.log(uqNo);
    // --------------------------------------
    setLoading(true);
    const { username, password, remember_me } = data;
    const params = new Proxy(new URLSearchParams(window.location.search), {
      get: (searchParams, prop) => searchParams.get(prop),
    });
    let value = params.service;
    let is_admin = params.LoginAdmin;
    if (!is_admin) {
      is_admin = false;
    }
    SIGNIN_URL.post(`/users/login`, { username, password, service, is_admin })
      .then(function (response) {
        if (response.data.success === 6000) {
          axios
            .get(
              `${URL}api/v1/accounts/accounts?sid=${response.data.data.access}&is_admin=${is_admin}`,
              { withCredentials: true }
            )
            .then(() => {
              dispatch(
                loginSuccess({
                  ...response.data.data,
                  username: response.data.data.username,
                })
              );
              let pass_data = {
                token: response.data.data.access,
                service: value,
                is_admin: is_admin,
              };
              let ciphertext = Encrypt(pass_data);
              window.open(
                `${VIKNBOOKS_FRONT_URL}dashboard/home?data=${ciphertext}&uqNo=${uqNo}&remember_me=${remember_me}`,
                "_self"
              );
            });
        } else if (response.data.success === 6001) {
          let password_error = "";
          let username_error = "";
          if (response.data.error_code === 6002) {
            password_error = response.data.error;
            username_error = "";
          } else if (response.data.error_code === 6003) {
            setLoading(false);
            if (response.data.error_code === 6003) {
              navigate(
                `/email-verification/?q=${response.data.user_email}&service=${value}`,
                {
                  state: {
                    userid: response.data.data,
                  },
                }
              );
            } else {
              setState((prevState) => {
                return {
                  ...prevState,
                  username_error: response.data.error,
                };
              });
            }
          } else {
            username_error = response.data.error;
            password_error = "";
          }
          setLoading(false);

          setState((prevState) => {
            return {
              ...prevState,
              username_error,
              password_error,
            };
          });
        }
      })
      .catch((error) => {
        setLoading(false);
        console.error("There was an error!", error);
      });
  };
  // const handlechange = () => {
  //   setState((prevState) => {
  //     return {
  //       username_error: null,
  //     };
  //   });
  // };
  console.log(errors);
  console.log(state.username_error);
  return (
    <MainContainer>
      <Container className="section login wf-section">
        <img src="../../images/1.svg" loading="lazy" alt="" />
        {/* ========RECT USERS============ */}
        {state.recent_login_users.length > 0 &&
        state.recent_username == null ? (
          [
            <RecentHead className="text-block">Recent Logins</RecentHead>,
            <RecentContainer className="div-block">
              {state.recent_login_users.map((i) => (
                <RecentInnerCard>
                  <CloseContainer>
                    <CloseIconDiv
                      onClick={() => {
                        handleCloseRecentNameCard(i);
                      }}
                    />
                  </CloseContainer>

                  <ImgContainer>
                    <RecentUserImg
                      onClick={() => handleClickRecentUser(i)}
                      // src="https://uploads-ssl.webflow.com/62cea7db42570ac27a160653/62cfd04ccd5cb4653e5cc6fc_Rectangle%209804.png"
                      src={getAvatar(i.id)}
                      loading="lazy"
                      height="44"
                      width="44"
                      alt=""
                    />
                    <div className="text-block-2">{i.username}</div>
                  </ImgContainer>

                  {/* <img
                    src="https://uploads-ssl.webflow.com/62cea7db42570ac27a160653/62cfd0cc6b0d2a6ac9bf5ba0_Group%20984.png"
                    loading="lazy"
                    width="4"
                    alt=""
                    className="image-2"
                  /> */}
                </RecentInnerCard>
              ))}

              <CreateNew
                onClick={() => navigate(`/sign-up?service=${service}`)}
                className="div-block-3 w-inline-block"
              >
                <img
                  src="../../images/Plus.svg"
                  loading="lazy"
                  height="44"
                  width="44"
                  alt=""
                  className="image _1"
                />
                <div className="text-block-3">Create New</div>
              </CreateNew>
            </RecentContainer>,
            <img
              src="../../images/Or.svg"
              // src="https://uploads-ssl.webflow.com/62cea7db42570ac27a160653/62cfd3500601297a58c2f1a7_or.svg"
              loading="lazy"
              alt=""
              className="image-3"
            />,
            <ContainerHead className="text-block-4">
              Login To Another Vikn Account
            </ContainerHead>,
          ]
        ) : (
          <ContainerHead className="text-block-4">
            Login To Vikn Account
          </ContainerHead>
        )}
        {/* =========================== */}

        <div className="div-block-4">
          <div className="form-block w-form">
            <Form
              variants={staggerOne}
              initial="initial"
              animate="animate"
              exit="exit"
              className="SignIn__form form"
              onSubmit={handleSubmit(onSubmit)}
            >
              {state.recent_username == null ? null : (
                <UserNameCard
                  handleCloseUsernameCard={handleCloseUsernameCard}
                  state={state}
                />
              )}
              <>
                <SigninInputField
                  // style={{ position: "relative" }}
                  className={
                    errors.username || state.username_error
                      ? "text-field w-input user-name outline-red"
                      : "text-field w-input user-name"
                  }
                  type="text"
                  id="id_username"
                  name="username"
                  placeholder="username or email"
                  // validationMessage="Please enter a valid username."
                  validationMessage="username required."
                  validation={register("username", {
                    required: "username required.",
                  })}
                  errors={errors}
                  disabled={isLoading}
                />
                {errors.username || state.username_error ? (
                  <>
                    <Exclamation1 data-tip data-for="sadFace" />
                    <StyledReactTooltip
                      id="sadFace"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.username ? (
                        <span>{errors.username.message}</span>
                      ) : state.username_error ? (
                        <span>{state.username_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : null}
              </>
              <div style={{ position: "relative", width: "100%" }}>
                <SigninInputField
                  className={
                    errors.password
                      ? "text-field-2 w-input outline-red"
                      : "text-field-2 w-input"
                  }
                  type={visibleEye1 ? "text" : "password"}
                  name="password"
                  placeholder="Password"
                  validationMessage="The password should have a length between 6 and 30 characters."
                  // validationMessage="password required."
                  validation={register("password", {
                    required: "password required",
                    minLength: {
                      value: 6,
                      message:
                        "The password should have minimum length of 6 characters",
                    },
                    maxLength: {
                      value: 30,
                      message:
                        "The password should have maximum of 30 characters",
                    },
                  })}
                  errors={errors}
                  disabled={isLoading}
                />

                {errors.password || state.password_error ? (
                  <>
                    <Exclamation2 data-tip data-for="sadFace1" />
                    <StyledReactTooltip
                      id="sadFace1"
                      effect="solid"
                      place="bottom"
                      tipPointerPosition="Start"
                    >
                      {errors.password ? (
                        <span>{errors.password.message}</span>
                      ) : state.password_error ? (
                        <span>{state.password_error}</span>
                      ) : null}
                    </StyledReactTooltip>
                  </>
                ) : (
                  <>
                    {visibleEye1 ? (
                      <VisibilityOff
                        onClick={() => setvisibleEye1(false)}
                        data-tip
                        data-for="sadFace1"
                      />
                    ) : (
                      <RemovedEye
                        onClick={() => setvisibleEye1(true)}
                        data-tip
                        data-for="sadFace1"
                      />
                    )}
                  </>
                )}
              </div>
              <BottomContainer>
                <CheckBoxContainer>
                  <CheckBoxInnerContainer
                    style={{ paddingTop: "23px", paddingLeft: "10px" }}
                    control={
                      <Checkbox
                        // onChange={(e, v) => handleChange(e, v)}
                        defaultChecked
                        color="default"
                        name="remember_me"
                        {...register("remember_me")}
                      />
                    }
                    label="Remember me"
                    name="remember_me"
                  />
                </CheckBoxContainer>
                <ForgotPasswordButton text="Forgot Password" type="button">
                  <Link to="/forgot-password">{"Forgot Password?"}</Link>
                </ForgotPasswordButton>
              </BottomContainer>
              <Button
                className="button w-button"
                color="#fff"
                background="#155e4b"
                text="Sign In"
                type="submit"
                loading={loading}
              ></Button>
              {state.recent_login_users.length > 0 ? null : (
                <Button
                  className="button create w-button"
                  background="#fff"
                  color="#276eb5"
                  text="Create New Account"
                  type="button"
                  onClick={() => navigate(`/sign-up?service=${service}`)}
                ></Button>
              )}
            </Form>
          </div>
          <TextBlock5>By clicking the above button, you accept our</TextBlock5>
          <TextBlock6>
            <a href="#" className="link">
              Terms of Service
            </a>{" "}
            And{" "}
            <a href="#" className="link-2">
              Privacy Statement
            </a>
          </TextBlock6>
        </div>
      </Container>
    </MainContainer>
  );
};

export default SignIn;

const MainContainer = styled.div`
  display: flex;
  -webkit-justify-content: space-around;
  -ms-flex-pack: distribute;
  justify-content: space-around;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  background-color: #ecf2f0;
  height: 100vh;
`;
const Label = styled.p`
  margin-top: 0.4em;
  font-size: 13px;
  color: rgb(255, 0, 0);
  min-height: 10px;
  margin-bottom: 0;
`;
const MessageText = styled.p`
  margin-top: 0.4em;
  font-size: 13px;
  color: #727272;
  min-height: 10px;
  margin-bottom: 0;
`;

const Input = styled.input`
  width: 100%;
  height: 39px;
  border: 1px solid #a8a7aa;
  border-radius: 9px;
  font-family: Poppins, sans-serif;
  color: #000;

  .w-input {
    display: block;
    width: 100%;
    height: 38px;
    padding: 8px 12px;
    margin-bottom: 10px;
    font-size: 14px;
    line-height: 1.42857143;
    color: #333333;
    /* vertical-align: middle; */
    background-color: #ffffff;
    border: 1px solid #cccccc;
    .text-field- {
      height: 39px;
      margin-top: 0px;
      border: 1px solid #a8a7aa;
      border-radius: 9px;
      font-family: Poppins, sans-serif;
    }
  }
`;
const Container = styled.div`
  display: flex;
  width: 419px;
  height: auto;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  border-style: none;
  border-width: 1px;
  border-color: #dbdbdb;
  background-color: #ecf2f0;
  line-height: 23px;
`;
const ContainerHead = styled.div`
  padding-top: 13px;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;
const RecentHead = styled.div`
  display: flex;
  margin-top: 25px;
  font-family: Poppins, sans-serif;
  font-size: 16px;
  font-weight: 500;
`;
const RecentContainer = styled.div`
  display: flex;
  width: 80%;
  height: auto;
  margin-top: 11px;
  flex-direction: row;
  justify-content: space-around;
`;
const RecentInnerCard = styled.div`
  /* cursor: pointer; */
  position: relative;
  display: flex;
  width: 101px;
  height: 101px;
  flex-direction: column;
  align-items: center;
  border-radius: 13px;
  background-color: #fff;
  text-decoration: none;
  &.w-inline-block {
    max-width: 100%;
    display: inline-block;
  }
`;
const ImgContainer = styled.div`
  /* cursor: pointer; */
  position: relative;
  display: flex;
  width: 101px;
  height: 101px;
  flex-direction: column;
  align-items: center;
  border-radius: 13px;
  background-color: #fff;
  text-decoration: none;
`;
const CreateNew = styled.div`
  cursor: pointer;
  display: flex;
  width: 101px;
  height: 101px;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  border-radius: 13px;
  background-image: linear-gradient(127deg, #eb5a46, #972d06);
  text-decoration: none;
`;
const TextBlock5 = styled.div`
  margin-top: 17px;
  font-family: Poppins, sans-serif;
  color: #999;
  font-size: 13px;
`;
const TextBlock6 = styled.div`
  color: #a5a5a5;
  font-size: 13px;
  font-weight: 400;
  text-align: right;
  text-decoration: none;
`;
const Form = styled.form``;
const BottomContainer = styled.div`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const ForgotPasswordButton = styled.button`
  cursor: pointer;
  background: unset;

  a {
    color: #0a7292;
  }
`;
const CheckBoxContainer = styled(FormGroup)``;
const CheckBoxInnerContainer = styled(FormControlLabel)`
  padding-top: unset !important;
  .MuiTypography-root.MuiFormControlLabel-label.MuiTypography-body1 {
    font-size: 14px;
    font-family: "Poppins", sans-serif;
  }
`;
// const CheckBox = styled(CheckBox)``;
const CloseIconDiv = styled(CloseIcon)`
  cursor: pointer;
  width: 17px !important;
  height: 17px !important;
  /* position: absolute;
  top: 4px;
  right: 4px; */
  svg.MuiSvgIcon-root {
  }
`;
const CloseContainer = styled.div`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  padding: 3px 3px 0px 0px;
`;
const RecentUserImg = styled.img`
  /* margin-top: 18px; */
  border-radius: 51px;
  box-shadow: 5px 5px 11px 1px rgb(0 0 0 / 31%);
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000; ;
`;
const Exclamation2 = styled(Exclamation1)`
  /* right: 33px; */
`;

const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
const RemovedEye = styled(RemoveRedEyeIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
const VisibilityOff = styled(VisibilityOffIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #979797;
`;
