import * as base from "../settings";

export const countryUrl = base.BASE_URL + "countries/countries/";
export const countryStateUrl = base.BASE_URL + "states/country-states/";
export const stateDetailUrl = base.BASE_URL + "states/get-state-detail/";
