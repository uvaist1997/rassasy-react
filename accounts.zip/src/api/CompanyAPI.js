import * as base from "../settings";

export const companiesUrl = base.BASE_URL + "company/companies/";
export const getSingleCompanyUrl =
  base.BASE_URL + "company/get-company-details/";
