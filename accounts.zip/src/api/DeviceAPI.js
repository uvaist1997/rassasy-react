import * as base from "../settings";

export const deviceListUrl = base.BASE_URL + "users/list-device/";
