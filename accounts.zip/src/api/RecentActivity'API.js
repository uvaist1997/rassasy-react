import * as base from "../settings";

export const recentActivityListUrl =
  base.BASE_URL + "users/list-recent-activity/";
