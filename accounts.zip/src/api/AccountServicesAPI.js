import * as base from "../settings";

export const listAccountServicesUrl =
  base.BASE_URL + "users/list-account-services/";

export const accountServiceStatusUrl =
  base.BASE_URL + "users/account-service-status/";

export const accountDeleteUrl = base.BASE_URL + "users/account-delete/";
export const changeOwnerShipUrl = base.BASE_URL + "users/change-ownership/";
export const deleteOrganisationUrl =
  base.BASE_URL + "users/delete-organisation/";

export const accountSubscriptionUrl =
  base.BASE_URL + "accounts/payments-subscription";
