import styled from "styled-components/macro";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  logoutSuccess,
  selectAuthenticated,
} from "../../slices/user/userSlice";
import { useNavigate } from "react-router-dom";
import LogoutIcon from "@mui/icons-material/Logout";
import {
  Decrypt,
  Encrypt,
  getCookie,
  getDecryptedData,
  setRecentUsersCookie,
} from "../../functions/utils";
import axios from "axios";
import { URL } from "../../settings";
import {
  set_handleLogout,
  set_RecentLoginUsersCookies,
} from "../../functions/common";
import Header from "../Header/Header";

const _ = require("lodash");

const Dashboard = ({ text, align }) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  //   const isAuthenticated = useSelector(selectAuthenticated);
  const { username, email } = useSelector((state) => state.user);

  const [access, setAccess] = useState(getCookie("VBID"));
  const [callRefresh, setcallRefresh] = useState(false);

  useEffect(() => {
    if (!access) {
      navigate("/signin");
    }
  }, [access]);
  useEffect(() => {
    if (callRefresh === true) {
      window.location.reload();
      dispatch(
        logoutSuccess({
          username: "",
          email: "",
          user_id: "",
          isAuth: false,
          admin_login: false,
        })
      );
      setcallRefresh(false);
    }
  }, [callRefresh]);

  const handleLogout = () => {
    let dic = {
      username: username,
      email: email,
      image_url:
        "https://www.api.viknbooks.com/media/profiles/Screenshot_from_2022-02-02_11-45-23.png",
    };
    set_handleLogout(dic);
    setAccess("");
    setcallRefresh(true);
  };
  return (
    <Container>
      {/* <div>Dashboard</div>
      <LogoutContainer
        onClick={(e) => {
          handleLogout(e);
        }}
      >
        <LogoutIcon />
      </LogoutContainer> */}
    </Container>
  );
};

export default Dashboard;

const Container = styled.div`
  font-weight: bold;
  text-align: "center";
  display: flex;
  justify-content: space-between;
`;
const LogoutContainer = styled.div`
  cursor: pointer;
`;
