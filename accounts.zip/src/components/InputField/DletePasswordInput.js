import React from "react";
import styled from "styled-components/macro";
import FormControl from "@mui/material/FormControl";
import ReactTooltip from "react-tooltip";
import ErrorIcon from "@mui/icons-material/Error";

const DletePasswordInput = ({
  type,
  placeholder,
  name,
  validationMessage,
  message,
  validation,
  errors,
  disabled,
  width,
  className,
  onFocus,
  onBlur,
}) => {
  return (
    <Input
      className={className}
      type={type}
      name={name}
      placeholder={placeholder}
      {...validation}
      disabled={disabled}
      onFocus={() => (onFocus ? onFocus() : null)}
    />
  );
};

export default DletePasswordInput;
const Form_control = styled(FormControl)`
  && {
    width: 473px;

    margin-left: 29px;
  }
  @media (max-width: 748px) {
    width: 525px;
  }
  button {
    padding: unset !important;
  }
`;
const Container = styled.div`
  width: 100%;
`;

const Input = styled.input`
  width: 100%;
  box-sizing: border-box;

  font-family: "Poppins", sans-serif;
  font-size: 13px;
  height: 39px;
  padding-left: 10px;

  outline: none;
  border-radius: 9px;
  border: 1px solid #a8a7aa;
  ::placeholder {
    color: #9f9f9f;
    font-size: 13px;
  }
  &.outline-red {
    outline: 1px solid red;
  }
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
