import React from "react";
import styled from "styled-components/macro";
import FormControl from "@mui/material/FormControl";
import ReactTooltip from "react-tooltip";
import ErrorIcon from "@mui/icons-material/Error";

const ResetPasswordInputField = ({
  type,
  placeholder,
  name,
  validationMessage,
  message,
  validation,
  errors,
  disabled,
  width,
  className,
  onFocus,
  onBlur,
}) => {
  return (
    <Input
      className={className}
      type={type}
      name={name}
      placeholder={placeholder}
      {...validation}
      disabled={disabled}
      onFocus={() => (onFocus ? onFocus() : null)}
    />
  );
};

export default ResetPasswordInputField;
const Form_control = styled(FormControl)`
  && {
    width: 473px;

    margin-left: 29px;
  }
  @media (max-width: 748px) {
    width: 525px;
  }
  button {
    padding: unset !important;
  }
`;
const Container = styled.div`
  width: 100%;
`;

const Input = styled.input`
  border: unset;
  border-bottom: 1px solid rgba(0, 0, 0, 0.42);
  padding: 4px 0 5px;
  font-size: 1rem;
  line-height: 1.4375em;
  letter-spacing: 0.00938em;
  color: currentColor;
  &.outline-red {
    border-bottom: 1px solid red;
  }
  &:focus-visible {
    outline: unset;
    border-bottom: 1px solid rgba(0, 0, 0, 0.42) !important;
  }
  ::placeholder {
    font-size: 12px;
  }
`;
const Exclamation1 = styled(ErrorIcon)`
  position: absolute;
  right: 13px;
  cursor: pointer;
  outline: none;
  top: 7px;
  color: #b40000;
`;
const StyledReactTooltip = styled(ReactTooltip)`
  background-color: white !important;

  color: black !important;
  box-shadow: 0px 2px 20px lightgray;
  &:after {
    border-bottom-color: white !important;
    border-top-color: white !important;
    /* margin-left: 9px !important; */
  }
`;
