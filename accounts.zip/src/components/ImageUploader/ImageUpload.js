import styled from "styled-components/macro";
import React, { useState, useEffect } from "react";
import Button from "@mui/material/Button";
import { getFileUrl } from "../../functions/common";
import { TryRounded } from "@mui/icons-material";
import { useTranslation } from "react-i18next";

function ImageUpload(props) {
  const [t] = useTranslation("common");
  const [state, setState] = useState({
    profileImage_url:
      "https://png.pngtree.com/png-vector/20191027/ourlarge/pngtree-avatar-vector-icon-white-background-png-image_1884971.jpg",
  });

  const onChange = async (e) => {
    // let src = await new Promise((resolve) => {
    //   const reader = new FileReader();
    //   reader.readAsDataURL(e.target.files[0]);
    //   reader.onload = () => resolve(reader.result);
    // });
    let src = await getFileUrl(e.target.files[0]);
    setState((prevState) => {
      return {
        ...prevState,
        profileImage_url: src,
      };
    });
    props.setFileList(e.target.files[0]);
    props.setPersonalData((prevState) => {
      return {
        ...prevState,
        call_save: true,
      };
    });
  };

  useEffect(() => {
    if (props.personalData.profile_pic) {
      setState((prevState) => {
        return {
          ...prevState,
          profileImage_url: props.personalData.profile_pic,
        };
      });
    }
  }, [props.personalData.profile_pic]);

  return (
    <>
      <ImagContainer>
        <Img src={state.profileImage_url} />
      </ImagContainer>
      <StyledButton variant="contained">
        <Container>
          <NameTxt>{t("Change")}</NameTxt>
          <Input type="file" onChange={onChange} />
        </Container>
      </StyledButton>
    </>
  );
}

export default ImageUpload;

const Img = styled.img`
  width: 100%;
  height: 100%;
  border-radius: 50px;
`;
const ImagContainer = styled.div`
  width: 88px;
  margin: auto;
  border-radius: 50px;
  height: 88px;
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 9px;
    text-transform: capitalize;
    font-family: "poppins", sans-serif;
    background-color: unset;
    background-image: linear-gradient(280deg, #033631, #005049);
    max-width: 154px;
  }
`;

const NameTxt = styled.span`
  position: absolute;
  top: 1px;
  cursor: pointer;
  left: 41px;
`;
const Container = styled.div`
  position: relative;
  cursor: pointer;
`;
const Input = styled.input`
  opacity: 0;
  cursor: pointer;
  width: 154px;
`;
// const ImageUpload = styled(Upload)`
//   .ant-upload.ant-upload-select.ant-upload-select-picture-card {
//     border: 1px solid #ccc;
//   }
//   .ant-upload.ant-upload-select-picture-card > .ant-upload {
//     background: whitesmoke;
//     border-radius: inherit;
//   }
// `;
