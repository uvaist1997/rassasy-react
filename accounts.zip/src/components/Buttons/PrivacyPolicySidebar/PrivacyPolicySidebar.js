import React, { useRef, useState } from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import styled from "styled-components/macro";
import { Link } from "react-scroll";
import { Element } from "react-scroll";
import { useTranslation } from "react-i18next";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`vertical-tabpanel-${index}`}
      aria-labelledby={`vertical-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box>
          <Typography1>{children}</Typography1>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `vertical-tab-${index}`,
    "aria-controls": `vertical-tabpanel-${index}`,
  };
}

export default function PrivacyPolicySidebar({ menuss, image1, headline }) {
  const [t] = useTranslation("common");
  const [value, setValue] = useState(0);

  const [height1, setHeight1] = useState();
  const ref = useRef(null);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const [active, setActive] = useState(0);
  return (
    <Boxx
      sx={{
        flexGrow: 1,

        display: "flex",
        // height: 224,
      }}
      check={active}
      height1={height1}
    >
      <Tabs1
        orientation="vertical"
        // variant="scrollable"
        value={value}
        onChange={handleChange}
        aria-label="Vertical tabs example"
        sx={{ borderRight: 1, borderColor: "divider" }}
      >
        {menuss.heading.map((item, index) => (
          <Atag
            href={`#${index + 1}`}
            smooth={true}
            duration={500}
            active={active}
            index={index}
          >
            <TabMenu
              onClick={(e) => {
                setActive(e.target.offsetTop);
                setHeight1(e.target.clientHeight);
              }}
              ref={ref}
              label={item}
              {...a11yProps(index)}
            />
          </Atag>
        ))}
      </Tabs1>
      <TablePanel1 value={value} index={0}>
        <InfoContainer>
          <Element id="1">
            <HeadingContainer>
              <First>
                <Headline>{headline}</Headline>

                <SmallTxt>
                  {t(
                    `Please read these terms and conditions carefully before using
                    the Application. Your access to and use of the service is
                    conditioned on your acceptance of and compliance with
                    these terms. These terms apply to all visitors, users and
                    others who access or use the service.`
                  )}
                </SmallTxt>

                <InlineContainer>
                  <SmallTxt>{t("Last updated")} : </SmallTxt>
                  <DateTxt>{t("August 22, 2022")}</DateTxt>
                </InlineContainer>
              </First>
              <ImageContainer>
                <ImgLogo src={image1} />
              </ImageContainer>
            </HeadingContainer>
          </Element>
          <NotesContainer>
            <SmallTxt>
              {t(
                `These terms will be applied fully and affect to your use of this
                application. By using this application, you agreed to accept all
                terms and conditions written in here. You must not use this
                application if you disagree with any of these application
                standard terms and conditions.`
              )}
            </SmallTxt>
            <SubHeading>{menuss.heading[0]}</SubHeading>
            <SmallTxt>
              {t(
                `Other than the content you own, under these terms, Vikn
                  Codes and/or its licensors own all the intellectual property
                  rights and materials contained on this application.`
              )}
            </SmallTxt>

            {/* ========================Demo========================= */}
            <Element style={{ textAlign: "left" }} id="2">
              <SubHeading>{menuss.heading[1]}</SubHeading>

              <SmallTxt>
                {t(
                  "You are specifically restricted from all of the following:"
                )}
              </SmallTxt>
              <Li>
                {t("Publishing any application material in any other media.")}
              </Li>
              <Li>
                {t(
                  `Selling, sublicensing and/or otherwise commercializing any application material.`
                )}
              </Li>
              <Li>
                {t(
                  `Publicly performing and/or showing any application
                  material.`
                )}
              </Li>
              <Li>
                {t(
                  `Using the application in any way that impacts user
                  access to this application.`
                )}
              </Li>
              <Li>
                {t(
                  `Engaging in any data mining, data harvesting, data
                  extracting or any other similar activity in relation to this
                  application.`
                )}
              </Li>
              <Li>
                {t(
                  `Using this application to engage in any advertising or
                  marketing.`
                )}
              </Li>
              <SmallTxt>
                {t(
                  `Certain areas of this application are restricted from
                  being access by you and Vikn Codes may further restrict
                  access by you to any areas of this application, at any time, in
                  absolute discretion. Any user ID and password you may have
                  for this application are confidential and you maintain
                  confidentiality as well.`
                )}
              </SmallTxt>
            </Element>
            <Element style={{ textAlign: "left" }} id="3">
              <SubHeading>{menuss.heading[2]}</SubHeading>

              <SmallTxt>
                {t(
                  `Your content must be own and must not invading any third
                  party’s rights. Vikn Codes reserves the right to remove any of
                  your content from this application at any time without
                  notice.`
                )}
              </SmallTxt>
            </Element>
            <Element style={{ textAlign: "left" }} id="Third party sites">
              <SubHeading>{menuss.heading[3]}</SubHeading>
              <SmallTxt>
                {t(
                  `You hereby indemnify to the fullest extent Vikn Codes from
                  and against any and or/ all liabilities, costs, demands, causes
                  of action, damages and expenses arising in any way related
                  to your breach of any of the provisions of these terms.`
                )}
              </SmallTxt>
            </Element>
            <Element style={{ textAlign: "left" }} id="4">
              <SubHeading>{menuss.heading[4]}</SubHeading>

              <SmallTxt>
                {t(
                  `Vikn Codes is permitted to revise these terms at any time as
                  it sees fit, and by using this application you are expected to
                  review these terms on a regular basis.`
                )}
              </SmallTxt>
            </Element>
            <Element style={{ textAlign: "left" }} id="4">
              <SubHeading>{menuss.heading[5]}</SubHeading>

              <SmallTxt>
                {t(
                  `These terms constitute the entire agreement between Vikn
                  Codes and you in relation to your use of this application, and
                  supersede all prior agreements and understandings.`
                )}
              </SmallTxt>
            </Element>
            <Element style={{ textAlign: "left" }} id="4">
              <SubHeading>{menuss.heading[6]}</SubHeading>

              <SmallTxt>
                {t(
                  `These terms will be governed by and interpreted in
                  accordance with the laws of the state of country, and you
                  submit to the non- exclusive jurisdiction of the state and
                  federal courts located in country for the resolution of any
                  disputes.`
                )}
              </SmallTxt>
            </Element>
          </NotesContainer>
        </InfoContainer>
      </TablePanel1>
    </Boxx>
  );
}

const Li = styled.li`
  font-size: 14px;
  margin-left: 5px;
  color: #7b7b7b;
  text-align: left;
`;

const Atag = styled.a`
  text-decoration: none;
  text-align: left;
  color: unset;
  z-index: 0;
`;

const SubHeading = styled.span`
  font-size: 16px;
  font-weight: 500;
  margin-top: 15px;
  margin-bottom: 10px;
`;
const NotesContainer = styled.div`
  display: grid;
  place-items: baseline;
  grid-template-columns: 1fr;
  max-width: 614px;
  width: 83vw;

  padding: 30px;
  background-color: white;
  border-radius: 23px;
`;

const Typography1 = styled(Typography)`
  && {
    font-family: "poppins", sans-serif !important;
  }
`;
const InlineContainer = styled.div`
  display: flex;

  @media (max-width: 1024px) {
    justify-content: center;
  }
  margin-top: 15px; ;
`;
const DateTxt = styled.span`
  font-size: 14px;
  color: #033631;
  margin-left: 5px;
  font-weight: 500;
`;
const ImgLogo = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
`;

const First = styled.div`
  align-self: end;
  text-align: left;
  @media (max-width: 1024px) {
    text-align: unset;
  }
`;

const ImageContainer = styled.div`
  width: 208px;
  height: 208px;
`;
const TablePanel1 = styled(TabPanel)`
  width: 100%;
  overflow-y: scroll;

  scroll-behavior: smooth;
  height: 646px;
  @media (width: 1920px) {
    height: 844px;
  }
  @media (width: 1800px) {
    height: 778px;
  }
  @media (width: 1600px) {
    height: 712px;
  }
  @media (width: 1152px) {
    height: 440px;
  }
  @media (width: 1309.09px) {
    height: 545px;
  }
  ::-webkit-scrollbar {
    display: none;
  }
  display: flex;

  justify-content: center;
`;
const InfoContainer = styled.div``;

const HeadingContainer = styled.div`
  font-family: "poppins", sans-serif !important;

  display: grid;
  grid-template-columns: 1.5fr 1fr;
  @media (max-width: 1024px) {
    max-width: 656px;
    grid-template-columns: 1fr;
    margin: auto;
    place-items: center;
  }

  padding: 10px;
  max-width: 614px;
  width: 83vw;
`;
const Headline = styled.h4`
  font-size: 24px;
  margin: 0;
  font-weight: 500;
  color: #000000;
`;
const Boxx = styled(Box)`
  @media (max-width: 1024px) {
    margin-left: 0;
  }
  margin-left: 41px;
  min-height: 80vh;

  @media (width: 1309.09px) {
    min-height: 50vh;
  }
  @media (width: 1152px) {
    min-height: 30vh;
  }

  && {
    background: unset;
    .css-35zqo5-MuiTabs-root {
      border-left: 1px solid rgba(0, 0, 0, 0.12);
      border-right: unset;
    }

    .MuiTabs-indicator {
      top: ${({ check }) => (check ? `${check}px !important` : "")};
      left: 0;
      height: ${({ height1 }) => (height1 ? `${height1}px !important` : "")};

      background-color: #033631;
    }
  }
`;
const SmallTxt = styled.p`
  color: #7b7b7b;
  font-size: 14px;
  text-align: left;
  display: block;
  margin: 0;
`;

const Tabs1 = styled(Tabs)`
  && {
    .css-1h9z7r5-MuiButtonBase-root-MuiTab-root.Mui-selected {
      color: #373737;
    }
    @media (max-width: 1024px) {
      display: none;
    }
  }
`;

const TabMenu = styled(Tab)`
  && {
    text-align: left;
    align-items: unset;
    @media (width: 1152px) {
      font-size: 11px;
    }
    /* min-height: unset; */
  }
`;
