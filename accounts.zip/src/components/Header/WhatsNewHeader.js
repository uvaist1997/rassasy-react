import React, { useContext, useState } from "react";
import styled from "styled-components/macro";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import { Avatar, Badge, IconButton, Menu, MenuItem } from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { useNavigate } from "react-router-dom";
import CloseIcon from "@mui/icons-material/Close";
import AppsIcon from "@mui/icons-material/Apps";
import MenuIcon from "@mui/icons-material/Menu";
import { ContextData } from "../Context1/Context1";
import FolderOpenOutlinedIcon from "@mui/icons-material/FolderOpenOutlined";
import { Button } from "@mui/material";

function WhatsNewHeader({ hidemenu }) {
  let navigate = useNavigate();
  ///Notification bell icon -- MUI
  function notificationsLabel(count) {
    if (count === 0) {
      return "no notifications";
    }
    if (count > 99) {
      return "more than 99 notifications";
    }
    return `${count} notifications`;
  }

  //   Three dot menu icon --MUI
  const ITEM_HEIGHT = 48;
  const options = [
    {
      title: "Countries",
      urlLink: "/countries",
    },
    {
      title: "States",
      urlLink: "/states",
    },
    {
      title: "Users",
      urlLink: "/users",
    },

    {
      title: "UQC",
      urlLink: "/uqc",
    },
    {
      title: "BussinessTypes",
      urlLink: "/bussinesstypes",
    },

    {
      title: "Enquiry Questions",
      urlLink: "/enquiryquestions",
    },
    {
      title: "Activity Log",
      urlLink: "/activitylog",
    },
  ];

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = (link) => {
    // navigate(link);
    setAnchorEl(null);
  };

  return (
    <Container>
      <LeftContainer>
        <ImgContainer onClick={() => navigate("/")}>
          <ImgSvg src="../../images/1.svg" alt="" />
        </ImgContainer>
      </LeftContainer>
      <RightContainer>
        <AdminContainer>
          <SignInButton variant="text">Signin</SignInButton>
        </AdminContainer>

        <MenuIconContainer>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-controls={open ? "long-menu" : undefined}
            aria-expanded={open ? "true" : undefined}
            aria-haspopup="true"
            onClick={handleClick}
          >
            <MoreVertIcon />
          </IconButton>

          <MenuContainer
            disableScrollLock={true}
            id="long-menu"
            MenuListProps={{
              "aria-labelledby": "long-button",
            }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            PaperProps={{
              style: {
                maxHeight: ITEM_HEIGHT * 5.5,
                width: "20ch",
              },
            }}
          >
            {options.map((option) => (
              <MenuItems
                key={option}
                selected={option === "Countries"}
                onClick={() => handleClose(option.urlLink)}
              >
                {option.title}
              </MenuItems>
            ))}
          </MenuContainer>
        </MenuIconContainer>
      </RightContainer>
    </Container>
  );
}

export default WhatsNewHeader;

const SignInButton = styled(Button)`
  && {
    border-radius: 19px;
    font-size: 11px;
    min-width: 92px;
    color: white;
    text-transform: capitalize;
    background-color: black;
    font-family: "poppins", sans-serif;
    &:hover {
      color: white;
      background-color: black;
    }
  }
`;

const MenuIcon1 = styled(MenuIcon)`
  color: black;
`;

const LeftContainer = styled.div`
  display: flex;
  gap: 3px;
  align-items: center;

  margin-left: 10px;
`;

const ImgSvg = styled.img`
  width: 100%;
  object-fit: contain;
  height: 100%;
`;
const ImgContainer = styled.div`
  width: 114.93px;
  height: 27.74px;
  cursor: pointer;

  @media (max-width: 731px) {
    width: 92.93px;
  }
`;

const MenuItems = styled(MenuItem)`
  font-size: 13px !important;
`;
const MenuContainer = styled(Menu)`
  .css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root {
    font-family: "Poppins", sans-serif;
  }
  .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
    max-height: 194px !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
`;

const MenuIconContainer = styled.div`
  svg {
    font-size: 1.5rem !important ;
    color: black !important;
  }
`;

const RightContainer = styled.div`
  display: flex;
  justify-content: space-around;
  min-width: 163px;
  height: 36px;
  margin-right: 10px;
`;
const Container = styled.div`
  height: 56px;
  position: fixed;
  top: 0;
  background-color: white;

  display: flex;
  align-items: center;
  border-radius: 0px 0px 28px 28px;

  z-index: 9;

  width: 100%;

  justify-content: space-between;
`;

const AdminContainer = styled.div`
  display: flex;
  gap: 10px;
  height: 36px;
  align-items: center;
`;
