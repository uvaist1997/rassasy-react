import * as React from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";

export default function CustomAutoComplete(props) {
  return (
    <Autocomplete
      disablePortal
      id="combo-box-demo"
      options={props.list}
      getOptionLabel={(option) => option.Country_Name}
      sx={{ width: 300 }}
      size="small"
      name={props.name ? props.name : ""}
      onChange={(e, value) => props.handleAutocomplete(e, value, "country")}
      renderInput={(params) => <TextField {...params} />}
    />
  );
}
