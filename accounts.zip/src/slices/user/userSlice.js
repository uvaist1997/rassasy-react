import { createSlice } from "@reduxjs/toolkit";

const initialState = localStorage.getItem("user")
  ? JSON.parse(localStorage.getItem("user"))
  : {
      access: "",
      user_id: "",
      username: "",
      email: "",
      isAuth: false,
    };

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    loginSuccess: (state, action) => {
      console.log(action.payload);
      state.access = action.payload.access;
      state.user_id = action.payload.user_id;
      state.username = action.payload.username;
      state.email = action.payload.email;
      state.isAuth = action.payload.isAuth;
      localStorage.setItem("user", JSON.stringify(action.payload));
    },
    logoutSuccess: (state, action) => {
      state.last_login = null;
      state.role = null;
      state.refresh = null;
      state.access = null;
      state.user_id = null;
      state.username = null;
      state.email = null;
      state.isAuth = false;

      localStorage.removeItem("user");
    },
  },
});

export const { loginSuccess, logoutSuccess } = userSlice.actions;

export const selectUserName = (state) => state.user.name;
export const selectUserEmail = (state) => state.user.email;
export const accessToken = (state) => state.user.access;
export const selectAuthenticated = (state) => state.user.isAuth;

export default userSlice.reducer;
