import "./App.css";
import React, { lazy, Suspense } from "react";
import {
  Route,
  BrowserRouter as Router,
  Routes as Switch,
} from "react-router-dom";

import { CircularProgress } from "@mui/material";
import styled from "styled-components";
import CacheBuster from "./CacheBuster";
// const CreateOrganization = lazy(() =>
//   import("./pages/Organization/CreateOrganization")
// );
const Navigation = lazy(() => import("./pages/Routes/Navigation"));
// const SignIn = lazy(() => import("./pages/Auth/SignIn"));
// const SignUp = lazy(() => import("./pages/Auth/SignUp"));

function App() {
  return (
    <CacheBuster>
      {({ loading, isLatestVersion, refreshCacheAndReload }) => {
        if (loading) return null;
        if (!loading && !isLatestVersion) {
          // You can decide how and when you want to force reload
          refreshCacheAndReload();
        }
        return (
          <Suspense
            fallback={
              <Box>
                <CircularProgress />
              </Box>
            }
          >
            <Router>
              <Switch>
                {/* <Route path="/" element={<SignIn />} />
                <Route path="/sign-up" element={<SignUp />} />
                <Route
                  path="/create-company"
                  element={<CreateOrganization />}
                /> */}
                <Route path="/*" element={<Navigation />} />
              </Switch>
            </Router>
          </Suspense>
        );
      }}
    </CacheBuster>
  );
}

export default App;
const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;
