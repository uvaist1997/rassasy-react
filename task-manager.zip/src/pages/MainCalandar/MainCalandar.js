import { Button, Fade, Menu } from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import styled from "styled-components/macro";
import { styled as styles } from "@mui/material/styles";
import DayOfWeek from "../../components/Calender/DayOfWeek";
import Calandar from "../../components/Calender/Calandar";
import DateRangeForm from "../../components/Calender/DateRangeForm";
import MonthNav from "../../components/Calender/MonthNav";
import YearNav from "../../components/Calender/YearNav";
import DayOfWeekDialog from "../../components/Calender/DayOfWeekDialog";
import {
  InputLabel,
  LinearProgress,
  linearProgressClasses,
} from "@mui/material";
import CalandarCreateTask from "../../components/Calender/CalandarCreateTask";

const MainCalandar = () => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const [showModal, setModal] = useState(false);
  const [showWeekDialog, setWeekDialog] = useState(false);

  const [month, setMonth] = useState(new Date());
  const [year, setYear] = useState(new Date());
  const [key, setKey] = useState(0);

  const [show, setShow] = useState(false);
  useEffect(() => {
    setKey(key + 1);
  }, [month.getMonth()]);

  useEffect(() => {
    setKey(key + 1);
  }, [year.getFullYear()]);

  const [state, setState] = useState({
    event: [
      { date: new Date(2022, 2, 10), note: "dfgsdf", isHoliday: false },
      { date: new Date(2022, 2, 11), note: "hregawef", isHoliday: false },
    ],
    note: "",
    fromDate: new Date(),
    toDate: new Date(),
    // monday
    isMonday: false,
    isFirstMonday: false,
    isSecondMonday: false,
    isThirdMonday: false,
    isFourthMonday: false,
    isFifthMonday: false,
    // tuesday
    isTuesday: false,
    isFirstTuesday: false,
    isSecondTuesday: false,
    isThirdTuesday: false,
    isFourthTuesday: false,
    isFifthTuesday: false,
    // wednesday
    isWednesday: false,
    isFirstWednesday: false,
    isSecondWednesday: false,
    isThirdWednesday: false,
    isFourthWednesday: false,
    isFifthWednesday: false,
    // thursday
    isThursday: false,
    isFirstThursday: false,
    isSecondThursday: false,
    isThirdThursday: false,
    isFourthThursday: false,
    isFifthThursday: false,
    // friday
    isFriday: false,
    isFirstFriday: false,
    isSecondFriday: false,
    isThirdFriday: false,
    isFourthFriday: false,
    isFifthFriday: false,
    // saturday
    isSaturday: false,
    isFirstSaturday: false,
    isSecondSaturday: false,
    isThirdSaturday: false,
    isFourthSaturday: false,
    isFifthSaturday: false,
    // sunday
    isSunday: false,
    isFirstSunday: false,
    isSecondSunday: false,
    isThirdSunday: false,
    isFourthSunday: false,
    isFifthSunday: false,
  });

  return (
    <MainContainer>
      <Container>
        <Header>
          <Heading>Calender</Heading>
          <RangeSelector>
            <MonthNav
              setMonth={setMonth}
              month={month}
              setYear={setYear}
              year={year}
            />
            <YearNav setYear={setYear} year={year} />
          </RangeSelector>
        </Header>
        <Calandar
          month={month}
          year={year}
          changeKey={key}
          parentState={state}
          setParentState={setState}
        />
        <DateRangeForm
          month={month}
          year={year}
          showModal={showModal}
          setModal={setModal}
          state={state}
          setState={setState}
        />
        <DayOfWeekDialog
          showWeekDialog={showWeekDialog}
          setWeekDialog={setWeekDialog}
          state={state}
        />
      </Container>

      <CalenderSideContainer>
        <div>
          <SideHeader>
            <DateConatiner>
              <h2>02</h2>
              <span>August</span>
              <span>2021</span>
            </DateConatiner>
            <CreateTaskContainer onClick={() => setShow(true)}>
              <PlusContainer>
                <img src="./images/icons/outlinecircle.svg" />
              </PlusContainer>
              <CreateTaskText>Create Task</CreateTaskText>
            </CreateTaskContainer>
          </SideHeader>
          <CardsDiv>
            {/* Cards........... */}

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>
            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <TaskTitleContainer>
                    <div style={{ display: "flex", alignItems: "center" }}>
                      <img src="./images/icons/load-a-green.svg" />
                    </div>
                    <h3>Task Title</h3>
                  </TaskTitleContainer>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            {/* 2 */}
            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>
            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>

            <MainTask>
              <TaskCardContainer>
                <TaskCard>
                  <h3>Task Title</h3>
                  <span>Project Name</span>
                </TaskCard>
                <DueDate>
                  <h4>Due Date</h4>

                  <YearContainer>
                    <p>26</p>
                    <p>March</p>
                    <p>2022</p>
                  </YearContainer>
                </DueDate>
              </TaskCardContainer>

              <ProgressValueContainer>
                <ProgressContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={30}
                  />
                </ProgressContainer>
              </ProgressValueContainer>
            </MainTask>
          </CardsDiv>
        </div>
      </CalenderSideContainer>

      <CalandarCreateTask
        show={show}
        setShow={setShow}
        state={state}
        setState={setState}
      />
    </MainContainer>
  );
};

export default MainCalandar;
const TaskTitleContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
`;

const CardsDiv = styled.div`
  height: 93vh;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }

  @media (min-width: 1920px) {
    height: 92vh;
  }
  & :nth-child(1) {
    margin-top: unset;
  }
`;
const MainTask = styled.div`
  border-left: 5px solid #950101 !important;
  border: 1px solid #dde2eb;
  margin-top: 10px;
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,

  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));

const ProgressContainer = styled.div`
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 4px;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;

const ProgressValueContainer = styled.div``;
const TaskCard = styled.div`
  display: flex;
  justify-content: space-between;
  h3 {
    font-size: 14px;
    font-weight: bold;
  }
  span {
    font-size: 13px;
    color: #011565;
  }
`;
const DueDate = styled(TaskCard)`
  padding-bottom: 10px;
  h4 {
    color: #a2a2a2;
  }
`;
const YearContainer = styled(TaskCard)`
  display: flex;
  gap: 3px;
  font-size: 12px;
`;

const TaskCardContainer = styled.div`
  padding: 8px 8px 0px 8px;

  padding: 8px 8px 0px 8px;
  border: 1px solid #dde2eb;
`;

const PlusContainer = styled.div`
  display: flex;
  align-items: center;
`;
const CreateTaskText = styled.p`
  color: #12368;
  font-size: 13px;
`;
const CreateTaskContainer = styled.div`
  display: flex;
  gap: 7px;
  color: #12368c;
  align-items: center;
  cursor: pointer;
`;
const DateConatiner = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  h2 {
    font-size: 27px;
    font-weight: bold;
  }
  span {
    color: #6d6d6d;
    font-size: 16px;
  }
`;
const SideHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 12px;
`;

const CalenderSideContainer = styled.div`
  padding: 10px;
  border: 1px solid #00000029;
  width: 25%;
  margin-left: 15px;
  background-color: white;
`;
const MainContainer = styled.div`
  display: flex;
`;
const ButtonGroup = styled.div`
  width: 25%;
  display: flex;
  justify-content: space-between;
`;
const RangeSelector = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
`;
const Container = styled.div`
  width: 75%;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const Heading = styled.p`
  margin: 0;
  font-size: 22px;
  font-weight: bold;
`;
const StyledButton = styled(Button)`
  &&,
  &&:hover {
    background: #5447a0;
    border-radius: 50px;
    padding-right: 35px;
    text-transform: capitalize;
  }
  &&.range {
    background: #1d39a4;
  }
  span {
    position: relative;
    z-index: 100;
  }
`;
