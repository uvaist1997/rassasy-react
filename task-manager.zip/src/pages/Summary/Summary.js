import { Button, Stack } from "@mui/material";
import React, { useRef, useState, useEffect } from "react";
import styled from "styled-components/macro";
import Avatar from "@mui/material/Avatar";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { getCookie } from "../../functions/utils";
import { BASE_URL } from "../../settings";
import { useTranslation } from "react-i18next";

function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}

function stringAvatar(name) {
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: `${name.split(" ")[0][0]}${
      name.split(" ")[1] ? name.split(" ")[1][0] : ""
    }`,
  };
}

export function BackgroundLetterAvatars() {
  return (
    <Stack direction="row" spacing={2}>
      <Avatar {...stringAvatar("Kent Dodds")} />
      <Avatar {...stringAvatar("Jed Watson")} />
      <Avatar {...stringAvatar("Tim Neutkens")} />
    </Stack>
  );
}

const access = getCookie("VBID");

const Summary = () => {
  const [age, setAge] = React.useState("high");
  const [t] = useTranslation("common");
  const [state, setState] = React.useState({
    ProgressData: {},
    UpComingTasks: [],
    RecentActivities: [],
    get_api: true,
  });

  // useEffect(() => {
  //   if (state.get_api === true) {
  //     get_api();
  //     return () => {
  //       setState((prevState) => {
  //         return {
  //           ...prevState,
  //           get_api: false,
  //         };
  //       });
  //     };
  //   }
  // });

  useEffect(() => {
    if (age) {
      get_api();
    }
  }, [age]);

  const get_api = async () => {
    const summaryResponse = await fetch(`${BASE_URL}general/summary`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        UpcomingFilter: age,
      }),
    }).then((response) => response.json());
    if (summaryResponse.StatusCode === 6000) {
      setState((prevState) => {
        return {
          ...prevState,
          ProgressData: summaryResponse.progress_dict,
          UpComingTasks: summaryResponse.UpComingTasks,
          RecentActivities: summaryResponse.RecentActivities,
          get_list: false,
        };
      });
    }
  };

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  // status progress start
  let TotalStatusCompleted = state.ProgressData
    ? state.ProgressData.Completed
    : 0;
  let TotalStatusInProgress = state.ProgressData
    ? state.ProgressData.InProgress
    : 0;
  let TotalStatusToDo = state.ProgressData ? state.ProgressData.ToDo : 0;
  let SumStatus =
    Number(TotalStatusCompleted) +
    Number(TotalStatusInProgress) +
    Number(TotalStatusToDo);
  let statusCompletedCount =
    (Number(TotalStatusCompleted) / Number(SumStatus)) * 100;
  let statusProgressCount =
    (Number(TotalStatusInProgress) / Number(SumStatus)) * 100;
  let statusToDoCount = (Number(TotalStatusToDo) / Number(SumStatus)) * 100;
  // status progress end
  // -----------------------------------------------------
  // priority progress start
  let TotalPriorityHigh = state.ProgressData ? state.ProgressData.High : 0;
  let TotalPriorityMedium = state.ProgressData ? state.ProgressData.Medium : 0;
  let TotalPriorityLow = state.ProgressData ? state.ProgressData.Low : 0;
  let SumPriority =
    Number(TotalPriorityHigh) +
    Number(TotalPriorityMedium) +
    Number(TotalPriorityLow);
  let PriorityHighCount =
    (Number(TotalPriorityHigh) / Number(SumPriority)) * 100;
  let PriorityMediumCount =
    (Number(TotalPriorityMedium) / Number(SumPriority)) * 100;
  let PriorityLowCount = (Number(TotalPriorityLow) / Number(SumPriority)) * 100;
  // pririty progress end
  return (
    <Container>
      <Heading>{t("Summary")}</Heading>
      <TaskContainer>
        <TaskBoxContainer>
          <TaskBoxHeading style={{ visibility: "unset" }}>
            {t("Status")}
          </TaskBoxHeading>
          <TaskBox>
            <ProgressBar>
              <ProgressBlock
                count={statusCompletedCount}
                className="green"
              ></ProgressBlock>
              <ProgressBlock
                count={statusProgressCount}
                className="blue"
              ></ProgressBlock>
              <ProgressBlock
                count={statusToDoCount}
                className="grey"
              ></ProgressBlock>
            </ProgressBar>
            <ProgressBox className="grey">
              <ProgressLabel>{t("To Do")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.ToDo : 0}
              </ProgressCount>
            </ProgressBox>
            <ProgressBox className="blue">
              <ProgressLabel>{t("In Progress")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.InProgress : 0}
              </ProgressCount>
            </ProgressBox>
            <ProgressBox className="green">
              <ProgressLabel>{t("Completed")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.Completed : 0}
              </ProgressCount>
            </ProgressBox>
          </TaskBox>
        </TaskBoxContainer>
        <TaskBoxContainer>
          <TaskBoxHeading>{t("Priority")}</TaskBoxHeading>
          <TaskBox>
            <ProgressBar>
              <ProgressBlock
                count={PriorityHighCount}
                className="red"
              ></ProgressBlock>
              <ProgressBlock
                count={PriorityMediumCount}
                className="green round-0"
              ></ProgressBlock>
              <ProgressBlock
                count={PriorityLowCount}
                className="yellow"
              ></ProgressBlock>
            </ProgressBar>
            <ProgressBox className="yellow">
              <ProgressLabel>{t("Low Priority")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.Low : 0}
              </ProgressCount>
            </ProgressBox>
            <ProgressBox className="green">
              <ProgressLabel>{t("Medium Priority")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.Medium : 0}
              </ProgressCount>
            </ProgressBox>
            <ProgressBox className="red">
              <ProgressLabel>{t("High Priority")}</ProgressLabel>
              <ProgressCount>
                {state.ProgressData ? state.ProgressData.High : 0}
              </ProgressCount>
            </ProgressBox>
          </TaskBox>
        </TaskBoxContainer>
      </TaskContainer>
      <TaskSchedules>
        <UpcomingTasks>
          <TaskHeader>
            <TaskBoxHeading>{t("Upcoming Tasks")}</TaskBoxHeading>
            <StyledSelect>
              <FormControl fullWidth>
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  onChange={handleChange}
                >
                  <MenuItem value="high">{t("High")}</MenuItem>
                  <MenuItem value="medium">{t("Medium")}</MenuItem>
                  <MenuItem value="low">{t("Low")}</MenuItem>
                </Select>
              </FormControl>
            </StyledSelect>
          </TaskHeader>
          <UpcomingTaskListContainer>
            {state.UpComingTasks.map((i, index) => (
              <UpcomingTaskListBox key={index}>
                <UpcomingTaskList>
                  <DateContainer>
                    <DayText>{i.day}</DayText>
                    <MonthYearContainer>
                      <MonthText>{i.month}</MonthText>
                      <YearText>{i.year}</YearText>
                    </MonthYearContainer>
                  </DateContainer>
                  <TaskInfoContainer>
                    <TaskNameText>{i.TaskName}</TaskNameText>
                    <ProjectNameText>{i.ProjectName}</ProjectNameText>
                  </TaskInfoContainer>
                  <TaskTypeButton priorty={i.Priority}>
                    {i.Priority}
                  </TaskTypeButton>
                </UpcomingTaskList>
                <Divider></Divider>
              </UpcomingTaskListBox>
            ))}
          </UpcomingTaskListContainer>
        </UpcomingTasks>
        <RecentActivities>
          <TaskHeader>
            <TaskBoxHeading>{t("Recent Activities")}</TaskBoxHeading>{" "}
          </TaskHeader>
          <UpcomingTaskListContainer>
            {state.RecentActivities.map((i, index) => (
              <UpcomingTaskList className="recent" key={index}>
                <AvatarContainer>
                  <Avatar
                    style={{ height: "35px", width: "35px" }}
                    {...stringAvatar(i.Description.split(" ")[0].toUpperCase())}
                  />
                </AvatarContainer>
                <TaskInfoContainer>
                  <UserActivityContainer>
                    {i.Description.split(" ").map((word, index) =>
                      index === 0 ? (
                        <UsernameText>{word}</UsernameText>
                      ) : (
                        <ChangedText word={word}>{word}</ChangedText>
                      )
                    )}
                    {/* <UsernameText>{i.Description.split(" ")[0]}</UsernameText>
                    <ChangedText>Changed</ChangedText>
                    <StatusText>Status</StatusText>
                    <ToText>to</ToText>
                    <StatusActionText>Completed</StatusActionText> */}
                  </UserActivityContainer>
                  <ProjectNameText className="recent">
                    {i.ProjectName}
                  </ProjectNameText>
                  <TaskNameText className="recent">{i.TaskName}</TaskNameText>
                </TaskInfoContainer>
                <DateText>{i.date}</DateText>
              </UpcomingTaskList>
            ))}
          </UpcomingTaskListContainer>
        </RecentActivities>
      </TaskSchedules>
    </Container>
  );
};

export default Summary;

const Container = styled.div``;
const Heading = styled.div`
  font-size: 20px;
  margin-bottom: 10px;
  font-weight: bold;
`;
const TaskContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
`;
const TaskBox = styled.div`
  border: 1px solid #ccc;
  border-radius: 2px;
  background: #fff;
  padding: 15px;
`;
const TaskBoxContainer = styled.div`
  width: 49.4%;
`;
const TaskBoxHeading = styled.p`
  font-weight: bold;
  font-size: 16px;
  color: #7f7f7f;
`;
const ProgressBar = styled.div`
  display: flex;
  border-radius: 50px;
  margin-bottom: 10px;
`;
const ProgressBlock = styled.div`
  height: 8px;
  &.round-0 {
    border-radius: 0 !important;
  }
  &.green {
    background: #04952b;
    /* width: calc(100% / 3); */
    border-radius: 50px 0px 0px 50px;
    ${({ count }) => count > 0 && `width: ${count}%;`}
  }
  &.red {
    background: #ff001a;
    /* width: calc(100% / 3); */
    border-radius: 50px 0px 0px 50px;
    ${({ count }) => count > 0 && `width: ${count}%;`}
  }
  &.blue {
    /* width: calc(100% / 3); */
    background: #1a4abc;
    ${({ count }) => count > 0 && `width: ${count}%;`}
  }
  &.grey {
    /* width: calc(100% / 3); */
    background: #a8a8a8;
    border-radius: 0px 50px 50px 0px;
    ${({ count }) => count > 0 && `width: ${count}%;`}
  }
  &.yellow {
    /* width: calc(100% / 3); */
    background: #c4b700;
    border-radius: 0px 50px 50px 0px;
    ${({ count }) => count > 0 && `width: ${count}%;`}
  }
`;
const ProgressBox = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding: 8px;

  &.grey {
    background: #e2e2e2;
  }
  &.blue {
    background: #dbe6ff;
    color: #1a4abc;
  }
  &.green {
    background: #bef1cc;
    color: #005617;
  }
  &.red {
    background: #f8cfcf;
    color: #5d0606;
  }
  &.yellow {
    background: #fffcd2;
  }
  &:last-child {
    margin-bottom: 0;
  }
`;
const ProgressLabel = styled.div``;
const ProgressCount = styled.div``;
const TaskSchedules = styled.div`
  display: flex;
  justify-content: space-between;
`;
const UpcomingTasks = styled.div`
  width: 49%;
`;
const RecentActivities = styled.div`
  width: 49%;
`;
const TaskHeader = styled.div`
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
`;
const UpcomingTaskList = styled.div`
  display: flex;
  align-items: center;
  &.recent {
    margin-bottom: 10px;
  }
`;
const DateContainer = styled.div`
  display: flex;
  align-items: center;
  border-right: 2px solid #ccc;
  width: 90px;
  margin-right: 10px;
`;
const DayText = styled.p`
  font-size: 30px;
  font-weight: bold;
  color: #12368c;
  margin-right: 5px;
`;
const MonthYearContainer = styled.div``;
const MonthText = styled.p`
  font-weight: bold;
`;
const YearText = styled.p`
  color: #929292;
`;
const TaskInfoContainer = styled.div``;
const TaskNameText = styled.p`
  font-weight: bold;
  &.recent {
    font-weight: normal;
    color: #8e8e8e;
  }
`;
const ProjectNameText = styled.p`
  &.recent {
    color: #001d63;
  }
`;
const TaskTypeButton = styled(Button)`
  && {
    text-transform: capitalize;
    /* color: #700000; */
    border: 1px solid #eb5f5f;
    /* background: #fff6f6; */
    border-radius: 0;
    height: 30px;
    padding: 0 30px;
    margin-left: auto;

    ${({ priorty }) =>
      priorty === "low" &&
      `background: #C2FBC3; color:#032406; border: 1px solid #4e7a52;`}
    min-width: min-content;
    ${({ priorty }) =>
      priorty === "medium" &&
      `background: #D5E2EF; color:#00024A;border: 1px solid #6f96bd;`}
    ${({ priorty }) =>
      priorty === "high" &&
      `background: #fff6f6; color:#700000; border: 1px solid #eb5f5f;`}
  }
`;
const Divider = styled.div`
  margin: 10px 0;
  border-bottom: 2px solid #ccc;
`;
const UpcomingTaskListContainer = styled.div`
  height: 500px;
  padding: 15px;
  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }

  /* &::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    border-radius: 10px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 7px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 10px;
    -webkit-box-shadow: inset 0 0 6px #7a7a7a;
    background-color: #7a7a7a;
  } */

  &::-webkit-scrollbar,
  &::-webkit-scrollbar-thumb,
  &::-webkit-scrollbar-track {
    width: 8px;
    border: none;
    background: transparent;
  }

  &::-webkit-scrollbar-button,
  &::-webkit-scrollbar-track-piece,
  &::-webkit-scrollbar-corner,
  &::-webkit-resizer {
    display: none;
  }

  &::-webkit-scrollbar-thumb {
    border-radius: 6px;
    background-color: #7a7a7a;
  }

  &::-webkit-scrollbar-track {
    background-image: url("./images/scroll-track.png");
    background-repeat: repeat-y;
    background-size: contain;
  }
`;
const UpcomingTaskListBox = styled.div``;

const AvatarContainer = styled.div`
  margin-right: 10px;
`;
const DateText = styled.div`
  margin-left: auto;
`;
const UserActivityContainer = styled.div`
  display: flex;
  align-items: center;
`;

const UsernameText = styled.div`
  font-weight: bold;
  text-transform: capitalize;
  margin-right: 5px;
`;

const ChangedText = styled.p`
  margin-right: 5px;
  color: ${({ word }) =>
    word === "Created"
      ? "#032406"
      : word === "Status"
      ? "#02288e"
      : word === "progress"
      ? "#00024A"
      : word === "completed"
      ? "#007a04"
      : word === "to"
      ? "#9c9c9c"
      : "#8e8e8e"};
`;

const StatusText = styled.p`
  color: #02288e;
  margin-right: 5px;
`;
const ToText = styled.p`
  color: #9c9c9c;
  margin-right: 5px;
`;
const StatusActionText = styled.p`
  color: #007a04;
`;
const StyledSelect = styled.div`
  min-width: 120px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
