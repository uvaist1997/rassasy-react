import React, { useState } from "react";
import styled from "styled-components/macro";
import { useNavigate } from "react-router-dom";
import {
  InputLabel,
  LinearProgress,
  linearProgressClasses,
} from "@mui/material";
import { styled as styles } from "@mui/material/styles";
function TeamsCard(props) {
  const [crown, setCrown] = useState(true);
  const navigate = useNavigate();

  const NavToIndividualTask = (e) => {
    console.log("name:", e.target);
    if (e.target.getAttribute("name") === "changecrown") {
      setCrown(!crown);
    } else {
      navigate("/IndividualTask");
    }
  };

  return (
    <div>
      <MemberProgressContainer
        onClick={(e) => NavToIndividualTask(e)}
        name="membercard"
      >
        <MembersProgress>
          <HeaderProgressMember>
            <div>
              <BlackIconLeft>
                <div>
                  <BlackIconContainer>
                    <h4>A</h4>
                  </BlackIconContainer>
                </div>

                <NameContainer>
                  <div style={{ display: "flex", gap: "5px" }}>
                    <NameText>Anusree</NameText>
                    <div
                      // onClick={(e) => ProjectTasks(i.id, e)}

                      style={{ cursor: "pointer" }}
                    >
                      <img
                        name="changecrown"
                        src={
                          crown
                            ? "/images/icons/crown.svg"
                            : "/images/icons/goldencrown.svg"
                        }
                      />
                    </div>
                  </div>
                  <PointConatiner>
                    <span>32</span>
                    <span>Points</span>
                  </PointConatiner>
                </NameContainer>
              </BlackIconLeft>
            </div>

            <div>
              <img src="/images/icons/delete.svg" />
            </div>
          </HeaderProgressMember>
        </MembersProgress>

        <Progress>
          <ProgressTextContainer>
            <ProgressLabel>Progress</ProgressLabel>
            <ProgressRate>30%</ProgressRate>
          </ProgressTextContainer>
          <ProgressBorder size="small" variant="determinate" value={30} />
        </Progress>
      </MemberProgressContainer>
    </div>
  );
}

export default TeamsCard;

const HeaderProgressMember = styled.div`
  display: flex;
  justify-content: space-between;
`;
const MembersProgress = styled.div`
  padding: 8px 8px 0px 8px;

  border-radius: 2px;
`;
const BlackIconLeft = styled.div`
  display: flex;
  gap: 5px;
`;

const NameText = styled.span`
  font-weight: bold;
`;
const MemberProgressContainer = styled.div`
  box-shadow: rgb(67 71 85 / 27%) 0px 0px 0.25em,
    rgb(90 125 188 / 5%) 0px 0.25em 1em;
  margin-top: 10px;
  border: 1px solid #e5e5e5;
  cursor: pointer;
`;
const BlackIconContainer = styled.div`
  border-radius: 50%;
  color: white;
  background-color: black;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;

  padding: 17px;
  height: 20px;
  width: 20px;
`;
const NameContainer = styled.div`
  font-size: 12px;
  font-weight: bold;
`;
const PointConatiner = styled.span`
  display: flex;
  gap: 3px;
  color: #035300;
  margin-top: -3px;
`;
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
  width: 100%;
  padding: 0 10px;
`;

const ProgressRate = styled.p`
  color: #757575;
`;
const ProgressLabel = styled.p``;
const ProgressContainer = styled.div`
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 7px;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;

const Progress = styled(ProgressContainer)`
  font-size: 11px !important;
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,

  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressBorder = styled(BorderLinearProgress)`
  height: 5px !important;
`;
