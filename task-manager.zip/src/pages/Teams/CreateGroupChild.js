import React, { useState } from "react";
import styled from "styled-components/macro";

function CreateGroupChild({ name }) {
  const [crown, setCrown] = useState(false);
  return (
    <div>
      <SmallCardContainer>
        <SmallCard>
          <RightContainer>
            <NameIcon>
              <span>A</span>
            </NameIcon>
            <span>{name}</span>
            <div>
              <img
                onClick={() => setCrown(!crown)}
                src={
                  crown
                    ? "/images/icons/goldencrown.svg"
                    : "/images/icons/crown.svg"
                }
                style={{ cursor: "pointer" }}
              />
            </div>
          </RightContainer>

          <div>
            <img
              src="./images/icons/delete.svg"
              style={{ cursor: "pointer" }}
            />
          </div>
        </SmallCard>
      </SmallCardContainer>
    </div>
  );
}

export default CreateGroupChild;

const SmallCardContainer = styled.div`
  /* padding: 11px; */
  border: 1px solid #e5e5e5;
  margin-top: 10px;
  border-radius: 2px;
`;
const RightContainer = styled.div`
  display: flex;
  gap: 5px;
  align-items: center;
`;
const SmallCard = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 10px;
`;
const NameIcon = styled.span`
  width: 26px;
  height: 26px;
  justify-content: center;
  border-radius: 50%;
  display: flex;
  align-items: center;
  color: white;
  font-weight: bold;
  background-color: black;
`;
