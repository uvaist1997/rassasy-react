import React, { useState } from "react";
import { styled as styles } from "@mui/material/styles";
import styled from "styled-components";
import Button from "@mui/material/Button";
import Checkbox from "@material-ui/core/Checkbox";
import TextField from "@mui/material/TextField";
import {
  Avatar,
  Autocomplete,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  FormControlLabel,
  Modal,
  Backdrop,
  Box,
  Fade,
} from "@mui/material";

import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
import OutlinedInput from "@mui/material/OutlinedInput";

import CloseIcon from "@mui/icons-material/Close";

import NativeSelect from "@mui/material/NativeSelect";
import InputAdornment from "@mui/material/InputAdornment";
import CreateGroupChild from "./CreateGroupChild";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import MenuItem from "@mui/material/MenuItem";

import { get_Userindex, stringAvatar } from "../../functions/utils";
import Select, { SelectChangeEvent } from "@mui/material/Select";
function CreateGroup({ open, setOpen }) {
  const [age, setAge] = useState("");
  const [state, setState] = useState({
    Projectlsd: [],
    ProjeID: "",
  });

  const [showReporterSelect, setReporterSelect] = useState();
  const [clearState, setClearState] = useState();
  const [smallCard, setSmallCard] = useState([1, 2, 3, 4, 5, 6, 7]);
  const [addMember, setAddMember] = useState(false);

  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 381,
    height: 550,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 2,
  };

  const handleChange = (event: SelectChangeEvent) => {
    setAge(event.target.value);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const handleSelectChange = () => {
    console.log("select");
  };
  return (
    <Container>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <BlockContainer>
              <Block>
                <h1>Create Group</h1>
              </Block>
              <CloseBtnContainer>
                <StyledButton
                  onClick={() => {
                    console.log("save");
                  }}
                  className="create"
                >
                  Save
                </StyledButton>

                <StyledCloseIcon
                  className="close-modal"
                  onClick={() => setOpen(false)}
                />
              </CloseBtnContainer>
            </BlockContainer>
            <TeamNameTextConatiner>
              <GroupIconContainer>
                <GroupIcon src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIkAAACJCAMAAAAv+uv7AAAAMFBMVEXk5ueutLeqsLPb3t/n6erq7O3g4uPS1de1ur3Gysy8wMPX2tunrbHM0NK/w8axt7pxv9y7AAADNElEQVR4nO2awZqrIAxGBQIiir7/217UttPOtZJgfzoLzmpm1fMlIUSg6xqNRqPRaDQajUaj0eBDRN9WSBLWkjMJl/76ogaZOCs9bWg/9+47waEueqW1epD+DmNX3YW6QT1Z3JmWWDlJ1E8HHltkFlPRhVx447ExVMsQmRONNSzB1XGheBaQjaWKCvVZkUQFFRonhkhSwYuwPFKC0CbdwjTRMzY/FJgiqclFpAqvWu9AS4Wbmz0/uGZLgyQkajK4/Eg8ErCiZTTXVzSqUsgLY6JRe6ERhgTW3oT1ugVlxJhIkwNLjxOLKOUhLYW7970EBRGTgjJJzQ2xjmkuiUkPCIqVF2wyQWzIVrL7PUAsHlsigjEpKFjMJviHYvJ36qRk7SjI2uEP0z9A+klZj4UMkKK5/m4C8EiDklxELZjxXr54QB+CBVug7hEi7FOCZ1DDvVgE9cFDg1BEG4xImmSF6fGwr1E7i1qKHnHfxbKWghnsd0QdH1clmwp/Q4Z9FN9M+N/G6CM/isz1Azux+FHhlQpy3TxUOEt5QkxI/8HoKpBR7YB8giqk5qZyOr7pOjcZN5VufreEtK58/0ajP4qLVqH6nSStLvq3xwA8DD7BdjEsKR07ys/99y7T0y+bPg7DEPvRdd+81Cf7zDdM1jcNzox9nIPfd+fFhzlFxriK7x3WXxpj8GqrkJf1u/67hGF9XwC3IevGwat3F+h3pQX82iFlpA/q6DnBgYz20YBaC1HSkEzUWocIcCE3KPknoJ7m0X5UhkzJsfAu48fPVYx1sygt/7t8Zk9MeZGn5ZXJf2I7on65EI8Hw9Xazbx54aOXaymS3ZmfM10KS8lx41u0L50qqTscy664lE3auddIRSolMy77yYtQRRwVwae4CPGrFERqdqRRKbkb5qqIypaK7nKYSG4VWMcB5fDPeD7ZWY/QgbuWHVaEf6hRdFkuhCdiro4jeXjnkgXPTArgnAeO6CpZ4bx1K7oCLVDJhwS+cG4m2aZfdBdbgs/GpEq9KsYZdqXk5NODbvRPZFq+rdBfb2T2wTptbSdTKMjB5BfnLxHd41ATzpS5Xzf1gF9FNRqNRqPxnn8imiUJ2aXMUQAAAABJRU5ErkJggg==" />
              </GroupIconContainer>
              <Text_boxContainer>
                <TeamnameText>Team's Name</TeamnameText>

                <CustomTextBox
                  id="outlined-adornment-weight"
                  aria-describedby="outlined-weight-helper-text"
                  inputProps={{
                    "aria-label": "weight",
                  }}
                />
              </Text_boxContainer>
            </TeamNameTextConatiner>
            <ProjectTextContainer>
              <DetailBlock>
                <DetailLabel>Project</DetailLabel>

                {showReporterSelect ? (
                  <CustomeAutocomplete
                    size="small"
                    id="combo-box-demo"
                    options={state.reporterList ? state.reporterList : []}
                    getOptionLabel={(option) => option.username || ""}
                    sx={{ width: 280 }}
                    onInputChange={(event, value, reason) => {}}
                    onChange={(e, v) => handleSelectChange("ReportUserID", v)}
                    renderInput={(params) => (
                      <TextField size="small" {...params} />
                    )}
                    value={
                      state.reporterList && state.ReportUserID
                        ? state.reporterList[
                            get_Userindex(
                              state.reporterList,
                              state.ReportUserID
                            )
                          ]
                        : ""
                    }
                  />
                ) : (
                  [
                    <Projectname
                      onClick={() => {
                        setReporterSelect(true);
                      }}
                    >
                      {state.ReporterName ? state.ReporterName : "Project Name"}
                    </Projectname>,
                  ]
                )}
                {/* ================ */}
              </DetailBlock>
            </ProjectTextContainer>
            <RoundChecBoxContainer>
              <RoundedCheckbox
                name={"teamperformane"}
                label={"Track Team Performance"}
                checked={true}
              />
              <RoundedCheckbox
                name={"taskconfirmation"}
                label={"Task Confirmation"}
                checked={true}
              />
            </RoundChecBoxContainer>

            <div>
              <AddTaskContainer>
                <AddTaskIconTxt>
                  <AddSubTaskContainer
                    onClick={() => {
                      setAddMember(!addMember);
                    }}
                  >
                    <AddCircleOutlineIcon />
                    Add Member
                  </AddSubTaskContainer>
                </AddTaskIconTxt>
              </AddTaskContainer>
              <AddmemberPopupContainer addMember={addMember}>
                <div style={{ position: "relative" }}>
                  <AddMemberHeader>
                    <AddMemberText>Add Member</AddMemberText>
                    <RoundCheckBoxAdd>
                      <RoundedCheckbox
                        name={"addasleader"}
                        label={"Add as Leader"}
                        checked={true}
                      />
                    </RoundCheckBoxAdd>
                  </AddMemberHeader>

                  <SelectBoxContainer>
                    <UserText>User</UserText>
                    <SelectContainer>
                      <FormControl sx={{ width: "100%" }}>
                        <Select
                          value={age}
                          onChange={handleChange}
                          displayEmpty
                          inputProps={{ "aria-label": "Without label" }}
                        >
                          <MenuItem value="">
                            <em>None</em>
                          </MenuItem>
                          <MenuItem value={10}>Ten</MenuItem>
                          <MenuItem value={20}>Twenty</MenuItem>
                          <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                      </FormControl>
                    </SelectContainer>
                  </SelectBoxContainer>

                  <CancelButtonContainer>
                    <CancelButton
                      onClick={() => {
                        console.log("save");
                        // SaveTask();
                      }}
                      className="create"
                    >
                      Cancel
                    </CancelButton>

                    <StyledButton
                      onClick={() => {
                        console.log("save");
                        // SaveTask();
                      }}
                      className="create"
                    >
                      Add
                    </StyledButton>
                  </CancelButtonContainer>
                </div>
              </AddmemberPopupContainer>
            </div>

            <CardMainContainer>
              {smallCard.map((i) => {
                return <CreateGroupChild name={"Anusree"} />;
              })}
            </CardMainContainer>
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
}

export default CreateGroup;
const AddMemberText = styled.h3`
  font-weight: bold;
  letter-spacing: 1px; ;
`;
const CancelButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
`;
const SelectContainer = styled.div`
  div
    div
    .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 10px !important;
  }
  display: block;
`;
const SelectBoxContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 5px;
`;
const UserText = styled.span`
  color: #8f8f8f;
`;
const AddMemberHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const AddmemberPopupContainer = styled.div`
  position: absolute;
  background-color: white;
  width: 92%;

  padding: 10px;
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  margin-top: 3px;
  transition: transform 0.3s ease-in-out;
  display: ${({ addMember }) => (addMember ? "" : "none")};
`;
const RoundCheckBoxAdd = styled.div`
  display: flex;

  label {
    font-size: 11px !important;
    font-weight: unset !important;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  button {
    padding: 0;
  }
`;

const AddSubTaskContainer = styled(Button)`
  && {
    background: #e7ebf6;

    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    justify-content: left;
    border-radius: 2px;
    svg {
      margin-right: 5px;
    }
  }
`;
const CardMainContainer = styled.div`
  height: 51%;

  overflow-y: scroll;
  ::-webkit-scrollbar {
    display: none;
  }
`;

const AddTaskContainer = styled.div`
  background-color: #e7ebf6;

  margin-top: 10px;
  padding: 4px 4px;
  border-radius: 2px;
`;
const AddTaskIconTxt = styled.div`
  display: flex;
  gap: 5px;
  align-items: center;
`;

const PlusImgContainer = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
  width: 23px;
`;

const RoundChecBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
  padding: 10px;
  label {
    font-size: 11px !important;
    font-weight: unset !important;
  }

  div label:after {
    border: 2px solid #fff;
    border-top: none;
    border-right: none;
    content: "";
    opacity: 0;
    width: 9px !important;
    height: 4px !important;
    position: absolute;
    visibility: visible;
    left: 3px !important;
    top: 4px !important;
  }
`;
const ProjectTextContainer = styled.div`
  background-color: #f3f3f3;
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
  padding: 3px 17px;
  border: 2px;
`;
const ProjectNameText = styled.span`
  color: #00536d;
`;
const CustomTextBox = styled(OutlinedInput)`
  .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 6.5px 14px !important;
  }
`;
const Text_boxContainer = styled.div`
  display: flex;
  flex-direction: column;
`;
const GroupIcon = styled.img`
  display: block;
  width: 100%;
  border-radius: 5px;
`;

const GroupIconContainer = styled.div`
  width: 72px;
  background-color: #ebebeb;
  border-radius: 5px;
`;
const TeamnameText = styled.span`
  font-size: 15px;
`;

const TeamNameTextConatiner = styled.div`
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 10px;
  margin-top: 10px;
`;

const StyledTextField = styled(TextField)`
  .MuiOutlinedInput-input.MuiInputBase-input.MuiInputBase-inputMultiline {
    min-height: 40px !important;
  }
  .css-8ewcdo-MuiInputBase-root-MuiOutlinedInput-root {
    padding: unset !important ;
  }
`;
const CloseBtnContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const TopBoxContainer = styled.div`
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
`;
const Container = styled.div`
  /* .MuiBox-root {

  } */
`;
const BlockContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const Block = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  /* &.left {
    width: 59%;
  }
  &.right {
    width: 39%; */
  /* } */
  max-height: 600px;
  font-weight: bold;
  font-size: 9px;
  /* padding: 15px; */
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
  }
`;
const StyledCloseIcon = styled(CloseIcon)`
  &.close-modal {
    top: 15px;
    right: 15px;
  }
  cursor: pointer;
`;
const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const CancelButton = styled(StyledButton)`
  && {
    background-color: #d5e2ef !important;
    color: #2b2b2b !important;
  }
`;

const DetailBlock = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 40px;
`;
const DetailLabel = styled.p`
  width: 100px;

  cursor: pointer;
`;
const Projectname = styled(DetailLabel)`
  color: #00536d;
`;
