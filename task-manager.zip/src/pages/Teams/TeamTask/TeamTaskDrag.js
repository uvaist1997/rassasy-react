import React, { useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { v4 as uuid } from "uuid";
import styled from "styled-components";
import { Button } from "@mui/material";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import TeamCreateTask from "./TeamCreateTask";
import RoundedCheckbox from "../../../components/RoundedCheckbox/RoundedCheckbox";

const itemsFromBackend = [
  { id: uuid(), content: "First task" },
  { id: uuid(), content: "Second task" },
  { id: uuid(), content: "Third task" },
  { id: uuid(), content: "Fourth task" },
  { id: uuid(), content: "Fifth task" },
];

const columnsFromBackend = {
  [uuid()]: {
    name: "To do",
    items: itemsFromBackend,
  },
  [uuid()]: {
    name: "In Progress",
    items: [],
  },
  [uuid()]: {
    name: "Completed",
    items: [],
  },
};

const onDragEnd = (result, columns, setColumns) => {
  if (!result.destination) return;
  const { source, destination } = result;

  if (source.droppableId !== destination.droppableId) {
    const sourceColumn = columns[source.droppableId];
    const destColumn = columns[destination.droppableId];
    const sourceItems = [...sourceColumn.items];
    const destItems = [...destColumn.items];
    const [removed] = sourceItems.splice(source.index, 1);
    destItems.splice(destination.index, 0, removed);
    setColumns({
      ...columns,
      [source.droppableId]: {
        ...sourceColumn,
        items: sourceItems,
      },
      [destination.droppableId]: {
        ...destColumn,
        items: destItems,
      },
    });
  } else {
    const column = columns[source.droppableId];
    const copiedItems = [...column.items];
    const [removed] = copiedItems.splice(source.index, 1);
    copiedItems.splice(destination.index, 0, removed);
    setColumns({
      ...columns,
      [source.droppableId]: {
        ...column,
        items: copiedItems,
      },
    });
  }
};

function TeamTaskDrag(props) {
  const [open, setOpen] = useState(false);
  const [columns, setColumns] = useState(columnsFromBackend);
  return (
    <GridContainer>
      <DragDropContext
        onDragEnd={(result) => onDragEnd(result, columns, setColumns)}
      >
        {Object.entries(columns).map(([columnId, column], index) => {
          return (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
              key={columnId}
            >
              <h2 style={{ width: "100%", marginBottom: 10 }}>{column.name}</h2>
              <div style={{ width: "100%" }}>
                <Droppable droppableId={columnId} key={columnId}>
                  {(provided, snapshot) => {
                    return (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        style={{
                          background: snapshot.isDraggingOver
                            ? "#fafcff"
                            : "#fafcff",
                          // padding: 4,
                          width: "100%",
                          minHeight: 500,
                        }}
                      >
                        {column.name === "To do" && (
                          <CreateProjectTaskButton
                            onClick={() => setOpen(true)}
                          >
                            <AddCircleOutlineRoundedIcon
                              style={{ marginRight: 5 }}
                            />
                            Create Task
                          </CreateProjectTaskButton>
                        )}

                        {column.name === "Completed" && (
                          <RoundChecBoxContainer>
                            <div>
                              <span>5</span>
                              <span> unconfirmed Task</span>
                            </div>
                            <RoundedCheckbox
                              name={"unconfirmedTask"}
                              label={"Show Unconfirmed Task"}
                              style={{ border: " 1px solid black" }}
                              checked={true}
                              //   value={state.is_customer}
                            />
                          </RoundChecBoxContainer>
                        )}
                        {column.items.map((item, index) => {
                          return (
                            <Draggable
                              key={item.id}
                              draggableId={item.id}
                              index={index}
                            >
                              {(provided, snapshot) => {
                                return (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    {...provided.dragHandleProps}
                                    style={{
                                      userSelect: "none",
                                      padding: "0px 0px 0px 0",
                                      margin: "0 0 8px 0",
                                      minHeight: "50px",
                                      border: "1px solid #DDE2EB",
                                      backgroundColor: snapshot.isDragging
                                        ? "#d4d4d4"
                                        : "white",
                                      color: "black",
                                      ...provided.draggableProps.style,
                                    }}
                                  >
                                    <MainContainer>
                                      <LeftColorLabel className="red"></LeftColorLabel>
                                      <LabelContainer>
                                        <ContentContainer>
                                          <Container className="top">
                                            <TaskTitleText>
                                              {item.content}
                                            </TaskTitleText>
                                            <UnassignedText>
                                              Unassigned
                                            </UnassignedText>
                                          </Container>
                                          <Container className="bottom">
                                            <DateLabelText>
                                              Due Date
                                            </DateLabelText>
                                            <ColoredDate className="blue">
                                              26 March 2022
                                            </ColoredDate>
                                          </Container>
                                        </ContentContainer>
                                        <BottomColorLabel className="blue"></BottomColorLabel>
                                      </LabelContainer>
                                    </MainContainer>
                                  </div>
                                );
                              }}
                            </Draggable>
                          );
                        })}
                        <DropContainer>Drag & Drop</DropContainer>
                        {provided.placeholder}
                      </div>
                    );
                  }}
                </Droppable>
              </div>
            </div>
          );
        })}
      </DragDropContext>

      <TeamCreateTask
        open={open}
        setOpen={setOpen}
        state={props.state}
        setState={props.setState}
        handleSelectChange={props.handleSelectChange}
        handleChangeImg={props.handleChangeImg}
        handleRemoveImg={props.handleRemoveImg}
        handleCheckBox={props.handleCheckBox}
        onSearchUsers={props.onSearchUsers}
        handleChange={props.handleChange}
        SaveTask={props.SaveTask}
      />
    </GridContainer>
  );
}

export default TeamTaskDrag;
const GridContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 10px;
`;
const RoundChecBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
`;

const DropContainer = styled.div`
  font-size: 14px;
  color: #a2aec8;
  padding: 16px;
  text-align: center;
  border: 1px dashed #a8b1c2;
`;

const CreateProjectTaskButton = styled(Button)`
  && {
    width: 100%;
    height: 36px;
    text-align: left;
    justify-content: left;
    text-transform: capitalize;
    color: #12368c;
    padding: 10px 16px;
    margin-bottom: 8px;
    background: #e7ebf6;
  }
`;
const TaskTitleText = styled.p`
  font-weight: bold;
`;
const UnassignedText = styled.p`
  color: #848484;
  font: italic normal normal 11px/17px Poppins;
`;
const Container = styled.div`
  display: flex;
  justify-content: space-between;
  &.top {
    margin-bottom: 5px;
  }
`;
const ColoredDate = styled.p`
  &.red {
    color: #ff0000;
  }
  &.blue {
    color: #12368c;
  }
`;
const DateLabelText = styled.p`
  color: #a2a2a2;
`;
const MainContainer = styled.div`
  display: flex;
`;
const LeftColorLabel = styled.div`
  width: 6px;

  height: auto;
  &.red {
    background: #eb5f5f;
  }
  &.green {
    background: #077553;
  }
  &.yellow {
    background: #ccac09;
  }
`;
const ContentContainer = styled.div`
  width: 100%;
  padding: 10px;
`;
const BottomColorLabel = styled.div`
  &.blue {
    background: #1145bf;
  }
  &.green {
    background: #07750b;
  }
  height: 4px;
  width: 100%;
  display: block;
`;
const LabelContainer = styled.div`
  width: 100%;
`;
