import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import {
  Avatar,
  Autocomplete,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  MenuItem,
  Select,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import {
  date_time_diff_in_mint,
  debugBase64,
  download,
  get_date,
  get_Userindex,
  stringAvatar,
  string_to_datetime,
  toDataURL,
  today_datetime,
  URLtoFile,
} from "../../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import EditIcon from "@mui/icons-material/Edit";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import NativeSelect from "@mui/material/NativeSelect";
import { useSelector } from "react-redux";
import RoundedCheckbox from "../../../components/RoundedCheckbox/RoundedCheckbox";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 831,
  bgcolor: "background.paper",
  borderRadius: "3px",

  boxShadow: 24,
  p: 2,
};

export default function TeamCreateTask({
  open,
  setOpen,
  handleSelectChange,
  // state,
  // setState,
  handleChangeImg,
  handleRemoveImg,
  handleCheckBox,
  handleDetailCheckBox,
  onSearchUsers,
  handleChange,
  SaveTask,
  clearState,
  AddSubTask,
  showSubTask,
  setSubTask,
  removeCheckBox,
  showReporterSelect,
  setReporterSelect,
  //   showAssigneeSelect,
  //   setAssigneeSelect,
  // ====coment=======
  commentRef,
  showActivies,
  setActivites,
  AddCommand,
  commentID,
  changeComment,
  FileList,
}) {
  // const [state, setState] = React.useState({
  //   DocumentList: [],
  // });

  console.log("This is TeamCreateTask Page");

  const [showAssigneeSelect, setAssigneeSelect] = React.useState(false);
  const [attachments, setAttachments] = React.useState(true);
  const [state, setState] = React.useState({
    user_id: user_id,
    Status: "progress",
    TaskConfermation: false,
    TaskName: "",
    Description: "",
    ProjectList: [],
    // ProjectID: props.ProjectTaskID ? props.ProjectTaskID : "",
    ProjectName: "",
    reporterList: [],
    assignerList: [],
    ReportUserID: "",
    ReporterName: "",
    DocumentList: [],
    Priority: "medium",
    // DueDate: get_date(selectedDate),
    Progress: 0,
    // CreatedBy: username,
    SubTaskDescription: "",
    SubTaskList: [],
    // For Comment
    CommentList: [],
    HistoryList: [],
    comment: "",
    EditDescription: "",
    AssignerID: "",
    AssigneeName: "",
    form_errors: {
      TaskName: "",
    },
    MemberType: "",
  });
  React.useEffect(() => {
    setAttachments(true);
    console.log(state, "----------------==========---------------");
  }, [state.DocumentList]);
  console.log(state.DocumentList);
  console.log(attachments);
  const { user_id } = useSelector((state) => state.user);

  const [selectedDate, handleDateChange] = React.useState(new Date());
  var month = selectedDate.toLocaleString("default", { month: "long" });
  var day = selectedDate.getUTCDate();
  var year = selectedDate.getUTCFullYear();
  console.log(selectedDate);
  const handleClose = () => setOpen(false);

  const [anchorEl, setAnchorEl] = React.useState(null);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  const formData = new FormData();
  const hiddenFileInput = React.useRef(null);
  let dateRef = React.useRef(null);

  // ------------------For Attchment-------------------------
  const handleClickImg = (event) => {
    hiddenFileInput.current.click();
  };
  function readFile(file) {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      const result = event.target.result;
      // Check if the file is an image.
      if (file.type && !file.type.startsWith("image/")) {
        console.log("File is not an image.", file.type, file);
        // e.g This will dowunload a file
        download(result);
      } else {
        // e.g This will open an image in a new window
        debugBase64(result);
      }
    });
    reader.readAsDataURL(file);
  }
  // ---------------------END------------------------
  const handleDateChangeRef = () => {
    dateRef.current.click();
    console.log(dateRef.current);
  };
  React.useEffect(() => {
    setState({
      ...state,
      DueDate: get_date(selectedDate),
    });
  }, [selectedDate]);
  // ----------------For Comment--------------------------------
  let Activities = [];
  if (showActivies === 3) {
    Activities = state.HistoryList;
  } else if (showActivies === 2) {
    Activities = state.CommentList;
  } else {
    Activities = state.CommentList.concat(state.HistoryList);
  }
  Activities.sort(function (a, b) {
    let aDate = new Date(a.CreatedDate);
    let bDate = new Date(b.CreatedDate);

    if (aDate > bDate) return -1;
    if (aDate < bDate) return 1;
    return 0;
  });
  // --------------------ENd---------------------
  console.log(state);
  return (
    <Container>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <TaskText1
              fullWidth
              focused
              id="standard-basic"
              label="Task"
              variant="standard"
              value={state.TaskName}
              onChange={(e) => handleChange("TaskName", e)}
            />
            <BlockContainer>
              <Block className="left">
                <InputLabel
                  style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                >
                  Description
                </InputLabel>
                <StyledTextField
                  fullWidth
                  multiline
                  id="outlined-basic"
                  variant="outlined"
                  // value={state.Description}
                  // onChange={(e) => handleChange("Description", e)}
                />
                <ButtonContainer>
                  {/* <ButtonGroup>
                    <StyledButton
                      onClick={() => {
                        SaveTask();
                      }}
                      className="create m"
                    >
                      Save
                    </StyledButton>
                    <StyledButton className="cancel">Cancel</StyledButton>
                  </ButtonGroup> */}
                  <ButtonGroup>
                    <StyledButton className="attach" onClick={handleClickImg}>
                      <AttachFileIcon />
                      Attach
                    </StyledButton>
                    <input
                      type="file"
                      ref={hiddenFileInput}
                      onChange={handleChangeImg}
                      style={{ display: "none" }}
                      multiple
                    />
                  </ButtonGroup>
                </ButtonContainer>
                {state.DocumentList.map((i) => (
                  <AttachmentListContainer>
                    <AttachmentLeftTitle>{i.name}</AttachmentLeftTitle>
                    <AttachmentRightTitle>
                      <p
                        onClick={() => {
                          readFile(i);
                        }}
                      >
                        View
                      </p>
                      {state.is_edit === false ? (
                        <p
                          onClick={() => {
                            readFile(i);
                          }}
                        >
                          Download
                        </p>
                      ) : (
                        <a
                          style={{ color: "black" }}
                          href={"http://localhost:8001" + i.DocFile}
                          download
                        >
                          Download
                        </a>
                      )}
                      <p
                        onClick={() => {
                          handleRemoveImg(i);
                        }}
                      >
                        Remove
                      </p>
                    </AttachmentRightTitle>
                  </AttachmentListContainer>
                ))}

                <AddSubTaskContainer
                  onClick={() => {
                    setSubTask(true);
                  }}
                >
                  <AddCircleOutlineIcon />
                  Add Subtask
                </AddSubTaskContainer>
                {/* ===========SubTask Modal======== */}
                {showSubTask ? (
                  <SubTaskBlock>
                    <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      Description
                    </InputLabel>
                    <StyledTextField
                      fullWidth
                      multiline
                      id="outlined-basic"
                      variant="outlined"
                      value={state.SubTaskDescription}
                      onChange={(e) => handleChange("SubTaskDescription", e)}
                    />
                    <ButtonContainer>
                      <ButtonGroup>
                        <StyledButton
                          onClick={() => {
                            AddSubTask();
                          }}
                          className="create m"
                        >
                          Save
                        </StyledButton>
                        <StyledButton
                          className="cancel"
                          onClick={() => {
                            setSubTask(false);
                          }}
                        >
                          Cancel
                        </StyledButton>
                      </ButtonGroup>
                    </ButtonContainer>
                  </SubTaskBlock>
                ) : null}

                {/* ======End============== */}
                {state.SubTaskList.map((i, index) => (
                  <CheckboxContainer>
                    <FormControlLabel
                      control={
                        <SubTaskCheckbox
                          checked={i.is_completed}
                          onChange={(e) => {
                            handleDetailCheckBox(e, index);
                          }}
                        />
                      }
                      label={i.Description}
                    />
                  </CheckboxContainer>
                ))}
                {state.is_edit
                  ? [
                      <InputLabel
                        style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                      >
                        Activities
                      </InputLabel>,
                      <ButtonContainer>
                        <ButtonGroup>
                          <InputLabel
                            style={{
                              fontSize: 12,
                              display: "inline",
                              marginRight: 10,
                            }}
                          >
                            Show:
                          </InputLabel>
                          <StyledButton
                            className={
                              showActivies === 1 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(1)}
                          >
                            All
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 2 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(2)}
                          >
                            Comments
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 3 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(3)}
                          >
                            History
                          </StyledButton>
                        </ButtonGroup>
                        <ButtonGroup>
                          <StyledButton className="cancel">
                            Newest First
                            <CompareArrowsIcon className="arrow" />
                          </StyledButton>
                        </ButtonGroup>
                      </ButtonContainer>,
                      <CommentListContainer>
                        {showActivies != 3 ? (
                          <AvatarContainer>
                            <Avatar
                              style={{
                                height: "25px",
                                width: "25px",
                                marginRight: "10px",
                                fontSize: "13px",
                                backgroundColor: "black !important",
                              }}
                              {...stringAvatar("Savad Farooque")}
                            />
                            <StyledInput
                              onKeyPress={(e) => AddCommand(e, "create")}
                              onChange={(e) => AddCommand(e, "create")}
                              value={state.comment}
                            />
                          </AvatarContainer>
                        ) : null}

                        {Activities
                          ? Activities.map((i) => (
                              <AvatarContainer>
                                <Avatar
                                  style={{
                                    height: "25px",
                                    width: "25px",
                                    marginRight: "10px",
                                    fontSize: "13px",
                                  }}
                                  {...stringAvatar("Savad Farooque")}
                                />
                                <CommentContainer>
                                  <UserDetailsContainer>
                                    <NameText>{i.name ? i.name : ""}</NameText>
                                    <TimeText>
                                      {date_time_diff_in_mint(
                                        string_to_datetime(i.CreatedDate),
                                        today_datetime()
                                      )}
                                    </TimeText>
                                    <StatusText>
                                      {i.Action === "A" ? "created" : "updated"}
                                    </StatusText>
                                  </UserDetailsContainer>
                                  {commentID === i.id ? (
                                    <StyledInput
                                      onKeyPress={(e) => AddCommand(e, "edit")}
                                      onChange={(e) => AddCommand(e, "edit")}
                                      value={state.EditDescription}
                                      ref={commentRef}
                                      name="EditDescription"
                                      id="EditDescription"
                                      focused
                                    />
                                  ) : (
                                    <CommentText>
                                      {i.Description ? i.Description : ""}
                                    </CommentText>
                                  )}

                                  {i.UserID === user_id ? (
                                    <ButtonGroup>
                                      <StyledButton
                                        className="edit"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "edit"
                                          )
                                        }
                                      >
                                        Edit
                                      </StyledButton>
                                      <StyledButton
                                        className="delete"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "delete"
                                          )
                                        }
                                      >
                                        Delete
                                      </StyledButton>
                                    </ButtonGroup>
                                  ) : null}
                                </CommentContainer>
                              </AvatarContainer>
                            ))
                          : null}
                      </CommentListContainer>,
                    ]
                  : null}
              </Block>
              <Block className="right block-2">
                <TopBoxContainer>
                  <StatusContainer>
                    <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      Status
                    </InputLabel>

                    <StatusSelect state={state} setState={setState} />
                  </StatusContainer>
                  <CheckboxContainer>
                    <RoundedCheckbox
                      name={"taskConfirmation"}
                      label={"Task Confirmation"}
                      style={{ border: " 1px solid black" }}
                      checked={state.TaskConfermation}
                      onChange={handleCheckBox}
                    />
                  </CheckboxContainer>
                </TopBoxContainer>
                <DetailsContainer>
                  <InputLabel
                    style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                  >
                    Details
                  </InputLabel>

                  <DetailBlock>
                    <DetailLabel>@Assignee</DetailLabel>

                    {showAssigneeSelect ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={state.reporterList ? state.reporterList : []}
                        getOptionLabel={(option) => option.username || ""}
                        sx={{ width: 280 }}
                        onInputChange={(event, value, reason) => {
                          if (reason === "input") {
                            onSearchUsers(value, event);
                          }
                        }}
                        onChange={(e, v) =>
                          handleSelectChange("ReportUserID", v)
                        }
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          state.reporterList && state.ReportUserID
                            ? state.reporterList[
                                get_Userindex(
                                  state.reporterList,
                                  state.ReportUserID
                                )
                              ]
                            : ""
                        }
                      />
                    ) : (
                      [
                        <Avatar
                          style={{
                            height: "25px",
                            width: "25px",
                            marginRight: "10px",
                            fontSize: "13px",
                          }}
                          {...stringAvatar(
                            state.AssigneeName ? state.AssigneName : "Assignee"
                          )}
                        />,
                        <DetailLabel
                          onClick={() => {
                            setAssigneeSelect(true);
                          }}
                        >
                          {state.AssigneeName ? state.AssigneeName : "Assignee"}
                        </DetailLabel>,
                      ]
                    )}
                    {/* ================ */}
                  </DetailBlock>

                  <DetailBlock>
                    <DetailLabel>@Reporter</DetailLabel>

                    {showReporterSelect ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={state.reporterList ? state.reporterList : []}
                        getOptionLabel={(option) => option.username || ""}
                        sx={{ width: 280 }}
                        onInputChange={(event, value, reason) => {
                          if (reason === "input") {
                            onSearchUsers(value, event);
                          }
                        }}
                        onChange={(e, v) =>
                          handleSelectChange("ReportUserID", v)
                        }
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          state.reporterList && state.ReportUserID
                            ? state.reporterList[
                                get_Userindex(
                                  state.reporterList,
                                  state.ReportUserID
                                )
                              ]
                            : ""
                        }
                      />
                    ) : (
                      [
                        <Avatar
                          style={{
                            height: "25px",
                            width: "25px",
                            marginRight: "10px",
                            fontSize: "13px",
                          }}
                          {...stringAvatar(
                            state.ReporterName ? state.ReporterName : "Reporter"
                          )}
                        />,
                        <DetailLabel
                          onClick={() => {
                            setReporterSelect(true);
                          }}
                        >
                          {state.ReporterName ? state.ReporterName : "Reporter"}
                        </DetailLabel>,
                      ]
                    )}
                    {/* ================ */}
                  </DetailBlock>

                  <DetailBlock>
                    <DetailLabel>Project</DetailLabel>
                    <ProjectNameText>Project Name</ProjectNameText>
                    {/* <NativeSelect
                      onChange={(e) => handleSelectChange("ProjectID", e)}
                      id="select"
                      defaultValue={state.ProjectID}
                    >
                      {state.ProjectList.map((i) => (
                        <option value={i.id}>{i.ProjectName}</option>
                      ))}
                    </NativeSelect> */}
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>Team</DetailLabel>
                    <TeamsName>Team's Name</TeamsName>
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>Priority</DetailLabel>
                    <PrioritySelect state={state} setState={setState} />
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>Due Date</DetailLabel>

                    <DateText>
                      {day} {month} {year}
                    </DateText>
                    <DateInputContainer>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <DatePicker
                          label="Basic example"
                          value={selectedDate}
                          onChange={handleDateChange}
                          animateYearScrolling
                          inputRef={dateRef}
                          format="dd/MM/yyyy"
                        />
                      </MuiPickersUtilsProvider>
                    </DateInputContainer>
                    <StyledEditIcon onClick={() => handleDateChangeRef()} />
                  </DetailBlock>
                </DetailsContainer>
                <div>
                  <ProgressContainer>
                    <ProgressTextContainer>
                      <ProgressLabel>Progress</ProgressLabel>
                      <ProgressRate>30%</ProgressRate>
                    </ProgressTextContainer>
                    <BorderLinearProgress
                      size="small"
                      variant="determinate"
                      value={30}
                    />
                  </ProgressContainer>
                  <SaveButtonContainer>
                    <StyledButton
                      onClick={() => {
                        SaveTask();
                      }}
                      className="create"
                    >
                      Save
                    </StyledButton>
                    <StyledButton
                      onClick={() => clearState()}
                      className="cancel"
                    >
                      Cancel
                    </StyledButton>
                  </SaveButtonContainer>
                </div>
                {/* <ButtonGroup>
                  <StyledButton
                    onClick={() => {
                      SaveTask();
                    }}
                    className="create m"
                  >
                    Save
                  </StyledButton>
                  <StyledButton className="cancel">Cancel</StyledButton>
                </ButtonGroup> */}
              </Block>
              <StyledCloseIcon
                className="close-modal"
                onClick={() => clearState()}
              />
            </BlockContainer>
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
}
const TaskText1 = styled(TextField)`
  width: 85%;
  .MuiInputBase-root {
    font-size: 16px;
  }
  .MuiFormLabel-root.Mui-focused {
    color: #8d8d8d;
    font-size: 13px;
  }
  .MuiInput-underline:after {
    border-bottom: 1px solid #12368c;
  }
  .MuiInput-underline:hover:not(.Mui-disabled):before {
    border-bottom: 1px solid #12368c;
  }
`;
const DateInputContainer = styled.div`
  display: none;
`;
const ProjectNameText = styled.p`
  color: #00536d;
`;
const TeamsName = styled.p`
  color: black;
`;

const StyledInput = styled.input`
  width: 100%;
  padding: 5px;
`;

const AvatarContainer = styled.div`
  font-size: 10px;
  margin-bottom: 20px;
  &.member {
    padding: 10px;
  }

  display: flex;
  & .MuiAvatar-root.MuiAvatar-circular.MuiAvatar-colorDefault {
    height: 30px !important;
    width: 30px !important;
    font-size: 14px;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
`;

const ButtonContainer = styled.div`
  margin-top: 6px;
  margin-bottom: 6px;
  display: flex;
  justify-content: right;
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const StyledTextField = styled(TextField)`
  && {
    outline: unset;
  }
  .MuiOutlinedInput-input.MuiInputBase-input.MuiInputBase-inputMultiline {
    height: 40px !important;
    overflow-y: scroll !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
  .MuiInputBase-multiline {
    padding: 6px 10px 7px !important;
    height: 58px;
    font-size: 13px;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d5d5d5 !important;
  }
  .css-8ewcdo-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-width: 1px !important;
  }
`;

const Container = styled.div``;
const BlockContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
  position: relative;
`;
const SubTaskBlock = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  /* max-height: 600px;
  overflow-y: scroll;
  padding: 15px; */
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
  }
`;
const Block = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #000;
    /* font-weight: unset !important; */
    font-size: 11px;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  max-height: 518px;
  overflow-y: scroll;
  padding: 0px 18px 0px 0px;
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow-y: unset !important;
    padding: 0px 0px 0px 0px;
  }
`;
const StyledCloseIcon = styled(CloseIcon)`
  &.close-modal {
    position: absolute;
    top: -66px;
    right: -6px;
  }
  cursor: pointer;
`;
const SubTaskCloseIcon = styled(CloseIcon)`
  /* &.close-modal {
    position: absolute;
    top: 15px;
    right: 15px;
  } */
  cursor: pointer;
`;
const CommentListContainer = styled.div``;

const CommentContainer = styled.div``;
const NameText = styled.p`
  font-weight: bold;
  margin-right: 5px;
`;
const UserDetailsContainer = styled.div`
  display: flex;
  margin-bottom: 3px;
`;
const TimeText = styled.p`
  margin-right: 5px;
  color: #8d8d8d;
`;
const StatusText = styled.p`
  color: #8d8d8d;
`;
const CommentText = styled.p`
  color: #363636;
  margin-bottom: 3px;
`;
const StatusContainer = styled.div`
  div div div div div {
    padding: 5px 11px !important;
  }
  .MuiBox-root {
    border: unset !important;
  }
`;

const DetailsContainer = styled.div``;

const DetailBlock = styled.div`
  background: #f3f3f3;
  padding: 10px;
  margin-bottom: 6px;
  display: flex;
  height: 44px;
  align-items: center;
  & .MuiInput-underline:before {
    border: unset;
  }
`;

const DetailLabel = styled.p`
  width: 100px;
  cursor: pointer;
`;

const ProgressContainer = styled.div`
  padding: 7px 10px;
  height: 44px;
  background: #f3f3f3;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 4px;
    background: #c8c8c8;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const SaveButtonContainer = styled.div`
  text-align: right;
  margin-top: 10px;
  /* position: absolute;
  right: 15px;
  bottom: 15px; */
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  width: 100%;
`;
const ProgressLabel = styled.p``;
const ProgressRate = styled.p`
  color: #757575;
`;
const DateText = styled.p`
  color: #727272;
`;
const TopBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
`;
const CheckboxContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  label {
    color: unset !important;
    font-weight: unset !important;
  }
`;

const StyledEditIcon = styled(EditIcon)`
  cursor: pointer;
  margin-left: auto;
  transition: all 0.1s ease-in;
  &:hover {
    background: #ccc;
    transition: all 0.1s ease-in;
    border-radius: 3px;
  }
`;

const AddSubTaskContainer = styled(Button)`
  && {
    background: #e7ebf6;
    padding: 10px;
    color: #12368c;
    height: 36px;
    text-transform: capitalize;
    width: 100%;
    justify-content: left;
    border-radius: 2px;
    svg {
      margin-right: 5px;
    }
  }
`;
const AttachmentListContainer = styled.div`
  && {
    background: #f3f3f3;
    padding: 10px;
    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    display: flex;
    justify-content: space-around;
    border-radius: 2px;
    margin-bottom: 10px;
  }
`;
const AttachmentLeftTitle = styled.div`
  width: 30%;
  color: #12368c;
`;
const AttachmentRightTitle = styled.div`
  display: flex;
  justify-content: space-between;
  width: 50%;
  p {
    cursor: pointer;
  }
  p:nth-child(1) {
    color: #128c16;
  }
  p:last-child {
    color: #8e1906;
  }
`;

const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;
const SubTaskCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: #12368c;
  }
`;
function StatusSelect(props) {
  const [work, setWork] = React.useState(
    props.state ? props.state.Status : "progress"
  );

  const handleChange = (event) => {
    setWork(event.target.value);
    props.setState({
      ...props.state,
      Status: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"progress"} className="progress">
              In Progress
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              Done
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
function PrioritySelect(props) {
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.Priority : "medium"
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      Priority: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #ebfcee !important;
      padding: 5px 11px;

      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }

    div {
      border-color: #005a0f !important;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"low"} className="progress">
              Low
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              Medium
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              High
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
function ProjectSelect(props) {
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.ProjectID : ""
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      ProjectID: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            {props.state.ProjectList.map((i) => (
              <MenuItem value={"high"} className="completed">
                {i.ProjectName}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
const CustomeAutocomplete = styled(Autocomplete)`
  button {
    padding: 0;
  }
`;
