import {
  Avatar,
  Box,
  Button,
  LinearProgress,
  linearProgressClasses,
  Menu,
} from "@mui/material";
import React, { useEffect, useRef } from "react";
import styled from "styled-components/macro";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Divider from "@mui/material/Divider";
import CalendarViewWeekIcon from "@mui/icons-material/CalendarViewWeek";
import TableRowsOutlinedIcon from "@mui/icons-material/TableRowsOutlined";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { useParams } from "react-router-dom";
import {
  get_date,
  stringAvatar,
  getCookie,
  URLtoFile,
  toDataURL,
} from "../../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";

import ProjectTaskDrag from "../../Tasks/ProjectTaskDrag";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { useSelector } from "react-redux";
import { projectListUrl } from "../../../api/ProjectsAPI";
import Swal from "sweetalert2";
import "animate.css";
import {
  taskCreateUrl,
  taskDeleteUrl,
  taskEditUrl,
  taskListUrl,
  taskUpadteStatusPriorityUrl,
  taskViewUrl,
} from "../../../api/TasksAPI";

import { ProjectComments } from "../../../functions/API_Call_functions";
import RoundedCheckbox from "../../../components/RoundedCheckbox/RoundedCheckbox";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import TeamCreateTask from "../TeamTask/TeamCreateTask";
import TeamTaskDrag from "../TeamTask/TeamTaskDrag";
const access = getCookie("VBID");

const IndividualTask = () => {
  const paramsData = useParams();
  console.log(paramsData);

  const [close, setClose] = React.useState(false);
  const [commentID, setcommentID] = React.useState(null);
  const commentRef = useRef(null);
  const [showActivies, setActivites] = React.useState(1);
  const navigate = useNavigate();
  const location = useLocation();

  const [showReporterSelect, setReporterSelect] = React.useState(false);
  const [selectedDate, handleDateChange] = React.useState(new Date());
  let DueDate = get_date(selectedDate);
  let dateRef = useRef(null);
  const { username, photo } = useSelector((state) => state.user);
  const [age, setAge] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [showSubTask, setSubTask] = React.useState(false);
  const [showTasks, setTasks] = React.useState("table");
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  let FilterType = 0;
  let FilterValue = "";
  if (params.q) {
    FilterType = 1;
    FilterValue = params.q;
  }
  const [state, setState] = React.useState({
    Status: "progress",
    TaskConfermation: false,
    TaskName: "",
    DocumentList: [],
    TaskList: [
      {
        Title: "qwwerrtteeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
        id: "123334",
        Status: "ddd",
        DueDate: "12-10-2021",

        Priority: "medium",
        ReporterName: "eeee",
        asigneeName: "anusree",
      },
      {
        Title: "fgtt",
        id: "122333",
        Status: "llll",
        DueDate: "11-12-2021",

        Priority: "high",
        ReporterName: "qwee",
        asigneeName: "savad",
      },
      {
        Title: "fgtt",
        id: "122333",
        Status: "llll",
        DueDate: "11-12-2021",

        Priority: "high",
        ReporterName: "qwee",
        asigneeName: "abhi",
      },
    ],
    Description: "",
    ProjectList: [],
    ProjectID: "",
    reporterList: [],
    ReportUserID: "",
    ReporterName: "",
    DocumentList: [],
    Priority: "medium",
    DueDate: get_date(selectedDate),
    Progress: 0,
    CreatedBy: username,
    get_list: true,
    is_edit: false,
    edit_id: "",
    SubTaskDescription: "",
    SubTaskList: [],
    // For Comment
    CommentList: [],
    HistoryList: [],
    comment: "",
    EditDescription: "",
    FilterType: FilterType,
    FilterValue: FilterValue,
  });
  const clearState = () => {
    setcommentID(null);
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [],
        Status: "progress",
        TaskConfermation: false,
        TaskName: "",
        Description: "",
        ProjectID: "",
        ReportUserID: "",
        ReporterName: "",
        Priority: "medium",
        DueDate: get_date(selectedDate),
        Progress: 0,
        CreatedBy: username,
        get_list: true,
        is_edit: false,
        edit_id: "",
        SubTaskDescription: "",
        SubTaskList: [],
        // For Comment
        CommentList: [],
        HistoryList: [],
        comment: "",
        EditDescription: "",
        FilterType: 0,
        FilterValue: "",
      };
    });
    setOpen(false);
  };
  const [checked, setChecked] = React.useState(true);

  const handleCheckBox = (event) => {
    setState((prevState) => {
      return {
        ...prevState,
        TaskConfermation: event.target.checked,
      };
    });
  };

  const handleDetailCheckBox = (event, index) => {
    let SubTaskList = [...state.SubTaskList];
    SubTaskList[index]["is_completed"] = event.target.checked;
    console.log(event.target.checked);
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList,
      };
    });
  };
  const handleChange = (n, e) => {
    setState((prevState) => {
      return {
        ...prevState,
        [n]: e.target.value,
      };
    });
  };
  const handleListSelect = (n, e, pk) => {
    if (e) {
      console.log(n, e.target.value, pk, "_______________REW");
      let val = e.target.value;
      upadteStatusPriorit(pk, val, n);
    }
  };

  const MoveToTeams = () => {
    navigate(`/teams?q=${true}`);
  };
  const handleSelectChange = (n, e) => {
    if (e) {
      if (n == "ReportUserID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.UserID,
            ReporterName: e.username,
          };
        });
        setReporterSelect(false);
      } else {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.target.value,
          };
        });
      }
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          [n]: "",
        };
      });
    }
  };
  const AddSubTask = () => {
    let sub_task = {
      Description: state.SubTaskDescription,
      is_completed: false,
    };
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: [...state.SubTaskList, sub_task],
        SubTaskDescription: "",
      };
    });
    setSubTask(false);
  };
  // const handleCheckbox = (event) => {
  //   setState({ ...state, [event.target.name]: event.target.checked });
  // };
  // --------------For Attachment Image List--------------
  const handleChangeImg = (event) => {
    const fileUploaded = event.target.files[0];

    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [...state.DocumentList, ...event.target.files],
      };
    });
  };
  const handleRemoveImg = (file) => {
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: state.DocumentList.filter((i) => i !== file),
      };
    });
  };

  // ------------------END---------------------
  const removeCheckBox = (value) => {
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: state.SubTaskList.filter((i) => i !== value),
      };
    });
  };
  const api_fetch = async () => {
    const taskListResponse = await fetch(taskListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        FilterType: state.FilterType,
        FilterValue: state.FilterValue,
      }),
    }).then((response) => response.json());
    if (taskListResponse.StatusCode === 6000) {
      setState((prevState) => {
        return {
          ...prevState,
          TaskList: taskListResponse.data,
          get_list: false,
        };
      });
    }
  };

  const onSearchUsers = async (val, e) => {
    console.log("====================>>>??????");
    if (val) {
      const userListResponse = await fetch(
        "http://localhost:8000/api/v1/users/get-users/",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            username: val,
          }),
        }
      ).then((response) => response.json());
      if (userListResponse.StatusCode === 6000) {
        setState((prevState) => {
          return {
            ...prevState,
            reporterList: userListResponse.data,
          };
        });
      }
    }
  };
  // -------------------_SAVE TASK---------------------------
  const SaveTask = async () => {
    let Url = taskCreateUrl;
    let title = "Task Created Successfully";
    if (state.is_edit) {
      Url = taskEditUrl + state.edit_id + "/";
      title = "Task Updated Successfully";
    }
    console.log("AAAAAAA");
    const formData = new FormData();
    formData.append("CreatedBy", state.CreatedBy);
    formData.append("TaskName", state.TaskName);
    formData.append("Description", state.Description);
    formData.append("Status", state.Status);
    formData.append("TaskConfermation", state.TaskConfermation);
    formData.append("ProjectID", state.ProjectID);
    formData.append("ReportUserID", state.ReportUserID);
    formData.append("Priority", state.Priority);
    formData.append("DueDate", state.DueDate);
    let DocumentList = state.DocumentList;
    DocumentList.map((i, index) => {
      let name = "image" + String(index);
      formData.append(name, i);
    });
    formData.append("DocumentList", state.DocumentList);
    // formData.append("SubTaskList", state.SubTaskList);
    formData.append("SubTaskList", JSON.stringify(state.SubTaskList));

    const Response = await fetch(Url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: formData,
    }).then((response) => response.json());
    if (Response.StatusCode === 6000) {
      Swal.fire({
        title: title,
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
      setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
        };
      });
      setOpen(false);
      clearState();
    } else {
      Swal.fire({
        title: "Task Created Failed",
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
    }
  };
  // --------------------END-------------------
  // ------------------DELETE TASK----------------------
  const DeleteTask = async (pk) => {
    const Response = await fetch(taskDeleteUrl + pk + "/", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
    }).then((response) => response.json());
    if (Response.StatusCode === 6000) {
      Swal.fire({
        title: "Task Deleted Successfully",
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
      setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
        };
      });
      clearState();
    } else {
      Swal.fire({
        title: "Task Deleted Failed",
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
    }
  };
  // ------------------------END-------------------------

  // const getImagePath = async(data)=>{
  //   let fileArr = [];

  //   data.DocumentList.map(async (i) => {
  //     // *** Calling both function ***
  //     let url = "http://localhost:8001" + i.DocFile;
  //     let file = await toDataURL(url).then((dataUrl) => {
  //       var fileData = URLtoFile(dataUrl, i.name);
  //       return fileData;
  //     });
  //     fileArr.push(file);
  //     console.log(fileArr);

  //   });
  //   return fileArr
  // }

  // -----------------Single ViewTask----------------------
  const ViewTask = async (pk) => {
    //   const Response = await fetch(taskViewUrl + pk + "/", {
    //     method: "POST",
    //     headers: {
    //       Authorization: `Bearer ${access}`,
    //       // "accept": "application/json"
    //     },
    //   }).then((response) => response.json());
    //   if (Response.StatusCode === 6000) {
    //     let data = Response.data;
    //     let reporterList = [
    //       {
    //         username: data.ReporterName,
    //         UserID: data.Reporter,
    //       },
    //     ];
    //     let fileArr = [];
    //     data.DocumentList.map(async (item, index) => {
    //       // *** Calling both function ***
    //       let url = "http://localhost:8001" + item.DocFile;
    //       let file = await toDataURL(url).then((dataUrl) => {
    //         var fileData = URLtoFile(dataUrl, item.name);
    //         return fileData;
    //       });
    //       fileArr.push(file);
    //       if (index === data.DocumentList.length - 1) {
    //         console.log(fileArr);
    //         setState((prevState) => {
    //           return {
    //             ...prevState,
    //             Status: data.Status,
    //             TaskConfermation: data.TaskConfermation,
    //             TaskName: data.Title,
    //             Description: data.Description,
    //             ProjectID: data.TaskProject,
    //             ReportUserID: data.Reporter,
    //             ReporterName: data.ReporterName,
    //             Priority: data.Priority,
    //             DueDate: data.DueDate,
    //             is_edit: true,
    //             edit_id: data.id,
    //             SubTaskList: data.SubTaskList,
    //             reporterList,
    //             DocumentList: fileArr,
    //           };
    //         });
    //         setOpen(true);
    //       }
    //     });
    //     if (data.DocumentList?.length == 0) {
    //       // setTimeout(() => {
    //       setState((prevState) => {
    //         return {
    //           ...prevState,
    //           Status: data.Status,
    //           TaskConfermation: data.TaskConfermation,
    //           TaskName: data.Title,
    //           Description: data.Description,
    //           ProjectID: data.TaskProject,
    //           ReportUserID: data.Reporter,
    //           ReporterName: data.ReporterName,
    //           Priority: data.Priority,
    //           DueDate: data.DueDate,
    //           is_edit: true,
    //           edit_id: data.id,
    //           SubTaskList: data.SubTaskList,
    //           reporterList,
    //           DocumentList: [],
    //         };
    //       });
    //       setOpen(true);
    //       // }, 50);
    //     }
    //   }
  };
  // ------------END------------------
  //------------- For Comment--------
  const AddCommand = async (e, type) => {
    // if (e.key === "Enter" || type === "delete") {
    //   let Description = e.target.value;
    //   let data = await ProjectComments(
    //     null,
    //     state.edit_id,
    //     Description,
    //     type,
    //     access,
    //     commentID
    //   );
    //   setState((prevState) => {
    //     return {
    //       ...prevState,
    //       CommentList: data,
    //       comment: "",
    //       EditDescription: "",
    //     };
    //   });
    //   setcommentID(null);
    // } else {
    //   let comment = "";
    //   let EditDescription = "";
    //   if (type === "create") {
    //     comment = e.target.value;
    //   }
    //   if (type === "edit") {
    //     EditDescription = e.target.value;
    //   }
    //   setState((prevState) => {
    //     return {
    //       ...prevState,
    //       comment,
    //       EditDescription,
    //     };
    //   });
    // }
  };
  const changeComment = (e, id, description, name) => {
    setcommentID(id);
    if (name === "edit") {
      setState((prevState) => {
        return {
          ...prevState,
          EditDescription: description,
        };
      });
      // setcommentID(id);
    } else if (name === "delete") {
      AddCommand(e, "delete");
    }
  };
  const handleEditClick = () => {
    commentRef.current.focus();
  };
  useEffect(() => {
    if (commentID) {
      handleEditClick();
    }
  }, [commentID]);
  // ----------------END-----------------
  // -----------Update Status&Priority-------------------
  const upadteStatusPriorit = async (pk, val, task_type) => {
    const Response = await fetch(taskUpadteStatusPriorityUrl + pk + "/", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        value: val,
        task_type: task_type,
      }),
    }).then((response) => response.json());
    if (Response.StatusCode === 6000) {
      setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
        };
      });
    }
  };
  // ------------END-----------------
  // --------Fetch Projects--------------
  // useEffect(() => {
  //   (async () => {
  //     const projectListResponse = await fetch(projectListUrl, {
  //       method: "POST",
  //       headers: {
  //         "content-type": "application/json",
  //         Authorization: `Bearer ${access}`,
  //         accept: "application/json",
  //       },
  //       body: JSON.stringify({
  //         ProjectFilter: "val",
  //       }),
  //     }).then((response) => response.json());
  //     if (projectListResponse.StatusCode === 6000) {
  //       setState((prevState) => {
  //         return {
  //           ...prevState,
  //           ProjectList: projectListResponse.data,
  //         };
  //       });
  //     }
  //   })();
  // }, []);
  // Fetch Task List
  // useEffect(() => {
  //   if (state.get_list === true) {
  //     (async () => {
  //       await api_fetch();
  //     })();
  //   }
  // }, [state.get_list]);
  useEffect(() => {
    console.log("Location", location);
    if (location.state) {
      setOpen(true);
    }
  }, [location.state]);

  const gridView = () => {
    setTasks("grid");
    setClose(true);
  };

  const listView = () => {
    setTasks("table");
    setClose(false);
  };
  return (
    <Container>
      <Header>
        <LeftHeader>
          <Heading>Savad's Task</Heading>

          <ListType>
            <Box
              sx={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                width: "fit-content",
                border: (theme) => `1px solid ${theme.palette.divider}`,
                borderRadius: 1,
                bgcolor: "background.paper",
                color: "text.secondary",
                "& svg": {
                  m: 1,
                },
                "& hr": {
                  mx: 0.5,
                },
              }}
            >
              <TableRowsOutlinedIcon onClick={listView} />
              <Divider orientation="vertical" flexItem />
              <CalendarViewWeekIcon onClick={gridView} />
            </Box>
          </ListType>
          <FilterContainer>
            <FilterLabel>Filter:</FilterLabel>
            <StyledSelect>
              <FormControl fullWidth>
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  onChange={handleChange}
                >
                  <MenuItem value={10}>All</MenuItem>
                  <MenuItem value={20}>Medium</MenuItem>
                  <MenuItem value={30}>Low</MenuItem>
                </Select>
              </FormControl>
            </StyledSelect>
          </FilterContainer>
        </LeftHeader>
        <RightHeader>
          <CheckBoxContainer close={close}>
            <RoundedCheckbox
              name={"showUnconfirmedTask"}
              label={"Show Unconfirmed Task"}
              style={{ border: " 1px solid black" }}
              checked={true}
              //   value={state.is_customer}
            />

            <CreateButton onClick={() => setOpen(true)}>Create</CreateButton>
          </CheckBoxContainer>
          <CloseButtonContainer onClick={MoveToTeams}>
            <img src="../images/icons/close-outline.svg" />
          </CloseButtonContainer>
        </RightHeader>
      </Header>
      <ProjectName>Project Name (Team's Name)</ProjectName>
      {showTasks === "table" ? (
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow2>
                <TableCell>Task Title</TableCell>
                <TableCell>Status</TableCell>

                <TableCell>Due Date</TableCell>
                <TableCell>Priority</TableCell>
                <TableCell>@Reporter</TableCell>
                <TableCell>Progress</TableCell>
                <TableCell></TableCell>
              </TableRow2>
            </TableHead>
            <TableBody>
              {state.TaskList.map((i) => (
                <TableRowCustom
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCells component="th" scope="row">
                    {i.Title}
                  </TableCells>
                  <TableCell>
                    <StatusSelect
                      handleListSelect={handleListSelect}
                      pk={i.id}
                      value={i.Status}
                    />
                  </TableCell>

                  <TableCell>
                    <ColoredDate className="red">{i.DueDate}</ColoredDate>
                  </TableCell>
                  <TableCell>
                    <PrioritySelect
                      handleListSelect={handleListSelect}
                      pk={i.id}
                      value={i.Priority}
                    />
                  </TableCell>
                  <TableCell>
                    <DetailBlock>
                      <Avatar
                        style={{
                          height: "29px",
                          width: "29px",
                          marginRight: "10px",
                          lineHeight: "unset ",
                        }}
                        {...stringAvatar(i.ReporterName)}
                      />
                      <DetailLabel>{i.ReporterName}</DetailLabel>
                    </DetailBlock>
                  </TableCell>
                  <TableCell>
                    <ProgressBarContainer>
                      <ProgressTextContainer>
                        <ProgressRate>30%</ProgressRate>
                      </ProgressTextContainer>
                      <BorderLinearProgress
                        size="small"
                        variant="determinate"
                        value={30}
                      />
                    </ProgressBarContainer>
                  </TableCell>
                  <TableCell>
                    <DropDownMenu
                      DeleteTask={DeleteTask}
                      ViewTask={ViewTask}
                      pk={i.id}
                    />
                  </TableCell>
                </TableRowCustom>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <TeamTaskDrag
          state={state}
          setState={setState}
          handleSelectChange={handleSelectChange}
          handleChangeImg={handleChangeImg}
          handleRemoveImg={handleRemoveImg}
          handleCheckBox={handleCheckBox}
          onSearchUsers={onSearchUsers}
          handleChange={handleChange}
          SaveTask={SaveTask}
        />
      )}
      <TeamCreateTask
        open={open}
        setOpen={setOpen}
        state={state}
        setState={setState}
        handleSelectChange={handleSelectChange}
        handleChangeImg={handleChangeImg}
        handleRemoveImg={handleRemoveImg}
        handleCheckBox={handleCheckBox}
        onSearchUsers={onSearchUsers}
        handleChange={handleChange}
        SaveTask={SaveTask}
        clearState={clearState}
        AddSubTask={AddSubTask}
        showSubTask={showSubTask}
        setSubTask={setSubTask}
        removeCheckBox={removeCheckBox}
        handleDetailCheckBox={handleDetailCheckBox}
        showReporterSelect={showReporterSelect}
        setReporterSelect={setReporterSelect}
        // For Comment
        commentRef={commentRef}
        showActivies={showActivies}
        setActivites={setActivites}
        AddCommand={AddCommand}
        commentID={commentID}
        changeComment={changeComment}
      />
    </Container>
  );
};

const TableRow2 = styled(TableRow)`
  th {
    font-weight: bold;
    padding: 11px 16px;
  }
`;
const TableCells = styled(TableCell)`
  padding: unset !important;
`;
const TableRowCustom = styled(TableRow)`
  th {
    padding: 5px 16px !important ;
  }
  td {
    padding: 5px 16px !important ;
  }
`;
const CloseButtonContainer = styled.div`
  cursor: pointer;
`;
const ColoredDate = styled.p`
  &.red {
    color: #f10000;
  }
  &.blue {
    color: #12368c;
  }
`;
const UnassignedText = styled.div`
  color: #848484;
  font: italic normal normal 14px/17px Poppins;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const Container = styled.div`
  /* display: ${({ show }) => (show ? "" : "none")}; */
`;
const LeftHeader = styled.div`
  display: flex;
  align-items: center;
`;
const Heading = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-right: 10px;
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #edeff3;
  padding: 0 0 0 8px;
  background: #fff;
  border-radius: 3px;
`;
const StyledSelect = styled.div`
  min-width: 120px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
const FilterLabel = styled.div`
  font-size: 16px;
`;
const RightHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 15px;
  label {
    font-weight: unset !important ;
  }
`;

const CheckBoxContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 15px;
  visibility: ${({ close }) => (close ? "hidden" : "visible")};
`;
const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;
const CreateButton = styled(Button)`
  && {
    background: #12368c;
    color: #fff;
    border-radius: 2px;
    padding: 5px 20px;
    text-transform: capitalize;
    &:hover {
      background: #5073c7;
    }
  }
`;
const ListType = styled.div`
  margin-right: 10px;
`;
const ProjectName = styled.p`
  font-size: 16px;
  color: #5e5e5e;
  font-weight: bold;
  margin-bottom: 10px;
`;

const DetailBlock = styled.div`
  display: flex;
  align-items: center;
`;

const ProgressBarContainer = styled.div`
  width: 100%;
  margin-right: 5px;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 3px;
    background: #c6c6c6;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #8c1212;
  }
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  width: 100%;
`;

const ProgressRate = styled.p`
  color: #757575;
`;

const DetailLabel = styled.p`
  line-height: unset !important;
`;

export default IndividualTask;

function StatusSelect(props) {
  const [work, setWork] = React.useState("");
  useEffect(() => {
    setWork(props.value);
  }, [props.value]);

  const handleChange = (event) => {
    setWork(event.target.value);
  };
  const Container = styled.div`
    .MuiBox-root {
      border: unset !important;
    }
    .MuiBox-root {
      border: unset !important;
    }
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
            min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;
  console.log(work, props.pk);
  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={(e) => {
              props.handleListSelect("Status", e, props.pk);
            }}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"progress"} className="progress">
              In Progress
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              Done
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function PrioritySelect(props) {
  const [priorty, setPriorty] = React.useState("");
  useEffect(() => {
    setPriorty(props.value);
  }, [props.value]);
  const Container = styled.div`
    .MuiBox-root {
      border: unset !important;
    }

    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            displayEmpty
            onChange={(e) => {
              props.handleListSelect("Priority", e, props.pk);
            }}
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"low"} className="progress">
              Low
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              Medium
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              High
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function DropDownMenu(props) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Tooltip title="Account settings">
        <IconButton
          onClick={handleClick}
          size="small"
          sx={{ ml: 2 }}
          aria-controls={open ? "account-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
        >
          <MoreVertIcon />
        </IconButton>
      </Tooltip>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem
          onClick={() => {
            props.ViewTask(props.pk);
          }}
        >
          Edit
        </MenuItem>
        <MenuItem
          onClick={() => {
            props.DeleteTask(props.pk);
          }}
        >
          Delete
        </MenuItem>
      </Menu>
    </React.Fragment>
  );
}
