import React from "react";
import styled from "styled-components/macro";
import { Button } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
import { LinearProgress, linearProgressClasses } from "@mui/material";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import { FormControl } from "@mui/material";
import { useState, useEffect, useRef } from "react";
import { styled as styles } from "@mui/material/styles";
import TeamsCard from "./TeamsCard";
import Picker from "emoji-picker-react";
import CreateGroup from "./CreateGroup";
import MenuItem from "@mui/material/MenuItem";
import { useLocation, useNavigate } from "react-router-dom";
import Select, { SelectChangeEvent } from "@mui/material/Select";

function Teams() {
  const location = useLocation();
  const messagesEndRef = useRef(null);

  const navigate = useNavigate();
  const [sideTab, setSideTab] = useState(true);
  const [open, setOpen] = useState(false);
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  const [card, setCard] = useState([1, 2, 3, 4, 5, 7, 8, 9, 1]);
  const [teamChat, setTeamChat] = useState([1, 2, 3, 5, 6, 7, 8, 856]);
  const [showEmoji, setShowEmoji] = useState(false);
  const [addMember, setAddMember] = useState(false);
  const [age, setAge] = useState("");

  const [chosenEmoji, setChosenEmoji] = useState(null);
  const [inputvalue, setInputValue] = useState("");
  const [RightPopup, setRightPopup] = useState(false);
  const [show, setShow] = useState(false);

  const onEmojiClick = (event, emojiObject) => {
    setChosenEmoji(emojiObject);
    let val = inputvalue + emojiObject.emoji;
    console.log(val);
    setInputValue(val);
  };

  const InputData = (e) => {
    console.log(e.target.value);
    setInputValue(e.target.value);
  };

  const handleChange = (event: SelectChangeEvent) => {
    setAge(event.target.value);
  };

  function useOutsideAlerter(ref) {
    useEffect(() => {
      /**
       * Alert if clicked on outside of element
       */
      function handleClickOutside(event) {
        if (
          ref.current &&
          !ref.current.contains(event.target) &&
          !String(new XMLSerializer().serializeToString(event.target)).includes(
            "<li "
          )
        ) {
          setShowEmoji(false);
        }
      }

      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }

  //  for close message box----emojiPicker

  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  const TeamsCreatePageNavigation = (e) => {
    console.log(e.target);
    if (e.target.getAttribute("name") === "addtask") {
      navigate("/team-tasks/", { state: { create: true } });
    } else {
      navigate("/team-tasks");
    }
  };

  // for latest message in chat............

  const scrollToBottom = () => {
    // messagesEndRef.current?.scrollIntoView();
  };

  useEffect(() => {
    if (!sideTab) {
      scrollToBottom();
    }
  }, [sideTab]);

  return (
    <Container>
      <TeamsLeftContainer RightPopup={RightPopup}>
        <Header>
          <LeftHeader>
            <Heading>Teams</Heading>
          </LeftHeader>
          <RightHeader>
            <CreateButton onClick={() => setOpen(true)}>Create</CreateButton>
          </RightHeader>
        </Header>
        <CreateGroup open={open} setOpen={setOpen} />

        <TeamsBody RightPopup={RightPopup}>
          {/* AdminCard............................ */}

          <GridItem onClick={() => setRightPopup(!RightPopup)}>
            <TeamCard>
              <CardHeadingConatiner>
                <CardHeadingImageConatainer>
                  <AvatarImageContainer>
                    <img
                      src="https://www.svgrepo.com/show/170303/avatar.svg"
                      style={{ borderRadius: "50%", zIndex: 100 }}
                    />
                  </AvatarImageContainer>
                  <div style={{ marginLeft: "5px" }}>
                    <TeamnameText>Team Name</TeamnameText>
                    <ProjectNameTxt>Project Name</ProjectNameTxt>
                  </div>
                </CardHeadingImageConatainer>

                <TeamAdminButton>Admin</TeamAdminButton>
              </CardHeadingConatiner>

              <MembersTextContainer>
                <p>5</p>
                <p>Members</p>
              </MembersTextContainer>
            </TeamCard>
          </GridItem>

          <GridItem>
            <TeamCard>
              <CardHeadingConatiner>
                <CardHeadingImageConatainer>
                  <AvatarImageContainer>
                    <img
                      src="https://www.svgrepo.com/show/170303/avatar.svg"
                      style={{ borderRadius: "50%" }}
                    />
                  </AvatarImageContainer>
                  <div style={{ marginLeft: "5px" }}>
                    <TeamnameText>Team Name</TeamnameText>
                    <ProjectNameTxt>Project Name</ProjectNameTxt>
                  </div>
                </CardHeadingImageConatainer>

                <TeamAdminButton>Admin</TeamAdminButton>
              </CardHeadingConatiner>

              <MembersTextContainer>
                <p>5</p>
                <p>Members</p>
              </MembersTextContainer>
            </TeamCard>
          </GridItem>

          <GridItem>
            <TeamCard>
              <CardHeadingConatiner>
                <CardHeadingImageConatainer>
                  <AvatarImageContainer>
                    <img
                      src="https://www.svgrepo.com/show/170303/avatar.svg"
                      style={{ borderRadius: "50%" }}
                    />
                  </AvatarImageContainer>
                  <div style={{ marginLeft: "5px" }}>
                    <TeamnameText>Team Name</TeamnameText>
                    <ProjectNameTxt>Project Name</ProjectNameTxt>
                  </div>
                </CardHeadingImageConatainer>

                <TeamAdminButton>Admin</TeamAdminButton>
              </CardHeadingConatiner>

              <MembersTextContainer>
                <p>5</p>
                <p>Members</p>
              </MembersTextContainer>
            </TeamCard>
          </GridItem>
          <GridItem>
            <TeamCard>
              <CardHeadingConatiner>
                <CardHeadingImageConatainer>
                  <AvatarImageContainer>
                    <img
                      src="https://www.svgrepo.com/show/170303/avatar.svg"
                      style={{ borderRadius: "50%" }}
                    />
                  </AvatarImageContainer>
                  <div style={{ marginLeft: "5px" }}>
                    <TeamnameText>Team Name</TeamnameText>
                    <ProjectNameTxt>Project Name</ProjectNameTxt>
                  </div>
                </CardHeadingImageConatainer>

                <TeamAdminButton>Admin</TeamAdminButton>
              </CardHeadingConatiner>

              <MembersTextContainer>
                <p>5</p>
                <p>Members</p>
              </MembersTextContainer>
            </TeamCard>
          </GridItem>
          <GridItem>
            <TeamCard>
              <CardHeadingConatiner>
                <CardHeadingImageConatainer>
                  <AvatarImageContainer>
                    <img
                      src="https://www.svgrepo.com/show/170303/avatar.svg"
                      style={{ borderRadius: "50%" }}
                    />
                  </AvatarImageContainer>
                  <div style={{ marginLeft: "5px" }}>
                    <TeamnameText>Team Name</TeamnameText>
                    <ProjectNameTxt>Project Name</ProjectNameTxt>
                  </div>
                </CardHeadingImageConatainer>

                <TeamAdminButton>Admin</TeamAdminButton>
              </CardHeadingConatiner>

              <MembersTextContainer>
                <p>5</p>
                <p>Members</p>
              </MembersTextContainer>
            </TeamCard>
          </GridItem>

          <TeamCard>
            <CardHeadingConatiner>
              <CardHeadingImageConatainer>
                <AvatarImageContainer>
                  <img
                    src="https://www.svgrepo.com/show/170303/avatar.svg"
                    style={{ borderRadius: "2px" }}
                  />
                </AvatarImageContainer>
                <div style={{ marginLeft: "5px" }}>
                  <TeamnameText>Team Name</TeamnameText>
                  <TeamLeaderProjectTxt>Project Name</TeamLeaderProjectTxt>
                </div>
              </CardHeadingImageConatainer>

              <TeamLeaderTypeButton>Team Leader</TeamLeaderTypeButton>
            </CardHeadingConatiner>

            <MembersTextContainer>
              <p>5</p>
              <p>Members</p>
            </MembersTextContainer>
          </TeamCard>
        </TeamsBody>
      </TeamsLeftContainer>

      {/* Right container............... */}

      <TeamsRightChatContainer RightPopup={RightPopup}>
        <div style={{ padding: "10px 10px 0 10px" }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <TeamLeftContiner>
              <AvatarImgContainer>
                <AvatarImg src="https://www.svgrepo.com/show/170303/avatar.svg" />
              </AvatarImgContainer>
              <div>
                <AdminText>Admin</AdminText>
                <RightTeamNameTxt>Team Name</RightTeamNameTxt>
                <RightProjectNametxt>Project Name</RightProjectNametxt>
              </div>
            </TeamLeftContiner>

            <EditDeleteContainer>
              <div style={{ cursor: "pointer" }}>
                <img src="./images/icons/edit.svg" />
              </div>
              <div style={{ cursor: "pointer" }}>
                <img src="./images/icons/delete.svg" />
              </div>
            </EditDeleteContainer>
          </div>
          <RoundChecBoxContainer>
            <RoundedCheckbox
              name={"trackperfomance"}
              label={"Track Performance"}
              style={{ border: " 1px solid black" }}
              checked={true}
              //   value={state.is_customer}
            />
          </RoundChecBoxContainer>
          <AddTaskContainer
            onClick={(e) => {
              TeamsCreatePageNavigation(e);
            }}
            name="createpage"
          >
            <AddTask1>
              <AddTaskHeader>
                <AddTaskIconTxt>
                  <PlusImgContainer>
                    <img
                      src="./images/icons/ios-add-circle-outline.svg"
                      name="addtask"
                    />
                  </PlusImgContainer>
                  <span style={{ color: "#12368C" }} name="addtask">
                    Add Task
                  </span>
                </AddTaskIconTxt>

                <LoaderContainer>
                  <LoadImg>
                    <img src="./images/icons/load-a.svg" />
                  </LoadImg>
                  <span style={{ color: "#A80A0A" }}>3</span>
                </LoaderContainer>
              </AddTaskHeader>

              <WorksContainer>
                <TodoTxtContainer>
                  <span>To Do</span> <Numbers>0</Numbers>
                </TodoTxtContainer>
                <InprogressTxtContainer>
                  <span>In Progress</span> <Numbers>0</Numbers>
                </InprogressTxtContainer>
                <CompleteTxtContainer>
                  <span>Completed</span> <Numbers>32</Numbers>
                </CompleteTxtContainer>
              </WorksContainer>
            </AddTask1>
            <ProgressValueContainer>
              <ProgressContainer>
                <ProgressTextContainer>
                  <ProgressLabel>Progress</ProgressLabel>
                  <ProgressRate>30%</ProgressRate>
                </ProgressTextContainer>
                <BorderLinearProgress
                  size="small"
                  variant="determinate"
                  value={30}
                />
              </ProgressContainer>
            </ProgressValueContainer>
          </AddTaskContainer>
          <TeamMemButtonContainer>
            <MembersButton sideTab={sideTab} onClick={() => setSideTab(true)}>
              Members
            </MembersButton>
            <TeamChatButton sideTab={sideTab} onClick={() => setSideTab(false)}>
              Team Chat
            </TeamChatButton>
          </TeamMemButtonContainer>
          <div>
            {sideTab ? (
              <div>
                {/* switch   -----Add Member Vs  TeamChat*/}

                <AddMemberContainer>
                  <AddMembesButton>
                    <Addmem
                      onClick={(e) => {
                        setAddMember(!addMember);
                      }}
                    >
                      <AddmemPlus>
                        <img src="/images/icons/outlinecircle.svg" />
                      </AddmemPlus>
                      <span>Add Member</span>
                    </Addmem>
                  </AddMembesButton>

                  {/* Small Popup.................... */}

                  <AddmemberPopupContainer addMember={addMember}>
                    <div style={{ position: "relative" }}>
                      <AddMemberHeader>
                        <AddMemberText>Add Member</AddMemberText>
                        <RoundCheckBoxAdd>
                          <RoundedCheckbox
                            name={"Addasleader"}
                            label={"Add as Leader"}
                            checked={true}
                          />
                        </RoundCheckBoxAdd>
                      </AddMemberHeader>

                      <SelectBoxContainer>
                        <UserText>User</UserText>
                        <SelectContainer>
                          <FormControl sx={{ width: "100%" }}>
                            <Select
                              value={age}
                              onChange={handleChange}
                              displayEmpty
                              inputProps={{ "aria-label": "Without label" }}
                            >
                              <MenuItem value="">
                                <em>None</em>
                              </MenuItem>
                              <MenuItem value={10}>Ten</MenuItem>
                              <MenuItem value={20}>Twenty</MenuItem>
                              <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                          </FormControl>
                        </SelectContainer>
                      </SelectBoxContainer>

                      <CancelButtonContainer>
                        <CancelButton
                          onClick={() => {
                            setAddMember(false);
                            // SaveTask();
                          }}
                          className="create"
                        >
                          Cancel
                        </CancelButton>

                        <AddButton
                          onClick={() => {
                            console.log("save");
                            // SaveTask();
                          }}
                          className="create"
                        >
                          Add
                        </AddButton>
                      </CancelButtonContainer>
                    </div>
                  </AddmemberPopupContainer>

                  <LeaveGroupButton>
                    <Leavegroup>
                      <LeaveGroupimg>
                        <img src="/images/icons/minus-circle-line.svg" />
                      </LeaveGroupimg>
                      <span>Leave Group</span>
                    </Leavegroup>
                  </LeaveGroupButton>
                </AddMemberContainer>
                <CardContainer sideTab={sideTab}>
                  {card.map((item) => {
                    return <TeamsCard />;
                  })}
                </CardContainer>
              </div>
            ) : (
              <TeamchatContainer>
                <div>
                  <GreenCheckBox>
                    <FormControlLabel
                      control={<CustomeCheckbox defaultChecked />}
                      label="Only show Messages Tagged to me"
                    />
                  </GreenCheckBox>
                </div>

                <CardContainer2>
                  {/* chat message -----member  without crown */}
                  <MemberProgressContainer>
                    <MembersProgress2>
                      <HeaderProgressMember>
                        <div>
                          <BlackIconLeft>
                            <div>
                              <BlackIconContainer>
                                <h4>A</h4>
                              </BlackIconContainer>
                            </div>

                            <NameContainer>
                              <div style={{ display: "flex", gap: "5px" }}>
                                <h4 style={{ fontWeight: "bold" }}>Anusree</h4>
                              </div>
                              <PointConatiner>
                                <span>32</span>
                                <span>Points</span>
                              </PointConatiner>
                            </NameContainer>
                          </BlackIconLeft>
                        </div>

                        <DateAndTimeContainer>
                          <span>08/04/2022</span>,<span>4:00PM</span>
                        </DateAndTimeContainer>
                      </HeaderProgressMember>
                      <DocumentPayroll>
                        <div>
                          <span>cumque?</span>
                        </div>
                        <FileUploadIconContainer>
                          <LinkNametext>@savadfarook</LinkNametext>
                        </FileUploadIconContainer>
                      </DocumentPayroll>
                    </MembersProgress2>
                  </MemberProgressContainer>

                  {/* Admin chat message------with crown */}

                  {teamChat.map((i) => {
                    return (
                      <MemberProgressContainer>
                        <MembersProgress2>
                          <HeaderProgressMember>
                            <div>
                              <BlackIconLeft>
                                <div>
                                  <BlackIconContainer>
                                    <h4>A</h4>
                                  </BlackIconContainer>
                                </div>

                                <NameContainer>
                                  <div style={{ display: "flex", gap: "5px" }}>
                                    <h4 style={{ fontWeight: "bold" }}>
                                      Anusree
                                    </h4>
                                    <div>
                                      <img
                                        style={{ cursor: "pointer" }}
                                        src="/images/icons/goldencrown.svg"
                                      />
                                    </div>
                                  </div>
                                  <PointConatiner>
                                    <span>32</span>
                                    <span>Points</span>
                                  </PointConatiner>
                                </NameContainer>
                              </BlackIconLeft>
                            </div>

                            <DateAndTimeContainer>
                              <span>08/04/2022</span>,<span>4:00PM</span>
                            </DateAndTimeContainer>
                          </HeaderProgressMember>
                          <DocumentPayroll>
                            <div>
                              <span>
                                ui, distinctio sapiente, eos nisi ipsam
                                delectus! Nisi, cumque?
                              </span>
                            </div>
                            <FileUploadIconContainer>
                              <LinkNametext>@savadfarook</LinkNametext>

                              <StyledButton1 className="attach attachement-icon">
                                <AttachFileIcon ref={messagesEndRef} />
                              </StyledButton1>
                            </FileUploadIconContainer>
                          </DocumentPayroll>
                        </MembersProgress2>
                      </MemberProgressContainer>
                    );
                  })}
                </CardContainer2>
              </TeamchatContainer>
            )}
          </div>
        </div>

        {!sideTab ? (
          // Emoji picker -------Box

          <MessageBox ref={wrapperRef}>
            <MessageBoxContainer>
              <EmojiPicker showEmoji={showEmoji}>
                <Picker onEmojiClick={onEmojiClick} />
              </EmojiPicker>
              <EmojiContainer onClick={() => setShowEmoji(!showEmoji)}>
                <img
                  src="/images/icons/emoji-smile.svg"
                  style={{ display: "block", width: "100%" }}
                />
              </EmojiContainer>

              <MesssageInputBox
                type="text"
                value={inputvalue}
                placeholder="Type Something"
                onChange={InputData}
              />

              <FileUploadButton className="attach  fileUploadBtn">
                <AttachFileIcon />
              </FileUploadButton>
              <input type="file" style={{ display: "none" }} multiple />

              <SendButton>
                <img src="/images/icons/send-sharp.svg" />
              </SendButton>
            </MessageBoxContainer>
          </MessageBox>
        ) : (
          ""
        )}
      </TeamsRightChatContainer>
    </Container>
  );
}

export default Teams;

const CancelButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
  && {
    background-color: #d5e2ef !important;
    color: #2b2b2b !important;
  }
`;
const AddButton = styled(CancelButton)`
  && {
    background-color: #12368c !important;
    color: #fff !important;
  }
`;

const CancelButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
`;
const SelectContainer = styled.div`
  div
    div
    .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    padding: 5px !important;
  }
  display: block;
`;
const SelectBoxContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 5px;
`;
const UserText = styled.span`
  color: #8f8f8f;
`;

const RoundCheckBoxAdd = styled.div`
  display: flex;

  label {
    font-size: 11px !important;
    font-weight: unset !important;
  }
`;
const AddMemberText = styled.h3`
  font-weight: bold;
  letter-spacing: 1px; ;
`;

const AddMemberHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const AddmemberPopupContainer = styled.div`
  position: absolute;
  background-color: white;
  width: 93.8%;
  z-index: 2;
  padding: 10px;
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  margin-top: 35px;
  transition: transform 0.3s ease-in-out;
  display: ${({ addMember }) => (addMember ? "" : "none")};
`;
const GridItem = styled.div`
  text-align: center;
  cursor: pointer;
`;

const EmojiPicker = styled.div`
  position: absolute;
  bottom: 0px;

  right: 5;
  visibility: ${({ showEmoji }) => (showEmoji ? "visible" : "hidden")};
`;

const EmojiContainer = styled.div`
  display: flex;
  cursor: pointer;
  width: 21px;
  align-items: center;
`;
const SendButton = styled(EmojiContainer)``;
const MesssageInputBox = styled.input`
  width: 195px;
  background-color: transparent;
  border: none;
  outline: none;
`;
const MessageBoxContainer = styled.div`
  display: flex;

  align-items: center;
  justify-content: space-evenly;
  width: 100%; ;
`;

const TeamchatContainer = styled.div``;

const MessageBox = styled.div`
  display: flex;
  align-items: center;
  bottom: 0px;
  position: absolute;

  height: 50px;
  width: 100%;
  background-color: #e8edf5;
`;
const CardContainer = styled.div`
  overflow-y: scroll;
  height: ${({ sideTab }) => (sideTab ? "61vh" : "")};

  @media (min-width: 1920px) {
    height: 68vh;
  }
  ::-webkit-scrollbar {
    display: none;
  }
`;
const CardContainer2 = styled.div`
  ::-webkit-scrollbar {
    display: none;
  }
  overflow-y: auto;
  height: 53vh !important;
  /* display: flex;
  flex-direction: column;
  justify-content: end; */
  position: relative;
  @media (min-width: 1920px) {
    height: 63vh !important;
  }
`;
const DocumentPayroll = styled.div`
  margin-top: 5px;
`;
const LinkNametext = styled.span`
  font-style: italic;
  color: #084594;
`;
const NameText = styled.span`
  font-weight: bold;
`;
const FileUploadIconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StyledButton = styled.span`
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    display: block !important;
    padding: none !important;
    min-width: none !important ;
  }

  .MuiTouchRipple-root css-8je8zh-MuiTouchRipple-root {
    padding: none !important;
    min-width: none !important ;
  }
  .css-8je8zh-MuiTouchRipple-root {
    display: block;
    padding: none !important;
    min-width: none !important ;
  }
  && {
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &:hover {
    background-color: unset !important ;
  }
  &&.create {
    color: #fff;

    background: #12368c;
  }
  &&.cancel {
    color: #8b98b0;
  }
  &&.attach {
    color: #8b98b0;

    /* background: #d8d8d8 0% 0% no-repeat padding-box; */
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const FileUploadButton = styled(StyledButton)`
  display: flex;
  align-items: center;
  cursor: pointer;

  &.fileUploadBtn svg {
    font-size: 21px !important;
  }
`;

const StyledButton1 = styled(StyledButton)`
  &.attachement-icon svg {
    font-size: 21px !important;
  }
`;

const DateAndTimeContainer = styled.div`
  color: #808080;
  font-size: 10px;
  display: flex;
  gap: 2px;
`;

const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;
const GreenCheckBox = styled.div`
  .MuiTypography-body1 {
    font-size: 12px !important;
    margin: -5px;
  }
`;
const MemberProgressContainer = styled.div`
  box-shadow: rgb(67 71 85 / 27%) 0px 0px 0.25em,
    rgb(90 125 188 / 5%) 0px 0.25em 1em;
  margin-top: auto;
  &:nth-child(1) {
    margin-top: unset !important;
  }
  &:last-child {
    margin-bottom: unset !important ;
  }

  border: 1px solid #e5e5e5;
  margin-bottom: 10px;
`;

const PointConatiner = styled.span`
  display: flex;
  gap: 3px;
  color: #035300;
  margin-top: -3px;
`;
const NameContainer = styled.div`
  font-size: 12px;
  font-weight: bold;
`;
const BlackIconLeft = styled.div`
  display: flex;
  gap: 5px;
`;

const BlackIconContainer = styled.div`
  border-radius: 50%;
  color: white;
  background-color: black;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;

  padding: 17px;
  height: 20px;
  width: 20px;
`;
const HeaderProgressMember = styled.div`
  display: flex;
  justify-content: space-between;
`;
const MembersProgress = styled.div`
  padding: 8px 8px 0px 8px;

  border-radius: 2px;
`;
const MembersProgress2 = styled(MembersProgress)`
  padding: 8px 8px 3px 8px;
`;
const Addmem = styled.div`
  display: flex;
  gap: 5px;
  font-size: 11px;
  padding: 5px 13px 4px 0px;
`;
const Leavegroup = styled(Addmem)`
  color: #b20000 !important;
`;
const AddmemPlus = styled.div`
  display: flex;
  align-items: center;
`;
const LeaveGroupimg = styled(AddmemPlus)`
  width: 20px;
  height: 20px;
`;
const TeamMemButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 8px;
`;
const AddMemberContainer = styled(TeamMemButtonContainer)`
  margin-top: 5px !important;
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,

  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressLabel = styled.p``;
const ProgressBorder = styled(BorderLinearProgress)`
  height: 5px !important;
`;

const ProgressRate = styled.p`
  color: #757575;
`;
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
  width: 100%;
  padding: 0 10px;
`;

const ProgressContainer = styled.div`
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 7px;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;

const ProgressValueContainer = styled.div``;
const Numbers = styled.span`
  font-weight: bold;
`;
const WorksContainer = styled.div`
  display: flex;
  gap: 5px;
  justify-content: space-between;
  margin-top: 7px;
`;
const TodoTxtContainer = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 3px;
  background-color: #e2e2e2;
  width: 100px;
  border-radius: 2px;
  font-size: 10px;
  flex: 1;
`;
const InprogressTxtContainer = styled(TodoTxtContainer)`
  background-color: #dbe6ff;
`;
const CompleteTxtContainer = styled(TodoTxtContainer)`
  background-color: #bef1cc;
`;

const PlusImgContainer = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;
const LoadImg = styled.div`
  display: flex;
  align-items: center;
`;
const LoaderContainer = styled.div`
  display: flex;
  gap: 5px;
`;

const AddTaskIconTxt = styled.div`
  display: flex;
  gap: 5px;
`;
const AddTaskHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const AddTaskContainer = styled.div`
  margin-top: 10px;
  cursor: pointer;
  border: 1px solid #dde2eb;
  /* border-radius: 5px; */
  box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em,
    rgba(90, 125, 188, 0.05) 0px 0.25em 1em;
`;
const AddTask1 = styled.div`
  padding: 10px;
`;

const RoundChecBoxContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
`;
const AdminText = styled.span`
  color: #013d23;
`;
const RightTeamNameTxt = styled.h4`
  font-size: 14px;
  font-weight: bold;
`;

const EditDeleteContainer = styled.div`
  padding-top: 40px;
  gap: 20px;
  display: flex;
`;
const TeamLeftContiner = styled.div`
  display: flex;
  gap: 8px;
`;
const AvatarImgContainer = styled.div`
  width: 60px;
  height: 60px; ;
`;
const AvatarImg = styled.img`
  border-radius: 50%;
`;
const TeamLeaderProjectTxt = styled.p`
  color: #c50000;
`;

const TeamLeaderTypeButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #00195d;

    background: #b4c8ff;
    border-radius: 0;
    height: 30px;
    height: 22px;
    font-size: 12px !important;
    margin-left: auto;
  }

  .MuiButton-root:hover {
    background-color: unset !important;
  }
`;
const ProjectNameTxt = styled.p`
  color: #918804;
  font-size: 11px;
`;
const RightProjectNametxt = styled(ProjectNameTxt)`
  font-size: 13px;
`;

const MembersTextContainer = styled.div`
  display: flex;
  gap: 3px;
  margin-top: 3px;
`;

const TeamnameText = styled.h4`
  font-size: 13px;
  font-weight: bold;
`;
const CardHeadingImageConatainer = styled.div`
  display: flex;

  align-items: center;
`;
const AvatarImageContainer = styled.div`
  width: 40px;
  height: 40px; ;
`;

const CardHeadingConatiner = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const TeamAdminButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #013d23;

    background: #bfe5d2;
    border-radius: 0;
    height: 30px;
    height: 22px;
    font-size: 12px !important;
    margin-left: auto;
  }

  .MuiButton-root:hover {
    background-color: unset !important;
  }
`;

const MembersButton = styled(TeamAdminButton)`
  background-color: ${({ sideTab }) =>
    sideTab ? "#12368c !important" : "#dde2eb !important "};
  color: ${({ sideTab }) =>
    sideTab ? "#ffffff !important" : "#12368c !important"};

  /* background-color: #12368c !important;
  color: #ffffff !important; */
  width: 48%;
  padding: 15px 5px !important;
  border-radius: 3px !important;
  margin: unset !important;
`;
const TeamChatButton = styled(TeamAdminButton)`
  background-color: ${({ sideTab }) =>
    sideTab ? "#dde2eb !important " : "#12368c !important"};
  color: ${({ sideTab }) =>
    sideTab ? " #12368c !important " : " #ffffff !important"};
  width: 48% !important;
  padding: 15px 5px !important;
  border-radius: 3px !important;
  margin-left: unset !important;
`;

const AddMembesButton = styled(TeamChatButton)`
  background-color: #dde2eb !important ;
  color: #12368c !important;

  /* padding: 15px 14px 15 6px !important; */
  border-radius: 2px !important;
`;
const LeaveGroupButton = styled(AddMembesButton)`
  background-color: #fff2f2 !important;
`;
const TeamCard = styled.div`
  padding: 5px 10px;
  /* border: 1px solid black; */
  /* width: 277px; */
  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
  height: 70px;
`;
const TeamsBody = styled.div`
  grid-column-gap: 10px;
  grid-row-gap: 10px;
  display: grid;

  grid-template-columns: ${({ RightPopup }) =>
    RightPopup ? "auto auto auto" : "auto auto auto auto"};
`;

const TeamsRightChatContainer = styled.div`
  display: ${({ RightPopup }) => (!RightPopup ? "none" : "")};
  position: ${({ RightPopup }) => (!RightPopup ? "unset" : "relative")};
  -webkit-transition: unset !important;
  right: 0;

  min-width: ${({ RightPopup }) => (RightPopup ? "24.5%" : "unset")};
  margin-left: ${({ RightPopup }) => (RightPopup ? "10px" : "0")};

  border: 1px solid #00000029;
  height: 97vh;
  /* transition: all 0.3s ease-in; */
  /* cubic-bezier(0.25, 0.25, 0.165, 1.325) */
`;

const TeamsLeftContainer = styled.div`
  min-width: ${({ RightPopup }) => (RightPopup ? "75%" : "100%")};
  padding: 5px;
  transition: all 0.3s linear;
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #edeff3;
  padding: 0 0 0 8px;
  background: #fff;
  border-radius: 3px;
`;
const LeftHeader = styled.div`
  display: flex;
  align-items: center;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const Heading = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-right: 10px;
`;
const FilterLabel = styled.div`
  font-size: 16px;
`;
const RightHeader = styled.div``;

const Container = styled.div`
  display: flex;
`;

const CreateButton = styled(Button)`
  && {
    background: #12368c;
    color: #fff;
    border-radius: 2px;
    height: 31px;
    font-size: 12px;
    width: 88px;
    padding: 5px 20px;
    text-transform: capitalize;
    &:hover {
      background: #5073c7;
    }
  }
`;
