import React, { useRef, useState } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import InputLabel from "@material-ui/core/InputLabel";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import styled from "styled-components/macro";

import { MenuProps, useStyles } from "./utils";

function CheckAutocomplete({
  selected,
  setSelected,
  handleChangeCheckAutocomplete,
}) {
  const classes = useStyles();
  const checkRef = useRef(null);

  const options = ["Status", "Priority", "Date"];

  return (
    <FilterFormControl className={classes.formControl}>
      {/* <InputLabel id="mutiple-select-label">Multiple Select</InputLabel> */}
      <FilterSelect
        labelId="mutiple-select-label"
        multiple
        value={selected}
        onChange={handleChangeCheckAutocomplete}
        renderValue={(selected) => selected.join(", ")}
        MenuProps={MenuProps}
      >
        <MenuItem value="all">
          {/* <ListItemIcon>
            <Checkbox
              classes={{ indeterminate: classes.indeterminateColor }}
              checked={isAllSelected}
              indeterminate={
                selected.length > 0 && selected.length < options.length
              }
            />
          </ListItemIcon>
          <ListItemText
            classes={{ primary: classes.selectAllText }}
            primary="Select All"
          /> */}
        </MenuItem>
        {options.map((option) => (
          <MenuItem key={option} value={option}>
            <ListItemIcon ref={checkRef}>
              <Checkbox checked={selected.indexOf(option) > -1} />
            </ListItemIcon>
            <ListItemText primary={option} />
          </MenuItem>
        ))}
      </FilterSelect>
    </FilterFormControl>
  );
}
const FilterFormControl = styled(FormControl)``;
const FilterSelect = styled(Select)`
  &.MuiSelect-root.MuiSelect-select.MuiSelect-selectMenu.MuiInputBase-input.MuiInput-input {
  }
  &.MuiInput-underline:before {
    border: unset;
  }
  &.MuiInput-underline:after {
    border: unset;
  }
  &.MuiInput-underline:hover {
    border: unset;
  }
`;
export default CheckAutocomplete;
