import React, { useCallback, useEffect, useMemo, useState } from "react";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { v4 as uuid } from "uuid";
import styled from "styled-components/macro";
import { Button } from "@mui/material";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import CreateTask from "./CreateTask";
import { useTranslation } from "react-i18next";
import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
const itemsFromBackend = [
  { id: uuid(), content: "First task" },
  { id: uuid(), content: "Second task" },
  { id: uuid(), content: "Third task" },
  { id: uuid(), content: "Fourth task" },
  { id: uuid(), content: "Fifth task" },
];

function ProjectTaskDrag(props) {
  const [t] = useTranslation("common");
  // const [open, setOpen] = useState(false);
  const [taskList, setTaskList] = useState(props.paginated_data);
  let columnsFromBackend = {
    [uuid()]: {
      name: "To Do",
      items:
        props.paginated_data &&
        props.paginated_data.filter((i) => i.Status == "todo"),
    },
    [uuid()]: {
      name: "In Progress",
      items:
        props.paginated_data &&
        props.paginated_data.filter((i) => i.Status == "progress"),
    },
    [uuid()]: {
      name: "Completed",
      items:
        props.paginated_data &&
        props.paginated_data.filter(
          (i) => i.Status == "completed" || i.Status == "confirming"
        ),
    },
  };
  const [columns, setColumns] = useState(columnsFromBackend);

  useCallback(() => {
    columnsFromBackend = {
      [uuid()]: {
        name: t("To Do"),
        items:
          props.paginated_data &&
          props.paginated_data.filter((i) => i.Status == "todo"),
      },
      [uuid()]: {
        name: t("In Progress"),
        items:
          props.paginated_data &&
          props.paginated_data.filter((i) => i.Status == "progress"),
      },
      [uuid()]: {
        name: t("Completed"),
        items:
          props.paginated_data &&
          props.paginated_data.filter(
            (i) => i.Status == "completed" || i.Status == "confirming"
          ),
      },
    };
    setColumns(columnsFromBackend);
    console.log(columnsFromBackend.name);
  }, [props.paginated_data]);

  const onDragEnd = (result, columns, setColumns) => {
    if (!result.destination) return;
    const { source, destination } = result;

    console.log(result);
    console.log(columns[destination.droppableId]["name"]);
    let val = "";
    if (columns[destination.droppableId]["name"] == "To Do") {
      val = "todo";
    } else if (columns[destination.droppableId]["name"] == "In Progress") {
      val = "progress";
    } else if (columns[destination.droppableId]["name"] == "Completed") {
      val = "completed";
    }
    props.upadteStatusPriorit(result.draggableId, val, "Status");
    if (source.droppableId !== destination.droppableId) {
      const sourceColumn = columns[source.droppableId];
      const destColumn = columns[destination.droppableId];
      const sourceItems = [...sourceColumn.items];
      const destItems = [...destColumn.items];
      const [removed] = sourceItems.splice(source.index, 1);
      destItems.splice(destination.index, 0, removed);
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...sourceColumn,
          items: sourceItems,
        },
        [destination.droppableId]: {
          ...destColumn,
          items: destItems,
        },
      });
    } else {
      const column = columns[source.droppableId];
      const copiedItems = [...column.items];
      const [removed] = copiedItems.splice(source.index, 1);
      copiedItems.splice(destination.index, 0, removed);
      setColumns({
        ...columns,
        [source.droppableId]: {
          ...column,
          items: copiedItems,
        },
      });
    }
  };

  return (
    // <div
    //   style={{
    //     display: "flex",
    //     justifyContent: "space-between",
    //     height: "100%",
    //   }}
    // >
    <GridContainer>
      <DragDropContext
        onDragEnd={(result) => onDragEnd(result, columns, setColumns)}
      >
        {Object.entries(columns).map(([columnId, column], index) => {
          return (
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
              key={index}
            >
              <h2 style={{ width: "100%", marginBottom: 10 }}>{column.name}</h2>
              <div style={{ width: "100%" }}>
                <Droppable droppableId={columnId} key={columnId}>
                  {(provided, snapshot) => {
                    return (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        style={{
                          background: snapshot.isDraggingOver
                            ? "#fafcff"
                            : "#fafcff",
                          // padding: 4,
                          width: "100%",
                          minHeight: 500,
                        }}
                      >
                        {column.name === "To Do" && (
                          <CreateProjectTaskButton
                            onClick={() => props.setOpen(true)}
                          >
                            <AddCircleOutlineRoundedIcon
                              style={{ marginRight: 5 }}
                            />
                            {t("Create Task")}
                          </CreateProjectTaskButton>
                        )}

                        {column.name === "Completed" && (
                          <RoundChecBoxContainer>
                            <div>
                              <span>5</span>
                              <span> unconfirmed Task</span>
                            </div>
                            <RoundedCheckbox
                              name={"unconfirmedTask"}
                              label={"Show Unconfirmed Task"}
                              style={{ border: " 1px solid black" }}
                              checked={true}
                              //   value={state.is_customer}
                            />
                          </RoundChecBoxContainer>
                        )}
                        {column.items.map((item, index) => {
                          return (
                            <Draggable
                              key={item.id}
                              draggableId={item.id}
                              index={index}
                            >
                              {(provided, snapshot) => {
                                return (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    {...provided.dragHandleProps}
                                    style={{
                                      userSelect: "none",
                                      padding: "0px 0px 0px 0",
                                      margin: "0 0 8px 0",
                                      minHeight: "50px",
                                      border: "1px solid #DDE2EB",
                                      backgroundColor: snapshot.isDragging
                                        ? "#d4d4d4"
                                        : "white",
                                      color: "black",
                                      ...provided.draggableProps.style,
                                    }}
                                  >
                                    <MainContainer
                                      onClick={(e) => props.UpdateTask(item, e)}
                                    >
                                      <LabelContainer>
                                        <ContentContainer>
                                          <Container className="top">
                                            <TaskTitleText>
                                              {item.Status == "confirming" ? (
                                                <div>
                                                  <img src="../../images/conferming-load.svg" />
                                                </div>
                                              ) : null}
                                              <BadgeContainer1>
                                                {item.is_view === false ? (
                                                  <Badge_span></Badge_span>
                                                ) : null}

                                                <p className="title">
                                                  {item.Title}
                                                </p>
                                              </BadgeContainer1>
                                            </TaskTitleText>
                                            <UnassignedText>
                                              {item.Assignee
                                                ? t("Assigned")
                                                : t("Unassigned")}
                                            </UnassignedText>
                                          </Container>
                                          <Container className="bottom">
                                            <DateLabelText>
                                              {t("Due Date")}
                                            </DateLabelText>
                                            <ColoredDate className="blue">
                                              {item.DueDate}
                                            </ColoredDate>
                                          </Container>
                                        </ContentContainer>
                                        <BottomColorLabel className="blue"></BottomColorLabel>
                                      </LabelContainer>
                                    </MainContainer>
                                  </div>
                                );
                              }}
                            </Draggable>
                          );
                        })}
                        <DropContainer>{t("Drag & Drop")}</DropContainer>
                        {provided.placeholder}
                      </div>
                    );
                  }}
                </Droppable>
              </div>
            </div>
          );
        })}
      </DragDropContext>
      <CreateTask
        open={props.open}
        setOpen={props.setOpen}
        state={props.state}
        setState={props.setState}
      />
      {/* </div> */}
    </GridContainer>
  );
}

export default ProjectTaskDrag;
const BadgeContainer1 = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
`;

const Badge_span = styled.span`
  border-radius: 50%;
  width: 8px;
  height: 8px;
  background-color: red;
`;
const RoundChecBoxContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  padding: 0px 2px; ;
`;

const GridContainer = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 10px;
`;
const DropContainer = styled.div`
  font-size: 14px;
  color: #a2aec8;
  padding: 16px;
  text-align: center;
  border: 1px dashed #a8b1c2;
`;

const CreateProjectTaskButton = styled(Button)`
  && {
    width: 100%;
    text-align: left;
    justify-content: left;
    text-transform: capitalize;
    color: #12368c;
    padding: 10px 16px;
    margin-bottom: 8px;
    height: 40px;
    background: #e7ebf6;
  }
`;
const TaskTitleText = styled.div`
  display: flex;
  p {
    font-weight: bold;
    margin-left: 5px;
  }
  /* div {
    /* -webkit-animation: spin 2s linear infinite; /* Safari */
    /* animation: spin 2s linear infinite; */
    */

    /* Safari */
    @-webkit-keyframes spin {
      0% {
        -webkit-transform: rotate(0deg);
      }
      100% {
        -webkit-transform: rotate(360deg);
      }
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
  } */
`;
const UnassignedText = styled.p`
  color: #848484;
  font: italic normal normal 11px/17px Poppins;
`;
const Container = styled.div`
  display: flex;
  justify-content: space-between;
  &.top {
    margin-bottom: 5px;
  }
`;
const ColoredDate = styled.p`
  &.red {
    color: #ff0000;
  }
  &.blue {
    color: #12368c;
  }
`;
const DateLabelText = styled.p`
  color: #a2a2a2;
`;
const MainContainer = styled.div`
  display: flex;
  cursor: pointer;
`;
const LeftColorLabel = styled.div`
  width: 6px;

  height: auto;
  &.red {
    background: #eb5f5f;
  }
  &.green {
    background: #077553;
  }
  &.yellow {
    background: #ccac09;
  }
`;
const ContentContainer = styled.div`
  width: 100%;
  padding: 10px;
`;
const BottomColorLabel = styled.div`
  &.blue {
    background: #1145bf;
  }
  &.green {
    background: #07750b;
  }
  height: 4px;
  width: 100%;
  display: block;
`;
const LabelContainer = styled.div`
  width: 100%;
`;
