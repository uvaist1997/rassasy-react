import {
  Avatar,
  Box,
  Button,
  LinearProgress,
  linearProgressClasses,
  Menu,
  Pagination,
  TablePagination,
} from "@mui/material";
import React, { useContext, useEffect, useRef, useState } from "react";
import styled from "styled-components/macro";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Divider from "@mui/material/Divider";
import CalendarViewWeekIcon from "@mui/icons-material/CalendarViewWeek";
import TableRowsOutlinedIcon from "@mui/icons-material/TableRowsOutlined";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import {
  get_date,
  stringAvatar,
  getCookie,
  date_monthName_format,
  get_color_due_date,
} from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import CreateTask from "./CreateTask";
import ProjectTaskDrag from "./ProjectTaskDrag";
import Checkbox from "@material-ui/core/Checkbox";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import "animate.css";
import {
  taskDeleteUrl,
  taskListUrl,
  taskUpadteStatusPriorityUrl,
} from "../../api/TasksAPI";
import { useLocation } from "react-router-dom";
import usePagination from "../../functions/Pagination";
import ListFilterTask from "../../components/ListFilterTask";
import { useTranslation } from "react-i18next";
import { projectListUrl } from "../../api/ProjectsAPI";
import Badge from "@mui/material/Badge";
import { DataContext } from "../../components/Context1";

const access = getCookie("VBID");

const Tasks = () => {
  const [t] = useTranslation("common");
  const { username, user_id } = useSelector((state) => state.user);
  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;
  const location = useLocation();
  const [showReporterSelect, setReporterSelect] = React.useState(false);
  const [selectedDate, handleDateChange] = React.useState(new Date());
  let DueDate = get_date(selectedDate);
  let subSelectRef = useRef(null);
  const [age, setAge] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [showTasks, setTasks] = React.useState("table");
  const [showFilter, setFilter] = useState(false);
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  let FilterType = null;
  let FilterValue = 0;
  if (params.q) {
    FilterType = 1;
    FilterValue = params.q;
  }
  let ProjectID = null;
  if (params.m && location.state.ProjectID) {
    FilterType = 2;
    FilterValue = params.m;
    ProjectID = location.state.ProjectID;
  }
  const [state, setState] = React.useState({
    showUnconfirmedTask: false,
    TaskList: [],
    get_list: true,
    is_edit: false,
    edit_id: "",
    FilterType: FilterType,
    FilterValue: FilterValue,
    singleTask: {},
    ProjectID: ProjectID,
    FilterStartDate: null,
    FilterEndDate: null,
    ProjectFilter: null,
    ProjectName: "",
    ProjectList: [],
    is_load: true,
  });

  // const paginated_data = usePagination(state.TaskList, PER_PAGE);

  const [checked, setChecked] = React.useState(true);
  const [selected, setSelected] = useState([]);
  const handleChangeCheckAutocomplete = (event) => {
    const value = event.target.value;
    setSelected(value);
    let current_li = event.nativeEvent.path[4];
    let current_ul = event.nativeEvent.path[5];
    var new_ul = document.createElement("ul");
    var new_li = document.createElement("li");
    new_ul.className("new-ul");
    current_li.append(new_ul);
    new_ul.append(new_li);
  };
  const handleChange = (n, e) => {
    setState((prevState) => {
      return {
        ...prevState,
        [n]: e.target.value,
      };
    });
  };
  const handleCheckBox = (event) => {
    setState((prevState) => {
      return {
        ...prevState,
        showUnconfirmedTask: event.target.checked,
        is_load: true,
        get_list: true,
      };
    });
  };
  const handleListSelect = (n, e, pk) => {
    if (e) {
      let val = e.target.value;
      if (val === "completed") {
        let task = state.TaskList.filter((a) => a.id === pk)[0];
        if (task.TaskConfermation && task.Reporter != user_id) {
          val = "confirming";
        }
      }
      upadteStatusPriorit(pk, val, n);
    }
  };
  const api_fetch = async () => {
    const taskListResponse = await fetch(taskListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        FilterType: state.FilterType,
        FilterValue: state.FilterValue,
        TaskConfermation: state.showUnconfirmedTask,
        ProjectID: state.ProjectID,
        FilterStartDate: state.FilterStartDate,
        FilterEndDate: state.FilterEndDate,
        ProjectFilter: state.ProjectFilter,
        is_load: state.is_load,
      }),
    }).then((response) => response.json());
    const projectListResponse = await fetch(projectListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        ProjectFilter: [],
        FilterStartDate: null,
        FilterEndDate: null,
      }),
    }).then((response) => response.json());
    let ProjectList = [];
    if (projectListResponse.StatusCode === 6000) {
      ProjectList = projectListResponse.data;
    }
    if (taskListResponse.StatusCode === 6000) {
      // setState((prevState) => {
      //   return {
      //     ...prevState,
      //     TaskList: taskListResponse.data,
      //     get_list: false,
      //   };
      // });

      setState({
        ...state,
        TaskList: taskListResponse.data,
        ProjectList: ProjectList,
        ProjectName: taskListResponse.ProjectName,
        get_list: false,
        is_load: false,
      });
      setNotificationCount((prevState) => {
        return {
          ...prevState,
          project_notify: taskListResponse.project_notify,
          task_notify: taskListResponse.task_notify,
        };
      });
    } else {
      setState({
        ...state,
        TaskList: [],
        get_list: false,
        ProjectList: ProjectList,
        ProjectName: taskListResponse.ProjectName,
        is_load: false,
      });
    }
  };
  // ------------------DELETE TASK----------------------
  const DeleteTask = async (pk) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const Response = await fetch(taskDeleteUrl + pk + "/", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            UserName: username,
          }),
        }).then((response) => response.json());
        if (Response.StatusCode === 6000) {
          Swal.fire("Deleted!", "Your Task has been deleted.", "success");

          setState((prevState) => {
            return {
              ...prevState,
              get_list: true,
            };
          });
        } else {
          Swal.fire({
            title: "Task Deleted Failed",
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
        }
      } else {
        console.log("cancelled");
      }
    });
  };
  // ------------------------END-------------------------

  // -----------------Single ViewTask----------------------
  // const ViewTask = async (pk) => {
  //   const Response = await fetch(taskViewUrl + pk + "/", {
  //     method: "POST",
  //     headers: {
  //       Authorization: `Bearer ${access}`,
  //       // "accept": "application/json"
  //     },
  //   }).then((response) => response.json());
  //   if (Response.StatusCode === 6000) {
  //     let data = Response.data;
  //     let reporterList = [
  //       {
  //         username: data.ReporterName,
  //         UserID: data.Reporter,
  //       },
  //     ];

  //     let fileArr = [];

  //     data.DocumentList.map(async (item, index) => {
  //       // *** Calling both function ***
  //       let url = "http://localhost:8001" + item.DocFile;
  //       let file = await toDataURL(url).then((dataUrl) => {
  //         var fileData = URLtoFile(dataUrl, item.name);
  //         return fileData;
  //       });
  //       fileArr.push(file);

  //       if (index === data.DocumentList.length - 1) {
  //         console.log(fileArr);
  //         setState((prevState) => {
  //           return {
  //             ...prevState,
  //             Status: data.Status,
  //             TaskConfermation: data.TaskConfermation,
  //             TaskName: data.Title,
  //             Description: data.Description,
  //             ProjectID: data.TaskProject,
  //             ReportUserID: data.Reporter,
  //             ReporterName: data.ReporterName,
  //             Priority: data.Priority,
  //             DueDate: data.DueDate,
  //             is_edit: true,
  //             edit_id: data.id,
  //             SubTaskList: data.SubTaskList,
  //             reporterList,
  //             DocumentList: fileArr,
  //           };
  //         });
  //         setOpen(true);
  //       }
  //     });

  //     if (data.DocumentList?.length == 0) {
  //       // setTimeout(() => {
  //       setState((prevState) => {
  //         return {
  //           ...prevState,
  //           Status: data.Status,
  //           TaskConfermation: data.TaskConfermation,
  //           TaskName: data.Title,
  //           Description: data.Description,
  //           ProjectID: data.TaskProject,
  //           ReportUserID: data.Reporter,
  //           ReporterName: data.ReporterName,
  //           Priority: data.Priority,
  //           DueDate: data.DueDate,
  //           is_edit: true,
  //           edit_id: data.id,
  //           SubTaskList: data.SubTaskList,
  //           reporterList,
  //           DocumentList: [],
  //         };
  //       });
  //       setOpen(true);
  //       // }, 50);
  //     }
  //   }
  // };
  const UpdateTask = (singleTask, e) => {
    setState((prevState) => {
      return {
        ...prevState,
        singleTask,
        is_edit: true,
      };
    });
    // if (
    //   e.target.className !=
    //     "MuiBackdrop-root MuiBackdrop-invisible css-g3hgs1-MuiBackdrop-root-MuiModal-backdrop" &&
    //   e.target.className !=
    //     "MuiMenuItem-root MuiMenuItem-gutters MuiButtonBase-root progress css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root" &&
    //   e.target.className !=
    //     "MuiMenuItem-root MuiMenuItem-gutters MuiButtonBase-root completed css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root"
    // ) {
    //   setState((prevState) => {
    //     return {
    //       ...prevState,
    //       singleTask,
    //       is_edit: true,
    //     };
    //   });
    // }
  };
  // ------------END------------------

  // -----------Update Status&Priority-------------------
  const upadteStatusPriorit = async (pk, val, task_type) => {
    const Response = await fetch(taskUpadteStatusPriorityUrl + pk + "/", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        value: val,
        task_type: task_type,
        UserName: username,
      }),
    }).then((response) => response.json());
    if (Response.StatusCode === 6000) {
      setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
          is_load: true,
        };
      });
    }
  };
  // ------------END-----------------

  useEffect(() => {
    if (location.state && !location.state.ProjectID) {
      setOpen(true);
    }
  }, [location.state]);


  // Fetch Task List
  useEffect(() => {
    if (state.get_list === true) {
      (async () => {
        await api_fetch();
      })();
    }
  }, [state.get_list]);
  useEffect(() => {
    if (page == 1) {
      // ref.current.children[0].children[1].children[0].click();
    }
  }, [paginated_data]);

  console.log(state.TaskList);

  // ==============================pagination

  const [page, setPage] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  const count1 = state.TaskList.length;
  let paginated_data = state.TaskList.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", paginated_data);

  const ChangePage = (event, value) => {
    console.log("value=========", value);

    setCurrentPage(value + 1);
    setPage(value);
  };
  const handleChangeRowsPerPage = (event) => {
    console.log("handleChangeRowsPerPage", event.target.value);
    setItemsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Container>
      <Header>
        <LeftHeader>
          <Heading>{t("Tasks")}</Heading>

          <ListType>
            <Box
              sx={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                width: "fit-content",
                border: (theme) => `1px solid ${theme.palette.divider}`,
                borderRadius: 1,
                bgcolor: "background.paper",
                color: "text.secondary",
                "& svg": {
                  m: 1,
                },
                // "& hr": {
                //   mx: 0.5,
                // },
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onClick={() => setTasks("table")}
              >
                <TableRowsOutlinedIcon />
              </div>
              <Divider orientation="vertical" flexItem />
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
                onClick={() => setTasks("grid")}
              >
                <CalendarViewWeekIcon />
              </div>
            </Box>
          </ListType>
          {/* <FilterContainer>
            <FilterLabel>Filter:</FilterLabel>
          </FilterContainer> */}
          <FilterMainContainer>
            <FilterIcon onClick={() => setFilter(!showFilter)}>
              {t("Filter")}
            </FilterIcon>
            <ListFilterTask
              state={state}
              setState={setState}
              showFilter={showFilter}
              setFilter={setFilter}
            />
          </FilterMainContainer>
        </LeftHeader>
        <RightHeader>
          {/* <FormControlLabel
            control={<CustomeCheckbox defaultChecked />}
            label="Show Unconfirmed Task"
          /> */}
          <CheckBoxContainer>
            <Round class="round">
              <Input
                type="checkbox"
                id={"showUnconfirmedTask"}
                name={"showUnconfirmedTask"}
                checked={state.showUnconfirmedTask}
                // onChange={is_detail?onChange(e, index):onChange}
                onChange={(e) => {
                  handleCheckBox(e);
                }}
              />
              <CustomTick for={"showUnconfirmedTask"}></CustomTick>
              <Label className="rounded-check" for={"showUnconfirmedTask"}>
                {t("Show Only Unconfirmed Task")}
              </Label>
            </Round>
          </CheckBoxContainer>

          {showTasks == "table" ? (
            <CreateButton onClick={() => setOpen(true)}>
              {t("Create")}
            </CreateButton>
          ) : null}
        </RightHeader>
      </Header>
      {FilterType === 1 || state.ProjectID ? (
        <ProjectName>
          {state.TaskList.length
            ? state.TaskList[0].ProjectName
            : state.ProjectName
            ? state.ProjectName
            : "Project Name"}
        </ProjectName>
      ) : (
        ""
      )}

      {showTasks === "table" ? (
        <>
          <PaginationContainer>
            <StyledPagination
              component="div"
              page={page}
              onPageChange={ChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              count={count1}
              rowsPerPage={itemsPerPage}
            />
          </PaginationContainer>
          <TableContainer component={Paper}>
            {/* {" "}
          <div>Projects Per page</div> */}

            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <Table_TD>{t("Task Title")}</Table_TD>
                  <Table_TD>{t("Status")}</Table_TD>
                  {/* <TableCell>@Assignee</TableCell> */}
                  <Table_TD>{t("Created On")}</Table_TD>
                  <Table_TD>{t("Due Date")}</Table_TD>
                  <Table_TD>{t("Priority")}</Table_TD>
                  {FilterType === 1 || state.ProjectID ? (
                    <Table_TD>@{t("Assignee")}</Table_TD>
                  ) : null}
                  <Table_TD>@{t("Reporter")}</Table_TD>
                  <Table_TD>{t("Progress")}</Table_TD>
                  <Table_TD></Table_TD>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginated_data.map((i) => (
                  <TableRow
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <Table_row_TD component="th" scope="row">
                      <BadgeContainer>
                        {i.is_view === false ? <Badge_span></Badge_span> : null}
                        <TaskTitle onClick={(e) => UpdateTask(i, e)}>
                          <TitleName>{i.Title}</TitleName>
                          <TaskProject>{i.ProjectName}</TaskProject>
                        </TaskTitle>
                      </BadgeContainer>
                    </Table_row_TD>
                    <Table_row_TD>
                      <StatusSelect
                        handleListSelect={handleListSelect}
                        pk={i.id}
                        value={i.Status}
                      />
                    </Table_row_TD>
                    <Table_row_TD>
                      <ColoredDate className="grey">
                        {i.CreatedDate
                          ? date_monthName_format(i.CreatedDate)
                          : null}
                      </ColoredDate>
                    </Table_row_TD>
                    <Table_row_TD>
                      <ColoredDate className={get_color_due_date(i.DueDate)}>
                        {i.DueDate ? date_monthName_format(i.DueDate) : null}
                      </ColoredDate>
                    </Table_row_TD>
                    <Table_row_TD>
                      <PrioritySelect
                        handleListSelect={handleListSelect}
                        pk={i.id}
                        value={i.Priority}
                        singleTask={i}
                      />
                    </Table_row_TD>
                    {FilterType === 1 || state.ProjectID ? (
                      <Table_row_TD>
                        {i.AssigneeName ? (
                          <DetailBlock>
                            <Avatar_1 {...stringAvatar(i.AssigneeName)} />
                            <DetailLabel>{i.AssigneeName}</DetailLabel>
                          </DetailBlock>
                        ) : null}
                      </Table_row_TD>
                    ) : null}
                    <Table_row_TD>
                      {i.ReporterName ? (
                        <DetailBlock>
                          <Avatar_1 {...stringAvatar(i.ReporterName)} />
                          <DetailLabel>{i.ReporterName}</DetailLabel>
                        </DetailBlock>
                      ) : null}
                    </Table_row_TD>
                    <Table_row_TD>
                      <ProgressBarContainer>
                        <ProgressTextContainer>
                          <ProgressRate>
                            {Number(i.Progress).toFixed(2)}%
                          </ProgressRate>
                        </ProgressTextContainer>
                        <BorderLinearProgress
                          size="small"
                          variant="determinate"
                          value={i.Progress}
                        />
                      </ProgressBarContainer>
                    </Table_row_TD>
                    <Table_row_TD>
                      <DropDownMenu
                        DeleteTask={DeleteTask}
                        UpdateTask={UpdateTask}
                        singleTask={i}
                      />
                    </Table_row_TD>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      ) : (
        <ProjectTaskDrag
          open={open}
          UpdateTask={UpdateTask}
          setOpen={setOpen}
          state={state}
          setState={setState}
          upadteStatusPriorit={upadteStatusPriorit}
          ProjectTaskID={FilterValue ? FilterValue : ""}
          paginated_data={paginated_data}
        />
      )}
      <CreateTask
        open={open}
        setOpen={setOpen}
        state={state}
        setState={setState}
        ProjectTaskID={state.ProjectID ? state.ProjectID : ""}
      />
      {/* <PaginationContainer>
        <StyledPagination
          page={page}
          onPageChange={ChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          count={count1}
          rowsPerPage={itemsPerPage}
        />
      </PaginationContainer> */}
    </Container>
  );
};
function StatusSelect(props) {
  const [t] = useTranslation("common");
  const [work, setWork] = React.useState("");
  useEffect(() => {
    setWork(props.value);
  }, [props.value]);

  const handleChange = (event) => {
    setWork(event.target.value);
  };

  return (
    <StatusContainer work={work}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={(e) => {
              props.handleListSelect("Status", e, props.pk);
            }}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"todo"} className="progress">
              {t("To Do")}
            </MenuItem>
            <MenuItem value={"progress"} className="progress">
              {t("In Progress")}
            </MenuItem>

            <MenuItem value={"completed"} className="completed">
              {t("Done")}
            </MenuItem>

            {work === "confirming" ? (
              <MenuItem
                value={"confirming"}
                className="completed"
                style={{ display: "none" }}
              >
                {t("Confirming")}...
              </MenuItem>
            ) : null}
          </Select>
        </FormControl>
      </Box>
    </StatusContainer>
  );
}
function PrioritySelect(props) {
  const [t] = useTranslation("common");
  const [priorty, setPriorty] = React.useState("");
  useEffect(() => {
    setPriorty(props.value);
  }, [props.value]);

  return (
    <PriorityContainer priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            displayEmpty
            onChange={(e) => {
              props.handleListSelect("Priority", e, props.pk);
            }}
            inputProps={{ "aria-label": "Without label" }}
            disabled={props.singleTask.user_type != "member" ? false : true}
          >
            <MenuItem value={"low"} className="progress">
              {t("Low")}
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              {t("Medium")}
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              {t("High")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </PriorityContainer>
  );
}
function DropDownMenu(props) {
  const [t] = useTranslation("common");
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Tooltip title={t("Account settings")}>
        <IconButton
          onClick={handleClick}
          size="small"
          sx={{ ml: 2 }}
          aria-controls={open ? "account-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
        >
          <MoreVertIcon />
        </IconButton>
      </Tooltip>
      {props.singleTask.user_type != "member" ? (
        <Menu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          onClick={handleClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
              mt: 1.5,
              "& .MuiAvatar-root": {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
              },
              "&:before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          }}
          transformOrigin={{ horizontal: "right", vertical: "top" }}
          anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
        >
          {/* <MenuItem onClick={(e) => props.UpdateTask(props.singleTask, e)}>
            {t("Edit")}
          </MenuItem> */}
          <MenuItem
            onClick={() => {
              props.DeleteTask(props.singleTask.id);
            }}
          >
            {t("Delete")}
          </MenuItem>

          {/* {props.singleTask.user_type != "member" ? (
          <MenuItem
            onClick={() => {
              props.DeleteTask(props.singleTask.id);
            }}
          >
            {t("Delete")}
          </MenuItem>
        ) : null} */}
        </Menu>
      ) : null}
    </React.Fragment>
  );
}

const BadgeContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const Badge_span = styled.span`
  border-radius: 50%;
  width: 8px;
  height: 8px;
  background-color: red;
`;
const Avatar_1 = styled(Avatar)`
  height: 25px !important;
  width: 25px !important;
  font-size: 14px !important;
  margin-right: 10px;
`;
const Table_TD = styled(TableCell)`
  padding: 10px 16px !important;
`;
const Table_row_TD = styled(TableCell)`
  padding: 5px 16px !important;
`;
const TaskTitle = styled.div`
  display: flex;
  flex-direction: column;
  cursor: pointer;
`;
const TitleName = styled.div`
  white-space: nowrap;
  width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
`;
const TaskProject = styled.div`
  font-size: 10px;
  color: #011565;
`;

const FilterMainContainer = styled.div`
  position: relative;
`;

const FilterIcon = styled(Button)`
  background: #12368c;
  color: #fff;
  cursor: pointer;
  color: black;
  border-radius: 2px;
  padding: 5px 20px;
  text-transform: capitalize;
  &:hover {
    background: #5073c7;
  }
`;
const PaginationContainer = styled.div`
  width: 100%;

  /* position: absolute;
  bottom: 15px;
  left: 0;
  right: 0; */
`;
const StyledPagination = styled(TablePagination)`
  width: 100%;
  .MuiPagination-ul {
    justify-content: center;
  }
`;
const StatusContainer = styled.div`
  div[role="button"] {
    background: #eeeeee;
    padding: 2px 10px;
    font-size: 12px;

    ${({ work }) =>
      work === "todo" && `background: #e6e6e6; color:#00024A; border:0;`}
    ${({ work }) =>
      work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
    ${({ work }) =>
      work === "confirming" && `background: #f5d6b5; color:#032406;`}
    ${({ work }) =>
      work === "completed" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
  }

  span {
    margin: 0;
  }
  fieldset {
    border: 0;
  }
`;
const PriorityContainer = styled.div`
  div[role="button"] {
    background: #eeeeee;
    padding: 2px 10px;
    font-size: 12px;

    ${({ priorty }) =>
      priorty === "low" && `background: #C2FBC3; color:#032406;`}
    min-width: min-content;
    ${({ priorty }) =>
      priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
    ${({ priorty }) =>
      priorty === "high" && `background: #eb505099; color:#00024A; border:0;`}
  }
  span {
    margin: 0;
  }
  fieldset {
    border: 0;
  }
`;
const ColoredDate = styled.p`
  &.red {
    color: #f10000;
  }
  &.blue {
    color: #12368c;
  }
  &.grey {
    color: #3d3d3d;
  }
`;
const SubSelect = styled.div`
  position: absolute;
  top: 0;
  left: 300px;
`;
const UnassignedText = styled.div`
  color: #848484;
  font: italic normal normal 14px/17px Poppins;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const Container = styled.div`
  .borderless1 {
    border: none !important;
  }
`;
const LeftHeader = styled.div`
  display: flex;
  align-items: center;
`;
const Heading = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-right: 10px;
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #edeff3;
  padding: 0 0 0 8px;
  background: #fff;
  border-radius: 3px;
`;
const StyledSelect = styled.div`
  min-width: 120px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
const FilterLabel = styled.div`
  font-size: 16px;
`;
const RightHeader = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
`;
const CheckBoxContainer = styled.div`
  /* margin-bottom: 10px; */
  font-size: 14px;
  /* &label {
  } */
`;

const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;
const CreateButton = styled(Button)`
  && {
    background: #12368c;
    color: #fff;
    height: 31px;
    font-size: 12px;
    width: 88px;
    border-radius: 2px;
    padding: 5px 20px;
    text-transform: capitalize;
    &:hover {
      background: #5073c7;
    }
  }
`;
const ListType = styled.div`
  margin-right: 10px;
`;
const ProjectName = styled.p`
  font-size: 16px;
  color: #5e5e5e;
  font-weight: bold;
  margin-bottom: 10px;
`;

const DetailBlock = styled.div`
  /* margin-bottom: 10px; */
  display: flex;
  align-items: center;
`;

const ProgressBarContainer = styled.div`
  width: 100%;
  margin-right: 5px;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 3px;
    background: #c6c6c6;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #8c1212;
  }
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  width: 100%;
`;

const ProgressRate = styled.p`
  color: #757575;
`;

const DetailLabel = styled.p``;
// ===============Rounded Check Box Style======================
const Round = styled.div`
  position: relative;
  display: flex;
  &label {
    border: 1px solid black;
  }
`;
const Input = styled.input`
  width: 18px;
  height: 18px;
  visibility: hidden;

  &:checked + label {
    background-color: #18368c;
    border-color: #18368c;
  }
  &:checked + label:after {
    opacity: 1;
    left: 1px;

    top: 2px;
    animation: checkbox-check 250ms cubic-bezier(0.4, 0, 0.23, 1) forwards;
  }

  @keyframes checkbox-check {
    0% {
      height: 0px;
      border: none;
    }

    50% {
      height: 6px;
    }
    100% {
      height: 6px;
      width: 12px;
    }
  }
`;
const CustomTick = styled.label`
  background-color: #fff;
  border: 1px solid;
  border-radius: 50%;
  cursor: pointer;
  left: 0;
  position: absolute;
  top: 3px;
  width: 18px;
  height: 18px;

  &:after {
    border: 2px solid #fff;
    border-top: none;
    border-right: none;
    content: "";
    opacity: 0;
    position: absolute;
    visibility: visible;
    left: 2px;
    top: 4px;
    transform: rotate(-45deg);
  }
`;
const Label = styled.label`
  cursor: pointer;
  display: flex;
  align-items: center;
  margin-left: 5px;
  font-weight: normal;
  text-transform: capitalize;
`;
export default Tasks;
