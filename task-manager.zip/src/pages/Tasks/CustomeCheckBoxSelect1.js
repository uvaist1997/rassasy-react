import React, { useEffect, useState } from "react";
import Checkbox from "@material-ui/core/Checkbox";
import InputLabel from "@material-ui/core/InputLabel";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

import { MenuProps, useStyles, options } from "./utils";
import styled from "styled-components/macro";

function CustomeCheckBoxSelect1() {
  const classes = useStyles();
  const [selected, setSelected] = useState([]);
  const [showSubSelect, setSubSelect] = useState(false);
  const isAllSelected =
    options.length > 0 && selected.length === options.length;

  const handleChange = (event) => {
    const value = event.target.value;
    if (value[value.length - 1] === "all") {
      setSelected(selected.length === options.length ? [] : options);
      return;
    }
    setSelected(value);
  };
  //   ==========================
  const obj = {
    Status: {
      ToDo: "",
      InProgress: "",
      Done: "",
    },
    Priority: {
      High: ["Orange", "Apple", "Banana"],
      Low: ["Pretzels", "Burger", "Noodles"],
    },
  };
  useEffect(() => {
    console.log(showSubSelect, "PPPPPPPPPOOOOOOOOOOIIIIIIIIII");
    if (showSubSelect) {
      initAccordeon(obj); // <--------------------------- Call initialization
    } else {
    }
  }, [showSubSelect]);

  function accordeonAddEvents() {
    Array.from(document.getElementsByClassName("accordeon-header")).forEach(
      function (header) {
        if (header.getAttribute("listener") !== "true") {
          header.addEventListener("click", function () {
            this.parentNode
              .getElementsByClassName("accordeon-body")[0]
              .classList.toggle("hide");
          });
          header.setAttribute("listener", "true");
        }
      }
    );

    Array.from(document.getElementsByClassName("button-group")).forEach(
      function (but) {
        if (but.getAttribute("listener") !== "true") {
          but.addEventListener("click", function () {
            if (this.getAttribute("depth") === "-1") {
              let header = this;
              while (
                (header = header.parentElement) &&
                header.className !== "accordeon"
              );
              header.getElementsByClassName("accordeon-header")[0].innerHTML =
                this.innerHTML;
              return;
            }
            const groups = Array.from(
              this.parentNode.getElementsByClassName("accordeon-group")
            );
            groups.forEach((g) => {
              if (
                g.getAttribute("uuid") === this.getAttribute("uuid") &&
                g.getAttribute("depth") === this.getAttribute("depth")
              ) {
                g.classList.toggle("hide");
              }
            });
          });
          but.setAttribute("listener", "true");
        }
      }
    );
  }

  function initAccordeon(data) {
    console.log("DDDD");
    let accordeons = Array.from(
      document.getElementsByClassName("accordeon-body")
    );
    accordeons.forEach((acc) => {
      acc.innerHTML = "";
      const route = (subObj, keyIndex = 0, parent = acc, depth = 0) => {
        const keys = Object.keys(subObj);
        if (
          typeof subObj === "object" &&
          !Array.isArray(subObj) &&
          keys.length > 0
        ) {
          while (keyIndex < keys.length) {
            var but = document.createElement("button");
            but.className = "button-group";
            but.setAttribute("uuid", keyIndex);
            but.setAttribute("depth", depth);
            but.innerHTML = keys[keyIndex];
            var group = document.createElement("div");
            group.className = "accordeon-group hide";
            group.setAttribute("uuid", keyIndex);
            group.setAttribute("depth", depth);
            route(subObj[keys[keyIndex]], 0, group, depth + 1);
            keyIndex++;
            parent.append(but);
            parent.append(group);
          }
        } else {
          if (!Array.isArray(subObj)) subObj = [subObj];
          subObj.forEach((e, i) => {
            if (typeof e === "object") {
              route(e, 0, parent, depth);
            } else {
              var but = document.createElement("button");
              but.className = "button-group";
              but.setAttribute("uuid", i);
              but.setAttribute("depth", "-1");
              but.innerHTML = e;
              parent.append(but);
            }
          });
        }
      };
      route(data);
    });
    accordeonAddEvents();
  }

  return (
    <Accordeon
      onClick={() => {
        setSubSelect(!showSubSelect);
      }}
      className="accordeon"
    >
      <AccordeonHeader className="accordeon-header">
        Select something
      </AccordeonHeader>
      <AccordeonBody className="accordeon-body hide"></AccordeonBody>
    </Accordeon>
  );
}

const Accordeon = styled.div`
  /* width: 460px; */
  /* height: auto;
  min-height: 340px; */
  font-size: 20px;
  cursor: pointer;
  user-select: none;
  -moz-user-select: none;
  -khtml-user-select: none;
  -webkit-user-select: none;
  -o-user-select: none;
  display: block;
  position: relative;
  z-index: 10;
`;

const AccordeonHeader = styled.span`
  display: inline-block;
  /* width: 450px; */
  font-size: 15px;
  background-color: white;
  padding-left: 10px;
  color: black;
`;
const AccordeonBody = styled.div`
  display: block;
  position: absolute;
  .hide {
    display: none;
  }
  .button-group {
    display: block;
    cursor: pointer;
    width: 188px;
    text-align: left;
    font-size: 13px;
    font-weight: bold;
  }

  .accordeon-group {
    padding-left: 20px;
  }

  .accordeon-group .button-group {
    width: 100%;
  }

  .button-group[depth="-1"] {
    color: green;
  }
`;

export default CustomeCheckBoxSelect1;
