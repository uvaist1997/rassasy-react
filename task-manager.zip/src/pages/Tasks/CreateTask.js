import React, { useContext, useEffect, useRef } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import {
  Avatar,
  Autocomplete,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  MenuItem,
  Select,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import {
  date_monthName_format,
  date_time_diff_in_mint,
  debugBase64,
  download,
  getCookie,
  get_date,
  get_index,
  get_Userindex,
  get_username,
  stringAvatar,
  string_to_datetime,
  toDataURL,
  today_datetime,
  URLtoFile,
} from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import EditIcon from "@mui/icons-material/Edit";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import NativeSelect from "@mui/material/NativeSelect";
import { useSelector } from "react-redux";
import { taskCreateUrl, taskEditUrl } from "../../api/TasksAPI";
import Swal from "sweetalert2";
import { ProjectComments } from "../../functions/API_Call_functions";
import { projectListUrl } from "../../api/ProjectsAPI";
import RoundedCheckbox from "./RoundedCheckbox";
import { ACCOUNTS_API_URL, BASE_URL, MEDIA_URL } from "../../settings";
import { useTranslation } from "react-i18next";
import { DataContext } from "../../components/Context1";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 850,
  bgcolor: "background.paper",

  boxShadow: 24,
  p: 2,
};
const access = getCookie("VBID");

export default function CreateTask(props) {
  const [t] = useTranslation("common");
  let open = props.open;
  let setOpen = props.setOpen;
  const [commentID, setcommentID] = React.useState(null);
  const commentRef = useRef(null);
  const [showActivies, setActivites] = React.useState(1);

  const { user_id } = useSelector((state) => state.user);
  const { username, photo } = useSelector((state) => state.user);
  const [showReporterSelect, setReporterSelect] = React.useState(false);
  const [showAssigneeSelect, setAssigneeSelect] = React.useState(false);
  const [showProjectSelect, setProjectSelect] = React.useState(false);
  const [rerender, setRerender] = React.useState(false);
  const [showSubTask, setSubTask] = React.useState(false);
  const [updatedSubTask, setUpdateSubTask] = React.useState(null);

  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;

  const [selectedDate, handleDateChange] = React.useState(new Date());
  let due_date = date_monthName_format(selectedDate);
  const handleClose = () => setOpen(false);
  const [state, setState] = React.useState({
    user_id: user_id,
    Status: "todo",
    TaskConfermation: false,
    TaskName: "",
    Description: "",
    ProjectList: [],
    ProjectID: props.ProjectTaskID ? props.ProjectTaskID : "",
    ProjectName: "",
    reporterList: [],
    assignerList: [],
    ReportUserID: "",
    ReporterName: "",
    DocumentList: [],
    Priority: "medium",
    DueDate: get_date(selectedDate),
    Progress: 0,
    CreatedBy: username,
    SubTaskDescription: "",
    SubTaskList: [],
    // For Comment
    CommentList: [],
    HistoryList: [],
    comment: "",
    EditDescription: "",
    AssignerID: "",
    AssigneeName: "",
    form_errors: {
      TaskName: "",
    },
    MemberType: "",
    CreatedDate:"",
  });
  const clearState = () => {
    setcommentID(null);
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [],
        Status: "progress",
        TaskConfermation: false,
        TaskName: "",
        Description: "",
        ProjectID: props.ProjectTaskID ? props.ProjectTaskID : "",
        ReportUserID: "",
        ReporterName: "",
        Priority: "medium",
        DueDate: get_date(selectedDate),
        Progress: 0,
        CreatedBy: username,
        SubTaskDescription: "",
        SubTaskList: [],
        // For Comment
        CommentList: [],
        HistoryList: [],
        comment: "",
        EditDescription: "",
        AssignerID: "",
        AssigneeName: "",
        form_errors: {
          TaskName: "",
        },
        MemberType: "",
        CreatedDate:"",
      };
    });
    // setOpen(false);
  };
  const hiddenFileInput = React.useRef(null);
  let dateRef = React.useRef(null);

  // ------------------For Attchment-------------------------
  const handleClickImg = (event) => {
    hiddenFileInput.current.click();
  };

  function readFile(file, file_type) {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      const result = event.target.result;
      // Check if the file is an image.
      if (file.type && !file.type.startsWith("image/")) {
        console.log("File is not an image.", file.type, file);
        // e.g This will dowunload a file
        download(result);
      } else {
        // e.g This will open an image in a new window
        debugBase64(result);
      }
    });
    reader.readAsDataURL(file);
  }
  // ---------------------END------------------------

  const handleDateChangeRef = () => {
    dateRef.current.click();
  };

  React.useEffect(() => {
    if (props.ProjectTaskID) {
      setProjectSelect(true);
    }
  }, []);

  React.useEffect(() => {
    setState({
      ...state,
      DueDate: get_date(selectedDate),
    });
  }, [selectedDate]);

  // ----------------For Comment--------------------------------
  let Activities = [];
  if (showActivies === 3) {
    Activities = state.HistoryList;
  } else if (showActivies === 2) {
    Activities = state.CommentList;
  } else {
    Activities = state.CommentList.concat(state.HistoryList);
  }
  Activities.sort(function (a, b) {
    let aDate = new Date(a.CreatedDate);
    let bDate = new Date(b.CreatedDate);

    if (aDate > bDate) return -1;
    if (aDate < bDate) return 1;
    return 0;
  });
  // --------------------ENd---------------------

  // ===================================================
  const [checked, setChecked] = React.useState(true);
  const handleCheckBox = (event) => {
    setState((prevState) => {
      return {
        ...prevState,
        TaskConfermation: event.target.checked,
      };
    });
  };

  const handleDetailCheckBox = (event, index) => {
    let SubTaskList = [...state.SubTaskList];
    SubTaskList[index]["is_completed"] = event.target.checked;
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList,
      };
    });
  };

  const handleChange = (n, e) => {
    if (n == "TaskName") {
      let form_errors = { ...state.form_errors };
      form_errors["TaskName"] = "";
      setState((prevState) => {
        return {
          ...prevState,
          [n]: e.target.value,
          form_errors,
        };
      });
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          [n]: e.target.value,
        };
      });
    }
  };

  const handleSelectChange = (n, e) => {
    if (e) {
      if (n == "ReportUserID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.MemberUserID,
            ReporterName: e.username,
          };
        });
        setReporterSelect(false);
      } else if (n == "AssignerID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.MemberUserID,
            AssigneeName: e.username,
          };
        });
        setAssigneeSelect(false);
      } else if (n == "ProjectID") {
        let TaskConfermation = state.TaskConfermation;
        let MemberType = state.MemberType;
        if (e.id) {
          let project = state.ProjectList.filter((i) => i.id === e.id)[0];
          TaskConfermation = project.TaskConfermation;
          MemberType = project.MemberType;
        }
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.id,
            ProjectName: e.ProjectName,
            TaskConfermation,
            MemberType,
          };
        });
        setAssigneeSelect(false);
      } else {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.target.value,
          };
        });
      }
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          [n]: "",
        };
      });
    }
  };

  const AddSubTask = () => {
    let sub_task = {
      Description: state.SubTaskDescription,
      is_completed: false,
    };
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: [...state.SubTaskList, sub_task],
        SubTaskDescription: "",
      };
    });
    setSubTask(false);
  };

  const addProgress = () => {
    if (state.Status === "completed") {
      let completedTask = state.SubTaskList.filter(
        (i) => (i.is_completed = true)
      );

      setState((prevState) => {
        return {
          ...prevState,
          Progress: 100,
          // SubTaskList: completedTask,
        };
      });
    } else if (state.SubTaskList.length > 0) {
      let completedTask = state.SubTaskList.filter(
        (i) => i.is_completed == true
      );
      let totalTask = state.SubTaskList.length;
      let Progress = (completedTask.length / totalTask) * 100;
      setState((prevState) => {
        return {
          ...prevState,
          Progress: Progress,
        };
      });
    }
  };

  // --------------For Attachment Image List--------------
  const handleChangeImg = (event) => {
    const fileUploaded = event.target.files[0];

    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [...state.DocumentList, ...event.target.files],
      };
    });
  };

  const handleRemoveImg = (file) => {
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: state.DocumentList.filter((i) => i !== file),
      };
    });
  };

  // ------------------END---------------------
  const removeCheckBox = (value) => {
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: state.SubTaskList.filter((i) => i !== value),
      };
    });
  };

  const updateSubTask = (value, index, type) => {
    if (type === "view") {
      let descreption = value.Description;
      setUpdateSubTask(index);
      setState((prevState) => {
        return {
          ...prevState,
          SubTaskDescription: descreption,
        };
      });
      setSubTask(true);
    } else {
      let SubTaskList = [...state.SubTaskList];
      SubTaskList[updatedSubTask]["Description"] = state.SubTaskDescription;
      setState((prevState) => {
        return {
          ...prevState,
          SubTaskList,
          SubTaskDescription: "",
        };
      });
      setUpdateSubTask(null);
      setSubTask(false);
    }
  };

  const onSearchUsers = async (val, e) => {
    if (val) {
      const userListResponse = await fetch(
        `${ACCOUNTS_API_URL}api/v1/users/get-users/`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            username: val,
          }),
        }
      ).then((response) => response.json());
      if (userListResponse.StatusCode === 6000) {
        setState((prevState) => {
          return {
            ...prevState,
            reporterList: userListResponse.data,
            assignerList: userListResponse.data,
          };
        });
      }
    }
  };

  // -------------------_SAVE TASK---------------------------
  const SaveTask = async () => {
    let Url = taskCreateUrl;
    let title = "Task Created Successfully";
    if (state.is_edit) {
      Url = taskEditUrl + state.edit_id + "/";
      title = "Task Updated Successfully";
    }
    let is_valid = handleValidation();
    if (is_valid == true) {
      const formData = new FormData();
      formData.append("CreatedBy", state.CreatedBy);
      formData.append("TaskName", state.TaskName);
      formData.append("Description", state.Description);
      formData.append("Status", state.Status);
      formData.append("TaskConfermation", state.TaskConfermation);
      formData.append("ProjectID", state.ProjectID);
      formData.append("ReportUserID", state.ReportUserID);
      formData.append("ReporterName", state.ReporterName);
      formData.append("AssignerID", state.AssignerID);
      formData.append("AssigneeName", state.AssigneeName);
      formData.append("Priority", state.Priority);
      formData.append("DueDate", state.DueDate);
      let DocumentList = state.DocumentList;
      DocumentList.map((i, index) => {
        let name = "image" + String(index);
        formData.append(name, i);
      });
      formData.append("DocumentList", state.DocumentList);
      // formData.append("SubTaskList", state.SubTaskList);
      formData.append("SubTaskList", JSON.stringify(state.SubTaskList));

      const Response = await fetch(Url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${access}`,
          // "accept": "application/json"
        },
        body: formData,
      }).then((response) => response.json());
      if (Response.StatusCode === 6000) {
        Swal.fire({
          title: title,
          showClass: {
            popup: "animate__animated animate__fadeInDown",
          },
          hideClass: {
            popup: "animate__animated animate__fadeOutUp",
          },
        });
        props.setState((prevState) => {
          return {
            ...prevState,
            get_list: true,
          };
        });
        setOpen(false);
        clearState();
      } else {
        Swal.fire({
          title: "Task Created Failed",
          showClass: {
            popup: "animate__animated animate__fadeInDown",
          },
          hideClass: {
            popup: "animate__animated animate__fadeOutUp",
          },
        });
      }
    }
  };
  // --------------------END-------------------

  //------------- For Comment--------
  const AddCommand = async (e, type) => {
    if (e.key === "Enter" || type === "delete") {
      let Description = e.target.value;
      let data = await ProjectComments(
        null,
        state.edit_id,
        Description,
        type,
        access,
        commentID
      );
      setState((prevState) => {
        return {
          ...prevState,
          CommentList: data,
          comment: "",
          EditDescription: "",
        };
      });
      setcommentID(null);
    } else {
      let comment = "";
      let EditDescription = "";
      if (type === "create") {
        comment = e.target.value;
      }
      if (type === "edit") {
        EditDescription = e.target.value;
      }
      setState((prevState) => {
        return {
          ...prevState,
          comment,
          EditDescription,
        };
      });
    }
  };

  const changeComment = (e, id, description, name) => {
    setcommentID(id);
    if (name === "edit") {
      setState((prevState) => {
        return {
          ...prevState,
          EditDescription: description,
        };
      });
      // setcommentID(id);
    } else if (name === "delete") {
      AddCommand(e, "delete");
    }
  };

  const handleEditClick = () => {
    commentRef.current.focus();
  };

  const handleValidation = () => {
    let form_errors = {};
    let formIsValid = true;
    //TaskName
    if (!state.TaskName) {
      formIsValid = false;
      form_errors["TaskName"] = "Cannot be empty";
    }

    setState((prevState) => {
      return {
        ...prevState,
        form_errors,
      };
    });

    return formIsValid;
  };

  useEffect(() => {
    if (commentID) {
      handleEditClick();
    }
  }, [commentID]);

  useEffect(() => {
    addProgress();
  }, [state.Status, state.SubTaskList]);

  // ----------------END-----------------

  // Give Single Data
  useEffect(() => {
    if (props.state.is_edit === true && props.state.singleTask) {
      (async () => {
        let data = props.state.singleTask;
        let CreatedBy = await get_username(data.CreatedUserID);
        let dateObj = new Date(data.DueDate);
        handleDateChange(dateObj);
        if (data) {
          let reporterList = [
            {
              username: data.ReporterName,
              UserID: data.Reporter,
            },
          ];
          let assignerList = [
            {
              username: data.AssigneeName,
              UserID: data.Assignee,
            },
          ];
          let fileArr = [];
          data.DocumentList.map(async (item, index) => {
            // *** Calling both function ***
            let url = MEDIA_URL + item.DocFile;
            console.log(url, "******************");
            let file = await toDataURL(url).then((dataUrl) => {
              var fileData = URLtoFile(dataUrl, item.name);
              return fileData;
            });
            fileArr.push(file);

            if (index === data.DocumentList.length - 1) {
              setState((prevState) => {
                return {
                  ...prevState,
                  Status: data.Status,
                  TaskConfermation: data.TaskConfermation,
                  TaskName: data.Title,
                  Description: data.Description,
                  ProjectID: data.TaskProject,
                  ProjectName: data.ProjectName,
                  ReportUserID: data.Reporter,
                  AssignerID: data.Assignee,
                  AssigneeName: data.AssigneeName,
                  ReporterName: data.ReporterName,
                  Priority: data.Priority,
                  DueDate: data.DueDate,
                  CreatedDate: data.CreatedDate,
                  is_edit: true,
                  edit_id: data.id,
                  SubTaskList: data.SubTaskList,
                  reporterList,
                  assignerList,
                  DocumentList: fileArr,
                };
              });
              setOpen(true);
              setProjectSelect(false);
              setAssigneeSelect(false);
            }
          });
          
          if (data.DocumentList.length == 0) {
            // setTimeout(() => {
            setState((prevState) => {
              return {
                ...prevState,
                Status: data.Status,
                TaskConfermation: data.TaskConfermation,
                TaskName: data.Title,
                Description: data.Description,
                ProjectID: data.TaskProject,
                ReportUserID: data.Reporter,
                ReporterName: data.ReporterName,
                Priority: data.Priority,
                DueDate: data.DueDate,
                CreatedDate: data.CreatedDate,
                is_edit: true,
                edit_id: data.id,
                SubTaskList: data.SubTaskList,
                reporterList,
                DocumentList: [],
                ProjectName: data.ProjectName,
              };
            });
            setOpen(true);
            // }, 50);
          }
        }
        if (data.is_view === false) {
          console.log("-------------------------------------->");
          console.log(data.is_view);
          const notificationResponse = await fetch(
            `${BASE_URL}general/view-notification`,
            {
              method: "POST",
              headers: {
                "content-type": "application/json",
                Authorization: `Bearer ${access}`,
                accept: "application/json",
              },
              body: JSON.stringify({
                UserID: user_id,
                TaskID: data.id,
                name: "task",
              }),
            }
          ).then((response) => response.json());
          if (notificationResponse.StatusCode === 6000) {
            data.is_view = true;
            setNotificationCount((prevState) => {
              return {
                ...prevState,
                task_notify: notificationCount.task_notify - 1,
              };
            });
          }
        }
        props.setState((prevState) => {
          return {
            ...prevState,
            is_edit: false,
          };
        });
        setOpen(true);
      })();
    }
  });

  // --------Fetch Projects--------------
  useEffect(() => {
    (async () => {
      const projectListResponse = await fetch(projectListUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${access}`,
          accept: "application/json",
        },
        body: JSON.stringify({
          ProjectFilter: [],
          FilterStartDate: null,
          FilterEndDate: null,
        }),
      }).then((response) => response.json());
      if (projectListResponse.StatusCode === 6000) {
        let assignerList = state.assignerList;
        if (props.ProjectTaskID) {
          assignerList = projectListResponse.data.filter(
            (i) => i.id === props.ProjectTaskID
          )[0].MemberList;
        }
        setState((prevState) => {
          return {
            ...prevState,
            ProjectList: projectListResponse.data,
            assignerList,
            reporterList: assignerList,
          };
        });
      }
    })();
  }, []);
  // ====================================================
  console.log(state,"state");
  const CloseModal = async () => {
    await clearState();
    await props.setOpen(false);
  };

  useEffect(() => {
    if (showSubTask == true) {
      handleClick();
    }
  }, [showSubTask == true]);

  const cancelSubTask = async () => {
    setSubTask(false);
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskDescription: "",
      };
    });
  };

  const ref = useRef(null);
  const handleClick = () => {
    console.log(ref.current.focus());
    ref.current.focus();
  };

  let CreatedDate = new Date(state.CreatedDate);
  let CreadedON = date_monthName_format(CreatedDate);
  let user_member_type = "admin";
  if (state.ProjectID && state.ProjectList.length) {
    let MemberList = state.ProjectList.filter(
      (i) => i.id === state.ProjectID
    )[0].MemberList;
    user_member_type = MemberList.filter((m) => m.MemberUserID === user_id)[0]
      .MemberType;
  }

  return (
    <Container>
      <CreateModal
        style={{ border: "none " }}
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <CustomTextField1
              fullWidth
              multiline
              focused
              id="standard-basic"
              label={t("Task")}
              variant="standard"
              value={state.TaskName}
              onChange={(e) => handleChange("TaskName", e)}
              error={state.form_errors.TaskName}
              helperText={state.form_errors.TaskName}
              disabled={
                user_member_type === "owner" ||
                user_member_type === "admin" ||
                state.is_update === false
                  ? false
                  : true
              }
            />
            <StyledCloseIcon
              className="close-modal"
              onClick={() => CloseModal()}
            />
            <BlockContainer>
              <Block className="left">
                <InputLabel
                  style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                >
                  {t("Description")}
                </InputLabel>
                <StyledTextField
                  fullWidth
                  multiline
                  id="outlined-basic"
                  variant="outlined"
                  value={state.Description}
                  onChange={(e) => handleChange("Description", e)}
                  disabled={
                    user_member_type === "owner" ||
                    user_member_type === "admin" ||
                    state.is_update === false
                      ? false
                      : true
                  }
                />

                <ButtonContainer>
                  {/* <ButtonGroup>
                    <StyledButton
                      onClick={() => {
                        SaveTask();
                      }}
                      className="create m"
                    >
                      Save
                    </StyledButton>
                    <StyledButton className="cancel">Cancel</StyledButton>
                  </ButtonGroup> */}
                  {user_member_type !== "member" ? (
                    <ButtonGroup>
                      <StyledButton className="attach" onClick={handleClickImg}>
                        <AttachFileIcon />
                        {t("Attach")}
                      </StyledButton>
                      <input
                        type="file"
                        ref={hiddenFileInput}
                        onChange={handleChangeImg}
                        style={{ display: "none" }}
                        multiple
                      />
                    </ButtonGroup>
                  ) : (
                    false
                  )}
                </ButtonContainer>

                {user_member_type !== "member"
                  ? state.DocumentList.map((i) => (
                      <AttachmentListContainer>
                        <AttachmentLeftTitle>{i.name}</AttachmentLeftTitle>
                        <AttachmentRightTitle>
                          <p
                            onClick={() => {
                              readFile(i, "view");
                            }}
                          >
                            {t("View")}
                          </p>
                          <p
                            onClick={() => {
                              readFile(i, "download");
                            }}
                          >
                            {t("Download")}
                          </p>
                          <p
                            onClick={() => {
                              handleRemoveImg(i);
                            }}
                          >
                            {t("Remove")}
                          </p>
                        </AttachmentRightTitle>
                      </AttachmentListContainer>
                    ))
                  : null}

                {/* {state.DocumentList.map((i) => (
                    <AttachmentListContainer>
                      <AttachmentLeftTitle>{i.name}</AttachmentLeftTitle>
                      <AttachmentRightTitle>
                        <p
                          onClick={() => {
                            readFile(i, "view");
                          }}
                        >
                          {t("View")}
                        </p>
                        <p
                          onClick={() => {
                            readFile(i, "download");
                          }}
                        >
                          {t("Download")}
                        </p>
                        <p
                          onClick={() => {
                            handleRemoveImg(i);
                          }}
                        >
                          {t("Remove")}
                        </p>
                      </AttachmentRightTitle>
                    </AttachmentListContainer>
                  ))} */}

                <AddSubTaskContainer
                  onClick={() => {
                    setSubTask(!showSubTask);
                  }}
                >
                  <AddCircleOutlineIcon />
                  {t("Add Subtask")}
                </AddSubTaskContainer>
                {/* ===========SubTask Modal======== */}
                {showSubTask ? (
                  <SubTaskBlock>
                    <InputLabel style={{ fontSize: 12, marginTop: 6 }}>
                      {/* {t("Description")} */}
                    </InputLabel>
                    <StyledTextField
                      ref={ref}
                      autoFocus={showSubTask}
                      fullWidth
                      multiline
                      id="Description"
                      name="Description"
                      variant="outlined"
                      value={state.SubTaskDescription}
                      onChange={(e) => handleChange("SubTaskDescription", e)}
                    />
                    <ButtonContainer>
                      <ButtonGroup>
                        <StyledButton
                          onClick={() => {
                            updatedSubTask || updatedSubTask === 0
                              ? updateSubTask("", updatedSubTask, "update")
                              : AddSubTask();
                          }}
                          className="create m"
                        >
                          {updatedSubTask || updatedSubTask === 0
                            ? t("Update")
                            : t("Save")}
                        </StyledButton>
                        <StyledButton
                          className="cancel"
                          onClick={() => {
                            // setSubTask(false);
                            cancelSubTask();
                          }}
                        >
                          {t("Cancel")}
                        </StyledButton>
                      </ButtonGroup>
                    </ButtonContainer>
                  </SubTaskBlock>
                ) : null}

                {/* ======End============== */}
                {state.SubTaskList.map((i, index) => (
                  <CheckboxContainer>
                    <RoundedCheckbox
                      checked={i.is_completed}
                      onChange={(e) => handleDetailCheckBox(e, index)}
                      label={i.Description}
                      is_detail={true}
                      index={index}
                      name={index}
                    />
                    {/* <FormControlLabel
                      control={
                        <SubTaskCheckbox
                          checked={i.is_completed}
                          onChange={(e) => {
                            handleDetailCheckBox(e, index);
                          }}
                        />
                      }
                      label={i.Description}
                    /> */}
                    <SubTaskEditIcon
                      className="close-modal"
                      onClick={() => updateSubTask(i, index, "view")}
                    />
                    <SubTaskCloseIcon
                      className="close-modal"
                      onClick={() => removeCheckBox(i)}
                    />
                  </CheckboxContainer>
                ))}
                {state.is_edit
                  ? [
                      <InputLabel
                        style={{
                          fontSize: 12,
                          marginTop: 10,
                          marginBottom: 5,
                        }}
                      >
                        {t("Activities")}
                      </InputLabel>,
                      <ButtonContainer>
                        <ButtonGroup>
                          <InputLabel
                            style={{
                              fontSize: 12,
                              display: "inline",
                              marginRight: 10,
                            }}
                          >
                            {t("Show")}:
                          </InputLabel>
                          <StyledButton
                            className={
                              showActivies === 1 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(1)}
                          >
                            {t("All")}
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 2 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(2)}
                          >
                            {t("Comments")}
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 3 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(3)}
                          >
                            {t("History")}
                          </StyledButton>
                        </ButtonGroup>
                        <ButtonGroup>
                          <StyledButton className="cancel">
                            {t("Newest First")}
                            <CompareArrowsIcon className="arrow" />
                          </StyledButton>
                        </ButtonGroup>
                      </ButtonContainer>,
                      <CommentListContainer>
                        {showActivies != 3 ? (
                          <AvatarContainer>
                            <Avatar
                              style={{
                                height: "25px",
                                width: "25px",
                                marginRight: "10px",
                                fontSize: "13px",
                              }}
                              {...stringAvatar("Savad Farooque")}
                            />
                            <StyledInput
                              onKeyPress={(e) => AddCommand(e, "create")}
                              onChange={(e) => AddCommand(e, "create")}
                              value={state.comment}
                            />
                          </AvatarContainer>
                        ) : null}

                        {Activities
                          ? Activities.map((i) => (
                              <AvatarContainer>
                                <Avatar
                                  style={{
                                    height: "25px",
                                    width: "25px",
                                    marginRight: "10px",
                                    fontSize: "13px",
                                  }}
                                  {...stringAvatar("Savad Farooque")}
                                />
                                <CommentContainer>
                                  <UserDetailsContainer>
                                    <NameText>{i.name ? i.name : ""}</NameText>
                                    <TimeText>
                                      {date_time_diff_in_mint(
                                        string_to_datetime(i.CreatedDate),
                                        today_datetime()
                                      )}
                                    </TimeText>
                                    <StatusText>
                                      {i.Action === "A" ? "created" : "updated"}
                                    </StatusText>
                                  </UserDetailsContainer>
                                  {commentID === i.id ? (
                                    <StyledInput
                                      onKeyPress={(e) => AddCommand(e, "edit")}
                                      onChange={(e) => AddCommand(e, "edit")}
                                      value={state.EditDescription}
                                      ref={commentRef}
                                      name="EditDescription"
                                      id="EditDescription"
                                      focused
                                    />
                                  ) : (
                                    <CommentText>
                                      {i.Description ? i.Description : ""}
                                    </CommentText>
                                  )}

                                  {i.UserID === user_id ? (
                                    <ButtonGroup>
                                      <StyledButton
                                        className="edit"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "edit"
                                          )
                                        }
                                      >
                                        {t("Edit")}
                                      </StyledButton>
                                      <StyledButton
                                        className="delete"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "delete"
                                          )
                                        }
                                      >
                                        {t("Delete")}
                                      </StyledButton>
                                    </ButtonGroup>
                                  ) : null}
                                </CommentContainer>
                              </AvatarContainer>
                            ))
                          : null}
                      </CommentListContainer>,
                    ]
                  : null}
              </Block>
              <Block className="right block-2">
                <TopBoxContainer>
                  <StatusContainer>
                    <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      {t("Status")}
                    </InputLabel>

                    <StatusSelect state={state} setState={setState} />
                  </StatusContainer>

                  <RoundedCheckbox
                    checked={state.TaskConfermation}
                    onChange={handleCheckBox}
                    name={"taskconfermation"}
                    label={t("Task Confirmation")}
                    index={0}
                    is_detail={false}
                    disabled={user_member_type === "member" ? true : false}
                  />
                </TopBoxContainer>
                <DetailsContainer>
                  <InputLabel
                    style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                  >
                    {t("Details")}
                  </InputLabel>
                  <DetailBlock>
                    <DetailLabel>{t("Project")}</DetailLabel>
                    {/* <ProjectNameText>Project Name</ProjectNameText> */}
                    {showProjectSelect ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={state.ProjectList ? state.ProjectList : []}
                        getOptionLabel={(option) => option.ProjectName || ""}
                        sx={{ width: 280 }}
                        onChange={(e, v) => handleSelectChange("ProjectID", v)}
                        disabled={user_member_type === "member" ? true : false}
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          state.ProjectList && state.ProjectID
                            ? state.ProjectList[
                                get_index(state.ProjectList, state.ProjectID)
                              ]
                            : ""
                        }
                      />
                    ) : props.state.ProjectName ? (
                      props.state.ProjectName
                    ) : (
                      <DetailLabel
                        onClick={() => {
                          setProjectSelect(true);
                        }}
                      >
                        {state.ProjectName
                          ? state.ProjectName
                          : t("Select a Project")}
                      </DetailLabel>
                    )}
                  </DetailBlock>
                  {props.ProjectTaskID ? (
                    <DetailBlock>
                      <DetailLabel>@{t("Assignee")}</DetailLabel>
                      {showAssigneeSelect ? (
                        <CustomeAutocomplete
                          // disablePortal
                          size="small"
                          id="combo-box-demo"
                          options={state.assignerList ? state.assignerList : []}
                          getOptionLabel={(option) => option.username || ""}
                          sx={{ width: 280 }}
                          // onInputChange={(event, value, reason) => {
                          //   if (reason === "input") {
                          //     onSearchUsers(value, event);
                          //   }
                          // }}
                          disabled={
                            user_member_type === "member" ? true : false
                          }
                          onChange={(e, v) =>
                            handleSelectChange("AssignerID", v)
                          }
                          renderInput={(params) => (
                            <TextField size="small" {...params} />
                          )}
                          value={
                            state.assignerList && state.AssignerID
                              ? state.assignerList[
                                  get_Userindex(
                                    state.assignerList,
                                    state.AssignerID
                                  )
                                ]
                              : ""
                          }
                        />
                      ) : (
                        <UnassignText
                          onClick={() => {
                            setAssigneeSelect(true);
                          }}
                        >
                          {state.AssigneeName
                            ? state.AssigneeName
                            : t("Unassigned")}
                        </UnassignText>
                      )}
                    </DetailBlock>
                  ) : null}
                  <DetailBlock>
                    <DetailLabel>@{t("Reporter")}</DetailLabel>

                    {showReporterSelect ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={state.reporterList ? state.reporterList : []}
                        getOptionLabel={(option) => option.username || ""}
                        sx={{ width: 280 }}
                        // onInputChange={(event, value, reason) => {
                        //   if (reason === "input") {
                        //     onSearchUsers(value, event);
                        //   }
                        // }}
                        disabled={user_member_type === "member" ? true : false}
                        onChange={(e, v) =>
                          handleSelectChange("ReportUserID", v)
                        }
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          state.reporterList && state.ReportUserID
                            ? state.reporterList[
                                get_Userindex(
                                  state.reporterList,
                                  state.ReportUserID
                                )
                              ]
                            : ""
                        }
                      />
                    ) : (
                      [
                        <Avatar
                          style={{
                            height: "25px",
                            width: "25px",
                            marginRight: "10px",
                            fontSize: "13px",
                          }}
                          {...stringAvatar(
                            state.ReporterName
                              ? state.ReporterName
                              : t("Reporter")
                          )}
                        />,
                        <DetailLabel
                          onClick={() => {
                            setReporterSelect(true);
                          }}
                        >
                          {state.ReporterName
                            ? state.ReporterName
                            : t("Reporter")}
                        </DetailLabel>,
                      ]
                    )}
                    {/* ================ */}
                  </DetailBlock>

                  <DetailBlock>
                    <DetailLabel>{t("Priority")}</DetailLabel>
                    <PrioritySelect
                      user_member_type={user_member_type}
                      state={state}
                      setState={setState}
                    />
                  </DetailBlock>
                  {state.is_edit === true ? (
                    <DetailBlock>
                      <DetailLabel>{t("Created On")}</DetailLabel>
                      <DateText>{CreadedON}</DateText>
                    </DetailBlock>
                  ) : null}
                  <DetailBlock>
                    <DetailLabel>{t("Due Date")}</DetailLabel>
                    <DateText>{due_date}</DateText>
                    <DateInputContainer>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <DatePicker
                          label="Basic example"
                          value={selectedDate}
                          onChange={handleDateChange}
                          animateYearScrolling
                          inputRef={dateRef}
                          format="dd/MM/yyyy"
                        />
                      </MuiPickersUtilsProvider>
                    </DateInputContainer>
                    {user_member_type !== "member" ? (
                      <StyledEditIcon onClick={() => handleDateChangeRef()} />
                    ) : null}
                  </DetailBlock>
                </DetailsContainer>
                <div>
                  <ProgressContainer>
                    <ProgressTextContainer>
                      <ProgressLabel>{t("Progress")}</ProgressLabel>
                      <ProgressRate>
                        {Number(state.Progress).toFixed(2)}%
                      </ProgressRate>
                    </ProgressTextContainer>
                    <BorderLinearProgress
                      size="small"
                      variant="determinate"
                      value={state.Progress}
                    />
                  </ProgressContainer>
                  <SaveButtonContainer>
                    <StyledButton
                      onClick={() => {
                        SaveTask();
                      }}
                      className="create"
                    >
                      {t("Save")}
                    </StyledButton>
                    {user_member_type !== "member" ? (
                      <StyledButton
                        onClick={() => clearState()}
                        className="cancel"
                      >
                        {t("Clear")}
                      </StyledButton>
                    ) : null}
                  </SaveButtonContainer>
                </div>
              </Block>
            </BlockContainer>
          </Box>
        </Fade>
      </CreateModal>
    </Container>
  );
}
const UnassignText = styled.p`
  font: italic normal normal 12px/18px Poppins;
  color: #848484;
  cursor: pointer;
`;
const DateInputContainer = styled.div`
  display: none;
`;
const ProjectNameText = styled.p`
  color: #00536d;
`;

const StyledInput = styled.input`
  width: 100%;
  padding: 5px;
`;

const AvatarContainer = styled.div`
  font-size: 10px;
  margin-bottom: 20px;
  &.member {
    padding: 10px;
  }

  display: flex;
  & .MuiAvatar-root.MuiAvatar-circular.MuiAvatar-colorDefault {
    height: 30px !important;
    width: 30px !important;
    font-size: 14px;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
`;

const ButtonContainer = styled.div`
  margin-top: 6px;
  margin-bottom: 6px;
  display: flex;
  justify-content: right;
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 15px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const StyledTextField = styled(TextField)`
  && {
    outline: unset;
  }
  .MuiOutlinedInput-input.MuiInputBase-input.MuiInputBase-inputMultiline {
    height: 57px !important;
    font-size: 13px;
    overflow-y: scroll !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
  .MuiInputBase-multiline {
    padding: 6px 10px 7px !important;
    height: 72px;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d5d5d5 !important;
  }
  .css-8ewcdo-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-width: 1px !important;
  }
`;

const Container = styled.div``;

const CreateModal = styled(Modal)`
  &.borderless1 {
    border: none !important ;
  }
`;

const CustomTextField1 = styled(TextField)`
  .MuiFormLabel-root.Mui-focused {
    color: #8d8d8d;
  }

  .MuiInput-underline:after {
    border-width: 1px !important;
    border-bottom: 1px solid #12368c;
  }
  .MuiInput-underline:hover:not(.Mui-disabled):before {
    border-width: 1px !important;
    border-bottom: 1px solid rgba(0, 0, 0, 0.42);
  }
`;
const BlockContainer = styled.div`
  display: flex;
  justify-content: space-between;
  position: relative;
  margin-top: 10px;
`;
const SubTaskBlock = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  /* max-height: 600px;
  overflow-y: scroll;
  padding: 15px; */
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
  }
  .MuiInputBase-multiline {
    padding: 6px 10px 7px !important ;
  }
`;
const Block = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  max-height: 600px;
  overflow-y: scroll;
  padding: 0px 18px 0px 0px;
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
    padding: 0px 0px 0px 0px;
  }
  .MuiInputBase-multiline {
    /* padding: 0px 0px 0px 0px; */
  }
`;
const StyledCloseIcon = styled(CloseIcon)`
  &.close-modal {
    top: 10px !important;
    position: absolute;
    right: 10px !important;
  }
  cursor: pointer;
`;
const SubTaskCloseIcon = styled(CloseIcon)`
  cursor: pointer;
`;
const SubTaskEditIcon = styled(EditIcon)`
  margin-right: 2px;
  /* &.close-modal {
    position: absolute;
    top: 15px;
    right: 15px;
  } */
  cursor: pointer;
`;
const CommentListContainer = styled.div``;

const CommentContainer = styled.div``;
const NameText = styled.p`
  font-weight: bold;
  margin-right: 5px;
`;
const UserDetailsContainer = styled.div`
  display: flex;
  margin-bottom: 3px;
`;
const TimeText = styled.p`
  margin-right: 5px;
  color: #8d8d8d;
`;
const StatusText = styled.p`
  color: #8d8d8d;
`;
const CommentText = styled.p`
  color: #363636;
  margin-bottom: 3px;
`;
const StatusContainer = styled.div``;

const DetailsContainer = styled.div``;

const DetailBlock = styled.div`
  background: #f3f3f3;
  padding: 10px;
  margin-bottom: 10px;
  height: 44px;
  display: flex;
  align-items: center;
  & .MuiInput-underline:before {
    border: unset;
    border-bottom-style: unset !important;
  }
  &.MuiInputBase-input {
    color: black !important;
  }
`;

const DetailLabel = styled.p`
  width: 100px;
  cursor: pointer;
`;

const ProgressContainer = styled.div`
  padding: 6px 10px;
  height: 44px;
  background: #f3f3f3;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 4px;
    background: #c8c8c8;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const SaveButtonContainer = styled.div`
  text-align: right;
  margin-top: 10px;
  /* position: absolute;
  right: 15px;
  bottom: 15px; */
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  width: 100%;
`;
const ProgressLabel = styled.p``;
const ProgressRate = styled.p`
  color: #757575;
`;
const DateText = styled.p`
  color: #727272;
`;
const TopBoxContainer = styled.div`
  display: flex;
  gap: 20px;

  align-items: flex-end;
`;
const CheckboxContainer = styled.div`
  margin-top: 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  svg.MuiSvgIcon-root {
    font-size: 1.2rem;
  }
  .MuiTypography-root.MuiFormControlLabel-label.MuiTypography-body1 {
    font-size: 11px;
    color: #000;
    font-weight: bold;
  }
`;

const StyledEditIcon = styled(EditIcon)`
  cursor: pointer;
  margin-left: auto;
  transition: all 0.1s ease-in;
  &:hover {
    background: #ccc;
    transition: all 0.1s ease-in;
    border-radius: 3px;
  }
`;

const AddSubTaskContainer = styled(Button)`
  && {
    background: #e7ebf6;
    padding: 10px;
    font-weight: bold;
    color: #12368c;
    text-transform: capitalize;
    height: 36px;
    width: 100%;
    justify-content: left;
    border-radius: 2px;
    font-size: 12px;
    svg {
      margin-right: 5px;
    }
  }
`;
const AttachmentListContainer = styled.div`
  && {
    background: #f3f3f3;
    padding: 10px;
    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    display: flex;
    justify-content: space-around;
    border-radius: 2px;
    margin-bottom: 10px;
  }
`;
const AttachmentLeftTitle = styled.div`
  width: 30%;
  color: #12368c;
`;
const AttachmentRightTitle = styled.div`
  display: flex;
  justify-content: space-between;
  width: 50%;
  p {
    cursor: pointer;
  }
  p:nth-child(1) {
    color: #128c16;
  }
  p:last-child {
    color: #8e1906;
  }
`;

const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;
const SubTaskCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: #12368c;
  }
`;
function StatusSelect(props) {
  const [t] = useTranslation("common");
  const [status, setStatus] = React.useState(props.state.Status);
  React.useEffect(() => {
    (async () => {
      setStatus(props.state ? props.state.Status : "todo");
    })();
  }, [props.state.Status]);

  const handleChange = (event) => {
    let val = event.target.value;
    if (val === "completed") {
      let TaskConfermation = props.state.TaskConfermation;
      let Reporter = props.state.Reporter;
      if (TaskConfermation && Reporter != props.state.user_id) {
        val = "confirming";
      }
    }
    setStatus(val);
    props.setState({
      ...props.state,
      Status: val,
    });
  };

  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;

      padding: 4px 10px;
      font-size: 12px;
      ${({ status }) =>
        status === "todo" && `background: #e6e6e6; color:#00024A; border:0;`}
      ${({ status }) =>
        status === "progress" &&
        `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ status }) =>
        status === "completed" && `background: #C2FBC3; color:#032406;`}
      ${({ status }) =>
        status === "confirming" && `background: #f5d6b5; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
    .css-jedpe8-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
      border-radius: 2px !important;
    }

    .borderless1 {
      border: unset !important;
    }
  `;

  return (
    <Container status={status}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={status}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"todo"} className="progress">
              {t("To Do")}
            </MenuItem>
            <MenuItem value={"progress"} className="progress">
              {t("In Progress")}
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              {t("Done")}
            </MenuItem>
            {status === "confirming" ? (
              <MenuItem
                value={"confirming"}
                className="completed"
                style={{ display: "none" }}
              >
                {t("Confirming")}...
              </MenuItem>
            ) : null}
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
function PrioritySelect(props) {
  const [t] = useTranslation("common");
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.Priority : "medium"
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      Priority: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 4px 10px;
      font-size: 12px;
      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
    .css-jedpe8-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
      border-radius: 2px !important;
    }
    .borderless1 {
      border: none !important ;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
            disabled={props.user_member_type === "member" ? true : false}
          >
            <MenuItem value={"low"} className="progress">
              {t("Low")}
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              {t("Medium")}
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              {t("High")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
function ProjectSelect(props) {
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.ProjectID : ""
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      ProjectID: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            {props.state.ProjectList.map((i) => (
              <MenuItem value={"high"} className="completed">
                {i.ProjectName}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
const CustomeAutocomplete = styled(Autocomplete)`
  button {
    padding: 0;
  }
`;
