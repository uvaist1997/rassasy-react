import React, { lazy, Suspense, useState, useEffect, useContext } from "react";
import styled from "styled-components/macro";
import {
  NavLink,
  Route,
  Routes as Switch,
  useLocation,
} from "react-router-dom";
import { Button, ButtonBase, CircularProgress } from "@mui/material";
import Header from "../../components/Header/Header";
import AddIcon from "@mui/icons-material/Add";
import ProjectTasks from "../Projects/ProjectTasks";
import Tasks from "../Tasks/Tasks";
import CreateProject from "../Projects/CreateProject";
import CreateTask from "../Tasks/CreateTask";
import Teams from "../Teams/Teams";
import MainCalandar from "../MainCalandar/MainCalandar";
import TeamTasks from "../Teams/TeamTask/TeamTasks";
import IndividualTask from "../Teams/IndividualTask/IndividualTask";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import Badge from "@mui/material/Badge";
import { getCookie } from "../../functions/utils";
import { BASE_URL } from "../../settings";
import { useSelector } from "react-redux";
import { DataContext } from "../../components/Context1";
const Projects = lazy(() => import("../Projects/Projects"));
const Summary = lazy(() => import("../Summary/Summary"));

const access = getCookie("VBID");

const Navigation = () => {
  const [t] = useTranslation("common");
  const { pathname } = useLocation();
  const [openProject, setProject] = useState(false);
  const [openTask, setTask] = useState(false);
  const navigate = useNavigate();
  const { username, user_id } = useSelector((state) => state.user);
  const [state, setState] = useState({
    is_notify_project: false,
    is_notify_task: false,
  });

  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;

  const image_root = window.location.origin;
  const MenuList = [
    {
      label: t("Summary"),
      image: image_root + "/images/icons/summary.svg",
      linkList: "/",
      linkCreate: "",
    },
    {
      label: t("Projects"),
      image: image_root + "/images/icons/projects.svg",
      linkList: "/projects",
      linkCreate: () => setProject(true),
    },
    {
      label: t("My Tasks"),
      image: image_root + "/images/icons/tasks.svg",
      linkList: "/tasks",
      linkCreate: () => setTask(true),
    },

    // {
    //   label: "Teams",
    //   image: image_root + "/images/icons/group-line.svg",
    //   linkList: "/teams",
    // },
    // {
    //   label: "Calender",
    //   image: image_root + "/images/icons/calendar2-event-fill.svg",
    //   linkList: "/calender",
    // },
  ];

  const GotCreate = (link) => {
    console.log(link);
    navigate(`${link}`, { state: { create: true } });
  };
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  let path = "";
  if (pathname === "/tasks" && params.q) {
    path = "/projects";
  } else {
    path = pathname;
  }

  return (
    <Container>
      <Header />
      <ViewPort>
        <SideNavigation>
          {/* <MenuBar onClick={() => setMenu(!showMenu)}>
            <MenuIcon />
          </MenuBar> */}
          {MenuList.map((i, index) => (
            <Menu key={index}>
              <ButtonBase>
                <MenuIconContainer>
                  <StyledNavLink
                    to={i.linkList}
                    className={
                      [i.linkList, i.linkCreate].includes(path)
                        ? "active123"
                        : ""
                    }
                  >
                    {i.label != "Summary" ? (
                      <Badge
                        color="error"
                        variant="dot"
                        invisible={
                          i.label === "Projects" &&
                          notificationCount.project_notify === 0
                            ? true
                            : i.label === "My Tasks" &&
                              notificationCount.task_notify === 0
                            ? true
                            : false
                        }
                      >
                        <MenuIconImg src={i.image} alt="label" />
                      </Badge>
                    ) : null}

                    <MenuText>{i.label}</MenuText>
                  </StyledNavLink>
                  {i.linkCreate && (
                    <CreateButton
                      style={{ minWidth: "41px" }}
                      onClick={() => GotCreate(i.linkList)}
                    >
                      <AddIcon style={{ fontSize: "20px", minWidth: "41px" }} />
                    </CreateButton>
                  )}
                </MenuIconContainer>
              </ButtonBase>
            </Menu>
          ))}
        </SideNavigation>

        <Main>
          <Suspense
            fallback={
              <Box>
                <CircularProgress />
              </Box>
            }
          >
            <Switch>
              <Route path="/" element={<Summary />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/project-tasks" element={<ProjectTasks />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/teams" element={<Teams />} />
              <Route path="/calender" element={<MainCalandar />} />
              <Route path="/team-tasks" element={<TeamTasks />} />
              <Route path="/IndividualTask" element={<IndividualTask />} />
            </Switch>
          </Suspense>
        </Main>
      </ViewPort>
      {/* <CreateProject open={openProject} setOpen={setProject} /> */}
      {/* <CreateTask open={openTask} setOpen={setTask} /> */}
    </Container>
  );
};

export default Navigation;

const CreateButton = styled(Button)`
  display: flex;
  margin-left: auto;
  padding: 0 10px;
  svg {
    transition: all 0.2s ease-in-out;
    color: #b8becb;
  }
  &&.active,
  &&:hover {
    svg {
      transition: all 0.2s ease-in-out;
      color: #000 !important;
    }
  }
`;

const Box = styled.div`
  width: 96%;
  height: 80vh;
  display: grid;
  place-items: center;
`;

const Container = styled.div`
  /* @media (max-width: 460px) {
    position: relative;
    height: 100vh;
  } */
`;
const SideNavigation = styled.div`
  padding: 10px;
  min-width: max-content;
  width: 207px;

  display: flex;
  flex-direction: column;

  border-right: 1px solid #ccc;
  height: 100vh;
  /* position: fixed;
  top: 0;
  bottom: 0;
  z-index: 100; */
  /* @media (max-width: 460px) {
    width: 100%;
    flex-direction: row;
    top: initial;
    padding: 10px 0;
    height: 140px;
    position: absolute;
  } */
`;
const MenuIconContainer = styled.div`
  background: transparent;

  /* padding: 7px; */
  margin: 0 auto;
  border-radius: 4px;
  text-align: left;
  display: flex;
  align-items: center;
  width: 177px;
  transition: all 0.1s ease-in-out;

  /* @media (max-width: 460px) {
    width: 60px;
    height: 60px;
  } */
`;
const MenuIconImg = styled.img`
  width: 20px;
  height: 20px;
  transition: all 0.2s ease-in-out;

  && path {
    fill: #fff !important;
  }

  /* @media (max-width: 460px) {
    width: 60px;
    height: 60px;
  } */
`;
const MenuText = styled.p`
  white-space: nowrap;
  color: #b8becb;
  font-size: 13px;

  margin-left: 10px;

  transition: all 0.1s ease-in-out;

  ${({ report }) =>
    report &&
    `
  margin-left:35px;

  `}/* @media (max-width: 460px) {
    margin-bottom: 0;
    display: none;
  } */
`;
const Menu = styled.div`
  && {
    cursor: pointer;
    text-decoration: none;
    margin-bottom: 15px;
  }
  /* &&.active, */
  &&:hover {
    ${MenuIconContainer} {
      /* background: #5447a0; */
      background: #ffffff 0% 0% no-repeat padding-box;
      box-shadow: 0px 0px 3px 0px #0000004f;
      transition: all 0.2s ease-in-out;
    }
    ${MenuIconImg} {
      transition: all 0.2s ease-in-out;
      filter: brightness(0);
      /* filter: brightness(0) invert(1); */
    }
    ${MenuText} {
      transition: all 0.2s ease-in-out;
      color: #3b4a58;
    }
    ${CreateButton} {
      svg {
        transition: all 0.2s ease-in-out;
        color: #000 !important;
      }
    }
  }

  ${({ report, showMenu }) =>
    report &&
    !showMenu &&
    `

  visibility:hidden;
  `}/* @media (max-width: 460px) {
    display: flex;
  } */
`;

const ViewPort = styled.div`
  display: flex;
  /* @media (max-width: 460px) {
    width: 100%;
    overflow-x: scroll;
    padding-left: 0;
  } */
`;

const Main = styled.div`
  min-height: calc(100% - 61px);
  width: 90%;
  padding: 15px;
  background: #fafcff;
`;

const StyledNavLink = styled(NavLink)`
  padding: 7px;
  width: 100%;
  display: flex;
  align-items: center;
  /* .active */

  /* &&.active, */
  &.active123,
  &&:hover {
    ${MenuIconContainer} {
      /* background: #5447a0; */
      background: #ffffff 0% 0% no-repeat padding-box;
      box-shadow: 0px 0px 3px 0px #0000004f;
      transition: all 0.2s ease-in-out;
    }
    ${MenuIconImg} {
      transition: all 0.2s ease-in-out;
      filter: brightness(0);
      /* filter: brightness(0) invert(1); */
    }
    ${MenuText} {
      transition: all 0.2s ease-in-out;
      color: #3b4a58;
    }
    ${CreateButton} {
      svg {
        transition: all 0.2s ease-in-out;
        color: #000 !important;
      }
      color: #000 !important;
    }
  }
`;
