import React, { useContext, useState, useEffect } from "react";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import styled from "styled-components/macro";
import Avatar from "@mui/material/Avatar";
import Tooltip from "@mui/material/Tooltip";
import { styled as styles } from "@mui/material/styles";
import { DataContext } from "../../components/Context1";
import {
  Autocomplete,
  Box,
  LinearProgress,
  linearProgressClasses,
  TextField,
} from "@mui/material";
import { Button } from "@mui/material";
import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
import { stringAvatar } from "../../functions/utils";

function MembersList(props) {
  const _ = require("lodash");
  const { showMemberList } = useContext(DataContext);
  const [showPopup, setShowPopup] = showMemberList;
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });

  const [addmember, setAddMember] = useState(false);
  const [memList, setMemList] = useState({
    data: [
      {
        name: "Uvais",
        progressValue: 30,
      },
      {
        name: "Jasmal",
        progressValue: 90,
      },
      {
        name: "Abhi",
        progressValue: 90,
      },
      {
        name: "Uvais",
        progressValue: 50,
      },
      {
        name: "Uvais",
        progressValue: 20,
      },
      {
        name: "Uvais",
        progressValue: 80,
      },
    ],
  });

  useEffect(() => {
    console.log(props.showPopup);
    if (props.showPopup === true) {
      if (!props.state.MemberList.length) {
        setAddMember(true);
      } else {
        setAddMember(false);
        // setShowPopup(false);
      }
    }
  }, [props.showPopup]);

  useEffect(() => {
    console.log(props.state.member_added);
    if (props.state.member_added === true) {
      setAddMember(false);
      props.setState((prevState) => {
        return {
          ...prevState,
          member_added: false,
        };
      })
    }
  }, [props.state.member_added]);

  const handleSearchMember = (e) => {
    console.log(e.target.value)
    let MemberList = props.state.MemberList;
    let searchedList = MemberList.filter((i) => (i.username).toLowerCase().includes((e.target.value).toLowerCase()))
    console.log(searchedList);
    props.setState((prevState) => {
      return {
        ...prevState,
        SearchList: searchedList,
      };
    });
  }

  const handleInvite = () => {
    setAddMember(false);
    props.InviteMember();
  }

  const handleCancel = () => {
    setAddMember(false);
    props.setuserSearch("");
    if (!props.state.MemberList.length) {
      setShowPopup(false);
    }
  }


  ////////////////////////////Three dot Menu-------

  const options = [
    {
      name: "Make Admin",
      value: "1",
    },
    {
      name: "Remove",
      value: "2",
    },
    {
      name: "Remove Admin",
      value: "3",
    },
  ];

const ITEM_HEIGHT = 48;
const [anchorEl, setAnchorEl] = React.useState(null);
const open = Boolean(anchorEl);
const handleClick = (event) => {
  setAnchorEl(event.currentTarget);
};
const handleClose = () => {
  setAnchorEl(null);
};
  
  function DropDownMenu(props) {
    const _ = require("lodash");
    const [anchorEl, setAnchorEl] = React.useState(null);

    const open = Boolean(anchorEl);
    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };
    let MemberList = [...props.state.MemberList];
    let member_type = "admin"
    if (MemberList.length) {
      let instance = MemberList.filter((i) => i.MemberUserID === props.UserID);
      if (instance.length) {
        member_type = instance[0].MemberType;
      }
    }
    

    const [action, setAction] = React.useState(member_type === "admin" ? 1 : 3);
    const onClickAction = (e) => {
      let MemberList = [...props.state.MemberList];
      if (e.target.value) {
        setAction(e.target.value);
      }
      if (e.target.value === 2) {
        MemberList = _.remove(MemberList, function (i) {
          return i.MemberUserID != props.UserID;
        });
        props.setState((prevState) => {
          return {
            ...prevState,
            MemberList,
          };
        });
      } else if (e.target.value === 1) {
        var NewList = _.map(MemberList, function (a) {
          return a.MemberUserID === props.UserID
            ? {
                MemberUserID: a.MemberUserID,
                username: a.username,
                MemberType: "admin",
                progress_rate: a.progress_rate,
              }
            : a;
        });

        props.setState((prevState) => {
          return {
            ...prevState,
            MemberList: NewList,
          };
        });
      } else if (e.target.value === 3) {
        var NewList = _.map(MemberList, function (a) {
          return a.MemberUserID === props.UserID
            ? {
                MemberUserID: a.MemberUserID,
                username: a.username,
                MemberType: "member",
                progress_rate: a.progress_rate,
              }
            : a;
        });

        props.setState((prevState) => {
          return {
            ...prevState,
            MemberList: NewList,
          };
        });
      }
      setAnchorEl(null);
    };
    return (
      <React.Fragment>
        <Tooltip title="Account settings">
          <IconButton
            onClick={handleClick}
            size="small"
            sx={{ ml: 2 }}
            aria-controls={open ? "account-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
          >
            <MoreVertIcon />
          </IconButton>
        </Tooltip>
        {member_type != "owner" ? (
          <Menu
            anchorEl={anchorEl}
            id="account-menu"
            open={open}
            onClose={handleClose}
            onClick={(e) => onClickAction(e)}
            PaperProps={{
              elevation: 0,
              sx: {
                overflow: "visible",
                filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                mt: 1.5,
                "& .MuiAvatar-root": {
                  width: 32,
                  height: 32,
                  ml: -0.5,
                  mr: 1,
                },
                "&:before": {
                  content: '""',
                  display: "block",
                  position: "absolute",
                  top: 0,
                  right: 14,
                  width: 10,
                  height: 10,
                  bgcolor: "background.paper",
                  transform: "translateY(-50%) rotate(45deg)",
                  zIndex: 0,
                },
              },
            }}
            transformOrigin={{ horizontal: "right", vertical: "top" }}
            anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
          >
            {action === 1 ? (
              <MenuItem key="3" value="3">
                Remove Admin
              </MenuItem>
            ) : action === 3 ? (
              <MenuItem key="1" value="1">
                Make Admin
              </MenuItem>
            ) : null}

            <MenuItem key="2" value="2">
              Remove
            </MenuItem>
          </Menu>
        ) : null}
      </React.Fragment>
    );
  }
  return (
    <MembersAvtarPopup showPopup={showPopup}>
      <MemberHead>
        <MemberTxt>Members</MemberTxt>
        {props.user_member_type === "owner" ||
        props.user_member_type === "admin" ||
        props.state.is_update === false ? (
          <AddButton onClick={() => setAddMember(!addmember)}>
            + Add Members
          </AddButton>
        ) : null}
      </MemberHead>

      <SeachBoxContainer>
        <Box
          component="form"
          sx={{
            "& > :not(style)": { width: "100% " },
          }}
          noValidate
          autoComplete="off"
        >
          <TextBox
            id="outlined-basic"
            variant="outlined"
            placeholder="Search..."
            onChange={(e) => handleSearchMember(e)}
          />
        </Box>
      </SeachBoxContainer>

      {/* ///Avatar List==============================||||||||||||||||||| */}
      <Lists
        dense
        sx={{ width: "100%", maxWidth: 360, bgcolor: "background.paper" }}
      >
        {props.state.SearchList.map((i) => {
          return (
            <ListItem key={i.MemberUserID} disablePadding>
              <ListItemButton
                style={{ paddingLeft: " 8px", paddingRight: " 8px" }}
              >
                <ListItemAvatars>
                  <Avatar
                    alt={`Avatar n°${i + 1}`}
                    // src={`https://www.thenewsminute.com/sites/default/files/styles/news_detail/public/RashmikaMandanna_Smiling_221120_1200_DN.jpg?itok=oDSUikQw/${
                    //   i + 1
                    // }.jpg`}
                    {...stringAvatar(i.username)}
                    style={{ width: "30px", height: "30px" }}
                  />
                </ListItemAvatars>
                <ListContainer
                  onClick={() => props.GotoMemberTask(i.MemberUserID)}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      width: "100%",
                    }}
                  >
                    <>
                      <ListItemText
                        style={{
                          // width: "100%",
                          marginTop: "6px",
                          marginBottom: "1px",
                          WebkitFlex: "unset",
                          flex: "inherit",
                        }}
                      >
                        {i.username}
                      </ListItemText>
                      {i.MemberType === "owner" || i.MemberType === "admin" ? (
                        <AdminImg src="../../images/administrator-solid.svg" />
                      ) : null}
                    </>
                    <ListItemText1
                      style={{
                        marginTop: "6px",
                        marginBottom: "1px",
                        width: "10%",
                      }}
                    >
                      <ProgressPercentage>
                        {i.progress_rate}%
                      </ProgressPercentage>
                    </ListItemText1>
                  </div>
                  <ListItemText>
                    <ProgressValueContainer>
                      <ProgressContainer>
                        <BorderLinearProgress
                          size="small"
                          variant="determinate"
                          value={i.progressValue}
                        />
                      </ProgressContainer>
                    </ProgressValueContainer>
                  </ListItemText>
                </ListContainer>

                {props.user_member_type === "owner" ||
                props.user_member_type === "admin" ||
                props.state.is_update === false ? (
                  <DropDownMenu
                    state={props.state}
                    setState={props.setState}
                    UserID={i.MemberUserID}
                  />
                ) : null}
              </ListItemButton>
            </ListItem>
          );
        })}
      </Lists>

      <AddmemberPopupContainer addMember={addmember}>
        <AddMemberHeader>
          <AddMemberText>Add Member</AddMemberText>
          <RoundCheckBoxAdd>
            <RoundedCheckbox
              name={"addasadmin"}
              label={"Add as Admin"}
              value={props.state.addasadmin}
              onChange={props.handleCheckBox}
            />
          </RoundCheckBoxAdd>
        </AddMemberHeader>

        <SelectBoxContainer>
          <UserText>User</UserText>
          <CustomeAutocomplete
            size="small"
            freeSolo
            id="combo-box-demo"
            name="addMember"
            options={props.state.usersList}
            getOptionLabel={(option) => option.user_email || ""}
            inputValue={props.userSearch}
            onChange={(e, v) => props.addMember(e, v, "member")}
            onInputChange={(event, value, reason) => {
              if (reason === "input") {
                props.onSearchUsers(value, event);
              }
            }}
            renderInput={(params) => (
              <TextField size="small" {...params} placeholder="Member " />
            )}
          />
        </SelectBoxContainer>

        <CancelButtonContainer>
          <CancelButton onClick={() => handleCancel()} className="create">
            Cancel
          </CancelButton>

          <StyledButton onClick={() => handleInvite()} className="create">
            Invite
          </StyledButton>
        </CancelButtonContainer>
      </AddmemberPopupContainer>
    </MembersAvtarPopup>
  );
}

export default MembersList;

   const Menus = styled(Menu)`
     .css-1poimk-MuiPaper-root-MuiMenu-paper-MuiPaper-root-MuiPopover-paper {
       ::-webkit-scrollbar {
         display: none;
       }
     }
   `;
const ListItemText1 = styled(ListItemText)`
  flex: inherit !important;
`;
const ListItemAvatars = styled(ListItemAvatar)`
  && {
    min-width: 34px !important;
    .css-1wlk0hk-MuiAvatar-root {
      width: 26px !important;
      height: 26px !important;
    }
  }
`;

const AdminImg = styled.img`
  margin-left: 5px;
  width: 11px;
  margin-top: 5px;
  margin-right:auto;
`;
const SeachBoxContainer = styled.div`
  margin-top: 8px;
  width: 100%;
  .MuiBox-root {
    border-color: #fff !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border: unset !important;
    border-width: 1px !important ;
    outline: unset !important;
  }
`;
const TextBox = styled(TextField)`
  background-color: #ececec;
  outline: unset !important;

  .MuiOutlinedInput-input {
    padding: 7px 15px !important;
    font-size: 12px;
  }
  &.fieldset {
    border: unset;
    border-color: #fff !important ;
  }
`;
const AddMemberHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const AddMemberText = styled.h3`
  font-weight: bold;
  font-size: 12px;
  letter-spacing: 1px; ;
`;
const RoundCheckBoxAdd = styled.div`
  display: flex;

  label {
    font-size: 11px !important;
    font-weight: unset !important;
  }
`;
const SelectBoxContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 5px;
`;
const UserText = styled.span`
  color: #8f8f8f;
  margin-left: 2px;
`;
const CancelButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
`;
const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }

  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }

  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;
const CancelButton = styled(StyledButton)`
  && {
    background-color: #d5e2ef !important;
    color: #2b2b2b !important;
  }
`;
const AddmemberPopupContainer = styled.div`
  position: absolute;
  background-color: white;

  width: 94%;
  top: 30px;
  z-index: 3;
  padding: 10px;
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  margin-top: 3px;
  transition: transform 0.3s ease-in-out;
  display: ${({ addMember }) => (addMember ? "" : "none")};
`;
const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: 3px !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #ffffff !important;
    border-width: 0px !important;
    z-index: 2;
    border-radius: 2px !important;
  }
  &.css-1auycx3-MuiAutocomplete-root
    .MuiOutlinedInput-root.MuiInputBase-sizeSmall
    .MuiAutocomplete-input {
    padding: 0px 4px 0px 6px !important;
  }
  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
    font-size: 12px !important;
  }
  .MuiFormControl-fullWidth {
    background-color: #ececec;
    .MuiFormControl-fullWidth {
      margin-top: unset;
    }
  }
`;

const ProgressPercentage = styled.span`
  color: #6b6b6b;
  font-size: 10px;
`;
const ListContainer = styled.div`
  width: 100%;
`;
const ProgressValueContainer = styled.div`
  width: 100%;
`;
const ProgressContainer = styled.div`
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 3px;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,

  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));

const Lists = styled(List)`
  && {
    overflow-y: scroll;
    max-height: 255px;
    ::-webkit-scrollbar {
      display: none;
    }
    .css-2s90m6-MuiAvatar-root {
      width: 29px !important;
      height: 29px !important;

      font-size: 1rem !important;
    }

    .css-et1ao3-MuiTypography-root {
      font-size: 12px !important;
    }
  }
`;
const AddButton = styled.span`
  font-size: 13px;
  color: #12368c;
  position: relative;
  cursor: pointer;
`;
const MemberHead = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const MembersAvtarPopup = styled.div`
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  z-index: 1;
  width: 311px;
  position: absolute;
  bottom: 101px;

  padding: 10px;
  background-color: white;

  display: ${({ showPopup }) => (showPopup ? "" : " none")};
`;
const MemberTxt = styled.span`
  font-size: 13px;
  color: #002272;
  font-weight: bold;
`;
