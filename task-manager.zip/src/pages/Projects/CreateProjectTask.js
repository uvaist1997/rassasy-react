import React, { useRef, useState, useEffect } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import {
  Avatar,
  Autocomplete,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  MenuItem,
  Select,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import {
  debugBase64,
  download,
  getCookie,
  get_date,
  stringAvatar,
  get_Userindex,
} from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import EditIcon from "@mui/icons-material/Edit";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import { useSelector } from "react-redux";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import NativeSelect from "@mui/material/NativeSelect";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import Checkbox from "@material-ui/core/Checkbox";
import Swal from "sweetalert2";
import {
  taskCreateUrl,
  taskDeleteUrl,
  taskEditUrl,
  taskListUrl,
  taskUpadteStatusPriorityUrl,
  taskViewUrl,
} from "../../api/TasksAPI";
import RoundedCheckbox from "../Tasks/RoundedCheckbox";
import { MEDIA_URL } from "../../settings";
import { useTranslation } from "react-i18next";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",

  boxShadow: 24,

  width: 831,
  bgcolor: "background.paper",
  borderRadius: "3px",

  p: 2,
};
const access = getCookie("VBID");

export default function CreateProjectTask(props) {
  const [t] = useTranslation("common");
  let singleProject = props.state.data.filter(
    (i) => i.id === props.singleProject
  )[0];
  let ProjectName = "";
  let MemberType = "";
  let ProjectID = null;
  let reporterList = [];
  let TaskConfermation = false;
  let load_single = false;
  if (singleProject) {
    ProjectName = singleProject.ProjectName;
    MemberType = singleProject.MemberType;
    ProjectID = singleProject.id;
    reporterList = singleProject.MemberList;
    TaskConfermation = singleProject.TaskConfermation;
    load_single = true;
  }
  let type = props.type;
  let open = props.open;
  let setOpen = props.setOpen;
  const _ = require("lodash");
  const { username, photo, user_id } = useSelector((state) => state.user);
  const [selectedDate, handleDateChange] = useState(new Date());
  var month = selectedDate.toLocaleString("default", { month: "long" });
  var day = selectedDate.getUTCDate();
  var year = selectedDate.getUTCFullYear();
  const [commentID, setcommentID] = React.useState(null);
  const ref = useRef(null);
  const [state, setState] = React.useState({
    ProjectID: ProjectID,
    TaskName: "",
    Description: "",
    Status: "todo",
    CreatedBy: username,
    Priority: "medium",
    DueDate: get_date(selectedDate),
    Progress: 0,
    fileName: "",
    fileList: [],
    CommentList: [],
    usersList: [],
    MemberList: [],
    DocumentList: [],
    is_update: false,
    HistoryList: [],
    EditDescription: "",
    SubTaskList: [],
    SubTaskDescription: "",
    is_edit: false,
    TaskConfermation: false,
    is_didmount: true,
    ReportUserID: "",
    AssignerID: "",
  });

  const clearState = () => {
    handleDateChange(new Date());
    setcommentID(null);
    setState((prevState) => {
      return {
        ...prevState,
        TaskName: "",
        Description: "",
        Status: "progress",
        CreatedBy: username,
        Priority: "medium",
        DueDate: get_date(selectedDate),
        Progress: 0,
        fileName: "",
        fileList: [],
        CommentList: [],
        HistoryList: [],
        usersList: [],
        MemberList: [],
        DocumentList: [],
        is_update: false,
        comment: "",
        EditDescription: "",
        ReporterName: "",
        AssigneeName: "",
        AssignerID: "",
        TaskConfermation: false,
        is_didmount: true,
      };
    });
  };

  useEffect(() => {
    setState({
      ...state,
      TaskConfermation: TaskConfermation,
      is_didmount: false,
    });
  }, [props.open]);

  const handleEditClick = () => {
    ref.current.focus();
  };
  const handleClose = () => setOpen(false);
  let dateRef = useRef(null);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const openMenu = Boolean(anchorEl);
  const [showReporterSelect, setReporterSelect] = React.useState(false);
  const [showAssigneeSelect, setAssigneeSelect] = React.useState(false);
  const [showSubTask, setSubTask] = React.useState(false);
  const [updatedSubTask, setUpdateSubTask] = React.useState(null);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleChangeImg = (event) => {
    const fileUploaded = event.target.files[0];

    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [...state.DocumentList, fileUploaded],
      };
    });
  };

  const handleRemoveImg = (file) => {
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: state.DocumentList.filter((i) => i !== file),
      };
    });
  };

  async function readFile(file) {
    // // let blob = convert_url_to_blob(url);
    // file = await convert_url_to_file(file);
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      const result = event.target.result;
      // Check if the file is an image.
      if (file.type && !file.type.startsWith("image/")) {
        // e.g This will dowunload a file
        download(result);
      } else {
        // e.g This will open an image in a new window
        debugBase64(result);
      }
    });
    reader.readAsDataURL(file);
  }

  const handleDateChangeRef = () => {
    dateRef.current.click();
  };

  const clickModalClose = () => {
    setOpen(false);
    clearState();
  };

  const handleChange = (e) => {
    setState((prevState) => {
      return {
        ...prevState,
        [e.target.name]: e.target.value,
      };
    });
  };
  const hiddenFileInput = React.useRef(null);
  const handleClickImg = (event) => {
    hiddenFileInput.current.click();
  };

  const handleCheckBox = (event) => {
    setState((prevState) => {
      return {
        ...prevState,
        TaskConfermation: event.target.checked,
      };
    });
  };

  const handleSelectChange = (n, e) => {
    if (e) {
      if (n == "ReportUserID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.MemberUserID,
            ReporterName: e.username,
          };
        });
        setReporterSelect(false);
      } else if (n == "AssignerID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.MemberUserID,
            AssigneeName: e.username,
          };
        });
        setAssigneeSelect(false);
      } else {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.target.value,
          };
        });
      }
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          [n]: "",
        };
      });
    }
  };

  const updateSubTask = (value, index, type) => {
    if (type === "view") {
      let descreption = value.Description;
      setUpdateSubTask(index);
      setState((prevState) => {
        return {
          ...prevState,
          SubTaskDescription: descreption,
        };
      });
      setSubTask(true);
    } else {
      let SubTaskList = [...state.SubTaskList];
      SubTaskList[updatedSubTask]["Description"] = state.SubTaskDescription;
      setState((prevState) => {
        return {
          ...prevState,
          SubTaskList,
          SubTaskDescription: "",
        };
      });
      setUpdateSubTask(null);
      setSubTask(false);
    }
  };

  const onSearchUsers = async (val, e) => {
    // if (val) {
    //   const userListResponse = await fetch(
    //     "http://localhost:8000/api/v1/users/get-users/",
    //     {
    //       method: "POST",
    //       headers: {
    //         "content-type": "application/json",
    //         Authorization: `Bearer ${access}`,
    //         accept: "application/json",
    //       },
    //       body: JSON.stringify({
    //         username: val,
    //       }),
    //     }
    //   ).then((response) => response.json());
    //   if (userListResponse.StatusCode === 6000) {
    //     setState((prevState) => {
    //       return {
    //         ...prevState,
    //         reporterList: userListResponse.data,
    //       };
    //     });
    //   }
    // }
  };

  const SaveTask = async () => {
    let Url = taskCreateUrl;
    let title = "Task Created Successfully";
    if (state.is_edit) {
      Url = taskEditUrl + state.edit_id + "/";
      title = "Task Updated Successfully";
    }
    let projectID = ProjectID;
    if (!ProjectID) {
      projectID = state.ProjectID;
    }

    const formData = new FormData();
    formData.append("CreatedBy", state.CreatedBy);
    formData.append("TaskName", state.TaskName);
    formData.append("Description", state.Description);
    formData.append("Status", state.Status);
    formData.append(
      "TaskConfermation",
      state.TaskConfermation ? state.TaskConfermation : false
    );
    formData.append("ProjectID", projectID);
    formData.append("ReportUserID", state.ReportUserID);
    formData.append("Priority", state.Priority);
    formData.append("DueDate", get_date(selectedDate));
    formData.append("AssignerID", state.AssignerID);
    formData.append("AssigneeName", state.AssigneeName);
    let DocumentList = state.DocumentList;
    DocumentList.map((i, index) => {
      let name = "image" + String(index);
      formData.append(name, i);
    });
    formData.append("DocumentList", state.DocumentList);
    // formData.append("SubTaskList", state.SubTaskList);
    formData.append("SubTaskList", JSON.stringify(state.SubTaskList));

    const Response = await fetch(Url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${access}`,
        // "accept": "application/json"
      },
      body: formData,
    }).then((response) => response.json());
    if (Response.StatusCode === 6000) {
      Swal.fire({
        title: title,
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
      props.setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
        };
      });
      setOpen(false);
      clearState();
    } else {
      Swal.fire({
        title: "Task Created Failed",
        showClass: {
          popup: "animate__animated animate__fadeInDown",
        },
        hideClass: {
          popup: "animate__animated animate__fadeOutUp",
        },
      });
    }
  };

  const AddSubTask = () => {
    let sub_task = {
      Description: state.SubTaskDescription,
      is_completed: false,
    };
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: [...state.SubTaskList, sub_task],
        SubTaskDescription: "",
      };
    });
    setSubTask(false);
  };

  const handleDetailCheckBox = (event, index) => {
    let SubTaskList = [...state.SubTaskList];
    SubTaskList[index]["is_completed"] = event.target.checked;
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList,
      };
    });
  };

  const removeCheckBox = (value) => {
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskList: state.SubTaskList.filter((i) => i !== value),
      };
    });
  };

  const cancelSubTask = async () => {
    setSubTask(false);
    setState((prevState) => {
      return {
        ...prevState,
        SubTaskDescription: "",
      };
    });
  };

  return (
    <Container>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <TaskNameText
              fullWidth
              focused
              id="standard-basic"
              label={t("Task")}
              variant="standard"
              name="TaskName"
              value={state.TaskName}
              onChange={(e) => handleChange(e)}
            />
            <BlockContainer>
              <Block className="left">
                <InputLabel
                  style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                >
                  {t("Description")}
                </InputLabel>
                <StyledTextField
                  fullWidth
                  multiline
                  id="outlined-basic"
                  variant="outlined"
                  name="Description"
                  value={state.Description}
                  onChange={(e) => handleChange(e)}
                />
                <ButtonContainer>
                  {/* <ButtonGroup>
                    <StyledButton className="create m">Save</StyledButton>
                    <StyledButton className="cancel">Cancel</StyledButton>
                  </ButtonGroup> */}
                  <ButtonGroup>
                    <FileName>{state.fileName}</FileName>
                    <StyledButton className="attach" onClick={handleClickImg}>
                      <AttachFileIcon />
                      {t("Attach")}
                    </StyledButton>
                    <input
                      type="file"
                      ref={hiddenFileInput}
                      onChange={handleChangeImg}
                      style={{ display: "none" }}
                      multiple
                    />
                  </ButtonGroup>
                </ButtonContainer>
                {state.DocumentList.map((i, index) => (
                  <AttachmentListContainer>
                    <AttachmentLeftTitle>{i.name}</AttachmentLeftTitle>
                    <AttachmentRightTitle>
                      <p
                        onClick={() => {
                          state.is_update === false
                            ? readFile(i)
                            : window.open(MEDIA_URL + i.DocFile, "_blank");
                        }}
                      >
                        {t("View")}
                      </p>
                      {state.is_update === false ? (
                        <p
                          onClick={() => {
                            readFile(i);
                          }}
                        >
                          {t("Download")}
                        </p>
                      ) : (
                        <a
                          style={{ color: "black" }}
                          href={MEDIA_URL + i.DocFile}
                          download
                        >
                          {t("Download")}
                        </a>
                      )}

                      <p
                        onClick={() => {
                          handleRemoveImg(i);
                        }}
                      >
                        {t("Remove")}
                      </p>
                    </AttachmentRightTitle>
                  </AttachmentListContainer>
                ))}
                <AddSubTaskContainer
                  onClick={() => {
                    setSubTask(true);
                  }}
                >
                  <AddCircleOutlineIcon />
                  {t("Add Subtask")}
                </AddSubTaskContainer>
                {showSubTask ? (
                  <SubTaskBlock>
                    {/* <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      {t("Description")}
                    </InputLabel> */}
                    <StyledTextField
                      fullWidth
                      multiline
                      id="outlined-basic"
                      variant="outlined"
                      name="SubTaskDescription"
                      value={state.SubTaskDescription}
                      onChange={(e) => handleChange(e)}
                    />
                    <ButtonContainer>
                      <ButtonGroup>
                        <StyledButton
                          onClick={() => {
                            updatedSubTask || updatedSubTask === 0
                              ? updateSubTask("", updatedSubTask, "update")
                              : AddSubTask();
                          }}
                          className="create m"
                        >
                          {updatedSubTask || updatedSubTask === 0
                            ? t("Update")
                            : t("Save")}
                        </StyledButton>
                        <StyledButton
                          className="cancel"
                          onClick={() => {
                            // setSubTask(false);
                            cancelSubTask();
                          }}
                        >
                          {t("Cancel")}
                        </StyledButton>
                      </ButtonGroup>
                    </ButtonContainer>
                  </SubTaskBlock>
                ) : null}
                {state.SubTaskList.map((i, index) => (
                  <CheckboxContainer>
                    <RoundedCheckbox
                      checked={i.is_completed}
                      onChange={(e) => handleDetailCheckBox(e, index)}
                      label={i.Description}
                      is_detail={true}
                      index={index}
                      name={index}
                    />
                    {/* <FormControlLabel
                      control={
                        <SubTaskCheckbox
                          checked={i.is_completed}
                          onChange={(e) => {
                            handleDetailCheckBox(e, index);
                          }}
                        />
                      }
                      label={i.Description}
                    /> */}
                    <SubTaskEditIcon
                      className="close-modal"
                      onClick={() => updateSubTask(i, index, "view")}
                    />
                    <SubTaskCloseIcon
                      className="close-modal"
                      onClick={() => removeCheckBox(i)}
                    />
                  </CheckboxContainer>
                ))}
              </Block>
              <Block className="right block-2">
                <TopBoxContainer>
                  <StatusContainer>
                    <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      {t("Status")}
                    </InputLabel>

                    <StatusSelect state={state} setState={setState} />
                  </StatusContainer>
                  {MemberType != "member" ? (
                    <RoundedCheckbox
                      checked={state.TaskConfermation}
                      onChange={handleCheckBox}
                      name={"taskconfermation"}
                      label={t("Task Confirmation")}
                      index={0}
                      is_detail={false}
                    />
                  ) : null}
                </TopBoxContainer>
                <DetailsContainer>
                  <InputLabel
                    style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                  >
                    {t("Details")}
                  </InputLabel>
                  <DetailBlock>
                    <DetailLabel>{t("Project")}</DetailLabel>
                    <ProjectNameText>{ProjectName}</ProjectNameText>
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>@{t("Assignee")}</DetailLabel>
                    {showAssigneeSelect && MemberType != "member" ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={reporterList ? reporterList : []}
                        getOptionLabel={(option) => option.username || ""}
                        sx={{ width: 280 }}
                        // onInputChange={(event, value, reason) => {
                        //   if (reason === "input") {
                        //     onSearchUsers(value, event);
                        //   }
                        // }}
                        onChange={(e, v) => handleSelectChange("AssignerID", v)}
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          reporterList && state.AssignerID
                            ? reporterList[
                                get_Userindex(reporterList, state.AssignerID)
                              ]
                            : ""
                        }
                      />
                    ) : (
                      <UnassignText
                        onClick={() => {
                          setAssigneeSelect(true);
                        }}
                      >
                        {state.AssigneeName ? state.AssigneeName : username}
                      </UnassignText>
                    )}
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>@{t("Reporter")}</DetailLabel>

                    {showReporterSelect ? (
                      <CustomeAutocomplete
                        // disablePortal
                        size="small"
                        id="combo-box-demo"
                        options={reporterList ? reporterList : []}
                        getOptionLabel={(option) => option.username || ""}
                        sx={{ width: 280 }}
                        // onInputChange={(event, value, reason) => {
                        //   if (reason === "input") {
                        //     onSearchUsers(value, event);
                        //   }
                        // }}
                        onChange={(e, v) =>
                          handleSelectChange("ReportUserID", v)
                        }
                        renderInput={(params) => (
                          <TextField size="small" {...params} />
                        )}
                        value={
                          reporterList && state.ReportUserID
                            ? reporterList[
                                get_Userindex(reporterList, state.ReportUserID)
                              ]
                            : ""
                        }
                      />
                    ) : (
                      [
                        <Avatar
                          style={{
                            height: "25px",
                            fontSize: "13px",
                            width: "25px",
                            marginRight: "10px",
                          }}
                          {...stringAvatar(
                            state.ReporterName ? state.ReporterName : "Reporter"
                          )}
                        />,
                        <DetailLabel
                          onClick={() => {
                            setReporterSelect(true);
                          }}
                        >
                          {state.ReporterName ? state.ReporterName : "Reporter"}
                        </DetailLabel>,
                      ]
                    )}
                  </DetailBlock>

                  <DetailBlock>
                    <DetailLabel>{t("Priority")}</DetailLabel>
                    <PrioritySelect state={state} setState={setState} />
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>{t("Due Date")}</DetailLabel>

                    <DateText>
                      {day} {month} {year}
                    </DateText>
                    <DateInputContainer>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <DatePicker
                          label="Basic example"
                          value={selectedDate}
                          onChange={handleDateChange}
                          animateYearScrolling
                          inputRef={dateRef}
                          format="dd/MM/yyyy"
                        />
                      </MuiPickersUtilsProvider>
                    </DateInputContainer>
                    <StyledEditIcon onClick={() => handleDateChangeRef()} />
                  </DetailBlock>
                </DetailsContainer>
                <ButtonGroup name="save_buttons">
                  <StyledButton className="create m" onClick={SaveTask}>
                    {t("Save")}
                  </StyledButton>
                  <StyledButton className="cancel" onClick={clearState}>
                    {t("Clear")}
                  </StyledButton>
                </ButtonGroup>
              </Block>
              <StyledCloseIcon
                className="close-modal"
                onClick={() => setOpen(false)}
              />
            </BlockContainer>
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
}

const ProjectNameText = styled.p`
  color: #00536d;
`;

const SubTaskCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: #12368c;
  }
`;

const CustomeAutocomplete = styled(Autocomplete)`
  button {
    padding: 0;
  }
`;
const SubTaskEditIcon = styled(EditIcon)`
  margin-right: 2px;
  /* &.close-modal {
    position: absolute;
    top: 15px;
    right: 15px;
  } */
  cursor: pointer;
`;
const SubTaskCloseIcon = styled(CloseIcon)`
  /* &.close-modal {
    position: absolute;
    top: 15px;
    right: 15px;
  } */
  cursor: pointer;
`;
const TaskNameText = styled(TextField)`
  width: 85%;
  .MuiInputBase-root {
    font-size: 16px;
  }
  .MuiFormLabel-root.Mui-focused {
    color: #8d8d8d;
    font-size: 13px;
  }
  .MuiInput-underline:after {
    border-bottom: 1px solid #12368c;
  }
  .MuiInput-underline:hover:not(.Mui-disabled):before {
    border-bottom: 1px solid #12368c;
  }
`;

const SubTaskBlock = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  /* max-height: 600px;
  overflow-y: scroll;
  padding: 15px; */
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
  }
`;

const CustomeCheckbox = styled(Checkbox)`
  .MuiSvgIcon-root {
    color: green;
  }
`;

const UnassignText = styled.p`
  font: italic normal normal 12px/18px Poppins;
  color: #848484;
`;

const StyledInput = styled.input`
  width: 100%;
  padding: 5px;
`;

const AvatarContainer = styled.div`
  font-size: 10px;
  margin-bottom: 20px;
  &.member {
    padding: 10px;
  }

  display: flex;
  & .MuiAvatar-root.MuiAvatar-circular.MuiAvatar-colorDefault {
    height: 30px !important;
    width: 30px !important;
    font-size: 14px;
  }
`;

const TopBoxContainer = styled.div`
  display: flex;
  gap: 15px;
  align-items: flex-end;
`;
const CheckboxContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  svg.MuiSvgIcon-root {
    font-size: 1.2rem;
  }
  .MuiTypography-root.MuiFormControlLabel-label.MuiTypography-body1 {
    font-size: 11px;
    color: #000;
    font-weight: bold;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
  ${({ name }) =>
    name === "save_buttons" &&
    `
    justify-content: flex-end;
    margin-top: 10px;
  `}
`;

const AttachmentListContainer = styled.div`
  && {
    background: #f3f3f3;
    padding: 10px;
    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    display: flex;
    justify-content: space-around;
    border-radius: 2px;
    margin-bottom: 10px;
  }
`;
const AttachmentLeftTitle = styled.div`
  width: 30%;
  color: #12368c;
`;
const AttachmentRightTitle = styled.div`
  display: flex;
  justify-content: space-between;
  width: 50%;
  p {
    cursor: pointer;
  }
  p:nth-child(1) {
    color: #128c16;
  }
  p:last-child {
    color: #8e1906;
  }
`;

const ButtonContainer = styled.div`
  margin-top: 6px;
  margin-bottom: 6px;
  display: flex;
  justify-content: space-between;
`;

const FileName = styled.span`
  /* margin-right: 5px; */
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 15px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const StyledTextField = styled(TextField)`
  && {
    margin-top: 6px;
    outline: unset;
  }
  .MuiOutlinedInput-input.MuiInputBase-input.MuiInputBase-inputMultiline {
    height: 40px !important;
    overflow-y: scroll !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
  .MuiInputBase-multiline {
    padding: 6px 10px 7px !important;
    height: 58px;
    font-size: 13px;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d5d5d5 !important;
  }
  .css-8ewcdo-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-width: 1px !important;
  }
`;

const Container = styled.div``;
const BlockContainer = styled.div`
  display: flex;
  margin-top: 10px;
  justify-content: space-between;
  position: relative;
`;
const Block = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #8d8d8d;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  max-height: 600px;
  overflow-y: scroll;
  padding: 0px 18px 0px 0px;
  /* padding: 15px; */
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow: auto;
    padding: 0px 0px 0px 0px;
  }
`;
const StyledCloseIcon = styled(CloseIcon)`
  &.close-modal {
    position: absolute;
    top: -64px;
    right: -2px;
  }
  cursor: pointer;
`;
const CommentListContainer = styled.div``;

const CommentContainer = styled.div``;
const NameText = styled.p`
  font-weight: bold;
  margin-right: 5px;
`;
const UserDetailsContainer = styled.div`
  display: flex;
  margin-bottom: 3px;
`;
const TimeText = styled.p`
  margin-right: 5px;
  color: #8d8d8d;
`;
const StatusText = styled.p`
  color: #8d8d8d;
`;
const CommentText = styled.p`
  color: #363636;
  margin-bottom: 3px;
`;
const StatusContainer = styled.div``;

const DetailsContainer = styled.div``;

const DetailBlock = styled.div`
  background: #f3f3f3;
  padding: 10px;
  height: 44px;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
`;

const DetailLabel = styled.p`
  width: 100px;
`;

const ProgressContainer = styled.div`
  padding: 10px;
  background: #f3f3f3;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 7px;
    background: #c8c8c8;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const SaveButtonContainer = styled.div`
  text-align: right;
  margin-top: 10px;
  position: absolute;
  right: 15px;
  bottom: 15px;
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  width: 100%;
`;
const ProgressLabel = styled.p``;
const ProgressRate = styled.p`
  color: #757575;
`;
const DateText = styled.p`
  color: #727272;
`;
const StyledEditIcon = styled(EditIcon)`
  cursor: pointer;
  margin-left: auto;
  transition: all 0.1s ease-in;
  &:hover {
    background: #ccc;
    transition: all 0.1s ease-in;
    border-radius: 3px;
  }
`;

const AddSubTaskContainer = styled(Button)`
  && {
    background: #e7ebf6;
    padding: 10px;
    height: 36px;
    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    justify-content: left;
    border-radius: 2px;
    svg {
      margin-right: 5px;
    }
  }
`;

function StatusSelect(props) {
  const [t] = useTranslation("common");
  const [work, setWork] = React.useState(
    props.state ? props.state.Status : "todo"
  );

  const handleChange = (event) => {
    setWork(event.target.value);
    props.setState({
      ...props.state,
      Status: event.target.value,
    });
  };
  const Container = styled.div`
    .borderless1 {
      border: none !important;
    }
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "todo" && `background: #e2e2e2; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"todo"} className="progress">
              {t("To Do")}
            </MenuItem>
            <MenuItem value={"progress"} className="progress">
              {t("In Progress")}
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              {t("Done")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function PrioritySelect(props) {
  const [t] = useTranslation("common");
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.Priority : "medium"
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      Priority: event.target.value,
    });
  };
  const Container = styled.div`
    .borderless1 {
      border: none !important;
    }
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"low"} className="progress">
              {t("Low")}
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              {t("Medium")}
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              {t("High")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

const DateInputContainer = styled.div`
  display: none;
`;
