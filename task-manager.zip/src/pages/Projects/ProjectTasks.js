import {
  Avatar,
  Box,
  Button,
  LinearProgress,
  linearProgressClasses,
  Menu,
} from "@mui/material";
import React from "react";
import styled from "styled-components/macro";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Divider from "@mui/material/Divider";
import CalendarViewWeekIcon from "@mui/icons-material/CalendarViewWeek";
import TableRowsOutlinedIcon from "@mui/icons-material/TableRowsOutlined";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { stringAvatar } from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import ListItemIcon from "@mui/material/ListItemIcon";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Tooltip from "@mui/material/Tooltip";
import PersonAdd from "@mui/icons-material/PersonAdd";
import Settings from "@mui/icons-material/Settings";
import Logout from "@mui/icons-material/Logout";
import ProjectTaskDrag from "./ProjectTaskDrag";
import { useTranslation } from "react-i18next";

const ProjectTasks = () => {
  const [t] = useTranslation("common");
  const [age, setAge] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [openTask, setOpenTask] = React.useState(false);
  const [showProjectTasks, setProjectTasks] = React.useState("table");

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  function createData(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein };
  }

  return (
    <Container>
      <Header>
        <LeftHeader>
          <Heading>t{("Project Tasks")}</Heading>

          <ListType>
            <Box
              sx={{
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                width: "fit-content",
                border: (theme) => `1px solid ${theme.palette.divider}`,
                borderRadius: 1,
                bgcolor: "background.paper",
                color: "text.secondary",
                "& svg": {
                  m: 1,
                },
                "& hr": {
                  mx: 0.5,
                },
              }}
            >
              <TableRowsOutlinedIcon onClick={() => setProjectTasks("table")} />
              <Divider orientation="vertical" flexItem />
              <CalendarViewWeekIcon onClick={() => setProjectTasks("grid")} />
            </Box>
          </ListType>
          <FilterContainer>
            <FilterLabel>Filter:</FilterLabel>
            <StyledSelect>
              <FormControl fullWidth>
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  onChange={handleChange}
                >
                  <MenuItem value={10}>All</MenuItem>
                  <MenuItem value={20}>Medium</MenuItem>
                  <MenuItem value={30}>Low</MenuItem>
                </Select>
              </FormControl>
            </StyledSelect>
          </FilterContainer>
        </LeftHeader>
        <RightHeader>
          <CreateButton onClick={() => setOpen(true)}>Create</CreateButton>
        </RightHeader>
      </Header>
      <ProjectName>Project Name</ProjectName>
      {showProjectTasks === "table" ? (
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Task Title</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>@Assignee</TableCell>
                <TableCell>Due Date</TableCell>
                <TableCell>Priority</TableCell>
                <TableCell>@Reporter</TableCell>
                <TableCell>Progress</TableCell>
                <TableCell></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  hello world
                </TableCell>
                <TableCell>
                  <ProgressSelect />
                </TableCell>
                <TableCell>
                  <DetailBlock>
                    <Avatar
                      style={{
                        height: "35px",
                        width: "35px",
                        marginRight: "10px",
                      }}
                      {...stringAvatar("Savad Farooque")}
                    />
                    <DetailLabel>Savad Farooque</DetailLabel>
                  </DetailBlock>
                </TableCell>
                <TableCell>
                  <ColoredDate className="red">09 March 2022</ColoredDate>
                </TableCell>
                <TableCell>
                  <PrioritySelect />
                </TableCell>
                <TableCell>
                  <DetailBlock>
                    <Avatar
                      style={{
                        height: "35px",
                        width: "35px",
                        marginRight: "10px",
                      }}
                      {...stringAvatar("Savad Farooque")}
                    />
                    <DetailLabel>Savad Farooque</DetailLabel>
                  </DetailBlock>
                </TableCell>
                <TableCell>
                  <ProgressBarContainer>
                    <ProgressTextContainer>
                      <ProgressRate>30%</ProgressRate>
                    </ProgressTextContainer>
                    <BorderLinearProgress
                      size="small"
                      variant="determinate"
                      value={30}
                    />
                  </ProgressBarContainer>
                </TableCell>
                <TableCell>
                  <DropDownMenu />
                </TableCell>
              </TableRow>
              {/* next row */}
              <TableRow
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  hello world
                </TableCell>
                <TableCell>
                  <ProgressSelect />
                </TableCell>
                <TableCell>
                  <UnassignedText>Unassigned</UnassignedText>
                </TableCell>
                <TableCell>
                  <ColoredDate className="blue">09 March 2022</ColoredDate>
                </TableCell>
                <TableCell>
                  <PrioritySelect />
                </TableCell>
                <TableCell>
                  <DetailBlock>
                    <Avatar
                      style={{
                        height: "35px",
                        width: "35px",
                        marginRight: "10px",
                      }}
                      {...stringAvatar("Savad Farooque")}
                    />
                    <DetailLabel>Savad Farooque</DetailLabel>
                  </DetailBlock>
                </TableCell>
                <TableCell>
                  <ProgressBarContainer>
                    <ProgressTextContainer>
                      <ProgressRate>30%</ProgressRate>
                    </ProgressTextContainer>
                    <BorderLinearProgress
                      size="small"
                      variant="determinate"
                      value={30}
                    />
                  </ProgressBarContainer>
                </TableCell>
                <TableCell>
                  <DropDownMenu />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      ) : (
        <ProjectTaskDrag />
      )}
    </Container>
  );
};

const ColoredDate = styled.p`
  &.red {
    color: #f10000;
  }
  &.blue {
    color: #12368c;
  }
`;
const UnassignedText = styled.div`
  color: #848484;
  font: italic normal normal 14px/17px Poppins;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const Container = styled.div``;
const LeftHeader = styled.div`
  display: flex;
  align-items: center;
`;
const Heading = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-right: 10px;
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #edeff3;
  padding: 0 0 0 8px;
  background: #fff;
  border-radius: 3px;
`;
const StyledSelect = styled.div`
  min-width: 120px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
const FilterLabel = styled.div`
  font-size: 16px;
`;
const RightHeader = styled.div``;
const CreateButton = styled(Button)`
  && {
    background: #12368c;
    color: #fff;
    border-radius: 2px;
    padding: 5px 20px;
    text-transform: capitalize;
    &:hover {
      background: #5073c7;
    }
  }
`;
const ListType = styled.div`
  margin-right: 10px;
`;
const ProjectName = styled.p`
  font-size: 16px;
  color: #5e5e5e;
  font-weight: bold;
  margin-bottom: 10px;
`;

const DetailBlock = styled.div`
  margin-bottom: 10px;
  display: flex;
  align-items: center;
`;

const ProgressBarContainer = styled.div`
  width: 100%;
  margin-right: 5px;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 3px;
    background: #c6c6c6;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #8c1212;
  }
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  width: 100%;
`;

const ProgressRate = styled.p`
  color: #757575;
`;

const DetailLabel = styled.p``;

export default ProjectTasks;

function ProgressSelect() {
  const [work, setWork] = React.useState("");

  const handleChange = (event) => {
    setWork(event.target.value);
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"progress"} className="progress">
              In Progress
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              Done
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function PrioritySelect() {
  const [work, setWork] = React.useState("");

  const handleChange = (event) => {
    setWork(event.target.value);
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 2px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }}>
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"progress"} className="progress">
              In Progress
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              Done
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function DropDownMenu() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Tooltip title="Account settings">
        <IconButton
          onClick={handleClick}
          size="small"
          sx={{ ml: 2 }}
          aria-controls={open ? "account-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
        >
          <MoreVertIcon />
        </IconButton>
      </Tooltip>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem>Edit</MenuItem>
        <MenuItem>Delete</MenuItem>
      </Menu>
    </React.Fragment>
  );
}
