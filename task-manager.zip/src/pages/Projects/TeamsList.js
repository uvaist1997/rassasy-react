import React, { useState } from "react";

import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import styled from "styled-components/macro";
import Avatar from "@mui/material/Avatar";

import { styled as styles } from "@mui/material/styles";

import {
  Autocomplete,
  Box,
  LinearProgress,
  linearProgressClasses,
  TextField,
} from "@mui/material";
import { Button } from "@mui/material";
import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
import AddTeam from "./AddTeam";

function TeamList({ showList }) {
  const [state, setState] = useState({
    data: ["uvais", "jasmal", "abhi"],
  });

  const [addmember, setAddMember] = useState(false);
  const [memList, setMemList] = useState({
    data: [
      {
        name: "Team1",
        progressValue: 30,
      },
      {
        name: "Team2",
        progressValue: 90,
      },
      {
        name: "Team3",
        progressValue: 90,
      },
      {
        name: "Team4",
        progressValue: 50,
      },
      {
        name: "Team5",
        progressValue: 20,
      },
      {
        name: "Team6",
        progressValue: 80,
      },
      {
        name: "Team6",
        progressValue: 80,
      },
      {
        name: "Team6",
        progressValue: 80,
      },
      {
        name: "Team6",
        progressValue: 80,
      },
    ],
  });

  const [open, setOpen] = useState(false);
  return (
    <MembersAvtarPopup showList={showList}>
      <MemberHead>
        <MemberTxt>Team</MemberTxt>

        <AddButton onClick={() => setOpen(!open)}>+ Add Team</AddButton>
      </MemberHead>
      <SeachBoxContainer>
        <Box
          component="form"
          sx={{
            "& > :not(style)": { width: "100% " },
          }}
          noValidate
          autoComplete="off"
        >
          <TextBox
            id="outlined-basic"
            variant="outlined"
            placeholder="Search..."
          />
        </Box>
      </SeachBoxContainer>
      {/* ///Avatar List==============================||||||||||||||||||| */}
      <Lists
        dense
        sx={{ width: "100%", maxWidth: 360, bgcolor: "background.paper" }}
      >
        {memList.data.map((i) => {
          return (
            <ListItem key={i.progressValue} disablePadding>
              <ListItemButton
                style={{ paddingLeft: " 8px", paddingRight: " 8px" }}
              >
                <ListItemAvatars>
                  <Avatar
                    alt={`Avatar n°${i + 1}`}
                    src={`https://www.thenewsminute.com/sites/default/files/styles/news_detail/public/RashmikaMandanna_Smiling_221120_1200_DN.jpg?itok=oDSUikQw/${
                      i + 1
                    }.jpg`}
                  />
                </ListItemAvatars>
                <ListContainer>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      width: "100%",
                    }}
                  >
                    <ListItemText
                      style={{
                        width: "100%",
                        marginTop: "6px",
                        marginBottom: "1px",
                      }}
                      primary={i.name}
                    />
                    <ListItemText
                      style={{
                        marginTop: "6px",
                        marginBottom: "1px",
                      }}
                    >
                      <ProgressPercentage>
                        {i.progressValue}%
                      </ProgressPercentage>
                    </ListItemText>
                  </div>
                  <ListItemText>
                    <ProgressValueContainer>
                      <ProgressContainer>
                        <BorderLinearProgress
                          size="small"
                          variant="determinate"
                          value={i.progressValue}
                        />
                      </ProgressContainer>
                    </ProgressValueContainer>
                  </ListItemText>
                </ListContainer>
              </ListItemButton>
            </ListItem>
          );
        })}
      </Lists>

      <AddTeam open={open} setOpen={setOpen} />

      {/* <AddmemberPopupContainer addMember={addmember}>
        <AddMemberHeader>
          <AddMemberText>Add Member</AddMemberText>
          <RoundCheckBoxAdd>
            <RoundedCheckbox
              name={"addasadmin"}
              label={"Add as Admin"}
              checked={true}
            />
          </RoundCheckBoxAdd>
        </AddMemberHeader>

        <SelectBoxContainer>
          <UserText>User</UserText>
          <CustomeAutocomplete1
            size="small"
            id="combo-box-demo"
            options={state.data}
            // getOptionLabel={(option) => option.username || ""}
            onInputChange={(event, value, reason) => {}}
            renderInput={(params) => (
              <TextField size="small" {...params} placeholder="member name" />
            )}
          />
        </SelectBoxContainer>

        <CancelButtonContainer>
          <CancelButton onClick={() => setAddMember(false)} className="create">
            Cancel
          </CancelButton>

          <StyledButton onClick={() => setAddMember(false)} className="create">
            Add
          </StyledButton>
        </CancelButtonContainer>
      </AddmemberPopupContainer> */}
    </MembersAvtarPopup>
  );
}

export default TeamList;
const ListItemAvatars = styled(ListItemAvatar)`
  && {
    min-width: 34px !important;
    .css-1wlk0hk-MuiAvatar-root {
      width: 26px !important;
      height: 26px !important;
    }
  }
`;
const SeachBoxContainer = styled.div`
  margin-top: 8px;
  width: 100%;
  .MuiBox-root {
    border-color: #fff !important;
  }
  .MuiOutlinedInput-notchedOutline {
    border: unset !important;
    border-width: 1px !important ;
    outline: unset !important;
  }
`;
const TextBox = styled(TextField)`
  background-color: #ececec;
  outline: unset !important;

  .MuiOutlinedInput-input {
    padding: 7px 15px !important;
    font-size: 12px;
  }
  &.fieldset {
    border: unset;
    border-color: #fff !important ;
  }
`;

const AddMemberHeader = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const AddMemberText = styled.h3`
  font-weight: bold;
  font-size: 12px;
  letter-spacing: 1px; ;
`;
const RoundCheckBoxAdd = styled.div`
  display: flex;

  label {
    font-size: 11px !important;
    font-weight: unset !important;
  }
`;
const SelectBoxContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 5px;
`;
const UserText = styled.span`
  color: #8f8f8f;
  margin-left: 2px;
`;
const CancelButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
`;
const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }


  } &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }

  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;
const CancelButton = styled(StyledButton)`
  && {
    background-color: #d5e2ef !important;
    color: #2b2b2b !important;
  }
`;
const AddmemberPopupContainer = styled.div`
  position: absolute;
  background-color: white;

  width: 94%;
  top: 30px;
  z-index: 3;
  padding: 10px;
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  margin-top: 3px;
  transition: transform 0.3s ease-in-out;
  display: ${({ addMember }) => (addMember ? "" : "none")};
`;
const CustomeAutocomplete = styled(Autocomplete)`
  && {
    /* width: 150px; */
    margin-top: unset !important;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    outline: unset !important ;
    border-color: #ffffff !important;
    border-width: 1px !important;
    z-index: 2;
    border-radius: 2px !important;
  }

  button {
    padding: 0;
  }
  .css-19qh8xo-MuiInputBase-input-MuiOutlinedInput-input {
    height: 1rem !important;
    font-size: 12px !important;
  }
  .MuiFormControl-fullWidth {
    margin-top: 10px;
    background-color: #ececec;
  }
`;

const CustomeAutocomplete1 = styled(CustomeAutocomplete)`
  .MuiFormControl-fullWidth {
    margin-top: unset;
  }
`;
const ProgressPercentage = styled.span`
  color: #6b6b6b;
  font-size: 10px;
`;
const ListContainer = styled.div`
  width: 100%;
`;
const ProgressValueContainer = styled.div`
  width: 100%;
`;
const ProgressContainer = styled.div`
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 4px;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,

  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));

const Lists = styled(List)`
  && {
    overflow-y: scroll;
    max-height: 307px;
    ::-webkit-scrollbar {
      display: none;
    }
    .css-2s90m6-MuiAvatar-root {
      width: 29px !important;
      height: 29px !important;

      font-size: 1rem !important;
    }

    .css-et1ao3-MuiTypography-root {
      font-size: 12px !important;
    }
  }
`;
const AddButton = styled.span`
  font-size: 13px;
  color: #12368c;
  position: relative;
  cursor: pointer;
`;
const MemberHead = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
const MembersAvtarPopup = styled.div`
  border: 1px solid #d5d5d5;
  border-radius: 2px;
  z-index: 1;
  width: 311px;
  position: absolute;
  bottom: 50px;

  padding: 10px;
  background-color: white;

  display: ${({ showList }) => (showList ? "" : " none")};
`;
const MemberTxt = styled.span`
  font-size: 13px;
  color: #002272;
  font-weight: bold;
`;
