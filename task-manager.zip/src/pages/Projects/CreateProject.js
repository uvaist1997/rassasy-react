import React, { useRef, useState, useEffect, useContext } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";

import { DataContext } from "../../components/Context1";
import {
  alpha,
  Autocomplete,
  Avatar,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  Menu,
  MenuItem,
  Select,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import {
  date_time_diff_in_mint,
  getCookie,
  get_date,
  get_username,
  stringAvatar,
  string_to_datetime,
  today_date,
  today_datetime,
  debugBase64,
  download,
  convert_url_to_file,
  convert_url_to_blob,
  fileDownload,
  sortArrayWithDate,
  date_monthName_format,
  Dowunload_debugBase64,
  toDataURL,
  URLtoFile,
} from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import styled from "styled-components/macro";

import EditIcon from "@mui/icons-material/Edit";
import DateFnsUtils from "@date-io/date-fns";
import { DatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import "animate.css";
import Tooltip from "@mui/material/Tooltip";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import IconButton from "@mui/material/IconButton";
import { ProjectComments } from "../../functions/API_Call_functions";
import { RiDeleteBin2Fill } from "react-icons/ri";
// import RoundedCheckbox from "../Tasks/RoundedCheckbox";
import DeleteIcon from "@mui/icons-material/Delete";
import RoundedCheckbox from "../../components/RoundedCheckbox/RoundedCheckbox";
import {
  projectCreateUrl,
  projectDeleteUrl,
  projectEditUrl,
} from "../../api/ProjectsAPI";
import { ACCOUNTS_API_URL, BASE_URL, MEDIA_URL } from "../../settings";
import { useLocation, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import validator from "validator";
import Paper from "@material-ui/core/Paper";
import MembersList from "./MembersList";
import TeamList from "./TeamsList";

const image_root = window.location.origin;

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 831,
  bgcolor: "background.paper",
  borderRadius: "3px",

  boxShadow: 24,
  p: 2,
};

const access = getCookie("VBID");

export default function CreateProject(props) {
  const { showMemberList, showTeamList } = useContext(DataContext);

  const [showPopup, setShowPopup] = showMemberList;
  const [showList, setShowList] = showTeamList;
  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;

  const [t] = useTranslation("common");
  let type = props.type;
  let open = props.open;
  let setOpen = props.setOpen;
  const navigate = useNavigate();
  const _ = require("lodash");
  const { username, photo, user_id } = useSelector((state) => state.user);
  const [selectedDate, handleDateChange] = useState(new Date());
  let due_date = date_monthName_format(selectedDate);
  const [commentID, setcommentID] = React.useState(null);
  const ref = useRef(null);
  const [state, setState] = React.useState({
    ProjectID: "",
    ProjectName: "",
    Description: "",
    Status: "todo",
    CreatedBy: username,
    Priority: "medium",
    DueDate: get_date(selectedDate),
    Progress: 0,
    fileName: "",
    fileList: [],
    CommentList: [],
    usersList: [],
    MemberList: [],
    SearchList: [],
    DocumentList: [],
    is_update: false,
    HistoryList: [],
    EditDescription: "",
    form_errors: {
      ProjectName: "",
    },
    TaskConfermation: false,
    TrakPerformance: false,
    InvitedList: [],
    CreatedDate: "",
    addasadmin: false,
    member_added: false,
  });

  useEffect(() => {
    if (props.open) {
      setuserSearch("");
    }
  }, [props.open]);

  setTimeout(async () => {
    const close = await document.getElementsByClassName(
      "MuiAutocomplete-clearIndicator"
    )[0];
    if (close) {
      close.addEventListener("click", () => {
        setuserSearch("");
      });
    }
  }, 100);

  useEffect(() => {
    setState({
      ...state,
      SearchList: state.MemberList,
    });
  }, [state.MemberList]);

  useEffect(() => {
    if (props.state.is_update === true && props.state.singleProject) {
      (async () => {
        let singleProject = props.state.singleProject;
        // let CreatedBy = await get_username(singleProject.CreatedUserID);
        let CreatedBy = singleProject.CreatedBy;
        let dateObj = new Date(singleProject.DueDate);
        handleDateChange(dateObj);
        // setState((prevState) => {
        //   return {
        //     ...prevState,
        //     ProjectID: singleProject.id,
        //     ProjectName: singleProject.ProjectName,
        //     Description: singleProject.Description,
        //     Status: singleProject.Status,
        //     MemberList: singleProject.MemberList,
        //     DocumentList: singleProject.DocumentList,
        //     CreatedBy,
        //     Priority: singleProject.Priority,
        //     DueDate: singleProject.DueDate,
        //     CommentList: singleProject.CommentList,
        //     HistoryList: singleProject.HistoryList,
        //     is_update: true,
        //     Progress: singleProject.Progress,
        //     TaskConfermation: singleProject.TaskConfermation,
        //     TrakPerformance: singleProject.TrakPerformance,
        //     CreatedDate: singleProject.CreatedDate,
        //   };
        // });

        let fileArr = [];
        singleProject.DocumentList.map(async (item, index) => {
          // *** Calling both function ***
          let url = MEDIA_URL + item.DocFile;
          let file = await toDataURL(url).then((dataUrl) => {
            var fileData = URLtoFile(dataUrl, item.name);
            return fileData;
          });
          fileArr.push(file);
          if (index === singleProject.DocumentList.length - 1) {
            setState((prevState) => {
              return {
                ...prevState,
                ProjectID: singleProject.id,
                ProjectName: singleProject.ProjectName,
                Description: singleProject.Description,
                Status: singleProject.Status,
                MemberList: singleProject.MemberList,
                DocumentList: fileArr,
                CreatedBy,
                Priority: singleProject.Priority,
                DueDate: singleProject.DueDate,
                CommentList: singleProject.CommentList,
                HistoryList: singleProject.HistoryList,
                is_update: true,
                Progress: singleProject.Progress,
                TaskConfermation: singleProject.TaskConfermation,
                TrakPerformance: singleProject.TrakPerformance,
                CreatedDate: singleProject.CreatedDate,
              };
            });
          }
        });
        if (singleProject.DocumentList.length == 0) {
          // setTimeout(() => {
          setState((prevState) => {
            return {
              ...prevState,

              ProjectID: singleProject.id,
              ProjectName: singleProject.ProjectName,
              Description: singleProject.Description,
              Status: singleProject.Status,
              MemberList: singleProject.MemberList,
              DocumentList: [],
              CreatedBy,
              Priority: singleProject.Priority,
              DueDate: singleProject.DueDate,
              CommentList: singleProject.CommentList,
              HistoryList: singleProject.HistoryList,
              is_update: true,
              Progress: singleProject.Progress,
              TaskConfermation: singleProject.TaskConfermation,
              TrakPerformance: singleProject.TrakPerformance,
              CreatedDate: singleProject.CreatedDate,
            };
          });
          // }, 50);
        }
        if (singleProject.is_view === false) {
          console.log("-------------------------------------->");
          console.log(singleProject.is_view);
          const notificationResponse = await fetch(
            `${BASE_URL}general/view-notification`,
            {
              method: "POST",
              headers: {
                "content-type": "application/json",
                Authorization: `Bearer ${access}`,
                accept: "application/json",
              },
              body: JSON.stringify({
                UserID: user_id,
                ProjectID: singleProject.id,
                name: "project",
              }),
            }
          ).then((response) => response.json());
          if (notificationResponse.StatusCode === 6000) {
            singleProject.is_view = true;
            setNotificationCount((prevState) => {
              return {
                ...prevState,
                project_notify: notificationCount.project_notify - 1,
              };
            });
          }
        }
        props.setState((prevState) => {
          return {
            ...prevState,
            is_update: false,
            singleProject,
          };
        });
        setOpen(true);
      })();
    }
  });

  const handleCheckBox = (event) => {
    setState((prevState) => {
      return {
        ...prevState,
        [event.target.name]: event.target.checked,
      };
    });
  };
  const handleEditClick = () => {
    ref.current.focus();
  };

  const handleClose = () => {
    setOpen(false);
  };
  let dateRef = useRef(null);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const openMenu = Boolean(anchorEl);
  const [showMenu, setMenu] = useState(false);
  const [showActivies, setActivites] = useState(1);
  const [showInvite, setInvite] = useState("");
  const [userSearch, setuserSearch] = useState("");
  const [emailError, setEmailError] = useState("");
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  const hiddenFileInput = React.useRef(null);
  const handleClickImg = (event) => {
    hiddenFileInput.current.click();
  };

  const handleChange = (e) => {
    if (e.target.name === "ProjectName") {
      let form_errors = { ...state.form_errors };
      form_errors["ProjectName"] = "";
      setState((prevState) => {
        return {
          ...prevState,
          [e.target.name]: e.target.value,
          form_errors,
        };
      });
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          [e.target.name]: e.target.value,
        };
      });
    }
  };

  const clearState = () => {
    handleDateChange(new Date());
    setcommentID(null);
    setState((prevState) => {
      return {
        ...prevState,
        ProjectName: "",
        Description: "",
        Status: "todo",
        CreatedBy: username,
        Priority: "medium",
        DueDate: get_date(selectedDate),
        Progress: 0,
        fileName: "",
        fileList: [],
        CommentList: [],
        HistoryList: [],
        usersList: [],
        MemberList: [],
        SearchList: [],
        DocumentList: [],
        is_update: false,
        comment: "",
        EditDescription: "",
        form_errors: {
          ProjectName: "",
        },
        TaskConfermation: false,
        TrakPerformance: false,
      };
    });
  };

  // const handleChangeImg = (event) => {
  //   const fileUploaded = event.target.files[0];
  //   let DocumentList = [...state.DocumentList];
  //   DocumentList.push(fileUploaded);
  //   setState((prevState) => {
  //     return {
  //       ...prevState,
  //       fileName: fileUploaded.name,
  //       fileList: fileUploaded,
  //       DocumentList,
  //     };
  //   });
  // };

  const handleChangeImg = (event) => {
    const fileUploaded = event.target.files[0];

    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: [...state.DocumentList, fileUploaded],
      };
    });
  };

  const handleRemoveImg = (file) => {
    setState((prevState) => {
      return {
        ...prevState,
        DocumentList: state.DocumentList.filter((i) => i !== file),
      };
    });
  };

  function readFile(file, file_type) {
    const reader = new FileReader();
    reader.addEventListener("load", (event) => {
      const result = event.target.result;
      // Check if the file is an image.
      if (file.type && !file.type.startsWith("image/")) {
        // e.g This will dowunload a file
        download(result);
      } else {
        if (file_type == "download") {
          // This will Download Base64 image in a new window
          Dowunload_debugBase64(result, file.name);
        } else {
          // This will View Base64 image in a new window
          debugBase64(result);
        }
      }
    });
    reader.readAsDataURL(file);
  }

  const handleDateChangeRef = () => {
    dateRef.current.click();
  };

  const AddCommand = async (e, type, id = "") => {
    if ((e.key === "Enter" && e.target.value) || type === "delete") {
      let unq_id = commentID;
      if (type === "delete") {
        unq_id = id;
      }
      let Description = e.target.value;
      let data = await ProjectComments(
        state.ProjectID,
        null,
        Description,
        type,
        access,
        unq_id
      );
      setState((prevState) => {
        return {
          ...prevState,
          CommentList: data,
          comment: "",
          EditDescription: "",
        };
      });
      setcommentID(null);
    } else {
      let comment = "";
      let EditDescription = "";
      if (type === "create") {
        comment = e.target.value;
      }
      if (type === "edit") {
        EditDescription = e.target.value;
      }
      setState((prevState) => {
        return {
          ...prevState,
          comment,
          EditDescription,
        };
      });
    }
  };

  useEffect(() => {
    if (commentID) {
      handleEditClick();
    }
  }, [commentID]);

  const changeComment = (e, id, description, name) => {
    if (name === "edit") {
      setState((prevState) => {
        return {
          ...prevState,
          EditDescription: description,
        };
      });
      setcommentID(id);
    } else if (name === "delete") {
      AddCommand(e, "delete", id);
    }
  };

  const onSearchUsers = async (val, e) => {
    setuserSearch(val);
    if (val) {
      const userListResponse = await fetch(
        `${ACCOUNTS_API_URL}api/v1/users/get-users/`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            username: val,
          }),
        }
      ).then((response) => response.json());
      if (userListResponse.StatusCode === 6000) {
        setInvite("");
        setState((prevState) => {
          return {
            ...prevState,
            usersList: userListResponse.data,
          };
        });
      } else {
        setInvite(val);
      }
    }
  };
  // outside click
  function useOutsideAlerter(ref) {
    if (
      ref.current &&
      ref.current.className !=
        "CreateProject__Block-sc-1vmvq5x-16 kEpKNS right block-2"
    ) {
      console.log(ref.current.className);
      useEffect(() => {
        /**
         * Alert if clicked on outside of element
         */
        function handleClickOutside(event) {
          if (ref.current && !ref.current.contains(event.target)) {
            setShowList(false);
            setShowPopup(false);
            // setOption(false);
            // alert("You clicked outside of me!");
          }
        }

        // Bind the event listener
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
          // Unbind the event listener on clean up
          document.removeEventListener("mousedown", handleClickOutside);
        };
      }, [ref]);
    }
  }
  const wrapperRef = useRef(null);
  useOutsideAlerter(wrapperRef);

  const addMember = (e, v, name) => {
    if (name === "member" && v) {
      let MemberList = [...state.MemberList];
      let foundObject = _.find(MemberList, function (e) {
        return e.MemberUserID === v.MemberUserID;
      });
      if (!foundObject) {
        if (state.addasadmin === true) {
          v.MemberType = "admin";
        }
        MemberList.push(v);
      }
      setState((prevState) => {
        return {
          ...prevState,
          MemberList: MemberList.reverse(),
          addasadmin: false,
          member_added: true,
        };
      });
      setMenu(!showMenu);
      // setShowPopup(!showPopup);
      setuserSearch("");
    }
  };

  const handleValidation = () => {
    let form_errors = {};
    let formIsValid = true;
    //ProjectName
    if (
      typeof state.ProjectName === "string" &&
      state.ProjectName.trim().length === 0
    ) {
      formIsValid = false;
      form_errors["ProjectName"] = "Cannot be empty";
    }

    setState((prevState) => {
      return {
        ...prevState,
        form_errors,
      };
    });

    return formIsValid;
  };

  const SaveProject = async () => {
    let is_valid = handleValidation();
    if (is_valid == true) {
      const formData = new FormData();
      let ProjectFile = "";
      if (state.fileList) {
        ProjectFile = state.fileList;
      }

      formData.append("TrakPerformance", state.TrakPerformance);
      formData.append("TaskConfermation", state.TaskConfermation);
      formData.append("ProjectName", state.ProjectName);
      formData.append("Description", state.Description);
      formData.append("Status", state.Status);
      formData.append("CreatedBy", state.CreatedBy);
      formData.append("Priority", state.Priority);
      formData.append("DueDate", get_date(selectedDate));
      formData.append("ProjectFile", ProjectFile);
      formData.append("MemberList", JSON.stringify(state.MemberList));
      formData.append("InvitedList", JSON.stringify(state.InvitedList));
      // formData.append("DocumentList", JSON.stringify(state.DocumentList));
      let DocumentList = state.DocumentList;
      DocumentList.map((i, index) => {
        let name = "image" + String(index);
        formData.append(name, i);
      });
      formData.append("DocumentList", state.DocumentList);
      // formData.append("MemberList", state.MemberList);
      if (state.is_update === false) {
        const Response = await fetch(projectCreateUrl, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
          },
          body: formData,
        }).then((response) => response.json());
        if (Response.StatusCode === 6000) {
          Swal.fire({
            title: "Project Created Successfully",
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
          props.setState((prevState) => {
            return {
              ...prevState,
              get_list: true,
            };
          });
          setOpen(false);
          clearState();
          if (state.InvitedList || state.MemberList.length) {
            let member_emails = _.map(state.MemberList, "email");
            SendMailInvitation(member_emails, state.InvitedList);
          }
        } else {
          Swal.fire({
            title: Response.message,
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
        }
      } else {
        const Response = await fetch(`${projectEditUrl}${state.ProjectID}`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${access}`,
            // "accept": "application/json"
          },
          body: formData,
        }).then((response) => response.json());
        if (Response.StatusCode === 6000) {
          Swal.fire({
            title: "Project Updated Successfully",
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
          props.setState((prevState) => {
            return {
              ...prevState,
              get_list: true,
            };
          });
          setOpen(false);
          clearState();
          if (state.InvitedList || state.MemberList.length) {
            SendMailInvitation(Response.new_member_emails, state.InvitedList);
          }
        } else {
          Swal.fire({
            title: "Project Updated Failed",
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
        }
      }
    }
  };

  // const removeMember = (UserID) => {
  //   let MemberList = [...state.MemberList];
  //   MemberList = _.remove(MemberList, function (i) {
  //     return i.UserID != UserID;
  //   });
  //   setState((prevState) => {
  //     return {
  //       ...prevState,
  //       MemberList,
  //     };
  //   });
  // };

  useEffect(() => {
    console.log(open);
    if (!open) {
      clearState();
    }
  }, [open]);

  const clickModalClose = () => {
    setShowPopup(false);
    setShowList(false);
    setOpen(false);
    // clearState();
  };
  let Activities = [];
  if (showActivies === 3) {
    Activities = state.HistoryList;
  } else if (showActivies === 2) {
    Activities = state.CommentList;
  } else {
    Activities = state.CommentList.concat(state.HistoryList);
  }
  Activities.sort(function (a, b) {
    let aDate = new Date(a.CreatedDate);
    let bDate = new Date(b.CreatedDate);

    if (aDate > bDate) return -1;
    if (aDate < bDate) return 1;
    return 0;
  });

  const DeleteProject = async () => {
    let ProjectID = state.ProjectID;
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const projectDeleteResponse = await fetch(
          `${projectDeleteUrl}${ProjectID}`,
          {
            method: "POST",
            headers: {
              "content-type": "application/json",
              Authorization: `Bearer ${access}`,
              accept: "application/json",
            },
            body: JSON.stringify({
              UserName: username,
            }),
          }
        ).then((response) => response.json());
        if (projectDeleteResponse.StatusCode === 6000) {
          Swal.fire("Deleted!", "Your Project has been deleted.", "success");
          setOpen(false);
          clearState();
          props.setState((prevState) => {
            return {
              ...prevState,
              get_list: true,
            };
          });
        } else {
          Swal.fire({
            title: "Project Deleted Failed",
            showClass: {
              popup: "animate__animated animate__fadeInDown",
            },
            hideClass: {
              popup: "animate__animated animate__fadeOutUp",
            },
          });
        }
      } else {
        console.log("cancelled");
      }
    });
  };

  const GotoMemberTask = (MemberUserID) => {
    if (
      state.ProjectID &&
      (user_member_type === "admin" || user_member_type === "owner")
    ) {
      navigate(`/tasks?m=${MemberUserID}`, {
        state: { ProjectID: state.ProjectID },
      });
    }
  };

  const InviteMember = async () => {
    if (validator.isEmail(userSearch)) {
      setuserSearch("");
      // setEmailError("Valid Email :)");
      let InvitedList = [...state.InvitedList];
      if (!InvitedList.includes(userSearch)) {
        InvitedList.push(userSearch);
      }
      setState((prevState) => {
        return {
          ...prevState,
          InvitedList,
        };
      });
    } else {
      setEmailError("Enter valid Email!");
      alert("Enter valid Email");
    }
  };

  const SendMailInvitation = async (MemberList, invited_mails) => {
    const mailResponse = await fetch(`${BASE_URL}general/send-mail`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        MemberList: MemberList,
        invited_mails: invited_mails,
      }),
    }).then((response) => response.json());
  };

  let Owner_ins = state.MemberList.filter((m) => m.MemberType === "owner")[0];
  let owner_id = null;
  if (Owner_ins) {
    owner_id = Owner_ins.MemberUserID;
  }
  let user_member_ins = state.MemberList.filter(
    (m) => m.MemberUserID === user_id
  )[0];
  let user_member_type = null;
  if (user_member_ins) {
    user_member_type = user_member_ins.MemberType;
  }
  let CreatedDate = new Date(state.CreatedDate);
  let CreadedON = date_monthName_format(CreatedDate);

  const Link = ({ children, ...other }) => (
    <Paper {...other}>
      {children}
      {showInvite ? (
        <LoyaltyCreate
          onMouseDown={(event) => {
            event.preventDefault();
          }}
          onClick={() => InviteMember()}
        >
          + {t("Invite")}
        </LoyaltyCreate>
      ) : null}
    </Paper>
  );
  return (
    <Container>
      <CreateModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box sx={style}>
            <ProjectNameContainer>
              <ProjectNameText
                fullWidth
                multiline
                focused
                id="standard-basic"
                label={t("Project Name")}
                variant="standard"
                name="ProjectName"
                value={state.ProjectName}
                onChange={(e) => handleChange(e)}
                error={state.form_errors.ProjectName}
                helperText={state.form_errors.ProjectName}
                disabled={
                  user_member_type === "owner" ||
                  user_member_type === "admin" ||
                  state.is_update === false
                    ? false
                    : true
                }
              />
              <Tooltip title="Close window">
                <StyledCloseIcon
                  className="close-modal"
                  onClick={() => clickModalClose()}
                />
              </Tooltip>
              {state.is_update && owner_id === user_id ? (
                <Tooltip title="Delete project">
                  <DeleteButton onClick={(e) => DeleteProject()} />
                </Tooltip>
              ) : null}
            </ProjectNameContainer>
            <BlockContainer>
              <Block className="left">
                <InputLabel
                  style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                >
                  {t("Description")}
                </InputLabel>
                <StyledTextField
                  fullWidth
                  multiline
                  id="outlined-basic"
                  variant="outlined"
                  name="Description"
                  value={state.Description}
                  onChange={(e) => handleChange(e)}
                  disabled={
                    user_member_type === "owner" ||
                    user_member_type === "admin" ||
                    state.is_update === false
                      ? false
                      : true
                  }
                />
                <ButtonContainer>
                  {/* <ButtonGroup>
                    <StyledButton className="create m" onClick={SaveProject}>
                      Save
                    </StyledButton>
                    <StyledButton className="cancel" onClick={clearState}>
                      Cancel
                    </StyledButton>
                  </ButtonGroup> */}
                  {user_member_type === "owner" ||
                  user_member_type === "admin" ||
                  state.is_update === false ? (
                    <ButtonGroup>
                      <FileName>{state.fileName}</FileName>
                      <StyledButton className="attach" onClick={handleClickImg}>
                        <AttachFileIcon />
                        {t("Attach")}
                      </StyledButton>
                      <input
                        type="file"
                        ref={hiddenFileInput}
                        onChange={handleChangeImg}
                        style={{ display: "none" }}
                        multiple
                      />
                    </ButtonGroup>
                  ) : null}
                </ButtonContainer>
                {state.DocumentList.map((i, index) => (
                  <AttachmentListContainer>
                    <AttachmentLeftTitle>{i.name}</AttachmentLeftTitle>
                    <AttachmentRightTitle>
                      <p
                        onClick={() => {
                          readFile(i, "view");
                        }}
                      >
                        {t("View")}
                      </p>
                      <p
                        onClick={() => {
                          readFile(i, "download");
                        }}
                      >
                        {t("Download")}
                      </p>
                      {user_member_type === "owner" ||
                      user_member_type === "admin" ||
                      state.is_update === false ? (
                        <p
                          onClick={() => {
                            handleRemoveImg(i);
                          }}
                        >
                          {t("Remove")}
                        </p>
                      ) : null}
                    </AttachmentRightTitle>
                  </AttachmentListContainer>
                ))}

                {state.is_update
                  ? [
                      <InputLabel
                        style={{
                          fontSize: 12,
                          marginTop: 10,
                          marginBottom: 5,
                        }}
                      >
                        {t("Activities")}
                      </InputLabel>,
                      <ButtonContainer>
                        <ButtonGroup>
                          <InputLabel
                            style={{
                              fontSize: 12,
                              display: "inline",
                              marginRight: 10,
                            }}
                          >
                            {t("Show")}:
                          </InputLabel>
                          <StyledButton
                            className={
                              showActivies === 1 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(1)}
                          >
                            {t("All")}
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 2 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(2)}
                          >
                            {t("Comments")}
                          </StyledButton>
                          <StyledButton
                            className={
                              showActivies === 3 ? "create m" : "attach m"
                            }
                            onClick={() => setActivites(3)}
                          >
                            {"History"}
                          </StyledButton>
                        </ButtonGroup>
                        {/* <ButtonGroup>
                          <StyledButton className="cancel">
                            Newest First
                            <CompareArrowsIcon className="arrow" />
                          </StyledButton>
                        </ButtonGroup> */}
                      </ButtonContainer>,

                      <CommentListContainer>
                        {showActivies != 3 ? (
                          <AvatarContainer>
                            <Avatar
                              style={{
                                height: "25px",
                                width: "25px",
                                marginRight: "10px",
                                fontSize: "13px",
                              }}
                              {...stringAvatar("Savad Farooque")}
                            />

                            <StyledInput
                              onKeyPress={(e) => AddCommand(e, "create")}
                              onChange={(e) => AddCommand(e, "create")}
                              value={state.comment}
                            />
                          </AvatarContainer>
                        ) : null}

                        {Activities
                          ? Activities.map((i) => (
                              <AvatarContainer>
                                <Avatar
                                  style={{
                                    height: "25px",
                                    width: "25px",
                                    marginRight: "10px",
                                    fontSize: "13px",
                                  }}
                                  {...stringAvatar("Savad Farooque")}
                                />
                                <CommentContainer>
                                  <UserDetailsContainer>
                                    <NameText>{i.name ? i.name : ""}</NameText>
                                    <TimeText>
                                      {date_time_diff_in_mint(
                                        string_to_datetime(i.CreatedDate),
                                        today_datetime()
                                      )}
                                    </TimeText>
                                    <StatusText>
                                      {i.Action === "A"
                                        ? t("created")
                                        : t("updated")}
                                    </StatusText>
                                  </UserDetailsContainer>
                                  {commentID === i.id ? (
                                    <StyledInput
                                      onKeyPress={(e) => AddCommand(e, "edit")}
                                      onChange={(e) => AddCommand(e, "edit")}
                                      value={state.EditDescription}
                                      ref={ref}
                                      name="EditDescription"
                                      id="EditDescription"
                                      focused
                                    />
                                  ) : (
                                    <CommentText>
                                      {i.Description ? i.Description : ""}
                                    </CommentText>
                                  )}

                                  {i.UserID === user_id &&
                                  i.type == "comments" ? (
                                    <ButtonGroup>
                                      <StyledButton
                                        className="edit"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "edit"
                                          )
                                        }
                                      >
                                        {t("Edit")}
                                      </StyledButton>
                                      <StyledButton
                                        className="delete"
                                        onClick={(e) =>
                                          changeComment(
                                            e,
                                            i.id,
                                            i.Description,
                                            "delete"
                                          )
                                        }
                                      >
                                        {t("Delete")}
                                      </StyledButton>
                                    </ButtonGroup>
                                  ) : null}
                                </CommentContainer>
                              </AvatarContainer>
                            ))
                          : null}
                      </CommentListContainer>,
                    ]
                  : null}
              </Block>

              <Block className="right block-2" ref={wrapperRef}>
                <TopBoxContainer>
                  <StatusContainer>
                    <InputLabel
                      style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                    >
                      {t("Status")}
                    </InputLabel>
                    <StatusSelect
                      state={state}
                      user_member_type={user_member_type}
                      setState={setState}
                    />
                  </StatusContainer>
                  <RoundedCheckbox
                    checked={state.TaskConfermation}
                    onChange={(e) => {
                      handleCheckBox(e);
                    }}
                    name={"TaskConfermation"}
                    label={t("Task Confirmation")}
                    index={0}
                    is_detail={false}
                    disabled={
                      user_member_type === "owner" ||
                      user_member_type === "admin" ||
                      state.is_update === false
                        ? false
                        : true
                    }
                  />
                </TopBoxContainer>
                <DetailsContainer>
                  <InputLabel
                    style={{ fontSize: 12, marginTop: 10, marginBottom: 5 }}
                  >
                    {t("Details")}
                  </InputLabel>
                  <DetailBlock>
                    <DetailLabel>{t("Created By")}</DetailLabel>
                    <Avatar
                      style={{
                        height: "25px",
                        width: "25px",
                        marginRight: "10px",
                        fontSize: "13px",
                      }}
                      {...stringAvatar(username)}
                    />

                    <DetailLabel>
                      {state.CreatedBy ? state.CreatedBy : username}
                    </DetailLabel>
                  </DetailBlock>
                  <DetailBlock>
                    <DetailLabel>{t("Priority")}</DetailLabel>
                    <PrioritySelect
                      state={state}
                      user_member_type={user_member_type}
                      setState={setState}
                    />
                  </DetailBlock>
                  {state.is_update === true ? (
                    <DetailBlock>
                      <DetailLabel>{t("Created On")}</DetailLabel>
                      <DateText>{CreadedON}</DateText>
                    </DetailBlock>
                  ) : null}
                  <DetailBlock>
                    <DetailLabel>{t("Due Date")}</DetailLabel>
                    <DateText>{due_date}</DateText>

                    <DateInputContainer>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <DatePicker
                          label="Basic example"
                          value={selectedDate}
                          onChange={handleDateChange}
                          animateYearScrolling
                          inputRef={dateRef}
                          format="dd/MM/yyyy"
                        />
                      </MuiPickersUtilsProvider>
                    </DateInputContainer>
                    {user_member_type === "owner" ||
                    user_member_type === "admin" ||
                    state.is_update === false ? (
                      <StyledEditIcon onClick={() => handleDateChangeRef()} />
                    ) : null}
                  </DetailBlock>
                </DetailsContainer>
                <ProgressContainer>
                  <ProgressTextContainer>
                    <ProgressLabel>{t("Progress")}</ProgressLabel>
                    <ProgressRate>
                      {Number(state.Progress).toFixed(2)}%
                    </ProgressRate>
                  </ProgressTextContainer>
                  <BorderLinearProgress
                    size="small"
                    variant="determinate"
                    value={state.Progress}
                  />
                </ProgressContainer>
                <MembersContainer>
                  {/* <MemberHeader>
                    <MemberHeading>{t("Members")}</MemberHeading>
                    {user_member_type === "owner" ||
                    user_member_type === "admin" ||
                    state.is_update === false ? (
                      <AddMemberButton onClick={() => setMenu(!showMenu)}>
                        + {t("Add Member")}
                      </AddMemberButton>
                    ) : null}
                  </MemberHeader> */}
                  <MemberHeader
                    onClick={() => {
                      setShowPopup(!showPopup);
                      setShowList(false);
                    }}
                  >
                    <>
                      <MemberHeading>{t("Members")} -</MemberHeading>
                      <DateText
                        style={{
                          marginRight: "auto",
                          marginLeft: "10px",
                        }}
                      >
                        {state.MemberList.length}
                      </DateText>
                    </>
                    <AddMemberButton
                      style={{
                        minWidth: "20px",
                        padding: "2px 6px",
                        color: "black",
                        fontSize: "1.5rem",
                        height: "26px",
                      }}
                    ></AddMemberButton>
                  </MemberHeader>{" "}
                  {/* <MemberHeader
                    onClick={() => {
                      setShowList(!showList);
                      setShowPopup(false);
                    }}
                  >
                    <>
                      <MemberHeading>{t("Teams")} -</MemberHeading>
                      <DateText
                        style={{
                          marginRight: "auto",
                          marginLeft: "10px",
                        }}
                      >
                        6
                      </DateText>
                    </>
                    <AddMemberButton
                      style={{
                        minWidth: "20px",
                        padding: "2px 6px",
                        color: "black",
                        fontSize: "1.5rem",
                        height: "26px",
                      }}
                    ></AddMemberButton>
                  </MemberHeader> */}
                  {/* {showMenu */}
                  {/* // <MemberHeader> */}
                  {/* <Autocomplete
                            // disablePortal
                            freeSolo={true}
                            size="small"
                            id="combo-box-demo"
                            options={state.usersList ? state.usersList : []}
                            getOptionLabel={(option) => option.user_email || ""}
                            sx={{ width: 280 }}
                            onInputChange={(event, value, reason) => {
                              if (reason === "input") {
                                onSearchUsers(value, event);
                              }
                            }}
                            inputValue={userSearch}
                            onChange={(e, v) => addMember(e, v, "member")}
                            renderInput={(params) => (
                              <TextField size="small" {...params} />
                            )}
                            PaperComponent={Link}
                          /> */}
                  {/* {showInvite ? (
                            <MemberInvite onClick={() => InviteMember()}>
                              Invite
                            </MemberInvite>
                          ) : null} */}
                  {/* // </MemberHeader>, */}
                  {/* // <EmailErrorP>{emailError}</EmailErrorP>, */}
                  {/* //   ] */}
                  {/* // : null} */}
                  {/* ///Members AVATAR =================popup */}
                  {/* <SearchSelect></SearchSelect> */}
                  <MembersList
                    showPopup={showPopup}
                    state={state}
                    setState={setState}
                    onSearchUsers={onSearchUsers}
                    addMember={addMember}
                    userSearch={userSearch}
                    setuserSearch={setuserSearch}
                    handleCheckBox={handleCheckBox}
                    InviteMember={InviteMember}
                    user_member_type={user_member_type}
                    GotoMemberTask={GotoMemberTask}
                  />
                  {/* <TeamList showList={showList} setOpen={setOpen} /> */}
                  {/* ================ Member List Maping ================== */}
                  {/* <MembersListContainer>
                    {state.MemberList.map((i) => (
                      <AvatarContainer className="member">
                        <Avatar
                          style={{
                            height: "35px",
                            width: "35px",
                            marginRight: "10px",
                          }}
                          {...stringAvatar(i.username)}
                        />
                        <ProgressListContainer>
                          <ProgressBarContainer>
                            <ProgressTextContainer>
                              <NameText
                                onClick={() => GotoMemberTask(i.MemberUserID)}
                              >
                                {i.username}
                                {i.MemberType === "owner" ||
                                i.MemberType === "admin" ? (
                                  <AdminImg src="../../images/administrator-solid.svg" />
                                ) : null}
                              </NameText>
                              <ProgressRate>
                                {Number(i.progress_rate).toFixed(2)}%
                              </ProgressRate>
                            </ProgressTextContainer>
                            <BorderLinearProgress
                              size="small"
                              variant="determinate"
                              value={i.progress_rate}
                            />
                          </ProgressBarContainer>
                          {user_member_type === "owner" ||
                          user_member_type === "admin" ||
                          state.is_update === false ? (
                            <DropDownMenu
                              state={state}
                              setState={setState}
                              UserID={i.MemberUserID}
                            />
                          ) : null}

                        </ProgressListContainer>
                      </AvatarContainer>
                    ))}
                  </MembersListContainer>
                */}
                </MembersContainer>
                <ButtonGroup name="save_buttons">
                  <MainRoundedCheckbox>
                    <RoundedCheckbox
                      checked={state.TrakPerformance}
                      onChange={(e) => {
                        handleCheckBox(e);
                      }}
                      name={"TrakPerformance"}
                      label={t("Track Performance")}
                      index={0}
                      is_detail={false}
                      disabled={
                        user_member_type === "owner" ||
                        user_member_type === "admin" ||
                        state.is_update === false
                          ? false
                          : true
                      }
                    />
                  </MainRoundedCheckbox>
                  {user_member_type === "owner" ||
                  user_member_type === "admin" ||
                  state.is_update === false
                    ? [
                        <StyledButton
                          className="create m"
                          onClick={SaveProject}
                        >
                          {t("Save")}
                        </StyledButton>,
                        <StyledButton className="cancel" onClick={clearState}>
                          {t("Clear")}
                        </StyledButton>,
                      ]
                    : null}
                </ButtonGroup>
                {/* <SaveButtonContainer>
                  <StyledButton className="create">Save</StyledButton>
                </SaveButtonContainer> */}

                {/* <MemberMenu
                  handleClick={handleClick}
                  handleMenuClose={handleMenuClose}
                  anchorEl={anchorEl}
                  open={openMenu}
                  state={state}
                  setState={setState}
                  showMenu={showMenu}
                /> */}
              </Block>
            </BlockContainer>
          </Box>
        </Fade>
      </CreateModal>
    </Container>
  );
}

const AttachmentListContainer = styled.div`
  && {
    background: #f3f3f3;
    padding: 10px;
    color: #12368c;
    text-transform: capitalize;
    width: 100%;
    display: flex;
    justify-content: space-around;
    border-radius: 2px;
    margin-bottom: 10px;
  }
`;
const AttachmentLeftTitle = styled.div`
  width: 30%;
  color: #12368c;
  overflow: hidden;
  text-overflow: ellipsis;
`;
const AttachmentRightTitle = styled.div`
  display: flex;
  justify-content: space-between;
  width: 50%;
  p {
    cursor: pointer;
  }
  p:nth-child(1) {
    color: #128c16;
  }
  p:last-child {
    color: #8e1906;
  }
`;

const StyledInput = styled.input`
  width: 100%;
  padding: 5px;

  outline: none;

  border: 1px solid #00000033;
`;

const AvatarContainer = styled.div`
  font-size: 10px;
  margin-bottom: 20px;
  &.member {
    padding: 10px;
  }

  display: flex;
  & .MuiAvatar-root.MuiAvatar-circular.MuiAvatar-colorDefault {
    height: 30px !important;
    width: 30px !important;
    font-size: 14px;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  align-items: center;
  ${({ name }) =>
    name === "save_buttons" &&
    `
    justify-content: flex-end;
    margin-top: 10px;
  `}
`;

const ButtonContainer = styled.div`
  margin-top: 10px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
`;
const FileName = styled.span`
  /* margin-right: 5px; */
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 15px;
    margin-left: 10px;
    margin-right: 0;
  }
`;

const StyledTextField = styled(TextField)`
  && {
    outline: unset;
  }
  .MuiOutlinedInput-input.MuiInputBase-input.MuiInputBase-inputMultiline {
    height: 40px !important;
    overflow-y: scroll !important;
    ::-webkit-scrollbar {
      display: none;
    }
  }
  .MuiInputBase-multiline {
    padding: 6px 10px 7px !important;
    height: 58px;
    font-size: 13px;
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-color: #d5d5d5 !important;
  }
  .css-8ewcdo-MuiInputBase-root-MuiOutlinedInput-root.Mui-focused
    .MuiOutlinedInput-notchedOutline {
    border-width: 1px !important;
  }
`;

const Container = styled.div`
  position: fixed;
`;
const CreateModal = styled(Modal)`
  z-index: 1000 !important;

  .borderless1 {
    border: none !important ;
  }
`;
const ProjectNameContainer = styled.div`
  display: flex;
  justify-content: space-between;
  cursor: pointer;
`;
const ProjectNameText = styled(TextField)`
  width: 85%;
  .MuiInputBase-root {
    font-size: 16px;
  }
  .MuiFormLabel-root.Mui-focused {
    color: #8d8d8d;
    font-size: 13px;
  }
  .MuiInput-underline:after {
    border-bottom: 1px solid #12368c;
  }
  .MuiInput-underline:hover:not(.Mui-disabled):before {
    border-bottom: 1px solid #12368c;
  }
`;
const DeleteButton = styled(DeleteIcon)`
  && {
    position: absolute;
    right: 45px;
    top: 11px;
    color: darkred;
  } /* height: 40px;
  width: 40px;
  position: absolute;
 */
`;
const BlockContainer = styled.div`
  display: flex;
  justify-content: space-between;
  position: relative;
  margin-top: 10px;
`;
const Block = styled.div`
  position: relative;
  & .MuiFormLabel-colorPrimary.Mui-focused {
    color: #8d8d8d;
  }
  label {
    color: #000;
    /* font-weight: unset !important; */
    font-size: 11px;
  }
  &.left {
    width: 59%;
  }
  &.right {
    width: 39%;
  }
  max-height: 518px;
  overflow-y: scroll;
  padding: 0px 18px 0px 0px;
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  }

  &::-webkit-scrollbar-thumb {
    background-color: #929292;
  }
  &.block-2 {
    overflow-y: unset !important;
    padding: 0px 0px 0px 0px;
  }
`;
const StyledCloseIcon = styled(CloseIcon)`
  &.close-modal {
    position: absolute;
    top: 10px;
    right: 10px;
  }
  cursor: pointer;
`;
const CommentListContainer = styled.div``;

const CommentContainer = styled.div``;
const NameText = styled.p`
  font-weight: bold;
  margin-right: 5px;
  cursor: pointer;
`;
const UserDetailsContainer = styled.div`
  display: flex;
  margin-bottom: 3px;
`;
const TimeText = styled.p`
  margin-right: 5px;
  color: #8d8d8d;
`;
const StatusText = styled.p`
  color: #8d8d8d;
`;
const CommentText = styled.p`
  color: #363636;
  margin-bottom: 3px;
`;
const StatusContainer = styled.div``;
const TopBoxContainer = styled.div`
  display: flex;
  gap: 20px;
  /* justify-content: space-between; */

  align-items: flex-end;
`;
const DetailsContainer = styled.div``;

const DetailBlock = styled.div`
  background: #f3f3f3;
  padding: 10px;
  height: 44px;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
`;

const DetailLabel = styled.p`
  width: 100px;
`;
const ProgressBarContainer = styled.div`
  width: 100%;
  margin-right: 5px;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 3px;
    background: #c8c8c8;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const ProgressContainer = styled.div`
  padding: 7px 10px;
  background: #f3f3f3;

  height: 44px;
  &
    .MuiLinearProgress-root.MuiLinearProgress-colorPrimary.MuiLinearProgress-determinate {
    height: 5px;
    background: #c8c8c8;
  }
  &
    .MuiLinearProgress-bar.MuiLinearProgress-barColorPrimary.MuiLinearProgress-bar1Determinate {
    background: #1145bf;
  }
`;
const SaveButtonContainer = styled.div`
  text-align: right;
  margin-top: 10px;
  position: absolute;
  right: 15px;
  bottom: 15px;
`;
const MembersContainer = styled.div`
  /* background: #f3f3f3; */
  position: relative;
  margin-top: 6px;
`;
const MemberInvite = styled.p`
  cursor: pointer;
  margin-left: 1px;
`;
const EmailErrorP = styled.p`
  margin-left: 10px;
  color: red;
`;
const MemberHeader = styled.div`
  display: flex;
  align-items: center;
  margin-top: 6px;
  height: 44px;

  :nth-child(1) {
    margin-top: unset;
  }
  background-color: #f3f3f3;
  justify-content: space-between;
  cursor: pointer;
  padding: 10px;
`;
const MemberHeading = styled.p``;
const AddMemberButton = styled(Button)`
  position: relative;
  && {
    text-transform: capitalize;
    color: #12368c;
  }
`;

const ProgressListContainer = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
`;

const MembersListContainer = styled.div`
  /* height: 130px;
  overflow-y: scroll;
  &::-webkit-scrollbar-track {
    background-color: #f5f5f5; */
  /* }

  &::-webkit-scrollbar {
    width: 5px;
    background-color: #f5f5f5;
  } */

  /* &::-webkit-scrollbar-thumb {
    background-color: #929292;
  } */
`;

const BorderLinearProgress = styles(LinearProgress)(({ theme }) => ({
  height: 10,
  borderRadius: 5,
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor:
      theme.palette.grey[theme.palette.mode === "light" ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === "light" ? "#1a90ff" : "#308fe8",
  },
}));
const ProgressTextContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  width: 100%;
`;
const ProgressLabel = styled.p``;
const ProgressRate = styled.p`
  color: #757575;
`;
const DateInputContainer = styled.div`
  display: none;
`;
const DateText = styled.p`
  color: #727272;
`;
const DateField = styled(TextField)`
  input::-webkit-datetime-edit-fields-wrapper {
    font-size: 12px;
  }
  input::-webkit-calendar-picker-indicator {
    margin-left: 0px;
  }
  &.top-input {
    &.MuiFormControl-fullWidth {
      width: 50%;
    }
  }
  .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"][class*="MuiOutlinedInput-marginDense"] {
    padding: 3px;
  }
  input {
    color: #000;
    background: #fff;
  }
  input[type="number"]::-webkit-inner-spin-button,
  input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }
  & textarea {
    height: 100px;
    min-height: 116px;
    max-height: 116px;
    color: #000;
  }
  & .MuiOutlinedInput-root {
    /* border-radius: 25px; */
    border: 2px solid #e4e4e4;
  }
  fieldset {
    border: 0;
  }
  &::-webkit-input-placeholder {
    color: #000;
  }
  & .MuiInputBase-input::-webkit-input-placeholder {
    color: #767676;
    opacity: 1;
    font-size: 12px;
  }
  & .MuiOutlinedInput-inputMarginDense {
    font-family: "poppinsregular";
    padding-top: 5.5px;
    padding-bottom: 5.5px;
  }
  &.MuiFormControl-fullWidth {
    width: 100%;
  }
`;

const LoyaltyCreate = styled.button`
  border: 0;
  background: inherit;
  cursor: pointer;
  display: flex;
  outline: 0;
  box-sizing: border-box;
  align-items: center;
  padding: 0.25rem 0.5rem;
  justify-content: flex-start;
  -webkit-tap-highlight-color: transparent;
  display: block;
  width: 100%;
  text-align: left;
  color: #428bca;
  border-top: 1px solid #ccc;
  font-size: 14px;
  &:hover {
    background-color: rgba(0, 0, 0, 0.2) !important;
    color: #004d8f;
  }
`;
const StyledEditIcon = styled(EditIcon)`
  cursor: pointer;
  margin-left: auto;
  transition: all 0.1s ease-in;
  &:hover {
    background: #ccc;
    transition: all 0.1s ease-in;
    border-radius: 3px;
  }
`;

function StatusSelect(props) {
  const [t] = useTranslation("common");
  const [work, setWork] = React.useState(
    props.state ? props.state.Status : "todo"
  );
  const handleChange = (event) => {
    setWork(event.target.value);
    props.setState({
      ...props.state,
      Status: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 4px 10px;
      font-size: 12px;

      ${({ work }) =>
        work === "todo" && `background: #e2e2e2; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
    .css-jedpe8-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
      border-radius: 2px !important;
    }
  `;

  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
            disabled={
              props.user_member_type === "owner" ||
              props.user_member_type === "admin" ||
              props.state.is_update === false
                ? false
                : true
            }
          >
            <MenuItem value={"todo"} className="progress">
              {t("To Do")}
            </MenuItem>
            <MenuItem value={"progress"} className="progress">
              {t("In Progress")}
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              {t("Done")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

function PrioritySelect(props) {
  const [t] = useTranslation("common");
  const [priorty, setPriorty] = React.useState(
    props.state ? props.state.Priority : "medium"
  );

  const handleChange = (event) => {
    setPriorty(event.target.value);
    props.setState({
      ...props.state,
      Priority: event.target.value,
    });
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 4px 10px;
      font-size: 12px;

      ${({ priorty }) =>
        priorty === "low" && `background: #C2FBC3; color:#032406;`}
      min-width: min-content;
      ${({ priorty }) =>
        priorty === "medium" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ priorty }) =>
        priorty === "high" && `background: #eb5050; color:#00024A; border:0;`}
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
    .css-jedpe8-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
      border-radius: 2px !important;
    }
  `;

  return (
    <Container priorty={priorty}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderless1">
        <FormControl fullWidth>
          <Select
            size="small"
            value={priorty}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
            disabled={
              props.user_member_type === "owner" ||
              props.user_member_type === "admin" ||
              props.state.is_update === false
                ? false
                : true
            }
          >
            <MenuItem value={"low"} className="progress">
              {t("Low")}
            </MenuItem>
            <MenuItem value={"medium"} className="completed">
              {t("Medium")}
            </MenuItem>
            <MenuItem value={"high"} className="completed">
              {t("High")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}

const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 200,
    padding: 10,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

function MemberMenu({
  handleClick,
  handleMenuClose,
  anchorEl,
  open,
  state,
  setState,
  showMenu,
}) {
  const { username, photo } = useSelector((state) => state.user);
  const onSearchUsers = async (val, e) => {
    if (val) {
      const userListResponse = await fetch(
        `${ACCOUNTS_API_URL}api/v1/users/get-users/`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            username: val,
          }),
        }
      ).then((response) => response.json());
      if (userListResponse.StatusCode === 6000) {
        setState((prevState) => {
          return {
            ...prevState,
            usersList: userListResponse.data,
          };
        });
      }
    }
  };

  return (
    <div>
      <AddMemberModal showMenu={showMenu}>
        <MenuHeading>Add Members</MenuHeading>
        <MenuLabel>Add By Username or Email</MenuLabel>
        <Autocomplete
          // disablePortal
          size="small"
          id="combo-box-demo"
          // options={state.usersList ? state.usersList : []}
          options={[
            { username: "jasmaltk", UserID: 6 },
            { username: "jasmal", UserID: 22 },
            { username: "jasmalvikn", UserID: 66 },
            { username: "VIJESHKM", UserID: 93 },
            { username: "jasdq123", UserID: 117 },
            { username: "jasmalDQ", UserID: 130 },
          ]}
          getOptionLabel={(option) => option.username || ""}
          sx={{ width: 300 }}
          // onInputChange={(event, value, reason) => {
          //   if (reason === "input") {
          //     onSearchUsers(value, event);
          //   }
          // }}
          renderInput={(params) => <TextField size="small" {...params} />}
        />
        <MenuButtonContainer>
          <StyledButton className="cancel m" onClick={handleMenuClose}>
            Cancel
          </StyledButton>
          <StyledButton className="create">Invite</StyledButton>
        </MenuButtonContainer>
      </AddMemberModal>

      {/* <StyledMenu
        id="demo-customized-menu"
        MenuListProps={{
          "aria-labelledby": "demo-customized-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleMenuClose}
      >
        <MenuHeading>Add Members</MenuHeading>
        <MenuLabel>Add By Username or Email</MenuLabel>
        <Autocomplete
          // disablePortal
          size="small"
          id="combo-box-demo"
          // options={state.usersList ? state.usersList : []}
          options={[
            { username: "jasmaltk", UserID: 6 },
            { username: "jasmal", UserID: 22 },
            { username: "jasmalvikn", UserID: 66 },
            { username: "VIJESHKM", UserID: 93 },
            { username: "jasdq123", UserID: 117 },
            { username: "jasmalDQ", UserID: 130 },
          ]}
          getOptionLabel={(option) => option.username || ""}
          sx={{ width: 300 }}
          // onInputChange={(event, value, reason) => {
          //   if (reason === "input") {
          //     onSearchUsers(value, event);
          //   }
          // }}
          renderInput={(params) => <TextField size="small" {...params} />}
        />
        <MenuButtonContainer>
          <StyledButton className="cancel m" onClick={handleMenuClose}>
            Cancel
          </StyledButton>
          <StyledButton className="create">Invite</StyledButton>
        </MenuButtonContainer>
      </StyledMenu> */}
    </div>
  );
}
const AddMemberModal = styled.div`
  visibility: ${({ showMenu }) => (showMenu ? "unset" : "hidden")};
  position: absolute;
  right: 0px;
  top: 0px;
  z-index: 15;
`;
const MenuHeading = styled.p`
  font-weight: bold;
  font-size: 16px;
`;
const MainRoundedCheckbox = styled.div`
  margin-right: 22px;
`;
const MenuLabel = styled.p`
  color: #8f8f8f;
`;
const MenuButtonContainer = styled.div`
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
`;

const UserImg = styled.img`
  border: ${({ selected }) =>
    selected ? "2px solid #1fa500" : "2px solid #e5e5e5"};
  /* border: 2px solid #e5e5e5; */
  width: 100%;
  border-radius: 30px;
  display: block;
  height: 100%;
  object-fit: cover;
`;

const AdminImg = styled.img`
  margin-left: 5px;
  width: 11px;
`;

function DropDownMenu(props) {
  const _ = require("lodash");
  const [anchorEl, setAnchorEl] = React.useState(null);

  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  let MemberList = [...props.state.MemberList];
  let member_type = MemberList.filter((i) => i.MemberUserID === props.UserID)[0]
    .MemberType;

  const [action, setAction] = React.useState(member_type === "admin" ? 1 : 3);
  const onClickAction = (e) => {
    let MemberList = [...props.state.MemberList];
    if (e.target.value) {
      setAction(e.target.value);
    }
    if (e.target.value === 2) {
      MemberList = _.remove(MemberList, function (i) {
        return i.MemberUserID != props.UserID;
      });
      props.setState((prevState) => {
        return {
          ...prevState,
          MemberList,
        };
      });
    } else if (e.target.value === 1) {
      var NewList = _.map(MemberList, function (a) {
        return a.MemberUserID === props.UserID
          ? {
              MemberUserID: a.MemberUserID,
              username: a.username,
              MemberType: "admin",
              progress_rate: a.progress_rate,
            }
          : a;
      });

      props.setState((prevState) => {
        return {
          ...prevState,
          MemberList: NewList,
        };
      });
    } else if (e.target.value === 3) {
      var NewList = _.map(MemberList, function (a) {
        return a.MemberUserID === props.UserID
          ? {
              MemberUserID: a.MemberUserID,
              username: a.username,
              MemberType: "member",
              progress_rate: a.progress_rate,
            }
          : a;
      });

      props.setState((prevState) => {
        return {
          ...prevState,
          MemberList: NewList,
        };
      });
    }
    setAnchorEl(null);
  };
  return (
    <React.Fragment>
      <Tooltip title="Account settings">
        <IconButton
          onClick={handleClick}
          size="small"
          sx={{ ml: 2 }}
          aria-controls={open ? "account-menu" : undefined}
          aria-haspopup="true"
          aria-expanded={open ? "true" : undefined}
        >
          <MoreVertIcon />
        </IconButton>
      </Tooltip>
      {member_type != "owner" ? (
        <Menu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          onClick={(e) => onClickAction(e)}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
              mt: 1.5,
              "& .MuiAvatar-root": {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
              },
              "&:before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          }}
          transformOrigin={{ horizontal: "right", vertical: "top" }}
          anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
        >
          {action === 1 ? (
            <MenuItem key="3" value="3">
              Remove Admin
            </MenuItem>
          ) : action === 3 ? (
            <MenuItem key="1" value="1">
              Make Admin
            </MenuItem>
          ) : null}

          <MenuItem key="2" value="2">
            Remove
          </MenuItem>
        </Menu>
      ) : null}
    </React.Fragment>
  );
}
