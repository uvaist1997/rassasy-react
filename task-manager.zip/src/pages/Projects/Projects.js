import { Box, Button, Pagination, TablePagination } from "@mui/material";
import React, { useRef, useState, useEffect, useContext } from "react";
import styled from "styled-components/macro";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import CreateProject from "./CreateProject";
import CreateProjectTask from "./CreateProjectTask";
import {
  date_monthName_format,
  getCookie,
  get_color_due_date,
  stringAvatar,
} from "../../functions/utils";
import { useLocation, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import NestedList from "../../components/NestedList";
import usePagination from "../../functions/Pagination";
import { projectListUrl, projectProgressUrl } from "../../api/ProjectsAPI";
import ListFilter from "../../components/ListFilter";
import FilterAltSharpIcon from "@mui/icons-material/FilterAltSharp";
import { useTranslation } from "react-i18next";
import Avatar from "@mui/material/Avatar";
import AvatarGroup from "@mui/material/AvatarGroup";
import Badge from "@mui/material/Badge";
import SearchIcon from "@mui/icons-material/Search";
import { DataContext } from "../../components/Context1";
const access = getCookie("VBID");

const Projects = () => {
  const [t] = useTranslation("common");
  const params = new Proxy(new URLSearchParams(window.location.search), {
    get: (searchParams, prop) => searchParams.get(prop),
  });
  const { username, user_id } = useSelector((state) => state.user);
  const [age, setAge] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const [openTask, setOpenTask] = React.useState(false);
  const [singleProjectID, setsingleProject] = React.useState(null);
  const [navCreate, setNavCreate] = React.useState(false);
  const [showFilter, setFilter] = useState(false);
  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;
  const [state, setState] = React.useState({
    data: [],
    ProjectList: [],
    get_list: true,
    singleProject: {},
    is_update: false,
    ProjectFilter: null,
    FilterStartDate: null,
    FilterEndDate: null,
  });
  // pagination

  const [page, setPage] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const IndexofLastItem = currentPage * itemsPerPage;
  const indexOfFirstDish = IndexofLastItem - itemsPerPage;
  const count1 = state.data.length;
  let paginated_data = state.data.slice(indexOfFirstDish, IndexofLastItem);
  console.log("page", paginated_data);

  const ChangePage = (event, value) => {
    console.log("value=========", value);

    setCurrentPage(value + 1);
    setPage(value);
  };
  const handleChangeRowsPerPage = (event) => {
    console.log("handleChangeRowsPerPage", event.target.value);
    setItemsPerPage(+event.target.value);
    setPage(0);
  };

  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => {
    if (location.state) {
      setOpen(true);
    }
  }, [location.state]);
  console.log(state);
  useEffect(() => {
    console.log("LIST IS WORKING......");
    if (state.get_list === true) {
      get_api();
      return () => {
        setState((prevState) => {
          return {
            ...prevState,
            get_list: false,
          };
        });
      };
    }
  }, [state.get_list]);

  const get_api = async () => {
    const projectListResponse = await fetch(projectListUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        ProjectFilter: state.ProjectFilter,
        FilterStartDate: state.FilterStartDate,
        FilterEndDate: state.FilterEndDate,
      }),
    }).then((response) => response.json());
    if (projectListResponse.StatusCode === 6000) {
      setState((prevState) => {
        return {
          ...prevState,
          data: projectListResponse.data,
          ProjectList: projectListResponse.data,
          get_list: false,
        };
      });
      setNotificationCount((prevState) => {
        return {
          ...prevState,
          project_notify: projectListResponse.project_notify,
          task_notify: projectListResponse.task_notify,
        };
      });
    }
  };

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const UpdateProject = (singleProject, e) => {
    if (
      e.target.className !=
        "MuiBackdrop-root MuiBackdrop-invisible css-g3hgs1-MuiBackdrop-root-MuiModal-backdrop" &&
      e.target.className !=
        "MuiMenuItem-root MuiMenuItem-gutters MuiButtonBase-root progress css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root" &&
      e.target.className !=
        "MuiMenuItem-root MuiMenuItem-gutters MuiButtonBase-root completed css-kk1bwy-MuiButtonBase-root-MuiMenuItem-root"
    ) {
      setState((prevState) => {
        return {
          ...prevState,
          singleProject,
          is_update: true,
        };
      });
    }
  };
  const ProjectTasks = (projectID, e) => {
    if (e.target.getAttribute("name") === "AddButton") {
      setOpenTask(true);
    } else {
      navigate(`/tasks?q=${projectID}`, {});
    }
    setsingleProject(projectID);
    // if (name === "AddButton") {
    //   setOpenTask(true);
    // } else {
    //   navigate(`/tasks?q=${projectID}`, {});
    // }
    // setsingleProject(projectID);
    // if (e.target.className !== "Projects__AddTaskButton-sc-k5j3by-26 hlHIKm") {
    //   navigate(`/tasks?q=${projectID}`, {});
    // } else {
    //   setOpenTask(true);
    // }
    // setsingleProject(projectID);
    // let className = "";
    // if (typeof e.target.className === "object") {
    //   className = e.target.className.baseVal;
    // }

    // console.log(className);
    // if (
    //   e.target.className !=
    //     "MuiButton-root MuiButton-text MuiButton-textPrimary MuiButton-sizeMedium MuiButton-textSizeMedium MuiButtonBase-root Projects__AddTaskButton-sc-k5j3by-26 hlHIKm css-1e6y48t-MuiButtonBase-root-MuiButton-root" &&
    //   className !=
    //     "MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-i4bv87-MuiSvgIcon-root"
    // ) {
    //   navigate(`/tasks?q=${projectID}`, {});
    // } else {
    //   setOpenTask(true);
    // }
    // setsingleProject(projectID);
  };

  const searChProject = (e) => {
    let projects = state.ProjectList;
    let data = projects.filter((i) =>
      i.ProjectName.toLowerCase().includes(e.target.value.toLowerCase())
    );
    setState((prevState) => {
      return {
        ...prevState,
        data,
      };
    });
  };

  return (
    <Container>
      <Header>
        <LeftHeader>
          <Heading>{t("Projects")}</Heading>
          <FilterMainContainer>
            <FilterIcon onClick={() => setFilter(!showFilter)}>
              {t("Filter")}
            </FilterIcon>
            <ListFilter
              state={state}
              setState={setState}
              showFilter={showFilter}
              setFilter={setFilter}
            />
          </FilterMainContainer>
          <Search>
            <SearchIcon1 />
            <SearchBar1
              type="text"
              placeholder="Search..."
              onChange={(e) => searChProject(e)}
            />
          </Search>
          {/* <NestedList state={state} setState={setState} /> */}
          {/* <FilterContainer>
            <FilterLabel>Filter:</FilterLabel>
            <StyledSelect>
              <FormControl fullWidth>
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  onChange={handleChange}
                >
                  <MenuItem value={10}>High</MenuItem>
                  <MenuItem value={20}>Medium</MenuItem>
                  <MenuItem value={30}>Low</MenuItem>
                </Select>
              </FormControl>
            </StyledSelect>
          </FilterContainer> */}
        </LeftHeader>
        <RightHeader>
          <div>Projects Per page</div>
          <PaginationContainer>
            <StyledPagination
              // rowsPerPageOptions={[10, 25, 50]}

              component="div"
              page={page}
              onPageChange={ChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              count={count1}
              rowsPerPage={itemsPerPage}
            />
          </PaginationContainer>
          <CreateButton onClick={() => setOpen(true)}>
            {t("Create")}
          </CreateButton>
        </RightHeader>
      </Header>
      <ProjectListContainer>
        {paginated_data.map((i) => (
          <Badge
            color="error"
            variant="dot"
            invisible={i.is_view ? true : false}
          >
            <ProjectTaskBoxContainer>
              <ProjectTaskBox onClick={(e) => UpdateProject(i, e)}>
                <ListHeader>
                  <ListHeading>{i.ProjectName}</ListHeading>
                  <ProjectTaskButton className={i.MemberType}>
                    {i.MemberType ? t(i.MemberType) : t("admin")}
                  </ProjectTaskButton>
                </ListHeader>
                {i.CreatedDate ? (
                  <CreateDate>
                    <CreatedSpan>on</CreatedSpan>{" "}
                    {date_monthName_format(i.CreatedDate)}
                  </CreateDate>
                ) : null}

                <ListBody>
                  <PriorityButton className={i.Priority}>
                    {t(i.Priority)}
                  </PriorityButton>
                  <DateContainer>
                    <DateText>{t("Due Date")}</DateText>
                    <StatusDate className={get_color_due_date(i.DueDate)}>
                      {i.DueDate
                        ? date_monthName_format(i.DueDate)
                        : "no due date"}
                    </StatusDate>
                  </DateContainer>
                </ListBody>
                <StatusContainer>
                  {/* <StatusText>{t("Status")}</StatusText> */}

                  <AvatarGp max={4} total={i.MemberList.length}>
                    {i.MemberList.map((m) => (
                      <Avatar
                        alt="Remy Sharp"
                        // src="https://static.tnn.in/photo/msid-92061587,imgsize-634888,updatedat-1654602797801,width-200,height-200,resizemode-75/92061587.jpg"
                        {...stringAvatar(m.username)}
                        style={{ width: "25px", height: "25px" }}
                      />
                    ))}

                    {/* <Avatar
                      alt="Travis Howard"
                      src="https://img.starbiz.com/resize/750x-/2019/06/05/lucifer-99c4.jpg"
                      style={{ width: "25px", height: "25px" }}
                    />
                    <Avatar
                      alt="Cindy Baker"
                      src="https://static.tnn.in/photo/msid-92061587,imgsize-634888,updatedat-1654602797801,width-200,height-200,resizemode-75/92061587.jpg"
                      style={{ width: "25px", height: "25px" }}
                    />
                    <Avatar
                      alt="Agnes Walker"
                      src="https://img.starbiz.com/resize/750x-/2019/06/05/lucifer-99c4.jpg"
                      style={{ width: "25px", height: "25px" }}
                    />
                    <Avatar
                      alt="Trevor Henderson"
                      src="https://static.tnn.in/photo/msid-92061587,imgsize-634888,updatedat-1654602797801,width-200,height-200,resizemode-75/92061587.jpg"
                      style={{ width: "25px", height: "25px" }}
                    /> */}
                  </AvatarGp>
                  <StatusSelect
                    work={i.Status}
                    ProjectID={i.id}
                    username={username}
                    state={state}
                    setState={setState}
                  />
                </StatusContainer>
              </ProjectTaskBox>
              <ProjectTaskBox1>
                <AddButtonContainer
                  name="content"
                  onClick={(e) => ProjectTasks(i.id, e)}
                >
                  <AddTaskButton name="AddButton">
                    <AddCircleOutlineRoundedIcon name="AddButton" />
                    {t("Add Task")}
                  </AddTaskButton>
                </AddButtonContainer>

                <TaskProgressBlock
                  name="content"
                  onClick={(e) => ProjectTasks(i.id, e)}
                >
                  <TodoContainer className="todo">
                    <TodoText>{t("To Do")}</TodoText>
                    <TodoCountText>{i.ToDoTaskCount}</TodoCountText>
                  </TodoContainer>

                  <TodoContainer className="progress">
                    <TodoText>{t("In Progress")}</TodoText>
                    <TodoCountText>{i.ProgressTaskCount}</TodoCountText>
                  </TodoContainer>

                  <TodoContainer className="completed">
                    <TodoText>{t("Completed")}</TodoText>
                    <TodoCountText>{i.CompletedTaskCount}</TodoCountText>
                  </TodoContainer>
                </TaskProgressBlock>
                <ProgressRateContainer
                  name="content"
                  onClick={(e) => ProjectTasks(i.id, e)}
                >
                  <ProgressText>{t("Progress")}</ProgressText>
                  <ProgressRateText>
                    {Number(i.Progress).toFixed(2)}%
                  </ProgressRateText>
                </ProgressRateContainer>
              </ProjectTaskBox1>
              <ProgressBar
                className="blue "
                percentage={i.Progress}
              ></ProgressBar>
            </ProjectTaskBoxContainer>
          </Badge>
        ))}
      </ProjectListContainer>
      <CreateProject
        type={state.is_update === false ? "create" : "create"}
        open={open}
        setOpen={setOpen}
        state={state}
        setState={setState}
      />
      <CreateProjectTask
        open={openTask}
        setOpen={setOpenTask}
        state={state}
        setState={setState}
        singleProject={singleProjectID}
      />
    </Container>
  );
};

export default Projects;
const Search = styled.div`
  position: relative;
`;

const SearchBar1 = styled.input`
  padding: 8px;
  padding-left: 34px;

  margin-left: 10px;
  position: relative;
  border: 1px solid #edeff3;
  outline: none;
  border-radius: 3px;
  ::placeholder {
    font-size: 12px;
    color: grey;
  }
`;
const SearchIcon1 = styled(SearchIcon)`
  position: absolute;
  z-index: 1;
  color: #b9b3b7;
  top: 7px;
  left: 16px;
`;
const AvatarGp = styled(AvatarGroup)`
  .MuiAvatar-colorDefault {
    width: 25px !important;
    height: 25px !important;
    background-color: black;
    font-size: 9px;
    color: white;
  }
`;
const PaginationContainer = styled.div`
  /* width: 100%; */
  .css-78c6dr-MuiToolbar-root-MuiTablePagination-toolbar {
    padding-left: unset;
  }
  .css-16c50h-MuiInputBase-root-MuiTablePagination-select {
    margin-left: unset;
  }

  /* position: absolute;
  bottom: 15px;
  left: 0;
  right: 0; */
`;
const StyledPagination = styled(TablePagination)`
  width: 100%;
  .MuiPagination-ul {
    justify-content: center;
  }
  .css-pdct74-MuiTablePagination-selectLabel {
    display: none;
  }
`;
const FilterMainContainer = styled.div`
  position: relative;
`;

const FilterIcon = styled(Button)`
  background: #12368c;
  color: #fff;
  cursor: pointer;
  color: black;
  border-radius: 2px;
  padding: 5px 20px;
  text-transform: capitalize;
  &:hover {
    background: #5073c7;
  }
`;
const Container = styled.div``;
const Heading = styled.div`
  font-size: 20px;
  font-weight: bold;
  margin-right: 10px;
`;
const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const LeftHeader = styled.div`
  display: flex;
  align-items: center;
`;
const RightHeader = styled.div`
  display: flex;
  align-items: center;
`;
const CreateButton = styled(Button)`
  && {
    background: #12368c;
    color: #fff;
    border-radius: 2px;
    height: 31px;
    font-size: 12px;
    width: 88px;
    padding: 5px 20px;
    text-transform: capitalize;
    &:hover {
      background: #12368c;
    }
  }
`;
const StyledSelect = styled.div`
  min-width: 120px;
  & .MuiFormControl-root {
    margin: 0 !important;
    border: 0;
  }
  fieldset {
    border: 0;
  }
`;
const FilterContainer = styled.div`
  display: flex;
  align-items: center;
  border: 1px solid #edeff3;
  padding: 0 0 0 8px;
  background: #fff;
  border-radius: 3px;
`;
const FilterLabel = styled.div`
  font-size: 16px;
  margin-right: 5px;
`;
const ProjectListContainer = styled.div`
  /* display: grid; */
  /* grid-template-columns: 1fr 1fr 1fr 1fr; */
  /* @media (width: 1920px) {
    grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
  } */
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  /* grid-gap: 15px; */
`;
const ProjectTaskBox = styled.div`
  background: #fff;
  height: 121px;
  width: 255px;
  padding: 10px;
  border: 1px solid #dde2eb;
  &:hover {
    background: #f0f0f0;
    cursor: pointer;
  }
`;
const ProjectTaskBox1 = styled(ProjectTaskBox)`
  height: 80px;
  padding: 10px 10px 0px 10px;
`;
const ProjectTaskBoxContainer = styled.div`
  position: relative;
`;
const ListHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* margin-bottom: 10px; */
`;
const CreateDate = styled.p`
  font-size: 10px;
  color: #565656;
`;
const CreatedSpan = styled.span`
  color: "#A2A2A2";
  font-size: 9px;
  opacity: 0.8;
`;
// const CreatedSpan = styled.span'
//   col
// ';
const ListHeading = styled.div`
  font-weight: bold;
  white-space: nowrap;
  width: 160px;
  overflow: hidden;
  text-overflow: ellipsis;
`;
const ProjectTaskButton = styled.div`
  && {
    text-transform: capitalize;
    border-radius: 2px;
    font-size: 9px;
    height: 18px;
    width: 46px;
    padding: 3px 7px;
  }
  &&.admin {
    background: #d0f2e1;
    color: #013d23;
  }
  &&.owner {
    background: #bfe5d2;
    color: #013d23;
  }
  &&.team-leader {
    color: #00195d;
    background: #b4c8ff;
  }
  &&.member {
    color: #500000;
    background: #ffbf9e;
  }
`;
const ListBody = styled.div`
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-bottom: 10px;
`;
const PriorityButton = styled.div`
  && {
    text-transform: capitalize;
    border-radius: 2px;
    padding: 6px 10px;
    font-size: 10px;
    width: 105px;
    height: 26px;
    text-align: center;
  }
  &&.high {
    background: #fff6f6;
    color: #700000;
    border: 1px solid #eb5f5f;
  }
  &&.low {
    color: #00195d;
    background: #b4c8ff;
  }
  &&.medium {
    color: #500000;
    background: #ffbf9e;
  }
`;
const StatusDate = styled.div`
  font-size: 11px;
  color: #12368c;
  &.red {
    color: #f10000;
  }
  &.blue {
    color: #12368c;
  }
  &.grey {
    color: #3d3d3d;
  }
`;
const DateText = styled.div`
  color: #a2a2a2;
  font-size: 9px;
`;
const DateContainer = styled.div`
  display: flex;
  flex-direction: column;
  text-align: right;
  justify-content: center;
`;
const StatusContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const StatusText = styled.div``;

const AddTaskSpace = styled.div`
  min-width: 170;
`;
const AddButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const AddTaskButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
    padding: 0px 0px 3px 0px !important  ;
  }
  svg {
    font-size: 16px;
    margin-right: 3px;
  }
`;

const TaskProgressBlock = styled.div`
  margin-top: 1px;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-gap: 5px;
  margin-bottom: 3px;
`;
const TodoContainer = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 3px;
  width: 74px;
  height: 20px;
  border-radius: 1px;
  &.todo {
    background: #e2e2e2;
  }
  &.progress {
    background: #dbe6ff;
    color: #000660;
  }
  &.completed {
    background: #bef1cc;
    color: #002e19;
  }
`;
const TodoText = styled.div`
  font-size: 9px;
`;
const TodoCountText = styled.div`
  font-size: 9px;
`;

const ProgressRateContainer = styled.div`
  display: flex;
  justify-content: space-between;
`;
const ProgressText = styled.p`
  font-size: 11px;
`;
const ProgressRateText = styled.p`
  color: #9b9b9b;
  font-size: 11px;
`;

const ProgressBar = styled.div`
  width: 100%;
  height: 3px;
  position: absolute;
  bottom: 0;
  ${({ percentage }) =>
    percentage < 100 &&
    `
    width:${percentage}%;
  `}
  background: #1145bf;
  &.red {
    background: #f10000;
  }
  &.green {
    background: #07750b;
  }
`;

function StatusSelect(props) {
  const [t] = useTranslation("common");
  const [work, setWork] = React.useState(props.work);
  useEffect(() => {
    setWork(props.work);
  }, [props.work]);
  const handleChange = async (event) => {
    setWork(event.target.value);
    if (event.target.value && props.ProjectID) {
      const progressUpdateResponse = await fetch(projectProgressUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${access}`,
          accept: "application/json",
        },
        body: JSON.stringify({
          ProjectID: props.ProjectID,
          Progress: event.target.value,
          UserName: props.username,
        }),
      }).then((response) => response.json());
      if (progressUpdateResponse.StatusCode === 6000) {
        props.setState((prevState) => {
          return {
            ...prevState,
            get_list: true,
          };
        });
      }
    }
  };
  const Container = styled.div`
    div[role="button"] {
      background: #eeeeee;
      padding: 0px 7px 3px 11px;
      font-size: 9px;
      border-radius: 2px !important;
      height: 18px;
      width: 80px;

      ${({ work }) =>
        work === "todo" && `background: #e2e2e2; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "progress" && `background: #D5E2EF; color:#00024A; border:0;`}
      ${({ work }) =>
        work === "completed" && `background: #C2FBC3; color:#032406;`}
        min-width: min-content;
    }
    .css-hfutr2-MuiSvgIcon-root-MuiSelect-icon {
      font-size: 1rem !important;
    }
    span {
      margin: 0;
    }
    fieldset {
      border: 0;
    }
    .borderLess {
      border: none !important;
    }
  `;
  return (
    <Container work={work}>
      <Box sx={{ minWidth: 60, width: 120 }} className="borderLess">
        <FormControl fullWidth>
          <Select
            size="small"
            value={work}
            onChange={handleChange}
            displayEmpty
            inputProps={{ "aria-label": "Without label" }}
          >
            <MenuItem value={"todo"} className="progress">
              {t("To Do")}
            </MenuItem>
            <MenuItem value={"progress"} className="progress">
              {t("In Progress")}
            </MenuItem>
            <MenuItem value={"completed"} className="completed">
              {t("Done")}
            </MenuItem>
          </Select>
        </FormControl>
      </Box>
    </Container>
  );
}
