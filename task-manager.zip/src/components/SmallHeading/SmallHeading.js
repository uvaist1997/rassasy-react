import styled from "styled-components";

const SmallHeading = ({ text, align }) => {
  return <Heading align={align}> {text}</Heading>;
};

export default SmallHeading;

const Heading = styled.p`
  font-weight: bold;
  ${({ align }) =>
    align &&
    `
    text-align: ${align};
  `}
`;
