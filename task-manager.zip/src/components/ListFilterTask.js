import React, { useRef, useState, useEffect } from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import { formatDate, getCookie, get_index } from "../functions/utils";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import "animate.css";
import FormLabel from "@mui/material/FormLabel";
import FormControl from "@mui/material/FormControl";
import FormGroup from "@mui/material/FormGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormHelperText from "@mui/material/FormHelperText";
import Checkbox from "@mui/material/Checkbox";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { addDays } from "date-fns";
import { DateRangePicker } from "react-date-range";
import "react-date-range/dist/styles.css";
import "react-date-range/dist/theme/default.css";
import { Autocomplete } from "@mui/material";
import { projectListUrl } from "../api/ProjectsAPI";
import { useTranslation } from "react-i18next";

const style = {
  position: "absolute",
  top: 430,
  left: 668,
  transform: "translate(-50%, -50%)",
  width: "42%",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 1,
  overflowX: "scroll",
  overflowX: "hidden",
  height: 600,
};

const access = getCookie("VBID");

export default function ListFilterTask(props) {
  const [t] = useTranslation("common");
  var _ = require("lodash");
  let open = props.showFilter;
  let setOpen = props.setFilter;

  const { username, photo, user_id } = useSelector((state) => state.user);
  const [checkStatus, setCheckStatus] = React.useState(false);
  const [checkPriority, setCheckPriority] = React.useState(false);
  const [state, setState] = React.useState({
    ProjectFilter: [],
    todo: false,
    progress: false,
    completed: false,
    low: false,
    medium: false,
    high: false,
    ProjectList: [],
    ProjectID: null,
  });

  const [dateState, setdateState] = useState([
    {
      startDate: addDays(new Date(), -365),
      endDate: addDays(new Date(), 365),
      key: "selection",
      is_change: false,
    },
  ]);

  const handleClose = () => {
    setOpen(false);
  };

  const clickModalClose = () => {
    setOpen(false);
  };

  const handleCheckBoxChange = (e) => {
    let ProjectFilter = state.ProjectFilter;
    if (e.target.checked) {
      ProjectFilter = _.uniq(_.concat(ProjectFilter, e.target.name));
    } else {
      ProjectFilter = _.remove(ProjectFilter, (val) => {
        return val != e.target.name;
      });
    }

    setState((prevState) => {
      return {
        ...prevState,
        ProjectFilter,
        [e.target.name]: e.target.checked,
      };
    });
  };

  const handleFilter = (type = "filter") => {
    let ProjectFilter = [];
    let FilterStartDate = null;
    let FilterEndDate = null;
    let ProjectID = null;
    if (type === "filter") {
      ProjectFilter = state.ProjectFilter;
      FilterStartDate = dateState[0].startDate;
      FilterEndDate = dateState[0].endDate;
      FilterStartDate = formatDate(FilterStartDate);
      FilterEndDate = formatDate(FilterEndDate);
      ProjectID = state.ProjectID;
      if (!ProjectFilter.length) {
        ProjectFilter = ["confirming"];
      }
    } else {
      setState((prevState) => {
        return {
          ...prevState,
          ProjectFilter: [],
          todo: false,
          progress: false,
          completed: false,
          low: false,
          medium: false,
          high: false,
          ProjectList: [],
          ProjectID: null,
        };
      });
      setdateState([
        {
          startDate: addDays(new Date(), -365),
          endDate: addDays(new Date(), 365),
          key: "selection",
        },
      ]);
    }

    props.setState((prevState) => {
      return {
        ...prevState,
        ProjectFilter,
        FilterStartDate,
        FilterEndDate,
        ProjectID,
        get_list: true,
      };
    });
    setOpen(false);
  };

  const handleSelectChange = (n, e) => {
    if (e) {
      if (n == "ProjectID") {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: e.id,
            ProjectName: e.ProjectName,
          };
        });
      } else {
        setState((prevState) => {
          return {
            ...prevState,
            [n]: "",
          };
        });
      }
    }
  };

  useEffect(() => {
    (async () => {
      // const projectListResponse = await fetch(projectListUrl, {
      //   method: "POST",
      //   headers: {
      //     "content-type": "application/json",
      //     Authorization: `Bearer ${access}`,
      //     accept: "application/json",
      //   },
      //   body: JSON.stringify({
      //     ProjectFilter: [],
      //     FilterStartDate: null,
      //     FilterEndDate: null,
      //   }),
      // }).then((response) => response.json());
      if (props.state.ProjectList) {
        setState((prevState) => {
          return {
            ...prevState,
            ProjectList: props.state.ProjectList,
          };
        });
      }
    })();
  }, [props.state.ProjectList]);
  return (
    <Container>
      <CreateModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={handleClose}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={open}>
          <Box1 sx={style}>
            <FilterContainer>
              <StatusContainer>
                <Accordion disableGutters={true}>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography>{t("Projects")}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <TopFilterDiv>
                      <FormGroup>
                        <CustomeAutocomplete
                          // disablePortal
                          size="small"
                          id="combo-box-demo"
                          options={state.ProjectList ? state.ProjectList : []}
                          getOptionLabel={(option) => option.ProjectName || ""}
                          sx={{ width: 280 }}
                          onChange={(e, v) =>
                            handleSelectChange("ProjectID", v)
                          }
                          renderInput={(params) => (
                            <TextField size="small" {...params} />
                          )}
                          value={
                            state.ProjectList && state.ProjectID
                              ? state.ProjectList[
                                  get_index(state.ProjectList, state.ProjectID)
                                ]
                              : ""
                          }
                        />
                      </FormGroup>
                      <FormGroup></FormGroup>
                      <FormGroup></FormGroup>
                    </TopFilterDiv>
                  </AccordionDetails>
                </Accordion>
                <Accordion disableGutters={true}>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography>{t("Status & Priority")}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <TopFilterDiv>
                      <FormGroup>
                        <TopSubHead>{t("Status")}</TopSubHead>
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.todo}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="todo"
                            />
                          }
                          label={t("To Do")}
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.progress}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="progress"
                            />
                          }
                          label={t("Progress")}
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.completed}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="completed"
                            />
                          }
                          label={t("Completed")}
                        />
                      </FormGroup>
                      <FormGroup>
                        <TopSubHead>{t("Priority")}</TopSubHead>
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.low}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="low"
                            />
                          }
                          label={t("Low")}
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.medium}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="medium"
                            />
                          }
                          label={t("Medium")}
                        />
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={state.high}
                              onChange={(e) => handleCheckBoxChange(e)}
                              name="high"
                            />
                          }
                          label={t("High")}
                        />
                      </FormGroup>
                      <FormGroup></FormGroup>
                    </TopFilterDiv>
                  </AccordionDetails>
                </Accordion>

                <Accordion disableGutters={true}>
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography>{t("Due Date")}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <DateRangePicker
                      onChange={(item) => setdateState([item.selection])}
                      showSelectionPreview={true}
                      moveRangeOnFirstSelection={false}
                      months={1}
                      ranges={dateState}
                      direction="vertical"
                    />
                    ;
                  </AccordionDetails>
                </Accordion>
              </StatusContainer>
            </FilterContainer>
            <ButtonContainer>
              <FilterButton onClick={() => handleFilter("filter")}>
                {t("Filter")}
              </FilterButton>
              <FilterButton onClick={() => handleFilter("clear")}>
                {t("Clear")}
              </FilterButton>
            </ButtonContainer>
          </Box1>
        </Fade>
      </CreateModal>
    </Container>
  );
}
const Box1 = styled(Box)`
  ::-webkit-scrollbar {
    display: none;
  }
`;
const CustomeAutocomplete = styled(Autocomplete)`
  button {
    padding: 0;
  }
`;
const TopSubHead = styled.p`
  font-size: 16px;
  font-weight: bold;
`;

const TopFilterDiv = styled.div`
  display: flex;
  justify-content: space-between;
`;

const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 15px;
`;

const FilterButton = styled.button`
  background-color: white;
  color: black;
  border: 2px solid #008cba;
  padding: 8px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  margin: 4px 2px;
  cursor: pointer;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  text-align: center;
  &:hover {
    background-color: #008cba;
    color: white;
  }
`;
const Container = styled.div`
  position: absolute;
`;
const CreateModal = styled(Modal)`
  z-index: 1000 !important;
`;
const FilterContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
`;

const StatusContainer = styled.div`
  min-width: 282px;
  width: 100%;
`;
