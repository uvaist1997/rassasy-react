import React, { useEffect, useState, CSSProperties, useContext } from "react";
import styled from "styled-components";
import { useNavigate } from "react-router-dom";
import { Button, Menu, MenuItem } from "@mui/material";
import Stack from "@mui/material/Stack";
import Avatar from "@mui/material/Avatar";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import AppsRoundedIcon from "@mui/icons-material/AppsRounded";
import { getCookie, stringAvatar } from "../../functions/utils";
import AppMenu from "../AppMenu/AppMenu";
import { selectUserName } from "../../slices/userSice";
import ClipLoader from "react-spinners/ClipLoader";
import { useDispatch, useSelector } from "react-redux";
import { loginSuccess, logoutSuccess } from "../../slices/userSice";
import {
  ACCOUNTS_API_URL,
  ACCOUNTS_FRONT_URL,
  BASE_URL,
  domain1,
  VIKNBOOKS_FRONT_URL,
} from "../../settings";
import axios from "axios";
import store from "../../store/store";
import { languageSuccess } from "../../slices/language/languageSlice";
import { useTranslation } from "react-i18next";
import { domain } from "../../settings";
import { set_handleLogout } from "../../functions/common";
import { DataContext } from "../Context1";

const override: CSSProperties = {
  display: "block",
  margin: "0 auto",
  borderColor: "red",
};
// const access = getCookie("VBID");

const Header = () => {
  const [t, i18n] = useTranslation("common");
  const store_values = store.getState();
  const dispatch = useDispatch();
  let [access, setAccess] = useState(getCookie("VBID"));
  const { username, email, user_id } = useSelector((state) => state.user);
  const [language, setLanguage] = useState(store_values.language.language);
  const { showNotificationCount } = useContext(DataContext);
  const [notificationCount, setNotificationCount] = showNotificationCount;

  const handleChangeLanguage = (e) => {
    e.preventDefault();
    setLanguage(e.target.value);
    dispatch(languageSuccess({ language: e.target.value }));
    i18n.changeLanguage(e.target.value);
  };
  let [loading, setLoading] = useState(true);
  let [color, setColor] = useState("#ffffff");
  const navigate = useNavigate();
  useEffect(() => {
    console.log(user_id, "@@@@@@@@@!!!!!!!!!$");
    if (access) {
      if (!user_id) {
        (async () => {
          console.log("?>>>>>>>>>>>>>>>>>>>>>");
          const projectListResponse = await fetch(
            `${ACCOUNTS_API_URL}api/v1/users/get-username/`,
            {
              method: "POST",
              headers: {
                "content-type": "application/json",
                Authorization: `Bearer ${access}`,
                accept: "application/json",
              },
              body: JSON.stringify({
                ProjectFilter: "",
              }),
            }
          ).then((response) => response.json());
          if (projectListResponse.StatusCode === 6000) {
            dispatch(
              loginSuccess({
                username: projectListResponse.username,
                email: projectListResponse.email,
                user_id: projectListResponse.UserID,
                isAuth: true,
                admin_login: false,
              })
            );
            setLoading(false);
          }
        })();
      } else {
        setLoading(false);
      }
    } else {
      window.open(`${ACCOUNTS_FRONT_URL}signin?service=task_manager`, "_self");
    }
  });

  useEffect(() => {
    async function fetchMyAPI() {
      const notificationcheck = await fetch(
        `${BASE_URL}general/check-notification`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            Authorization: `Bearer ${access}`,
            accept: "application/json",
          },
          body: JSON.stringify({
            UserID: user_id,
          }),
        }
      ).then((response) => response.json());
      if (notificationcheck.StatusCode === 6000) {
        console.log(notificationcheck);
        setNotificationCount((prevState) => {
          return {
            ...prevState,
            project_notify: notificationcheck.project_notify,
            task_notify: notificationcheck.task_notify,
          };
        });
      }
    }

    fetchMyAPI();
  }, [showNotificationCount.notificationCount]);

  const [anchorEl, setAnchorEl] = useState(null);
  const [callRefresh, setcallRefresh] = useState(false);
  useEffect(() => {
    if (callRefresh === true) {
      dispatch(
        logoutSuccess({
          username: "",
          email: "",
          user_id: "",
          isAuth: false,
          admin_login: false,
        })
      );
      setcallRefresh(false);
    }
  }, [callRefresh]);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  // app menu function
  const handleMenuClick = (event) => {
    setAnchorMenuEl(event.currentTarget);
  };
  const [anchorMenuEl, setAnchorMenuEl] = React.useState(null);
  const handleMenuClose = () => {
    setAnchorMenuEl(null);
  };
  const openMenu = Boolean(anchorMenuEl);

  const handleLogout = async () => {
    // axios
    //   .get(
    //     `${ACCOUNTS_API_URL}api/v1/users/logout-cookie?service=task_manager`,
    //     { withCredentials: true }
    //   )
    //   .then(() => {
    //     const params = new Proxy(new URLSearchParams(window.location.search), {
    //       get: (searchParams, prop) => searchParams.get(prop),
    //     });
    //   });
    // document.cookie = `VBID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;domain=${domain}`;
    let dic = {
      username: username,
      email: email,
      image_url:
        "https://www.api.viknbooks.com/media/profiles/Screenshot_from_2022-02-02_11-45-23.png",
    };
    let return_value = await set_handleLogout(dic);
    window.open(
      `${VIKNBOOKS_FRONT_URL}service?service=task_manager&type=logout`,
      "_self"
    );
    console.log(return_value, "________________");
    if (return_value) {
      setAccess("");
      setcallRefresh(true);
    }
  };

  // app menu funtion ends here
  if (loading) {
    return (
      <ClipLoader
        color={color}
        loading={loading}
        cssOverride={override}
        size={150}
      />
    );
  } else {
    return (
      <Container>
        <LeftContainer>
          <LogoContainer>
            <img src="../../images/icons/Optiid.svg" />
          </LogoContainer>
        </LeftContainer>
        <RightContainer>
          <LanguageButton
            value={language == "en" ? "ar" : "en"}
            onClick={handleChangeLanguage}
          >
            {language == "en" ? "ar" : "en"}
          </LanguageButton>
          <AppsContainer onClick={handleMenuClick}>
            <AppsRoundedIcon style={{ color: "#9c9c9c" }} />
          </AppsContainer>
          <NameText>{username}</NameText>
          <AvatarConatiner>
            <Avatar
              style={{ height: "35px", width: "35px" }}
              {...stringAvatar(username ? username : "No User")}
            />
          </AvatarConatiner>
          <ArrowContainer>
            <KeyboardArrowDownIcon
              style={{ fontSize: "30px" }}
              onClick={handleClick}
            />
          </ArrowContainer>
        </RightContainer>
        <Menu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          onClick={handleClose}
          PaperProps={{
            elevation: 0,
            sx: {
              overflow: "visible",
              filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
              mt: 1.5,
              "& .MuiAvatar-root": {
                width: 32,
                height: 32,
                ml: -0.5,
                mr: 1,
              },
              "&:before": {
                content: '""',
                display: "block",
                position: "absolute",
                top: 0,
                right: 14,
                width: 10,
                height: 10,
                bgcolor: "background.paper",
                transform: "translateY(-50%) rotate(45deg)",
                zIndex: 0,
              },
            },
          }}
          transformOrigin={{ horizontal: "right", vertical: "top" }}
          anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
        >
          <MenuItem onClick={() => handleLogout()}>Logout</MenuItem>
        </Menu>
        <AppMenu
          handleClick={handleMenuClick}
          handleMenuClose={handleMenuClose}
          anchorEl={anchorMenuEl}
          open={openMenu}
        />
      </Container>
    );
  }
};

export default Header;

const LanguageButton = styled(Button)`
  && {
    color: #000;
    border: 1px solid #f3f3f3;
    margin-right: 10px;
  }
`;

const ArrowContainer = styled.div`
  border: 2px solid #d2dae9;
  border-radius: 50px;
  display: flex;
`;

const AvatarConatiner = styled.div`
  margin: 0 10px;
  font-size: 10px;
`;

const Container = styled.div`
  height: 60px;
  background: #fff;
  border-bottom: 1px solid #ccc;
  padding: 10px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
`;

const LeftContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  width: 50%;
  align-items: center;
`;
const RightContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  width: 50%;
  align-items: center;
  svg {
    color: #3d3d3d;
    font-size: 25px;
    cursor: pointer;
  }
`;

const NameText = styled.p`
  margin: auto 0;
  font-weight: bold;
  font-size: 14px;
`;

const LogoContainer = styled.div`
  font-family: "Abril Fatface" !important;
  font-size: 35px;
  padding: 0 10px;
  & span {
    color: #a00bb5;
  }
`;
const AppsContainer = styled.div`
  margin-right: 10px;
  background: #f3f3f3;
  display: flex;
  align-items: center;
  border-radius: 50px;
  padding: 5px;
`;

// link

export function BackgroundLetterAvatars() {
  return (
    <Stack direction="row" spacing={2}>
      <Avatar {...stringAvatar("Kent Dodds")} />
      <Avatar {...stringAvatar("Jed Watson")} />
      <Avatar {...stringAvatar("Tim Neutkens")} />
    </Stack>
  );
}
