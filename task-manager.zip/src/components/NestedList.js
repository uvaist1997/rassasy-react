import React, { useEffect } from "react";
import Select, { components } from "react-select";
import styled from "styled-components/macro";
import { Collapse } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import TextField from "@mui/material/TextField";

const NestedList = (props) => {
  const [filter, setFilter] = React.useState(null);
  const [selectedDate, handleDateChange] = React.useState(new Date());
  const handleHeaderClick = (id) => {
    const node = document.querySelector(`#${id}`).parentElement
      .nextElementSibling;
    const classes = node.classList;
    // console.log(classes.contains("collapsed"));
    
    if (classes.contains("collapsed")) {
      node.classList.remove("collapsed");
      node.style.display = "block";
      // node.style.display = "none";
    } else {
      node.classList.add("collapsed");
      // node.style.display = "block";
      node.style.display = "none";
    }
  };

  const CustomGroupHeading = (props) => {
    return (
      <GroupDiv
        className="group-heading-wrapper"
        onClick={() => handleHeaderClick(props.id)}
      >
          <components.GroupHeading {...props} />
      </GroupDiv>
    );
  };

  const CustomeGroup = (props) => {
    return (
      <GroupDiv
        className="group-heading-wrapper"
        // onClick={() => handleHeaderClick(props.id)}
      >
        {props.label === "Due Date" ? (
          [
            <DateLabel>DUE DATE</DateLabel>,
            <DueDate
              type="date"
              value={selectedDate}
              onChange={(e)=> handleDateChange(e.target.value)}
            />,
          ]
        ) : (
          <components.Group {...props} />
        )}
      </GroupDiv>
    );
  };



  useEffect(() => {
    if (filter) {
      props.setState((prevState) => {
        return {
          ...prevState,
          get_list: true,
          ProjectFilter: filter,
        };
      });
    }
  }, [filter]);

   useEffect(() => {
     if (selectedDate) {
       props.setState((prevState) => {
         return {
           ...prevState,
           get_list: true,
           FilterDate: selectedDate,
         };
       });
     }
   }, [selectedDate]);

  const selectedFilter = (e) => {
    setFilter(e);
  }

  const statusOptions = [
    { value: "completed", label: "Completed", name: "status" },
    { value: "progress", label: "Progress", name: "status" },
    { value: "todo", label: "Todo", name: "status" },
  ];

  const priorityOptions = [
    { value: "high", label: "High", name: "priority" },
    { value: "medium", label: "Medium", name: "priority" },
    { value: "low", label: "Low", name: "priority" },
  ];

    const dueDateOptions = [
      { value: "high", label: "High", name: "dueDate" },
    ];

  const groupedOptions = [
    {
      label: "Status",
      options: statusOptions,
    },
    {
      label: "Priority",
      options: priorityOptions,
    },
    {
      label: "Due Date",
      options: dueDateOptions,
    },
  ];

 
  return (
    <MainContainer className="container">
      <Select
        options={groupedOptions}
        isMulti
        blurInputOnSelect={false}
        closeMenuOnSelect={false}
        components={{
          GroupHeading: CustomGroupHeading,
          Group: CustomeGroup,
        }}
        onChange={(e)=>selectedFilter(e)}
        formatOptionLabel={(option, context) => {
          return (
            <React.Fragment>
              <label>{option.label}</label>
              {/* <Collapse in={open} timeout="auto" unmountOnExit>
                <input type="checkbox" />
                <label>{option.label}</label>
              </Collapse> */}
            </React.Fragment>
          );
        }}
      />
    </MainContainer>
  );
};

export default NestedList;

const MainContainer = styled.div`
  margin: auto;
  width: 200px;
`;

const DateDiv = styled.div``

const GroupDiv = styled.div`
  &.collapsed{
    display: none;
  }
`;

const DateLabel = styled.p`
  font-size: 75%;
  margin-left: 12px;
  color: #999;
  font-weight: 500;
  text-transform: uppercase;
`;

const DueDate = styled.input`
  width: 100%;
  appearance: none;
  -webkit-appearance: none;
  color: #95a5a6;
  font-family: "Helvetica", arial, sans-serif;
  font-size: 14px;
  border: 1px solid #ecf0f1;
  background: #ecf0f1;
  padding: 5px;
  display: inline-block !important;
  visibility: visible !important;
`;