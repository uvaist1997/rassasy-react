// import "./loader.scss"

const Loader = () => <span className='Loader' />

export default Loader
