import React, { useEffect, useState } from "react";
import { styled as styles } from "@mui/material/styles";
import ArrowForwardIosSharpIcon from "@mui/icons-material/ArrowForwardIosSharp";
import MuiAccordion from "@mui/material/Accordion";
import MuiAccordionSummary from "@mui/material/AccordionSummary";
import MuiAccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import styled from "styled-components";
import Checkbox from "@mui/material/Checkbox";
import { FormControlLabel } from "@mui/material";

const Accordion = styles((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
  "&:not(:last-child)": {
    borderBottom: 0,
  },
  "&:before": {
    display: "none",
  },
}));

const AccordionSummary = styles((props) => (
  <MuiAccordionSummary
    expandIcon={<StyledArrowForwardIosSharpIcon sx={{ fontSize: "0.9rem" }} />}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiAccordionSummary-expandIconWrapper.Mui-expanded": {
    transform: "rotate(90deg)",
  },
  "& .MuiAccordionSummary-content": {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styles(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
}));

export default function DayOfWeek({
  state,
  setState,
  month,
  year,
  setWeekDialog,
}) {
  const [expanded, setExpanded] = useState("");

  const handleExpand = (panel) => {
    if (expanded === panel) {
      setExpanded(false);
    } else {
      setExpanded(panel);
    }
  };

  const handleWeek = (e) => {
    const { name, checked } = e.target;
    if (name === "isMonday") {
      setState({
        ...state,
        [name]: checked,
        isFirstMonday: checked,
        isSecondMonday: checked,
        isThirdMonday: checked,
        isFourthMonday: checked,
        isFifthMonday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("monday");
      } else {
        handleDayWiseHoliday("monday", "unmark");
      }
    }
    if (name === "isTuesday") {
      setState({
        ...state,
        [name]: checked,
        isFirstTuesday: checked,
        isSecondTuesday: checked,
        isThirdTuesday: checked,
        isFourthTuesday: checked,
        isFifthTuesday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("tuesday");
      } else {
        handleDayWiseHoliday("tuesday", "unmark");
      }
    }
    if (name === "isWednesday") {
      setState({
        ...state,
        [name]: checked,
        isFirstWednesday: checked,
        isSecondWednesday: checked,
        isThirdWednesday: checked,
        isFourthWednesday: checked,
        isFifthWednesday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("wednesday");
      } else {
        handleDayWiseHoliday("wednesday", "unmark");
      }
    }
    if (name === "isThursday") {
      setState({
        ...state,
        [name]: checked,
        isFirstThursday: checked,
        isSecondThursday: checked,
        isThirdThursday: checked,
        isFourthThursday: checked,
        isFifthThursday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("thursday");
      } else {
        handleDayWiseHoliday("thursday", "unmark");
      }
    }
    if (name === "isFriday") {
      setState({
        ...state,
        [name]: checked,
        isFirstFriday: checked,
        isSecondFriday: checked,
        isThirdFriday: checked,
        isFourthFriday: checked,
        isFifthFriday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("friday");
      } else {
        handleDayWiseHoliday("friday", "unmark");
      }
    }
    if (name === "isSaturday") {
      setState({
        ...state,
        [name]: checked,
        isFirstSaturday: checked,
        isSecondSaturday: checked,
        isThirdSaturday: checked,
        isFourthSaturday: checked,
        isFifthSaturday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("saturday");
      } else {
        handleDayWiseHoliday("saturday", "unmark");
      }
    }
    if (name === "isSunday") {
      setState({
        ...state,
        [name]: checked,
        isFirstSunday: checked,
        isSecondSunday: checked,
        isThirdSunday: checked,
        isFourthSunday: checked,
        isFifthSunday: checked,
      });
      if (checked) {
        handleDayWiseHoliday("sunday");
      } else {
        handleDayWiseHoliday("sunday", "unmark");
      }
    }
    if (checked) {
      setWeekDialog(true);
    }
    // setState({ ...state });
  };

  const handleSubWeek = (e) => {
    const { name, checked } = e.target;

    const monday = [
      "isFirstMonday",
      "isSecondMonday",
      "isThirdMonday",
      "isFourthMonday",
      "isFifthMonday",
    ];

    const tuesday = [
      "isFirstTuesday",
      "isSecondTuesday",
      "isThirdTuesday",
      "isFourthTuesday",
      "isFifthTuesday",
    ];

    const wednesday = [
      "isFirstWednesday",
      "isSecondWednesday",
      "isThirdWednesday",
      "isFourthWednesday",
      "isFifthWednesday",
    ];

    const thursday = [
      "isFirstThursday",
      "isSecondThursday",
      "isThirdThursday",
      "isFourthThursday",
      "isFifthThursday",
    ];

    const friday = [
      "isFirstFriday",
      "isSecondFriday",
      "isThirdFriday",
      "isFourthFriday",
      "isFifthFriday",
    ];

    const saturday = [
      "isFirstSaturday",
      "isSecondSaturday",
      "isThirdSaturday",
      "isFourthSaturday",
      "isFifthSaturday",
    ];

    const sunday = [
      "isFirstSunday",
      "isSecondSunday",
      "isThirdSunday",
      "isFourthSunday",
      "isFifthSunday",
    ];
    // monday
    if (monday.includes(name)) {
      const newState = {};
      for (let m = 0; m < monday.length; m++) {
        newState[monday[m]] = state[monday[m]];
      }
      newState[name] = checked;

      if (monday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isMonday: true });
      } else {
        setState({ ...state, [name]: checked, isMonday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // tuesday
    if (tuesday.includes(name)) {
      const newState = {};
      for (let m = 0; m < tuesday.length; m++) {
        newState[tuesday[m]] = state[tuesday[m]];
      }
      newState[name] = checked;

      if (tuesday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isTuesday: true });
      } else {
        setState({ ...state, [name]: checked, isTuesday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // wednesday
    if (wednesday.includes(name)) {
      const newState = {};
      for (let m = 0; m < wednesday.length; m++) {
        newState[wednesday[m]] = state[wednesday[m]];
      }
      newState[name] = checked;

      if (wednesday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isWednesday: true });
      } else {
        setState({ ...state, [name]: checked, isWednesday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // thursday
    if (thursday.includes(name)) {
      const newState = {};
      for (let m = 0; m < thursday.length; m++) {
        newState[thursday[m]] = state[thursday[m]];
      }
      newState[name] = checked;

      if (thursday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isThursday: true });
      } else {
        setState({ ...state, [name]: checked, isThursday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // friday
    if (friday.includes(name)) {
      const newState = {};
      for (let m = 0; m < friday.length; m++) {
        newState[friday[m]] = state[friday[m]];
      }
      newState[name] = checked;

      if (friday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isFriday: true });
      } else {
        setState({ ...state, [name]: checked, isFriday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // saturday
    if (saturday.includes(name)) {
      const newState = {};
      for (let m = 0; m < saturday.length; m++) {
        newState[saturday[m]] = state[saturday[m]];
      }
      newState[name] = checked;

      if (saturday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isSaturday: true });
      } else {
        setState({ ...state, [name]: checked, isSaturday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    // sunday
    if (sunday.includes(name)) {
      const newState = {};
      for (let m = 0; m < sunday.length; m++) {
        newState[sunday[m]] = state[sunday[m]];
      }
      newState[name] = checked;

      if (sunday.filter((i) => newState[i] === false).length === 0) {
        setState({ ...state, [name]: checked, isSunday: true });
      } else {
        setState({ ...state, [name]: checked, isSunday: false });
      }
      if (checked) {
        handleDayWiseHoliday(name);
      } else {
        handleDayWiseHoliday(name, "unmark");
      }
    }
    if (checked) {
      setWeekDialog(true);
    }
  };

  function dayTypeInMonth(m, y, day = "sunday") {
    var getTot = new Date(y, m + 1, 0).getDate();

    var dayType = [];

    for (var i = 1; i <= getTot; i++) {
      var newDate = new Date(y, m, i);

      if (day === "sunday") {
        if (newDate.getDay() === 0) {
          dayType.push(i);
        }
      }
      if (day === "monday") {
        if (newDate.getDay() === 1) {
          dayType.push(i);
        }
      }
      if (day === "tuesday") {
        if (newDate.getDay() === 2) {
          dayType.push(i);
        }
      }
      if (day === "wednesday") {
        if (newDate.getDay() === 3) {
          dayType.push(i);
        }
      }
      if (day === "thursday") {
        if (newDate.getDay() === 4) {
          dayType.push(i);
        }
      }
      if (day === "friday") {
        if (newDate.getDay() === 5) {
          dayType.push(i);
        }
      }

      if (day === "saturday") {
        if (newDate.getDay() === 6) {
          dayType.push(i);
        }
      }
    }

    return dayType;
  }

  const handleDayWiseHoliday = (day = "sunday", mark = "mark") => {
    console.log(day);
    let event = [...state.event];
    let holidayArr = [];
    console.log(day);
    let verifiedDay = day;
    if (day.toLowerCase().includes("sunday")) {
      verifiedDay = "sunday";
    }
    if (day.toLowerCase().includes("monday")) {
      verifiedDay = "monday";
    }
    if (day.toLowerCase().includes("tuesday")) {
      verifiedDay = "tuesday";
    }
    if (day.toLowerCase().includes("wednesday")) {
      verifiedDay = "wednesday";
    }
    if (day.toLowerCase().includes("thursday")) {
      verifiedDay = "thursday";
    }
    if (day.toLowerCase().includes("friday")) {
      verifiedDay = "friday";
    }
    if (day.toLowerCase().includes("saturday")) {
      verifiedDay = "saturday";
    }
    for (let k = 0; k < 12; k++) {
      let holidays = dayTypeInMonth(k, year.getFullYear(), verifiedDay);
      console.log(holidays);
      let startLength = 0;
      let stopLength = holidays.length;
      if (
        day === "isFirstMonday" ||
        day === "isFirstTuesday" ||
        day === "isFirstWednesday" ||
        day === "isFirstThursday" ||
        day === "isFirstFriday" ||
        day === "isFirstSaturday" ||
        day === "isFirstSunday"
      ) {
        startLength = 0;
        stopLength = 1;
      }
      if (
        day === "isSecondMonday" ||
        day === "isSecondTuesday" ||
        day === "isSecondWednesday" ||
        day === "isSecondThursday" ||
        day === "isSecondFriday" ||
        day === "isSecondSaturday" ||
        day === "isSecondSunday"
      ) {
        startLength = 1;
        stopLength = 2;
      }
      if (
        day === "isThirdMonday" ||
        day === "isThirdTuesday" ||
        day === "isThirdWednesday" ||
        day === "isThirdThursday" ||
        day === "isThirdFriday" ||
        day === "isThirdSaturday" ||
        day === "isThirdSunday"
      ) {
        startLength = 2;
        stopLength = 3;
      }
      if (
        day === "isFourthMonday" ||
        day === "isFourthTuesday" ||
        day === "isFourthWednesday" ||
        day === "isFourthThursday" ||
        day === "isFourthFriday" ||
        day === "isFourthSaturday" ||
        day === "isFourthSunday"
      ) {
        startLength = 3;
        stopLength = 4;
      }
      if (
        day === "isFifthMonday" ||
        day === "isFifthTuesday" ||
        day === "isFifthWednesday" ||
        day === "isFifthThursday" ||
        day === "isFifthFriday" ||
        day === "isFifthSaturday" ||
        day === "isFifthSunday"
      ) {
        startLength = 4;
        stopLength = 5;
      }
      for (let i = startLength; i < stopLength; i++) {
        let stateDate = event.filter(
          (j) =>
            j.date.getFullYear() === year.getFullYear() &&
            j.date.getMonth() === k &&
            j.date.getDate() === holidays[i]
        );
        if (mark === "mark") {
          if (stateDate.length > 0) {
            let eventIndex = event.findIndex(
              (i) =>
                i.date.getFullYear() === stateDate[0].date.getFullYear() &&
                i.date.getMonth() === stateDate[0].date.getMonth() &&
                i.date.getDate() === stateDate[0].date.getDate()
            );
            event[eventIndex] = {
              date: new Date(year.getFullYear(), k, holidays[i]),
              note: stateDate[0].note,
              isHoliday: true,
            };
          } else {
            console.log(isNaN(new Date(year.getFullYear(), k, holidays[i])));
            if (!isNaN(new Date(year.getFullYear(), k, holidays[i]))) {
              holidayArr.push({
                date: new Date(year.getFullYear(), k, holidays[i]),
                note: "",
                isHoliday: true,
              });
            }
          }
        } else if (mark === "unmark") {
          if (stateDate.length > 0) {
            let eventIndex = event.findIndex(
              (i) =>
                i.date.getFullYear() === stateDate[0].date.getFullYear() &&
                i.date.getMonth() === stateDate[0].date.getMonth() &&
                i.date.getDate() === stateDate[0].date.getDate()
            );
            event[eventIndex] = {
              date: new Date(year.getFullYear(), k, holidays[i]),
              note: stateDate[0].note,
              isHoliday: false,
            };
          } else {
            holidayArr.push({
              date: new Date(year.getFullYear(), k, holidays[i]),
              note: "",
              isHoliday: false,
            });
          }
        }
      }
    }

    setState((state) => ({
      ...state,
      event: [...event, ...holidayArr],
    }));
  };

  const accordionData = [
    {
      accordionName: "panel1",
      name: "isMonday",
      label: "Monday",
      checked: state.isMonday,
      days: [
        {
          name: "isFirstMonday",
          label: "1st Monday",
          checked: state.isFirstMonday,
        },
        {
          name: "isSecondMonday",
          label: "2st Monday",
          checked: state.isSecondMonday,
        },
        {
          name: "isThirdMonday",
          label: "3rd Monday",
          checked: state.isThirdMonday,
        },
        {
          name: "isFourthMonday",
          label: "4rd Monday",
          checked: state.isFourthMonday,
        },
        {
          name: "isFifthMonday",
          label: "5rd Monday",
          checked: state.isFifthMonday,
        },
      ],
    },
    {
      accordionName: "panel2",
      name: "isTuesday",
      label: "Tuesday",
      checked: state.isTuesday,
      days: [
        {
          name: "isFirstTuesday",
          label: "1st Tuesday",
          checked: state.isFirstTuesday,
        },
        {
          name: "isSecondTuesday",
          label: "2st Tuesday",
          checked: state.isSecondTuesday,
        },
        {
          name: "isThirdTuesday",
          label: "3rd Tuesday",
          checked: state.isThirdTuesday,
        },
        {
          name: "isFourthTuesday",
          label: "4rd Tuesday",
          checked: state.isFourthTuesday,
        },
        {
          name: "isFifthTuesday",
          label: "5rd Tuesday",
          checked: state.isFifthTuesday,
        },
      ],
    },
    {
      accordionName: "panel3",
      name: "isWednesday",
      label: "Wednesday",
      checked: state.isWednesday,
      days: [
        {
          name: "isFirstWednesday",
          label: "1st Wednesday",
          checked: state.isFirstWednesday,
        },
        {
          name: "isSecondWednesday",
          label: "2st Wednesday",
          checked: state.isSecondWednesday,
        },
        {
          name: "isThirdWednesday",
          label: "3rd Wednesday",
          checked: state.isThirdWednesday,
        },
        {
          name: "isFourthWednesday",
          label: "4rd Wednesday",
          checked: state.isFourthWednesday,
        },
        {
          name: "isFifthWednesday",
          label: "5rd Wednesday",
          checked: state.isFifthWednesday,
        },
      ],
    },
    {
      accordionName: "panel4",
      name: "isThursday",
      label: "Thursday",
      checked: state.isThursday,
      days: [
        {
          name: "isFirstThursday",
          label: "1st Thursday",
          checked: state.isFirstThursday,
        },
        {
          name: "isSecondThursday",
          label: "2st Thursday",
          checked: state.isSecondThursday,
        },
        {
          name: "isThirdThursday",
          label: "3rd Thursday",
          checked: state.isThirdThursday,
        },
        {
          name: "isFourthThursday",
          label: "4rd Thursday",
          checked: state.isFourthThursday,
        },
        {
          name: "isFifthThursday",
          label: "5rd Thursday",
          checked: state.isFifthThursday,
        },
      ],
    },
    {
      accordionName: "panel5",
      name: "isFriday",
      label: "Friday",
      checked: state.isFriday,
      days: [
        {
          name: "isFirstFriday",
          label: "1st Friday",
          checked: state.isFirstFriday,
        },
        {
          name: "isSecondFriday",
          label: "2st Friday",
          checked: state.isSecondFriday,
        },
        {
          name: "isThirdFriday",
          label: "3rd Friday",
          checked: state.isThirdFriday,
        },
        {
          name: "isFourthFriday",
          label: "4rd Friday",
          checked: state.isFourthFriday,
        },
        {
          name: "isFifthFriday",
          label: "5rd Friday",
          checked: state.isFifthFriday,
        },
      ],
    },
    {
      accordionName: "panel6",
      name: "isSaturday",
      label: "Saturday",
      checked: state.isSaturday,
      days: [
        {
          name: "isFirstSaturday",
          label: "1st Saturday",
          checked: state.isFirstSaturday,
        },
        {
          name: "isSecondSaturday",
          label: "2st Saturday",
          checked: state.isSecondSaturday,
        },
        {
          name: "isThirdSaturday",
          label: "3rd Saturday",
          checked: state.isThirdSaturday,
        },
        {
          name: "isFourthSaturday",
          label: "4rd Saturday",
          checked: state.isFourthSaturday,
        },
        {
          name: "isFifthSaturday",
          label: "5rd Saturday",
          checked: state.isFifthSaturday,
        },
      ],
    },
    {
      accordionName: "panel7",
      name: "isSunday",
      label: "Sunday",
      checked: state.isSunday,
      days: [
        {
          name: "isFirstSunday",
          label: "1st Sunday",
          checked: state.isFirstSunday,
        },
        {
          name: "isSecondSunday",
          label: "2st Sunday",
          checked: state.isSecondSunday,
        },
        {
          name: "isThirdSunday",
          label: "3rd Sunday",
          checked: state.isThirdSunday,
        },
        {
          name: "isFourthSunday",
          label: "4rd Sunday",
          checked: state.isFourthSunday,
        },
        {
          name: "isFifthSunday",
          label: "5rd Sunday",
          checked: state.isFifthSunday,
        },
      ],
    },
  ];
  console.log(state);
  return (
    <Container>
      {accordionData.map((i) => (
        <Accordion expanded={expanded === i.accordionName}>
          <AccordionSummary
            aria-controls="panel1d-content"
            id="panel1d-header"
            expandIcon={
              <StyledArrowForwardIosSharpIcon
                sx={{ fontSize: "0.9rem" }}
                onClick={() => handleExpand(i.accordionName)}
              />
            }
          >
            <Typography>
              <FormControlLabel
                control={
                  <StyledCheckbox
                    checked={
                      i.days.filter((k) => k.checked === false).length === 0
                    }
                    indeterminate={
                      i.days.filter((k) => k.checked === true).length < 5 &&
                      i.days.filter((k) => k.checked === true).length > 0
                    }
                    onChange={(e) => handleWeek(e)}
                    size="small"
                  />
                }
                name={i.name}
                label={i.label}
              />
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              {i.days.map((j) => (
                <FormControlLabel
                  control={
                    <StyledCheckbox
                      onChange={(e) => handleSubWeek(e)}
                      size="small"
                      className="padding"
                    />
                  }
                  checked={j.checked}
                  name={j.name}
                  label={j.label}
                />
              ))}
            </Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </Container>
  );
}

const Container = styled.div`
  width: 200px;
  border-radius: 5px;
  .MuiPaper-root.MuiPaper-elevation.MuiPaper-elevation0.MuiAccordion-root {
    border-radius: inherit;
  }
  .MuiAccordionSummary-content {
    margin-top: 0;
    margin-bottom: 0;
  }
`;

const StyledCheckbox = styled(Checkbox)`
  &&.MuiCheckbox-root.MuiCheckbox-colorPrimary.MuiButtonBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.PrivateSwitchBase-root {
    padding: 0 !important;
    margin-right: 5px;
  }
  &&.MuiCheckbox-root.MuiCheckbox-colorPrimary.MuiButtonBase-root.MuiCheckbox-root.MuiCheckbox-colorPrimary.PrivateSwitchBase-root.padding {
    margin-left: 30px !important;
    margin-right: 5px;
  }
  &&.MuiCheckbox-indeterminate {
    color: #000;
  }
`;
const StyledArrowForwardIosSharpIcon = styled(ArrowForwardIosSharpIcon)`
  && {
    width: 25px;
    height: 25px;
    padding: 5px;
    box-sizing: border-box;
  }
`;
