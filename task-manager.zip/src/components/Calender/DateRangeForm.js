import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import styled from "styled-components";
import Draggable from "react-draggable";
import _ from "lodash";
import { getDateDifference } from "../../functions/utils";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 350,
  bgcolor: "background.paper",
  border: "1px solid #c7e6ec",
  boxShadow: 24,
  p: "15px",
  borderRadius: "3px",
};

export default function DateRangeForm({
  showModal,
  setModal,
  state,
  setState,
}) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setState({ ...state, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    let event = [...state.event];
    let dateArr = [];
    if (state.fromDate.length && state.toDate.length) {
      const dateDifference = getDateDifference(
        new Date(state.fromDate),
        new Date(state.toDate)
      );
      let fromDate = new Date(state.fromDate);
      let toDate = new Date(state.toDate);
      for (var i = 0; i <= dateDifference; i++) {
        dateArr.push({
          date: new Date(
            fromDate.getFullYear(),
            fromDate.getMonth(),
            fromDate.getDate()
          ),
          note: state.note || "",
          isHoliday: true,
        });
        fromDate.setDate(fromDate.getDate() + 1);
      }

      var result = dateArr.concat(state.event).filter(function (o) {
        return this[o.date] ? false : (this[o.date] = true);
      }, {});
      setState({ ...state, event: result });
      setModal(false);
    }
  };
  return (
    <Container>
      <StyledModal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={showModal}
        onClose={() => setModal(false)}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={showModal}>
          <Box sx={style}>
            <Heading>Date Range</Heading>
            <Form onChange={handleChange} onSubmit={handleSubmit}>
              <InputBottomContainer>
                <InputContainer className="bottom">
                  <InputGroup>
                    <Label>Note</Label>
                    <TextArea name="note" type="textarea"></TextArea>
                  </InputGroup>
                </InputContainer>

                <InputContainer className="bottom">
                  <InputGroup className="bottom">
                    <Label>From</Label>
                    <Input name="fromDate" type="date" />
                  </InputGroup>
                  <InputGroup className="bottom">
                    <Label>To</Label>
                    <Input name="toDate" type="date" />
                  </InputGroup>
                </InputContainer>

                <StyledButton variant="contained" type="submit">
                  Add Holiday
                </StyledButton>
              </InputBottomContainer>
            </Form>
          </Box>
        </Fade>
      </StyledModal>
    </Container>
  );
}
const TextArea = styled.textarea`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 200px;
  min-height: 90px;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const StyledButton = styled(Button)`
  &&,
  &&:hover {
    width: 100%;
    background: #1d39a4;
    text-transform: capitalize;
    font-family: "Poppins";
    margin-top: 10px;
    border-radius: 50px;
  }
  &&:hover {
    opacity: 0.9;
  }
`;
const StyledModal = styled(Modal)``;
const Container = styled.div``;
const Heading = styled.p`
  margin: 0;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
  color: #2344a0;
`;
const Form = styled.form``;
const InputGroup = styled.div`
  width: 100%;
  &.bottom {
    width: 47%;
  }
`;
const InputTopContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
`;
const InputLabelContainer = styled.div`
  margin-bottom: 10px;
`;
const Label = styled.p`
  width: 100%;
  margin: 0;
  font-size: 12px;
`;
const Input = styled.input`
  background: whitesmoke;
  padding: 7px;
  border-radius: 2px;
  border: 2px solid transparent;
  outline: 1px solid #ccc !important;
  transition: all 0.2s ease-in;
  outline: none;
  width: 100%;
  box-sizing: border-box;
  &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  }
`;
const ImageContainer = styled.div`
  margin-right: 15px;
`;
const InputContainer = styled.div`
  display: flex;
  margin-bottom: 10px;
  width: 100%;
  &.bottom {
    justify-content: space-between;
  }
`;
const InputBottomContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 20px;
`;
