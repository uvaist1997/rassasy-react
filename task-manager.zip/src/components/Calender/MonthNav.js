import React, { useEffect, useRef, useState } from "react";
import styled from "styled-components/macro";
import MobileDatePicker from "@mui/lab/MobileDatePicker";
import { ButtonBase, TextField, Tooltip } from "@mui/material";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import AdapterDateFns from "@mui/lab/AdapterDateFns";

const MonthNav = ({ setMonth, month }) => {
  let dateRef = useRef(null);

  const changeDate = (dateType) => {
    if (dateType === "increment") {
      setMonth(new Date(month.setMonth(month.getMonth() + 1)));
    } else {
      setMonth(new Date(month.setMonth(month.getMonth() - 1)));
    }
  };

  const handleDateChange = () => {
    dateRef.current.click();
  };

  const getFormatedDate = () => {
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    const d = new Date(month);
    console.log("return  :", monthNames[d.getMonth()]);
    return monthNames[d.getMonth()];
  };

  const handleChange = (newValue) => {
    setMonth(newValue);
  };
  return (
    <Container>
      <CalandarSelect>
        <Tooltip title={"Previous Month"}>
          <ButtonBase style={{ borderRadius: "50%" }}>
            <NavButton onClick={() => changeDate("decrement")}></NavButton>
          </ButtonBase>
        </Tooltip>
        <DateText onClick={() => handleDateChange()}>
          {getFormatedDate()}
        </DateText>
        <DateInputContainer>
          <LocalizationProvider dateAdapter={AdapterDateFns}>
            <StyledMobileDatePicker
              inputRef={dateRef}
              //   label="Date mobile"
              inputFormat="dd/MM/yyyy"
              value={month}
              onChange={handleChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </DateInputContainer>
        <Tooltip title={"Next Month"}>
          <ButtonBase style={{ borderRadius: "50%" }}>
            <NavButton
              className="right"
              onClick={() => changeDate("increment")}
            ></NavButton>
          </ButtonBase>
        </Tooltip>
      </CalandarSelect>
    </Container>
  );
};

export default MonthNav;

const Container = styled.div``;
const CalandarSelect = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;
const NavButton = styled.div`
  width: 35px;
  height: 35px;
  border-radius: 50%;
  background: #000;
  position: relative;
  transition: all 0.2s ease-in;
  &:hover {
    cursor: pointer;
    background: #6e6e6e;
    transition: all 0.2s ease-in;
  }
  &:after {
    content: "";
    width: 8px;
    height: 8px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: -3px;
    margin: auto;
    border-right: 2px solid #fff;
    border-bottom: 2px solid #fff;
    transform: rotate(135deg);
    border-radius: 1px;
  }
  &.right:after {
    transform: rotate(315deg);
    right: 3px;
  }
`;
const DateText = styled.p`
  margin: 0 5px;
  padding: 23px 0;
  width: 100px;
  text-align: center;
  user-select: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  -ms-user-select: none;
  font-weight: bold;
  max-width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  &:hover {
    cursor: pointer;
  }
`;
const StyledMobileDatePicker = styled(MobileDatePicker)``;

const DateInputContainer = styled.div`
  display: none;
`;
