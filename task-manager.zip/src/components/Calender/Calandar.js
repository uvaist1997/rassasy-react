import React, { useEffect, useState } from "react";
import styled from "styled-components";
import EditIcon from "@mui/icons-material/Edit";
import { grey } from "@mui/material/colors";
import { Button, Divider, Menu } from "@mui/material";

const Calandar = ({ month, year, changeKey, parentState, setParentState }) => {
  function dayTypeInMonth(m, y, day = "sunday") {
    var getTot = new Date(y, m + 1, 0).getDate();

    var dayType = [];

    for (var i = 1; i <= getTot; i++) {
      var newDate = new Date(y, m, i);

      if (day === "sunday") {
        if (newDate.getDay() === 0) {
          dayType.push(i);
        }
      }
      if (day === "monday") {
        if (newDate.getDay() === 1) {
          dayType.push(i);
        }
      }
      if (day === "tuesday") {
        if (newDate.getDay() === 2) {
          dayType.push(i);
        }
      }
      if (day === "wednesday") {
        if (newDate.getDay() === 3) {
          dayType.push(i);
        }
      }
      if (day === "thursday") {
        if (newDate.getDay() === 4) {
          dayType.push(i);
        }
      }
      if (day === "friday") {
        if (newDate.getDay() === 5) {
          dayType.push(i);
        }
      }

      if (day === "saturday") {
        if (newDate.getDay() === 6) {
          dayType.push(i);
        }
      }
    }

    return dayType;
  }

  // note menu
  const employeeID = 1;
  const [anchorEl, setAnchorEl] = useState(null);
  const [NoteEl, setNoteEl] = useState(null);
  const open = Boolean(anchorEl);
  const openNote = Boolean(NoteEl);

  const handleClick = (event, date) => {
    setAnchorEl(event.currentTarget);
    setState({ ...state, dateInstance: date });
  };

  const handleNotePreview = (event, date) => {
    let note = parentState.event.filter(
      (i) =>
        i.date.getFullYear() === year.getFullYear() &&
        i.date.getMonth() === month.getMonth() &&
        i.date.getDate() === date.getDate()
    )[0].note;

    setState({ ...state, dateInstance: date, note: note });
    setNoteEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handlePreviewClose = () => {
    setNoteEl(null);
  };

  const handleNoteDelete = (e, date) => {
    e.preventDefault();
    handlePreviewClose();

    const eventInstance = parentState.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = parentState.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...parentState.event];

    if (isDateExists) {
      eventInstances[eventInstanceIndex] = {
        ...eventInstances[eventInstanceIndex],
        note: "",
        date: date,
      };

      setParentState({
        ...parentState,
        event: eventInstances,
      });
    } else {
      setParentState({
        ...parentState,
        event: [
          ...parentState.event,
          {
            ...eventInstances[eventInstanceIndex],
            note: "",
            date: date,
          },
        ],
      });
    }
  };

  const handleNoteSubmit = (e, date) => {
    e.preventDefault();
    handleClose();
    handlePreviewClose();

    const eventInstance = parentState.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = parentState.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...parentState.event];

    if (isDateExists) {
      eventInstances[eventInstanceIndex] = {
        ...eventInstances[eventInstanceIndex],
        note: parentState.note,
        isHoliday: eventInstances[eventInstanceIndex].isHoliday,
        date: date,
      };

      setParentState({
        ...parentState,
        event: eventInstances,
      });
    } else {
      setParentState({
        ...parentState,
        event: [
          ...parentState.event,
          {
            note: parentState.note,
            isHoliday: false,
            date: date,
          },
        ],
      });
    }
  };

  const handleHoliday = (date) => {
    const eventInstance = parentState.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = parentState.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...parentState.event];

    if (isDateExists) {
      eventInstances[eventInstanceIndex] = {
        ...eventInstances[eventInstanceIndex],
        note: eventInstances[eventInstanceIndex].note || "",
        isHoliday: !eventInstances[eventInstanceIndex].isHoliday,
        date: date,
      };

      setParentState({
        ...parentState,
        event: eventInstances,
      });
    } else {
      setParentState({
        ...parentState,
        event: [
          ...parentState.event,
          {
            note: "",
            isHoliday: true,
            date: date,
          },
        ],
      });
    }
  };
  const handleDayWiseHoliday = (day, mark = "mark") => {
    let event = [...parentState.event];
    let holidays = dayTypeInMonth(month.getMonth(), year.getFullYear(), day);
    let holidayArr = [];
    for (let i = 0; i < holidays.length; i++) {
      let stateDate = event.filter(
        (j) =>
          j.date.getFullYear() === year.getFullYear() &&
          j.date.getMonth() === month.getMonth() &&
          j.date.getDate() === holidays[i]
      );
      if (mark === "mark") {
        if (stateDate.length > 0) {
          let eventIndex = event.findIndex(
            (i) =>
              i.date.getFullYear() === stateDate[0].date.getFullYear() &&
              i.date.getMonth() === stateDate[0].date.getMonth() &&
              i.date.getDate() === stateDate[0].date.getDate()
          );
          event[eventIndex] = {
            date: new Date(year.getFullYear(), month.getMonth(), holidays[i]),
            note: stateDate[0].note,
            isHoliday: true,
          };
        } else {
          holidayArr.push({
            date: new Date(year.getFullYear(), month.getMonth(), holidays[i]),
            note: "",
            isHoliday: true,
          });
        }
      } else {
        if (stateDate.length > 0) {
          let eventIndex = event.findIndex(
            (i) =>
              i.date.getFullYear() === stateDate[0].date.getFullYear() &&
              i.date.getMonth() === stateDate[0].date.getMonth() &&
              i.date.getDate() === stateDate[0].date.getDate()
          );
          event[eventIndex] = {
            date: new Date(year.getFullYear(), month.getMonth(), holidays[i]),
            note: stateDate[0].note,
            isHoliday: false,
          };
        } else {
          holidayArr.push({
            date: new Date(year.getFullYear(), month.getMonth(), holidays[i]),
            note: "",
            isHoliday: false,
          });
        }
      }
    }

    setParentState({
      ...parentState,
      event: [...event, ...holidayArr],
    });
  };

  const checkDateInState = (day) => {
    if (parentState.event) {
      let stateDate = [];
      let holidays = dayTypeInMonth(month.getMonth(), year.getFullYear(), day);
      for (let i = 0; i < holidays.length; i++) {
        let dateFilter = parentState.event.filter(
          (j) =>
            j.date.getFullYear() === year.getFullYear() &&
            j.date.getMonth() === month.getMonth() &&
            j.date.getDate() === holidays[i] &&
            j.isHoliday
        );
        if (dateFilter.length > 0) {
          stateDate.push(dateFilter[0]);
        }
      }

      if (stateDate.length === holidays.length) {
        return true;
      }
    }
    return false;
  };

  // note menu ends

  let today = new Date();
  const [state, setState] = useState({
    monthAndYear: "",
    currentMonth: today.getMonth(),
    currentYear: today.getFullYear(),
    isToday: [{ isDay: true, date: "" }],
    tbl: [],
    event: [],
    loading: true,
  });
  const handleChange = (e, date) => {
    const eventInstance = parentState.event.filter(
      (i) => String(i.date) === String(date)
    );
    const isDateExists = eventInstance.length > 0;
    const eventInstanceIndex = parentState.event.findIndex((i) => {
      return String(i.date) === String(date);
    });
    let eventInstances = [...parentState.event];
    if (e.target.name === "status") {
      if (isDateExists) {
        eventInstances[eventInstanceIndex] = {
          ...eventInstances[eventInstanceIndex],
          id: employeeID,
          status: e.target.value,
          date: date,
        };

        setParentState({
          ...parentState,
          event: eventInstances,
        });
      } else {
        setParentState({
          ...parentState,
          event: [
            ...parentState.event,
            {
              ...eventInstances[eventInstanceIndex],
              id: employeeID,
              note: "",
              status: e.target.value,
              date: date,
            },
          ],
        });
      }
    } else if (e.target.name === "note") {
      setParentState({
        ...parentState,
        note: e.target.value,
      });
    }
  };

  let months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  useEffect(() => {
    showCalendar(month.getMonth(), year.getFullYear());
  }, [changeKey]);

  const next = () => {
    let currentYear =
      month.getMonth() === 11 ? year.getFullYear() + 1 : year.getFullYear();
    let currentMonth = (month.getMonth() + 1) % 12;

    setState((prev) => ({
      ...prev,
      currentYear,
      currentMonth,
    }));
    showCalendar(currentMonth, currentYear);
  };

  const previous = () => {
    let currentYear =
      month.getMonth() === 0 ? year.getFullYear() - 1 : year.getFullYear();
    let currentMonth = month.getMonth() === 0 ? 11 : month.getMonth() - 1;
    setState((prev) => ({
      ...prev,
      currentYear,
      currentMonth,
    }));
    showCalendar(currentMonth, currentYear);
  };

  const showCalendar = (month, year) => {
    let firstDay = new Date(year, month).getDay();
    let daysInMonth = 32 - new Date(year, month, 32).getDate();
    let tbl = [];
    // filing data about month and in the page via DOM.
    setState((prev) => ({
      ...prev,
      monthAndYear: months[month] + " " + year,
    }));

    // creating all cells
    let date = 1;
    for (let i = 0; i < 6; i++) {
      // creates a table row
      let row = [];

      //creating individual cells, filing them up with data.
      for (let j = 0; j < 7; j++) {
        if (i === 0 && j < firstDay) {
          row.push("");
        } else if (date > daysInMonth) {
          break;
        } else {
          row.push(date);
          date++;
        }
      }
      tbl.push(row); // appending each row into calendar body.
    }
    if (tbl[tbl.length - 1].length === 0) {
      while (tbl[tbl.length - 2].length < 7) {
        tbl[tbl.length - 2].push("");
      }
    } else {
      while (tbl[tbl.length - 1].length < 7) {
        tbl[tbl.length - 1].push("");
      }
    }

    setState((prev) => ({ ...prev, tbl }));
  };

  const filterInstance = (arr, value) =>
    arr.filter((i) => String(i.date) === String(value));

  // const findInstanceIndex = (arr, value) =>
  //   arr.findIndex((i) => String(i.date) === String(value));

  return (
    <Container>
      {/* <h3 className="card-header" id="monthAndYear">
        {state.monthAndYear}
      </h3> */}
      <table className="table table-bordered table-responsive-sm" id="calendar">
        <thead>
          <tr>
            <th>Sun</th>
            <th>Mon</th>
            <th>Tue</th>
            <th>Wed</th>
            <th>Thu</th>
            <th>Fri</th>
            <th>Sat</th>
          </tr>
        </thead>

        <tbody id="calendar-body">
          {state.tbl.map((i, indexi) => (
            <tr key={indexi}>
              {i.map((j, indexj) => (
                <TD
                  onClick={() =>
                    console.log(
                      new Date(year.getFullYear(), month.getMonth(), j)
                    )
                  }
                  key={indexj}
                  today={
                    j === today.getDate() &&
                    year.getFullYear() === today.getFullYear() &&
                    month.getMonth() === today.getMonth()
                  }
                  sunday={indexj % 7 === 0}
                >
                  <p className="date">{j}</p>
                  {j && (
                    <>
                      <p className="month-year">{state.monthAndYear}</p>

                      <CircleContainer>
                        <span></span>
                        <span></span>
                        <span></span>
                      </CircleContainer>
                    </>
                  )}
                </TD>
              ))}
            </tr>
          ))}
        </tbody>
      </table>

      <div className="form-inline" style={{ display: "none" }}>
        <button
          className="btn btn-outline-primary col-sm-6"
          id="previous"
          onClick={previous}
        >
          Previous
        </button>

        <button
          className="btn btn-outline-primary col-sm-6"
          id="next"
          onClick={next}
        >
          Next
        </button>
      </div>
      <NoteBox
        handleNoteSubmit={handleNoteSubmit}
        state={state}
        parentState={parentState}
        setState={setState}
        setParentState={setParentState}
        anchorEl={anchorEl}
        setAnchorEl={setAnchorEl}
        open={open}
        handleClick={handleClick}
        handleClose={handleClose}
        handleChange={handleChange}
      />
      <NotePreview
        handleNoteSubmit={handleNoteSubmit}
        handleNoteDelete={handleNoteDelete}
        parentState={parentState}
        state={state}
        setState={setState}
        setParentState={setParentState}
        NoteEl={NoteEl}
        setNoteEl={setNoteEl}
        openNote={openNote}
        handleNotePreview={handleNotePreview}
        handlePreviewClose={handlePreviewClose}
        handleChange={handleChange}
      />
    </Container>
  );
};

const CircleContainer = styled.div`
  display: flex;
  gap: 5px;
  margin-top: 35px;
  span {
    border-radius: 50%;
    width: 10px;
    height: 10px;
  }
  span:nth-child(2) {
    background-color: green;
  }
  span:nth-child(1) {
    background-color: red;
  }
  span:nth-child(3) {
    background-color: yellow;
  }
`;

const StyledButton = styled(Button)`
  && {
    text-transform: capitalize;
    color: #000;
    background: whitesmoke;
    width: 100%;
    ${({ isHoliday }) =>
      isHoliday &&
      `
    background: #e43f3f;
    color:#fff;
  `}
  }
  && {
    ${({ today }) => today && `  color:#000 !important;`}
    ${({ isHoliday }) =>
      isHoliday &&
      `
    background: #e43f3f;
    color:#fff;
    &:hover{
      color:#000;
    }
  `}
  }
`;

const Container = styled.div`
  table {
    width: 100%;
    border-collapse: collapse;
  }
  td {
    padding: 5px 10px 0px 10px;
    cursor: pointer;
    height: 15vh;
  }
  th {
    font-size: 20px;
    text-transform: uppercase;
    min-width: 14%;
    max-width: 14%;
    width: 14%;
    letter-spacing: 5px;
  }
  td {
    border: 2px solid #e6e6e6;
  }
  td p.date {
    font-weight: bold;
    font-size: 20px;
    margin: 0;
    /* margin-bottom: 2px; */
  }
  td p.month-year {
    font-size: 12px;
    margin: 0;
    color: #727272;
  }
`;
const TD = styled.td`
  transition: all 0.2s ease-in;
  ${({ today }) =>
    today &&
    `
        & p.date{color:#000;  !important}
        background:#ABC4FF;
 
         & p.month-year {
            color: #6D6D6D !important;
        }
        button{
            color:#fff !important;
        }
        svg{
            color:#fff !important;
        }
        svg[data-testid="ArrowDropDownIcon"]{
            color:#000 !important;
        }
    `}

  &:hover {
    background: whitesmoke;
    transition: all 0.2s ease-in;
    color: black;
    & p.month-year {
      color: #000 !important;
    }
    & p.date {
      color: #000;
    }
    & button {
      color: #000 !important;
    }
    svg {
      color: #000 !important;
    }
  }
`;
const IconContainer = styled.div`
  width: 25px;
  height: 25px;
  border-radius: 3px;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: all 0.2s ease-in;
  &:hover {
    background: #f9c401;
    transition: all 0.2s ease-in;
    color: #fff !important;
    svg {
      color: #fff;
    }
  }
`;
const NoteButton = styled.button`
  display: flex;
  align-items: flex-end;
  color: #2a88a9;
  font-weight: bold;
  border: 0;
  background: transparent;
  cursor: pointer;
  margin: 5px 0 15px 0;

  max-width: 100%;
  border-radius: 3px;
  padding: 4px 7px;
  width: 167px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  transition: all 0.2s ease-in;
  &.active {
    display: block;
    background: #f9c401;
    color: #4c4c4c !important;
  }
  &:hover {
    background: #f9c401;
    color: #000 !important;
    transition: all 0.2s ease-in;
    svg {
      color: #000 !important;
    }
  }
`;

export default Calandar;

// option

const ITEM_HEIGHT = 48;

function NoteBox({
  anchorEl,
  setAnchorEl,
  open,
  handleClick,
  handleClose,
  state,
  setState,
  handleChange,
  date,
  handleNoteSubmit,
}) {
  return (
    <div>
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: -0.9,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="note"
          type="textarea"
          onChange={(e) => handleChange(e, state.dateInstance)}
        ></TextArea>
        <Divider />
        <NoteSubmitButton
          onClick={(e) => handleNoteSubmit(e, state.dateInstance)}
        >
          Add Note
        </NoteSubmitButton>
      </StyledMenu>
    </div>
  );
}
// options ends
const TextArea = styled.textarea`
  padding: 7px;
  border-radius: 10px;
  /* border: 2px solid transparent; */
  border: 0;
  /* outline: 1px solid #ccc !important; */
  outline: none;
  width: 100%;
  max-width: 100%;
  min-width: 100%;
  max-height: 150px;
  min-height: 100px;
  box-sizing: border-box;
  /* &:hover,
  &:focus {
    border: 2px solid #000;
    transition: all 0.2s ease-in;
  } */
  &::-webkit-scrollbar {
    display: none;
  }
`;
const StyledMenu = styled(Menu)`
  && ul {
    display: flex;
    flex-direction: column;
    padding: 0;
  }
`;
const NoteSubmitButton = styled(Button)`
  && {
    text-transform: capitalize;
    font-size: 10px;
  }
  &&.delete {
    background: #ff3e3e;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
  &&.edit {
    background: #3fac93;
    color: #fff;
    width: 50%;
    border-radius: 0;
  }
`;

function NotePreview({
  NoteEl,
  setNoteEl,
  openNote,
  handleNotePreview,
  handlePreviewClose,
  state,
  setState,
  parentState,
  handleChange,
  date,
  handleNoteSubmit,
  handleNoteDelete,
}) {
  return (
    <div>
      <StyledMenu
        id="long-menu"
        MenuListProps={{
          "aria-labelledby": "long-button",
        }}
        anchorEl={NoteEl}
        open={openNote}
        onClose={handlePreviewClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "15ch",
          },
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            ml: -0.9,

            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 70,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <TextArea
          name="note"
          type="textarea"
          defaultValue={state.note}
          onChange={(e) => handleChange(e, state.dateInstance)}
        ></TextArea>
        <Divider />
        <NoteButtonContainer>
          <NoteSubmitButton
            className="edit"
            onClick={(e) => handleNoteSubmit(e, state.dateInstance)}
          >
            Edit
          </NoteSubmitButton>
          <NoteSubmitButton
            className="delete"
            onClick={(e) => handleNoteDelete(e, state.dateInstance)}
          >
            Delete
          </NoteSubmitButton>
        </NoteButtonContainer>
      </StyledMenu>
    </div>
  );
}
const NoteButtonContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;
