import * as React from "react";
import Backdrop from "@mui/material/Backdrop";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import styled from "styled-components/macro";
import TextField from "@mui/material/TextField";
import {
  alpha,
  Autocomplete,
  Avatar,
  FormControl,
  InputLabel,
  LinearProgress,
  linearProgressClasses,
  Menu,
  MenuItem,
  Select,
} from "@mui/material";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import { stringAvatar } from "../../functions/utils";
import { styled as styles } from "@mui/material/styles";
import EditIcon from "@mui/icons-material/Edit";
import { PAYROLL_FRONT_URL, VIKNBOOKS_FRONT_URL } from "../../settings";

const StyledMenu = styles((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    border: "1px solid #e2e2e2",
    borderRadius: 2,
    marginTop: theme.spacing(1),
    minWidth: 200,
    padding: 10,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

export default function AppMenu({
  handleClick,
  handleMenuClose,
  anchorEl,
  open,
}) {
  const handleMenuClick = (page) => {
    if (page == "viknbooks") {
      window.open(`${VIKNBOOKS_FRONT_URL}dashboard/home`, "_self");
    } else if (page == "payroll") {
      window.open(`${PAYROLL_FRONT_URL}dashboard`, "_self");
    }
  };
  return (
    <div>
      <StyledMenu
        id="demo-customized-menu"
        MenuListProps={{
          "aria-labelledby": "demo-customized-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleMenuClose}
      >
        <Container>
          <AppContainer
            onClick={() => {
              handleMenuClick("viknbooks");
            }}
          >
            <AppLogo src="./images/app-logos/viknbooks.svg" />
            <AppName>Viknbooks</AppName>
          </AppContainer>
          <AppContainer
            onClick={() => {
              handleMenuClick("payroll");
            }}
          >
            <AppLogo src="./images/app-logos/payroll.svg" />
            <AppName>Payroll</AppName>
          </AppContainer>
        </Container>
      </StyledMenu>
    </div>
  );
}

const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 5px;
`;

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  height: 80px;
  width: 80px;
  justify-content: center;
  border-radius: 2px;
  transition: all ease-in-out 0.1s;
  &:hover {
    background: #ccc;
  }
`;
const AppLogo = styled.img`
  width: 40px;
  height: 40px;
`;
const AppName = styled.p``;

const MenuHeading = styled.p`
  font-weight: bold;
  font-size: 16px;
`;

const MenuLabel = styled.p`
  color: #8f8f8f;
`;
const MenuButtonContainer = styled.div`
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
`;

const StyledButton = styled(Button)`
  && {
    border-radius: 2px;
    padding: 3px 10px;
    text-transform: capitalize;
    font-size: 12px;
  }
  &&.m {
    margin-right: 5px;
  }
  &&.edit {
    color: #12368c;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
    margin-right: 15px;
  }
  &&.delete {
    color: #7b0000;
    justify-content: left;
    padding: 0;
    min-width: fit-content;
  }
  &&.create {
    color: #fff;

    background: #12368c;
    &:hover {
      background: #5073c7;
    }
  }
  &&.cancel {
    color: #000;
  }
  &&.attach {
    color: #000;
    background: #d8d8d8 0% 0% no-repeat padding-box;
  }
  && svg {
    transform: rotate(45deg);
    font-size: 18px;
    margin-right: 10px;
  }
  && svg.arrow {
    transform: rotate(90deg);
    font-size: 18px;
    margin-left: 10px;
    margin-right: 0;
  }
`;
