import React, { createContext, useState } from "react";

export const DataContext = createContext();

function Context1({ children }) {
  const [showPopup, setShowPopup] = useState(false);
  const [showList, setShowList] = useState(false);
  const [notificationCount, setNotificationCount] = useState({
    project_notify: 0,
    task_notify: 0,
  });
  return (
    <DataContext.Provider
      value={{
        showMemberList: [showPopup, setShowPopup],
        showTeamList: [showList, setShowList],
        showNotificationCount: [notificationCount, setNotificationCount],
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export default Context1;
