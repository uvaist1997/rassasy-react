import React from "react";
import styled from "styled-components";

const Button = ({ text, color, background, type, onClick, fullWidth }) => {
  return (
    <Container
      fullWidth={fullWidth}
      color={color}
      background={background}
      type={type}
      onClick={onClick}
    >
      {text}
    </Container>
  );
};

export default Button;

const Container = styled.button`
  cursor: pointer;
  border: 0;
  outline: none;
  padding: 10px 20px;
  border-radius: 3px;
  color: ${({ color }) => color};
  background: ${({ background }) => background};
  width: ${({ fullWidth }) => fullWidth && "100%"};
`;
