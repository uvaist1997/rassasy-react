import * as base from "../settings";

export const projectListUrl = base.BASE_URL + "projects/list-project";
export const projectCreateUrl = base.BASE_URL + "projects/create-project";
export const projectEditUrl = base.BASE_URL + "projects/edit-project/";
export const projectDeleteUrl = base.BASE_URL + "projects/delete-project/";
export const projectCommentsUrl = base.BASE_URL + "projects/project-comments";
export const projectProgressUrl = base.BASE_URL + "projects/update-progress";
