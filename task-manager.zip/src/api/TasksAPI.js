import * as base from "../settings";

export const taskListUrl = base.BASE_URL + "tasks/list-task";
export const taskCreateUrl = base.BASE_URL + "tasks/create-task";
export const taskEditUrl = base.BASE_URL + "tasks/edit/task/";
export const taskViewUrl = base.BASE_URL + "tasks/view/task/";
export const taskDeleteUrl = base.BASE_URL + "tasks/delete/task/";
export const taskUpadteStatusPriorityUrl =
  base.BASE_URL + "tasks/update-status-priority/";
