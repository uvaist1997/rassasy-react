import { useEffect } from "react";
import { projectCommentsUrl } from "../api/ProjectsAPI";

export const ProjectComments = async (
  ProjectID,
  TaskID,
  comment,
  type,
  access,
  unq_id
) => {
  const commentResponse = await fetch(projectCommentsUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
      accept: "application/json",
    },
    body: JSON.stringify({
      ProjectID: ProjectID,
      TaskID: TaskID,
      comment: comment,
      type: type,
      unq_id: unq_id,
    }),
  }).then((response) => response.json());
  return commentResponse.data;
};
