import axios from "axios";
import { ACCOUNTS_API_URL, domain } from "../settings";
import { Decrypt, Encrypt, getCookie } from "./utils";
const _ = require("lodash");

export const set_RecentLoginUsersCookies = async (data) => {
  let ciphertext = Encrypt(data);
  console.log(ciphertext, "(((((((((((************))))))))))))))))");
  // =======END=============
  let return_value = false;
  await axios
    .get(
      `${ACCOUNTS_API_URL}api/v1/accounts/recent-login-users?data=${ciphertext}`,
      {
        withCredentials: true,
      }
    )
    .then(() => {
      const params = new Proxy(new URLSearchParams(window.location.search), {
        get: (searchParams, prop) => searchParams.get(prop),
      });
      let value = params.service;
      // window.location.reload();
      return_value = true;
    });
  return return_value;
};

export const set_handleLogout = async (dic) => {
  document.cookie = `VBID=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;domain=${domain}`;

  // ==================RECENT USERS==================
  let recent_login_users = getCookie("ACCOUNT_CHOOSER");

  // let dic = {
  //   username: username,
  //   email: email,
  //   image_url:
  //     "https://www.api.viknbooks.com/media/profiles/Screenshot_from_2022-02-02_11-45-23.png",
  // };
  let data = [];
  let data_exists = {};
  if (recent_login_users) {
    console.log(data, "###datadata============");
    try {
      data = Decrypt(JSON.parse(recent_login_users));
    } catch (err) {
      data = Decrypt(recent_login_users);
    }
    data_exists = _.find(data, function (o) {
      return o.username == dic["username"];
    });
  }

  if (_.isEmpty(data_exists)) {
    data.push(dic);
    console.log("^^^^^IFFF^^^^^^^^^^^&*");
  } else {
    console.log("^^^^^ELSE^^^^^^^^^^^&*");
  }

  data = data.slice(-2);
  let return_value = await set_RecentLoginUsersCookies(data);

  // if (recent_login_users) {
  //   data = JSON.parse(data);
  // }
  return return_value;
};
