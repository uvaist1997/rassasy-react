import { useEffect } from "react";
import { ACCOUNTS_API_URL, BASE_URL } from "../settings";

export function checkWordLength(word) {
  let str = new String(word);
  let length = str.length;
  if (length > 13) {
    return true;
  }
  return false;
}

function useOutsideAlerter(ref) {
  useEffect(() => {
    function handleClickOutside(event) {
      if (ref.current && !ref.current.contains(event.target)) {
        console.log(false);
        // alert("You clicked outside of me!");
      }
      return false;
    }
  }, [ref]);
}

export function stringCamelCase(string) {
  var split_string = string.split(" ");

  let final_arr = [];
  let final_name = "";

  for (let index = 0; index < split_string.length; index++) {
    const element = split_string[index];
    let name = element.charAt(0).toUpperCase() + element.slice(1);
    console.log(name);
    if (final_name) {
      final_name += " " + String(name);
    } else {
      final_name = String(name);
    }
    final_arr.push(final_name);
  }
  var lastItem = final_arr.pop();

  return lastItem;
}
// truncate number of words by passing the paragraph and number
export function truncate(str, num = 12) {
  if (str.length > num) {
    return str.slice(0, num) + "...";
  } else {
    return str;
  }
}
// to check the list of values is present in the array
export const listChecker = (arr, target) =>
  target.every((v) => arr.includes(v));

export const getInitials = function (string) {
  var names = string.split(" "),
    initials = names[0].substring(0, 1).toUpperCase();

  if (names.length > 1) {
    initials += names[names.length - 1].substring(0, 1).toUpperCase();
  }
  return initials;
};

// to get index value from a array by passing array by passing the list of values and number
export const get_index = (list, id) => {
  let index = null;
  if (list) {
    // index = list.findIndex((i) => console.log(i.id, "FIXING BUG", id));
    index = list.findIndex((i) => i.id === id);
  }
  return index;
};
export const get_Userindex = (list, id) => {
  let index = null;
  if (list) {
    // index = list.findIndex((i) => console.log(i.UserID));
    index = list.findIndex((i) => i.UserID === id);
  }
  console.log(index, "||||||||||||||||||||");

  return index;
};

export const get_priceCategory_index = (list, id) => {
  let index = null;
  if (list) {
    index = list.findIndex((i) => i.PriceCategoryID === id);
  }
  return index;
};

// convert datetime object to python date string
export const formatDate = (date) => {
  var d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-");
};

export const findDuplicate = (array1, array2) => {
  var duplicates = array1.filter((val) => array2.indexOf(val) !== -1);
  return duplicates;
};

// just pass the id to show the password
export const showPassword = (id) => {
  var x = document.getElementById(id);
  console.log(x);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
};

/**
 * Display a base64 URL inside an iframe in another window.
 */
// View base64URL
export function debugBase64(base64URL) {
  var win = window.open();
  win.document.write(
    '<iframe src="' +
      base64URL +
      '" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>'
  );
}
// Download base64URL
export function Dowunload_debugBase64(base64URL, name) {
  console.log(base64URL);
  const downloadLink = document.createElement("a");

  downloadLink.href = base64URL;
  downloadLink.download = name;
  downloadLink.click();
}
// download Excel
export function download(url) {
  var element = window.document.createElement("a");
  element.href = url;
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}
// date to string(today)
export function today_date() {
  var today = new Date();
  today.setDate(today.getDate());
  var Today = today.toISOString().substr(0, 10);
  return Today;
}

export function get_date(dateObj) {
  var month = dateObj.toLocaleString("default", { month: "2-digit" });
  var day = dateObj.getUTCDate();
  var year = dateObj.getUTCFullYear();
  if (month.length < 2) month = "0" + month;

  if (day.toString().length < 2) day = "0" + day;
  return [year, month, day].join("-");
}

export function string_to_datetime(string) {
  var datetime_obj = new Date(string);
  return datetime_obj;
}

export function today_datetime() {
  var today = new Date();
  return today;
}

export function date_time_diff_in_mint(date1, date2) {
  var diffMs = date2 - date1;
  var diffMins = Math.floor(diffMs / 60000);
  let result = convert_minutes(diffMins);
  return result;
}

export function convert_minutes(minutes) {
  var val = minutes;
  var val_end = "minutes ago";
  if (Number(minutes) >= 43800) {
    val_end = "months ago";
    val = Number(minutes) / 43800;
  } else if (Number(minutes) >= 10080) {
    val_end = "weeks ago";
    val = Number(minutes) / 10080;
  } else if (Number(minutes) >= 1440) {
    val_end = "days ago";
    val = Number(minutes) / 1440;
  } else if (Number(minutes) >= 60) {
    val_end = "hours ago";
    val = Number(minutes) / 60;
  }
  let result = String(Number(val).toFixed(0)) + " " + String(val_end);
  return result;
}

// to get age pass date of birth
export const getAge = (dateString) => {
  var today = new Date();
  var birthDate = new Date(dateString);
  var age = today.getFullYear() - birthDate.getFullYear();
  var m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
};
// to get avatar images just pass a value you will get a random image
export const getAvatar = (value = "1", imageType = "identicon", res = 46) => {
  const hashCode = (s) =>
    s.split("").reduce((a, b) => {
      a = (a << 5) - a + b.charCodeAt(0);
      return Math.abs(a & a);
    }, 0);

  // Create an hash of the string
  const hash = hashCode(value);
  // Grab the actual image URL

  // return `https://avatars.dicebear.com/api/${imageType}/${hash}.svg`;
  return `https://www.gravatar.com/avatar/${hash}?s=${res}&d=${imageType}&r=PG&f=1`;
};

export const get_Transaction_index = (list, id) => {
  let index = null;
  if (list) {
    index = list.findIndex((i) => i.TransactionTypesID === id);
  }
  return index;
};

// check image exists
export const imageExists = (image_url) => {
  var http = new XMLHttpRequest();

  http.open("HEAD", image_url, false);
  http.send();

  return http.status != 404;
};

// export const convert_url_to_file = (MY_URL) => {
//   var request = new XMLHttpRequest();
//   request.open("GET", MY_URL, true);
//   request.responseType = "blob";
//   request.onload = function () {
//     var reader = new FileReader();
//     reader.readAsDataURL(request.response);
//     reader.onload = function (e) {
//       console.log("DataURL:", e.target.result);
//     };
//   };
//   return request.send();
// };

export const convert_url_to_file = async (file1) => {
  console.log(file1);
  let image = BASE_URL + file1.DocFile;
  const response = await fetch(image);
  // here image is url/location of image
  const blob = await response.blob();
  const file = new File([blob], file1.name, { type: "image/jpeg" });
  console.log(file);
  return file;
};

export const convert_url_to_blob = (MY_URL) => {
  fetch(MY_URL)
    .then((res) => res.blob()) // Gets the response and returns it as a blob
    .then((blob) => {
      let objectURL = URL.createObjectURL(blob);
      let myImage = new Image();
      myImage.src = objectURL;
      // document.getElementById("myImg").appendChild(myImage);
      return objectURL;
    });
};

export const dataURLtoFile = async (dataurl) => {
  let filename = dataurl.substring(
    dataurl.lastIndexOf("/") + 1,
    dataurl.length
  );

  let response = await fetch(dataurl);
  console.log(response);
  let data = await response.blob();
  let metadata = {
    type: "image/jpeg",
  };
  let fileobj = new File([data], filename, metadata);
  let file = [
    {
      originFileObj: fileobj,
      uid: "1",
      name: filename,
      url: dataurl,
    },
  ];
  return file;
};

// get date n days ahead date react js hook
export const addDays = (date, days) => {
  var result = new Date(date);
  result.setDate(result.getDate() + days);
  let Year = result.getFullYear();
  let Month = result.getMonth() + 1;
  let Day = result.getDate();
  Day = ("0" + Day).slice(-2);
  Month = ("0" + Month).slice(-2);
  result = String(Year) + "-" + String(Month) + "-" + String(Day);
  return result;
};

export const get_fileName_fromPath = (file) => {
  return file.split("\\").pop().split("/").pop();
};

export const stringAvatar = (name) => {
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: `${name.split(" ")[0][0]}${
      name.split(" ")[1] ? name.split(" ")[1][0] : ""
    }`,
  };
};

function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}

export const getCookie = (name) => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop().split(";").shift();
};

export const get_username = async (UserID) => {
  console.log(">>>>>>>>>>>>>>>>>>>>>>242");
  const access = getCookie("VBID");
  const userNameResponse = await fetch(
    `${ACCOUNTS_API_URL}api/v1/users/get-username/`,
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${access}`,
        accept: "application/json",
      },
      body: JSON.stringify({
        UserID: UserID,
      }),
    }
  ).then((response) => response.json());
  let username = "";
  if (userNameResponse.StatusCode === 6000) {
    username = userNameResponse.username;
  }
  return username;
};

export const fileDownload = (fileURL) => {
  fetch("https://cors-anywhere.herokuapp.com/" + fileURL, {
    method: "GET",
    headers: {
      "Content-Type": "image/png",
    },
  })
    .then((response) => response.blob())
    .then((blob) => {
      // Create blob link to download
      const url = window.URL.createObjectURL(new Blob([blob]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `FileName.png`);

      // Append to html link element page
      document.body.appendChild(link);

      // Start download
      link.click();

      // Clean up and remove the link
      link.parentNode.removeChild(link);
    });
  return "";
};
// ***Here is the code for converting "image source" (url) to "Base64".***

export const toDataURL = (url) =>
  fetch(url)
    .then((response) => response.blob())
    .then(
      (blob) =>
        new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        })
    );

// ***Here is code for converting "Base64" to javascript "File Object".***

export const URLtoFile = (dataurl, filename) => {
  console.log(dataurl, filename, "URLtoFile");
  var arr = dataurl.split(","),
    mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]),
    n = bstr.length,
    u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
};

export const getDateDifference = (fromDate, toDate) => {
  const diffTime = Math.abs(fromDate - toDate);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  // console.log(diffTime + " milliseconds");
  // console.log(diffDays + " days");
  return diffDays;
};
// convert datetime object to python date string
export const date_monthName_format = (date) => {
  date = new Date(date);
  var month = date.toLocaleString("default", { month: "long" });
  var day = date.getUTCDate();
  var year = date.getUTCFullYear();
  let result = String(day) + " " + String(month) + " " + String(year);
  return result;
};

export const get_color_due_date = (date) => {
  date = new Date(date);
  var today = new Date();
  let color = "blue";
  if (date < today) {
    color = "red";
  }
  return color;
};
export function Encrypt(word, key = "share") {
  var CryptoJS = require("crypto-js");
  let encJson = CryptoJS.AES.encrypt(JSON.stringify(word), key).toString();
  let encData = CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(encJson));
  return encData;
}
export function Decrypt(word, key = "share") {
  var CryptoJS = require("crypto-js");
  let decData = CryptoJS.enc.Base64.parse(word).toString(CryptoJS.enc.Utf8);
  let bytes = CryptoJS.AES.decrypt(decData, key).toString(CryptoJS.enc.Utf8);
  return JSON.parse(bytes);
}
