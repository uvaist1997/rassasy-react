import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { Provider } from "react-redux";
import store from "./store/store";
import { I18nextProvider } from "react-i18next";
import i18next from "i18next";
import common_ar from "./translations/ar/common.json";
import common_en from "./translations/en/common.json";
import Context1 from "./components/Context1";

const { language } = store.getState();

i18next.init({
  interpolation: { escapeValue: false }, // React already does escaping
  lng: language.language,
  resources: {
    en: {
      common: common_en, // 'common' is our custom namespace
    },
    ar: {
      common: common_ar,
    },
  },
});

// ReactDOM.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>,
//   document.getElementById("root")
// );
const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <I18nextProvider i18n={i18next}>
    <Provider store={store}>
      <Context1>
        <App />
      </Context1>
    </Provider>
  </I18nextProvider>

  // document.getElementById("root")
);
